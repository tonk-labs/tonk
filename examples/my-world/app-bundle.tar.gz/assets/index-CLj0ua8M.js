var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __privateWrapper = (obj, member, setter, getter) => ({
  set _(value) {
    __privateSet(obj, member, value, setter);
  },
  get _() {
    return __privateGet(obj, member, getter);
  }
});
import { r as Mv, a as Dv, R as Ku, g as Tf, b as ue, B as Uv } from "./vendor-Bv_yOIeQ.js";
import { v as Yy, a as Gy, p as zv, s as kv, f as Bv, e as Hv, i as ao, g as rn, d as Lv, c as qv, b as Yv, m as Gv, l as Vv, h as Xv, j as Vy, k as Xy, n as Fy, o as Fv, q as Qv, r as Zv, t as Kv, u as _m, w as $v, __tla as __tla_0 } from "./automerge-B_oyMRht.js";
Promise.all([
  (() => {
    try {
      return __tla_0;
    } catch {
    }
  })()
]).then(async () => {
  var _t, _e, _n, _a, _i, _e2_instances, s_get, r_get, l_fn, o_fn, _t2, _e2, _n2, _a2, _i2, _s, _u2_instances, r_fn, l_fn2, _t3, _e3, _n3, _a3, _i3, _s2, _r, _t4, _e4, _n4, _a4, _i4, _T2_instances, s_fn, r_fn2, l_fn3, o_fn2, _t5, _e5, _n5, _a5, _i5, _s3, _r2, _l, _o, _O2_instances, y_fn, p_fn, g_fn, u_fn, b_fn, v_fn, f_fn, d_fn, h_fn, c_fn, m_fn, _t6, _e6, _n6, _C2_instances, a_fn, i_fn, s_fn2, _t7, _e7, _n7, _a6, _i6, __2_instances, s_fn3, _r3, l_fn4, o_fn3, _t8, _e8, _n8, _ME_instances, a_fn2;
  (function() {
    const a = document.createElement("link").relList;
    if (a && a.supports && a.supports("modulepreload")) return;
    for (const c of document.querySelectorAll('link[rel="modulepreload"]')) r(c);
    new MutationObserver((c) => {
      for (const f of c) if (f.type === "childList") for (const d of f.addedNodes) d.tagName === "LINK" && d.rel === "modulepreload" && r(d);
    }).observe(document, {
      childList: true,
      subtree: true
    });
    function l(c) {
      const f = {};
      return c.integrity && (f.integrity = c.integrity), c.referrerPolicy && (f.referrerPolicy = c.referrerPolicy), c.crossOrigin === "use-credentials" ? f.credentials = "include" : c.crossOrigin === "anonymous" ? f.credentials = "omit" : f.credentials = "same-origin", f;
    }
    function r(c) {
      if (c.ep) return;
      c.ep = true;
      const f = l(c);
      fetch(c.href, f);
    }
  })();
  var xu = {
    exports: {}
  }, el = {};
  var Nm;
  function Jv() {
    if (Nm) return el;
    Nm = 1;
    var i = Symbol.for("react.transitional.element"), a = Symbol.for("react.fragment");
    function l(r, c, f) {
      var d = null;
      if (f !== void 0 && (d = "" + f), c.key !== void 0 && (d = "" + c.key), "key" in c) {
        f = {};
        for (var h in c) h !== "key" && (f[h] = c[h]);
      } else f = c;
      return c = f.ref, {
        $$typeof: i,
        type: r,
        key: d,
        ref: c !== void 0 ? c : null,
        props: f
      };
    }
    return el.Fragment = a, el.jsx = l, el.jsxs = l, el;
  }
  var Rm;
  function Iv() {
    return Rm || (Rm = 1, xu.exports = Jv()), xu.exports;
  }
  var E = Iv(), Su = {
    exports: {}
  }, tl = {}, wu = {
    exports: {}
  }, Eu = {};
  var jm;
  function Wv() {
    return jm || (jm = 1, function(i) {
      function a(R, k) {
        var J = R.length;
        R.push(k);
        e: for (; 0 < J; ) {
          var ne = J - 1 >>> 1, te = R[ne];
          if (0 < c(te, k)) R[ne] = k, R[J] = te, J = ne;
          else break e;
        }
      }
      function l(R) {
        return R.length === 0 ? null : R[0];
      }
      function r(R) {
        if (R.length === 0) return null;
        var k = R[0], J = R.pop();
        if (J !== k) {
          R[0] = J;
          e: for (var ne = 0, te = R.length, de = te >>> 1; ne < de; ) {
            var me = 2 * (ne + 1) - 1, gt = R[me], Ee = me + 1, bt = R[Ee];
            if (0 > c(gt, J)) Ee < te && 0 > c(bt, gt) ? (R[ne] = bt, R[Ee] = J, ne = Ee) : (R[ne] = gt, R[me] = J, ne = me);
            else if (Ee < te && 0 > c(bt, J)) R[ne] = bt, R[Ee] = J, ne = Ee;
            else break e;
          }
        }
        return k;
      }
      function c(R, k) {
        var J = R.sortIndex - k.sortIndex;
        return J !== 0 ? J : R.id - k.id;
      }
      if (i.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
        var f = performance;
        i.unstable_now = function() {
          return f.now();
        };
      } else {
        var d = Date, h = d.now();
        i.unstable_now = function() {
          return d.now() - h;
        };
      }
      var g = [], y = [], p = 1, b = null, S = 3, x = false, v = false, A = false, j = typeof setTimeout == "function" ? setTimeout : null, L = typeof clearTimeout == "function" ? clearTimeout : null, B = typeof setImmediate < "u" ? setImmediate : null;
      function D(R) {
        for (var k = l(y); k !== null; ) {
          if (k.callback === null) r(y);
          else if (k.startTime <= R) r(y), k.sortIndex = k.expirationTime, a(g, k);
          else break;
          k = l(y);
        }
      }
      function I(R) {
        if (A = false, D(R), !v) if (l(g) !== null) v = true, Q();
        else {
          var k = l(y);
          k !== null && Y(I, k.startTime - R);
        }
      }
      var ee = false, ae = -1, be = 5, le = -1;
      function W() {
        return !(i.unstable_now() - le < be);
      }
      function P() {
        if (ee) {
          var R = i.unstable_now();
          le = R;
          var k = true;
          try {
            e: {
              v = false, A && (A = false, L(ae), ae = -1), x = true;
              var J = S;
              try {
                t: {
                  for (D(R), b = l(g); b !== null && !(b.expirationTime > R && W()); ) {
                    var ne = b.callback;
                    if (typeof ne == "function") {
                      b.callback = null, S = b.priorityLevel;
                      var te = ne(b.expirationTime <= R);
                      if (R = i.unstable_now(), typeof te == "function") {
                        b.callback = te, D(R), k = true;
                        break t;
                      }
                      b === l(g) && r(g), D(R);
                    } else r(g);
                    b = l(g);
                  }
                  if (b !== null) k = true;
                  else {
                    var de = l(y);
                    de !== null && Y(I, de.startTime - R), k = false;
                  }
                }
                break e;
              } finally {
                b = null, S = J, x = false;
              }
              k = void 0;
            }
          } finally {
            k ? pe() : ee = false;
          }
        }
      }
      var pe;
      if (typeof B == "function") pe = function() {
        B(P);
      };
      else if (typeof MessageChannel < "u") {
        var F = new MessageChannel(), O = F.port2;
        F.port1.onmessage = P, pe = function() {
          O.postMessage(null);
        };
      } else pe = function() {
        j(P, 0);
      };
      function Q() {
        ee || (ee = true, pe());
      }
      function Y(R, k) {
        ae = j(function() {
          R(i.unstable_now());
        }, k);
      }
      i.unstable_IdlePriority = 5, i.unstable_ImmediatePriority = 1, i.unstable_LowPriority = 4, i.unstable_NormalPriority = 3, i.unstable_Profiling = null, i.unstable_UserBlockingPriority = 2, i.unstable_cancelCallback = function(R) {
        R.callback = null;
      }, i.unstable_continueExecution = function() {
        v || x || (v = true, Q());
      }, i.unstable_forceFrameRate = function(R) {
        0 > R || 125 < R ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : be = 0 < R ? Math.floor(1e3 / R) : 5;
      }, i.unstable_getCurrentPriorityLevel = function() {
        return S;
      }, i.unstable_getFirstCallbackNode = function() {
        return l(g);
      }, i.unstable_next = function(R) {
        switch (S) {
          case 1:
          case 2:
          case 3:
            var k = 3;
            break;
          default:
            k = S;
        }
        var J = S;
        S = k;
        try {
          return R();
        } finally {
          S = J;
        }
      }, i.unstable_pauseExecution = function() {
      }, i.unstable_requestPaint = function() {
      }, i.unstable_runWithPriority = function(R, k) {
        switch (R) {
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
          default:
            R = 3;
        }
        var J = S;
        S = R;
        try {
          return k();
        } finally {
          S = J;
        }
      }, i.unstable_scheduleCallback = function(R, k, J) {
        var ne = i.unstable_now();
        switch (typeof J == "object" && J !== null ? (J = J.delay, J = typeof J == "number" && 0 < J ? ne + J : ne) : J = ne, R) {
          case 1:
            var te = -1;
            break;
          case 2:
            te = 250;
            break;
          case 5:
            te = 1073741823;
            break;
          case 4:
            te = 1e4;
            break;
          default:
            te = 5e3;
        }
        return te = J + te, R = {
          id: p++,
          callback: k,
          priorityLevel: R,
          startTime: J,
          expirationTime: te,
          sortIndex: -1
        }, J > ne ? (R.sortIndex = J, a(y, R), l(g) === null && R === l(y) && (A ? (L(ae), ae = -1) : A = true, Y(I, J - ne))) : (R.sortIndex = te, a(g, R), v || x || (v = true, Q())), R;
      }, i.unstable_shouldYield = W, i.unstable_wrapCallback = function(R) {
        var k = S;
        return function() {
          var J = S;
          S = k;
          try {
            return R.apply(this, arguments);
          } finally {
            S = J;
          }
        };
      };
    }(Eu)), Eu;
  }
  var Mm;
  function Pv() {
    return Mm || (Mm = 1, wu.exports = Wv()), wu.exports;
  }
  var Dm;
  function e1() {
    if (Dm) return tl;
    Dm = 1;
    var i = Pv(), a = Mv(), l = Dv();
    function r(e) {
      var t = "https://react.dev/errors/" + e;
      if (1 < arguments.length) {
        t += "?args[]=" + encodeURIComponent(arguments[1]);
        for (var n = 2; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
      }
      return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
    }
    function c(e) {
      return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11);
    }
    var f = Symbol.for("react.element"), d = Symbol.for("react.transitional.element"), h = Symbol.for("react.portal"), g = Symbol.for("react.fragment"), y = Symbol.for("react.strict_mode"), p = Symbol.for("react.profiler"), b = Symbol.for("react.provider"), S = Symbol.for("react.consumer"), x = Symbol.for("react.context"), v = Symbol.for("react.forward_ref"), A = Symbol.for("react.suspense"), j = Symbol.for("react.suspense_list"), L = Symbol.for("react.memo"), B = Symbol.for("react.lazy"), D = Symbol.for("react.offscreen"), I = Symbol.for("react.memo_cache_sentinel"), ee = Symbol.iterator;
    function ae(e) {
      return e === null || typeof e != "object" ? null : (e = ee && e[ee] || e["@@iterator"], typeof e == "function" ? e : null);
    }
    var be = Symbol.for("react.client.reference");
    function le(e) {
      if (e == null) return null;
      if (typeof e == "function") return e.$$typeof === be ? null : e.displayName || e.name || null;
      if (typeof e == "string") return e;
      switch (e) {
        case g:
          return "Fragment";
        case h:
          return "Portal";
        case p:
          return "Profiler";
        case y:
          return "StrictMode";
        case A:
          return "Suspense";
        case j:
          return "SuspenseList";
      }
      if (typeof e == "object") switch (e.$$typeof) {
        case x:
          return (e.displayName || "Context") + ".Provider";
        case S:
          return (e._context.displayName || "Context") + ".Consumer";
        case v:
          var t = e.render;
          return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case L:
          return t = e.displayName || null, t !== null ? t : le(e.type) || "Memo";
        case B:
          t = e._payload, e = e._init;
          try {
            return le(e(t));
          } catch {
          }
      }
      return null;
    }
    var W = a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, P = Object.assign, pe, F;
    function O(e) {
      if (pe === void 0) try {
        throw Error();
      } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        pe = t && t[1] || "", F = -1 < n.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < n.stack.indexOf("@") ? "@unknown:0:0" : "";
      }
      return `
` + pe + e + F;
    }
    var Q = false;
    function Y(e, t) {
      if (!e || Q) return "";
      Q = true;
      var n = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        var s = {
          DetermineComponentFrameRoot: function() {
            try {
              if (t) {
                var $ = function() {
                  throw Error();
                };
                if (Object.defineProperty($.prototype, "props", {
                  set: function() {
                    throw Error();
                  }
                }), typeof Reflect == "object" && Reflect.construct) {
                  try {
                    Reflect.construct($, []);
                  } catch (G) {
                    var H = G;
                  }
                  Reflect.construct(e, [], $);
                } else {
                  try {
                    $.call();
                  } catch (G) {
                    H = G;
                  }
                  e.call($.prototype);
                }
              } else {
                try {
                  throw Error();
                } catch (G) {
                  H = G;
                }
                ($ = e()) && typeof $.catch == "function" && $.catch(function() {
                });
              }
            } catch (G) {
              if (G && H && typeof G.stack == "string") return [
                G.stack,
                H.stack
              ];
            }
            return [
              null,
              null
            ];
          }
        };
        s.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
        var o = Object.getOwnPropertyDescriptor(s.DetermineComponentFrameRoot, "name");
        o && o.configurable && Object.defineProperty(s.DetermineComponentFrameRoot, "name", {
          value: "DetermineComponentFrameRoot"
        });
        var u = s.DetermineComponentFrameRoot(), m = u[0], w = u[1];
        if (m && w) {
          var T = m.split(`
`), N = w.split(`
`);
          for (o = s = 0; s < T.length && !T[s].includes("DetermineComponentFrameRoot"); ) s++;
          for (; o < N.length && !N[o].includes("DetermineComponentFrameRoot"); ) o++;
          if (s === T.length || o === N.length) for (s = T.length - 1, o = N.length - 1; 1 <= s && 0 <= o && T[s] !== N[o]; ) o--;
          for (; 1 <= s && 0 <= o; s--, o--) if (T[s] !== N[o]) {
            if (s !== 1 || o !== 1) do
              if (s--, o--, 0 > o || T[s] !== N[o]) {
                var V = `
` + T[s].replace(" at new ", " at ");
                return e.displayName && V.includes("<anonymous>") && (V = V.replace("<anonymous>", e.displayName)), V;
              }
            while (1 <= s && 0 <= o);
            break;
          }
        }
      } finally {
        Q = false, Error.prepareStackTrace = n;
      }
      return (n = e ? e.displayName || e.name : "") ? O(n) : "";
    }
    function R(e) {
      switch (e.tag) {
        case 26:
        case 27:
        case 5:
          return O(e.type);
        case 16:
          return O("Lazy");
        case 13:
          return O("Suspense");
        case 19:
          return O("SuspenseList");
        case 0:
        case 15:
          return e = Y(e.type, false), e;
        case 11:
          return e = Y(e.type.render, false), e;
        case 1:
          return e = Y(e.type, true), e;
        default:
          return "";
      }
    }
    function k(e) {
      try {
        var t = "";
        do
          t += R(e), e = e.return;
        while (e);
        return t;
      } catch (n) {
        return `
Error generating stack: ` + n.message + `
` + n.stack;
      }
    }
    function J(e) {
      var t = e, n = e;
      if (e.alternate) for (; t.return; ) t = t.return;
      else {
        e = t;
        do
          t = e, (t.flags & 4098) !== 0 && (n = t.return), e = t.return;
        while (e);
      }
      return t.tag === 3 ? n : null;
    }
    function ne(e) {
      if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated;
      }
      return null;
    }
    function te(e) {
      if (J(e) !== e) throw Error(r(188));
    }
    function de(e) {
      var t = e.alternate;
      if (!t) {
        if (t = J(e), t === null) throw Error(r(188));
        return t !== e ? null : e;
      }
      for (var n = e, s = t; ; ) {
        var o = n.return;
        if (o === null) break;
        var u = o.alternate;
        if (u === null) {
          if (s = o.return, s !== null) {
            n = s;
            continue;
          }
          break;
        }
        if (o.child === u.child) {
          for (u = o.child; u; ) {
            if (u === n) return te(o), e;
            if (u === s) return te(o), t;
            u = u.sibling;
          }
          throw Error(r(188));
        }
        if (n.return !== s.return) n = o, s = u;
        else {
          for (var m = false, w = o.child; w; ) {
            if (w === n) {
              m = true, n = o, s = u;
              break;
            }
            if (w === s) {
              m = true, s = o, n = u;
              break;
            }
            w = w.sibling;
          }
          if (!m) {
            for (w = u.child; w; ) {
              if (w === n) {
                m = true, n = u, s = o;
                break;
              }
              if (w === s) {
                m = true, s = u, n = o;
                break;
              }
              w = w.sibling;
            }
            if (!m) throw Error(r(189));
          }
        }
        if (n.alternate !== s) throw Error(r(190));
      }
      if (n.tag !== 3) throw Error(r(188));
      return n.stateNode.current === n ? e : t;
    }
    function me(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e;
      for (e = e.child; e !== null; ) {
        if (t = me(e), t !== null) return t;
        e = e.sibling;
      }
      return null;
    }
    var gt = Array.isArray, Ee = l.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, bt = {
      pending: false,
      data: null,
      method: null,
      action: null
    }, Ea = [], xn = -1;
    function Tt(e) {
      return {
        current: e
      };
    }
    function Ge(e) {
      0 > xn || (e.current = Ea[xn], Ea[xn] = null, xn--);
    }
    function ze(e, t) {
      xn++, Ea[xn] = e.current, e.current = t;
    }
    var oe = Tt(null), Zn = Tt(null), tn = Tt(null), ni = Tt(null);
    function ai(e, t) {
      switch (ze(tn, t), ze(Zn, e), ze(oe, null), e = t.nodeType, e) {
        case 9:
        case 11:
          t = (t = t.documentElement) && (t = t.namespaceURI) ? am(t) : 0;
          break;
        default:
          if (e = e === 8 ? t.parentNode : t, t = e.tagName, e = e.namespaceURI) e = am(e), t = im(e, t);
          else switch (t) {
            case "svg":
              t = 1;
              break;
            case "math":
              t = 2;
              break;
            default:
              t = 0;
          }
      }
      Ge(oe), ze(oe, t);
    }
    function Sn() {
      Ge(oe), Ge(Zn), Ge(tn);
    }
    function is(e) {
      e.memoizedState !== null && ze(ni, e);
      var t = oe.current, n = im(t, e.type);
      t !== n && (ze(Zn, e), ze(oe, n));
    }
    function ii(e) {
      Zn.current === e && (Ge(oe), Ge(Zn)), ni.current === e && (Ge(ni), $s._currentValue = bt);
    }
    var K = Object.prototype.hasOwnProperty, he = i.unstable_scheduleCallback, Ae = i.unstable_cancelCallback, Ne = i.unstable_shouldYield, Ve = i.unstable_requestPaint, Je = i.unstable_now, Aa = i.unstable_getCurrentPriorityLevel, nt = i.unstable_ImmediatePriority, Te = i.unstable_UserBlockingPriority, wn = i.unstable_NormalPriority, mo = i.unstable_LowPriority, El = i.unstable_IdlePriority, cn = i.log, Kn = i.unstable_setDisableYieldValue, qt = null, at = null;
    function pg(e) {
      if (at && typeof at.onCommitFiberRoot == "function") try {
        at.onCommitFiberRoot(qt, e, void 0, (e.current.flags & 128) === 128);
      } catch {
      }
    }
    function $n(e) {
      if (typeof cn == "function" && Kn(e), at && typeof at.setStrictMode == "function") try {
        at.setStrictMode(qt, e);
      } catch {
      }
    }
    var Dt = Math.clz32 ? Math.clz32 : vg, gg = Math.log, bg = Math.LN2;
    function vg(e) {
      return e >>>= 0, e === 0 ? 32 : 31 - (gg(e) / bg | 0) | 0;
    }
    var Al = 128, Tl = 4194304;
    function Ta(e) {
      var t = e & 42;
      if (t !== 0) return t;
      switch (e & -e) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
          return 64;
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return e & 4194176;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return e & 62914560;
        case 67108864:
          return 67108864;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 0;
        default:
          return e;
      }
    }
    function Ol(e, t) {
      var n = e.pendingLanes;
      if (n === 0) return 0;
      var s = 0, o = e.suspendedLanes, u = e.pingedLanes, m = e.warmLanes;
      e = e.finishedLanes !== 0;
      var w = n & 134217727;
      return w !== 0 ? (n = w & ~o, n !== 0 ? s = Ta(n) : (u &= w, u !== 0 ? s = Ta(u) : e || (m = w & ~m, m !== 0 && (s = Ta(m))))) : (w = n & ~o, w !== 0 ? s = Ta(w) : u !== 0 ? s = Ta(u) : e || (m = n & ~m, m !== 0 && (s = Ta(m)))), s === 0 ? 0 : t !== 0 && t !== s && (t & o) === 0 && (o = s & -s, m = t & -t, o >= m || o === 32 && (m & 4194176) !== 0) ? t : s;
    }
    function ss(e, t) {
      return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
    }
    function xg(e, t) {
      switch (e) {
        case 1:
        case 2:
        case 4:
        case 8:
          return t + 250;
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return -1;
        case 67108864:
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function $f() {
      var e = Al;
      return Al <<= 1, (Al & 4194176) === 0 && (Al = 128), e;
    }
    function Jf() {
      var e = Tl;
      return Tl <<= 1, (Tl & 62914560) === 0 && (Tl = 4194304), e;
    }
    function yo(e) {
      for (var t = [], n = 0; 31 > n; n++) t.push(e);
      return t;
    }
    function ls(e, t) {
      e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0);
    }
    function Sg(e, t, n, s, o, u) {
      var m = e.pendingLanes;
      e.pendingLanes = n, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= n, e.entangledLanes &= n, e.errorRecoveryDisabledLanes &= n, e.shellSuspendCounter = 0;
      var w = e.entanglements, T = e.expirationTimes, N = e.hiddenUpdates;
      for (n = m & ~n; 0 < n; ) {
        var V = 31 - Dt(n), $ = 1 << V;
        w[V] = 0, T[V] = -1;
        var H = N[V];
        if (H !== null) for (N[V] = null, V = 0; V < H.length; V++) {
          var G = H[V];
          G !== null && (G.lane &= -536870913);
        }
        n &= ~$;
      }
      s !== 0 && If(e, s, 0), u !== 0 && o === 0 && e.tag !== 0 && (e.suspendedLanes |= u & ~(m & ~t));
    }
    function If(e, t, n) {
      e.pendingLanes |= t, e.suspendedLanes &= ~t;
      var s = 31 - Dt(t);
      e.entangledLanes |= t, e.entanglements[s] = e.entanglements[s] | 1073741824 | n & 4194218;
    }
    function Wf(e, t) {
      var n = e.entangledLanes |= t;
      for (e = e.entanglements; n; ) {
        var s = 31 - Dt(n), o = 1 << s;
        o & t | e[s] & t && (e[s] |= t), n &= ~o;
      }
    }
    function Pf(e) {
      return e &= -e, 2 < e ? 8 < e ? (e & 134217727) !== 0 ? 32 : 268435456 : 8 : 2;
    }
    function ed() {
      var e = Ee.p;
      return e !== 0 ? e : (e = window.event, e === void 0 ? 32 : wm(e.type));
    }
    function wg(e, t) {
      var n = Ee.p;
      try {
        return Ee.p = e, t();
      } finally {
        Ee.p = n;
      }
    }
    var Jn = Math.random().toString(36).slice(2), vt = "__reactFiber$" + Jn, Ot = "__reactProps$" + Jn, si = "__reactContainer$" + Jn, po = "__reactEvents$" + Jn, Eg = "__reactListeners$" + Jn, Ag = "__reactHandles$" + Jn, td = "__reactResources$" + Jn, rs = "__reactMarker$" + Jn;
    function go(e) {
      delete e[vt], delete e[Ot], delete e[po], delete e[Eg], delete e[Ag];
    }
    function Oa(e) {
      var t = e[vt];
      if (t) return t;
      for (var n = e.parentNode; n; ) {
        if (t = n[si] || n[vt]) {
          if (n = t.alternate, t.child !== null || n !== null && n.child !== null) for (e = rm(e); e !== null; ) {
            if (n = e[vt]) return n;
            e = rm(e);
          }
          return t;
        }
        e = n, n = e.parentNode;
      }
      return null;
    }
    function li(e) {
      if (e = e[vt] || e[si]) {
        var t = e.tag;
        if (t === 5 || t === 6 || t === 13 || t === 26 || t === 27 || t === 3) return e;
      }
      return null;
    }
    function os(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
      throw Error(r(33));
    }
    function ri(e) {
      var t = e[td];
      return t || (t = e[td] = {
        hoistableStyles: /* @__PURE__ */ new Map(),
        hoistableScripts: /* @__PURE__ */ new Map()
      }), t;
    }
    function ct(e) {
      e[rs] = true;
    }
    var nd = /* @__PURE__ */ new Set(), ad = {};
    function Ca(e, t) {
      oi(e, t), oi(e + "Capture", t);
    }
    function oi(e, t) {
      for (ad[e] = t, e = 0; e < t.length; e++) nd.add(t[e]);
    }
    var En = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"), Tg = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"), id = {}, sd = {};
    function Og(e) {
      return K.call(sd, e) ? true : K.call(id, e) ? false : Tg.test(e) ? sd[e] = true : (id[e] = true, false);
    }
    function Cl(e, t, n) {
      if (Og(t)) if (n === null) e.removeAttribute(t);
      else {
        switch (typeof n) {
          case "undefined":
          case "function":
          case "symbol":
            e.removeAttribute(t);
            return;
          case "boolean":
            var s = t.toLowerCase().slice(0, 5);
            if (s !== "data-" && s !== "aria-") {
              e.removeAttribute(t);
              return;
            }
        }
        e.setAttribute(t, "" + n);
      }
    }
    function _l2(e, t, n) {
      if (n === null) e.removeAttribute(t);
      else {
        switch (typeof n) {
          case "undefined":
          case "function":
          case "symbol":
          case "boolean":
            e.removeAttribute(t);
            return;
        }
        e.setAttribute(t, "" + n);
      }
    }
    function An(e, t, n, s) {
      if (s === null) e.removeAttribute(n);
      else {
        switch (typeof s) {
          case "undefined":
          case "function":
          case "symbol":
          case "boolean":
            e.removeAttribute(n);
            return;
        }
        e.setAttributeNS(t, n, "" + s);
      }
    }
    function Yt(e) {
      switch (typeof e) {
        case "bigint":
        case "boolean":
        case "number":
        case "string":
        case "undefined":
          return e;
        case "object":
          return e;
        default:
          return "";
      }
    }
    function ld(e) {
      var t = e.type;
      return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
    }
    function Cg(e) {
      var t = ld(e) ? "checked" : "value", n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t), s = "" + e[t];
      if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
        var o = n.get, u = n.set;
        return Object.defineProperty(e, t, {
          configurable: true,
          get: function() {
            return o.call(this);
          },
          set: function(m) {
            s = "" + m, u.call(this, m);
          }
        }), Object.defineProperty(e, t, {
          enumerable: n.enumerable
        }), {
          getValue: function() {
            return s;
          },
          setValue: function(m) {
            s = "" + m;
          },
          stopTracking: function() {
            e._valueTracker = null, delete e[t];
          }
        };
      }
    }
    function Nl(e) {
      e._valueTracker || (e._valueTracker = Cg(e));
    }
    function rd(e) {
      if (!e) return false;
      var t = e._valueTracker;
      if (!t) return true;
      var n = t.getValue(), s = "";
      return e && (s = ld(e) ? e.checked ? "true" : "false" : e.value), e = s, e !== n ? (t.setValue(e), true) : false;
    }
    function Rl(e) {
      if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
      try {
        return e.activeElement || e.body;
      } catch {
        return e.body;
      }
    }
    var _g = /[\n"\\]/g;
    function Gt(e) {
      return e.replace(_g, function(t) {
        return "\\" + t.charCodeAt(0).toString(16) + " ";
      });
    }
    function bo(e, t, n, s, o, u, m, w) {
      e.name = "", m != null && typeof m != "function" && typeof m != "symbol" && typeof m != "boolean" ? e.type = m : e.removeAttribute("type"), t != null ? m === "number" ? (t === 0 && e.value === "" || e.value != t) && (e.value = "" + Yt(t)) : e.value !== "" + Yt(t) && (e.value = "" + Yt(t)) : m !== "submit" && m !== "reset" || e.removeAttribute("value"), t != null ? vo(e, m, Yt(t)) : n != null ? vo(e, m, Yt(n)) : s != null && e.removeAttribute("value"), o == null && u != null && (e.defaultChecked = !!u), o != null && (e.checked = o && typeof o != "function" && typeof o != "symbol"), w != null && typeof w != "function" && typeof w != "symbol" && typeof w != "boolean" ? e.name = "" + Yt(w) : e.removeAttribute("name");
    }
    function od(e, t, n, s, o, u, m, w) {
      if (u != null && typeof u != "function" && typeof u != "symbol" && typeof u != "boolean" && (e.type = u), t != null || n != null) {
        if (!(u !== "submit" && u !== "reset" || t != null)) return;
        n = n != null ? "" + Yt(n) : "", t = t != null ? "" + Yt(t) : n, w || t === e.value || (e.value = t), e.defaultValue = t;
      }
      s = s ?? o, s = typeof s != "function" && typeof s != "symbol" && !!s, e.checked = w ? e.checked : !!s, e.defaultChecked = !!s, m != null && typeof m != "function" && typeof m != "symbol" && typeof m != "boolean" && (e.name = m);
    }
    function vo(e, t, n) {
      t === "number" && Rl(e.ownerDocument) === e || e.defaultValue === "" + n || (e.defaultValue = "" + n);
    }
    function ci(e, t, n, s) {
      if (e = e.options, t) {
        t = {};
        for (var o = 0; o < n.length; o++) t["$" + n[o]] = true;
        for (n = 0; n < e.length; n++) o = t.hasOwnProperty("$" + e[n].value), e[n].selected !== o && (e[n].selected = o), o && s && (e[n].defaultSelected = true);
      } else {
        for (n = "" + Yt(n), t = null, o = 0; o < e.length; o++) {
          if (e[o].value === n) {
            e[o].selected = true, s && (e[o].defaultSelected = true);
            return;
          }
          t !== null || e[o].disabled || (t = e[o]);
        }
        t !== null && (t.selected = true);
      }
    }
    function cd(e, t, n) {
      if (t != null && (t = "" + Yt(t), t !== e.value && (e.value = t), n == null)) {
        e.defaultValue !== t && (e.defaultValue = t);
        return;
      }
      e.defaultValue = n != null ? "" + Yt(n) : "";
    }
    function ud(e, t, n, s) {
      if (t == null) {
        if (s != null) {
          if (n != null) throw Error(r(92));
          if (gt(s)) {
            if (1 < s.length) throw Error(r(93));
            s = s[0];
          }
          n = s;
        }
        n == null && (n = ""), t = n;
      }
      n = Yt(t), e.defaultValue = n, s = e.textContent, s === n && s !== "" && s !== null && (e.value = s);
    }
    function ui(e, t) {
      if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
          n.nodeValue = t;
          return;
        }
      }
      e.textContent = t;
    }
    var Ng = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));
    function fd(e, t, n) {
      var s = t.indexOf("--") === 0;
      n == null || typeof n == "boolean" || n === "" ? s ? e.setProperty(t, "") : t === "float" ? e.cssFloat = "" : e[t] = "" : s ? e.setProperty(t, n) : typeof n != "number" || n === 0 || Ng.has(t) ? t === "float" ? e.cssFloat = n : e[t] = ("" + n).trim() : e[t] = n + "px";
    }
    function dd(e, t, n) {
      if (t != null && typeof t != "object") throw Error(r(62));
      if (e = e.style, n != null) {
        for (var s in n) !n.hasOwnProperty(s) || t != null && t.hasOwnProperty(s) || (s.indexOf("--") === 0 ? e.setProperty(s, "") : s === "float" ? e.cssFloat = "" : e[s] = "");
        for (var o in t) s = t[o], t.hasOwnProperty(o) && n[o] !== s && fd(e, o, s);
      } else for (var u in t) t.hasOwnProperty(u) && fd(e, u, t[u]);
    }
    function xo(e) {
      if (e.indexOf("-") === -1) return false;
      switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
          return false;
        default:
          return true;
      }
    }
    var Rg = /* @__PURE__ */ new Map([
      [
        "acceptCharset",
        "accept-charset"
      ],
      [
        "htmlFor",
        "for"
      ],
      [
        "httpEquiv",
        "http-equiv"
      ],
      [
        "crossOrigin",
        "crossorigin"
      ],
      [
        "accentHeight",
        "accent-height"
      ],
      [
        "alignmentBaseline",
        "alignment-baseline"
      ],
      [
        "arabicForm",
        "arabic-form"
      ],
      [
        "baselineShift",
        "baseline-shift"
      ],
      [
        "capHeight",
        "cap-height"
      ],
      [
        "clipPath",
        "clip-path"
      ],
      [
        "clipRule",
        "clip-rule"
      ],
      [
        "colorInterpolation",
        "color-interpolation"
      ],
      [
        "colorInterpolationFilters",
        "color-interpolation-filters"
      ],
      [
        "colorProfile",
        "color-profile"
      ],
      [
        "colorRendering",
        "color-rendering"
      ],
      [
        "dominantBaseline",
        "dominant-baseline"
      ],
      [
        "enableBackground",
        "enable-background"
      ],
      [
        "fillOpacity",
        "fill-opacity"
      ],
      [
        "fillRule",
        "fill-rule"
      ],
      [
        "floodColor",
        "flood-color"
      ],
      [
        "floodOpacity",
        "flood-opacity"
      ],
      [
        "fontFamily",
        "font-family"
      ],
      [
        "fontSize",
        "font-size"
      ],
      [
        "fontSizeAdjust",
        "font-size-adjust"
      ],
      [
        "fontStretch",
        "font-stretch"
      ],
      [
        "fontStyle",
        "font-style"
      ],
      [
        "fontVariant",
        "font-variant"
      ],
      [
        "fontWeight",
        "font-weight"
      ],
      [
        "glyphName",
        "glyph-name"
      ],
      [
        "glyphOrientationHorizontal",
        "glyph-orientation-horizontal"
      ],
      [
        "glyphOrientationVertical",
        "glyph-orientation-vertical"
      ],
      [
        "horizAdvX",
        "horiz-adv-x"
      ],
      [
        "horizOriginX",
        "horiz-origin-x"
      ],
      [
        "imageRendering",
        "image-rendering"
      ],
      [
        "letterSpacing",
        "letter-spacing"
      ],
      [
        "lightingColor",
        "lighting-color"
      ],
      [
        "markerEnd",
        "marker-end"
      ],
      [
        "markerMid",
        "marker-mid"
      ],
      [
        "markerStart",
        "marker-start"
      ],
      [
        "overlinePosition",
        "overline-position"
      ],
      [
        "overlineThickness",
        "overline-thickness"
      ],
      [
        "paintOrder",
        "paint-order"
      ],
      [
        "panose-1",
        "panose-1"
      ],
      [
        "pointerEvents",
        "pointer-events"
      ],
      [
        "renderingIntent",
        "rendering-intent"
      ],
      [
        "shapeRendering",
        "shape-rendering"
      ],
      [
        "stopColor",
        "stop-color"
      ],
      [
        "stopOpacity",
        "stop-opacity"
      ],
      [
        "strikethroughPosition",
        "strikethrough-position"
      ],
      [
        "strikethroughThickness",
        "strikethrough-thickness"
      ],
      [
        "strokeDasharray",
        "stroke-dasharray"
      ],
      [
        "strokeDashoffset",
        "stroke-dashoffset"
      ],
      [
        "strokeLinecap",
        "stroke-linecap"
      ],
      [
        "strokeLinejoin",
        "stroke-linejoin"
      ],
      [
        "strokeMiterlimit",
        "stroke-miterlimit"
      ],
      [
        "strokeOpacity",
        "stroke-opacity"
      ],
      [
        "strokeWidth",
        "stroke-width"
      ],
      [
        "textAnchor",
        "text-anchor"
      ],
      [
        "textDecoration",
        "text-decoration"
      ],
      [
        "textRendering",
        "text-rendering"
      ],
      [
        "transformOrigin",
        "transform-origin"
      ],
      [
        "underlinePosition",
        "underline-position"
      ],
      [
        "underlineThickness",
        "underline-thickness"
      ],
      [
        "unicodeBidi",
        "unicode-bidi"
      ],
      [
        "unicodeRange",
        "unicode-range"
      ],
      [
        "unitsPerEm",
        "units-per-em"
      ],
      [
        "vAlphabetic",
        "v-alphabetic"
      ],
      [
        "vHanging",
        "v-hanging"
      ],
      [
        "vIdeographic",
        "v-ideographic"
      ],
      [
        "vMathematical",
        "v-mathematical"
      ],
      [
        "vectorEffect",
        "vector-effect"
      ],
      [
        "vertAdvY",
        "vert-adv-y"
      ],
      [
        "vertOriginX",
        "vert-origin-x"
      ],
      [
        "vertOriginY",
        "vert-origin-y"
      ],
      [
        "wordSpacing",
        "word-spacing"
      ],
      [
        "writingMode",
        "writing-mode"
      ],
      [
        "xmlnsXlink",
        "xmlns:xlink"
      ],
      [
        "xHeight",
        "x-height"
      ]
    ]), jg = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
    function jl(e) {
      return jg.test("" + e) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : e;
    }
    var So = null;
    function wo(e) {
      return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e;
    }
    var fi = null, di = null;
    function hd(e) {
      var t = li(e);
      if (t && (e = t.stateNode)) {
        var n = e[Ot] || null;
        e: switch (e = t.stateNode, t.type) {
          case "input":
            if (bo(e, n.value, n.defaultValue, n.defaultValue, n.checked, n.defaultChecked, n.type, n.name), t = n.name, n.type === "radio" && t != null) {
              for (n = e; n.parentNode; ) n = n.parentNode;
              for (n = n.querySelectorAll('input[name="' + Gt("" + t) + '"][type="radio"]'), t = 0; t < n.length; t++) {
                var s = n[t];
                if (s !== e && s.form === e.form) {
                  var o = s[Ot] || null;
                  if (!o) throw Error(r(90));
                  bo(s, o.value, o.defaultValue, o.defaultValue, o.checked, o.defaultChecked, o.type, o.name);
                }
              }
              for (t = 0; t < n.length; t++) s = n[t], s.form === e.form && rd(s);
            }
            break e;
          case "textarea":
            cd(e, n.value, n.defaultValue);
            break e;
          case "select":
            t = n.value, t != null && ci(e, !!n.multiple, t, false);
        }
      }
    }
    var Eo = false;
    function md(e, t, n) {
      if (Eo) return e(t, n);
      Eo = true;
      try {
        var s = e(t);
        return s;
      } finally {
        if (Eo = false, (fi !== null || di !== null) && (mr(), fi && (t = fi, e = di, di = fi = null, hd(t), e))) for (t = 0; t < e.length; t++) hd(e[t]);
      }
    }
    function cs(e, t) {
      var n = e.stateNode;
      if (n === null) return null;
      var s = n[Ot] || null;
      if (s === null) return null;
      n = s[t];
      e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
          (s = !s.disabled) || (e = e.type, s = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !s;
          break e;
        default:
          e = false;
      }
      if (e) return null;
      if (n && typeof n != "function") throw Error(r(231, t, typeof n));
      return n;
    }
    var Ao = false;
    if (En) try {
      var us = {};
      Object.defineProperty(us, "passive", {
        get: function() {
          Ao = true;
        }
      }), window.addEventListener("test", us, us), window.removeEventListener("test", us, us);
    } catch {
      Ao = false;
    }
    var In = null, To = null, Ml = null;
    function yd() {
      if (Ml) return Ml;
      var e, t = To, n = t.length, s, o = "value" in In ? In.value : In.textContent, u = o.length;
      for (e = 0; e < n && t[e] === o[e]; e++) ;
      var m = n - e;
      for (s = 1; s <= m && t[n - s] === o[u - s]; s++) ;
      return Ml = o.slice(e, 1 < s ? 1 - s : void 0);
    }
    function Dl(e) {
      var t = e.keyCode;
      return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0;
    }
    function Ul() {
      return true;
    }
    function pd() {
      return false;
    }
    function Ct(e) {
      function t(n, s, o, u, m) {
        this._reactName = n, this._targetInst = o, this.type = s, this.nativeEvent = u, this.target = m, this.currentTarget = null;
        for (var w in e) e.hasOwnProperty(w) && (n = e[w], this[w] = n ? n(u) : u[w]);
        return this.isDefaultPrevented = (u.defaultPrevented != null ? u.defaultPrevented : u.returnValue === false) ? Ul : pd, this.isPropagationStopped = pd, this;
      }
      return P(t.prototype, {
        preventDefault: function() {
          this.defaultPrevented = true;
          var n = this.nativeEvent;
          n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = false), this.isDefaultPrevented = Ul);
        },
        stopPropagation: function() {
          var n = this.nativeEvent;
          n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = true), this.isPropagationStopped = Ul);
        },
        persist: function() {
        },
        isPersistent: Ul
      }), t;
    }
    var _a7 = {
      eventPhase: 0,
      bubbles: 0,
      cancelable: 0,
      timeStamp: function(e) {
        return e.timeStamp || Date.now();
      },
      defaultPrevented: 0,
      isTrusted: 0
    }, zl = Ct(_a7), fs = P({}, _a7, {
      view: 0,
      detail: 0
    }), Mg = Ct(fs), Oo, Co, ds, kl = P({}, fs, {
      screenX: 0,
      screenY: 0,
      clientX: 0,
      clientY: 0,
      pageX: 0,
      pageY: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      getModifierState: No,
      button: 0,
      buttons: 0,
      relatedTarget: function(e) {
        return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
      },
      movementX: function(e) {
        return "movementX" in e ? e.movementX : (e !== ds && (ds && e.type === "mousemove" ? (Oo = e.screenX - ds.screenX, Co = e.screenY - ds.screenY) : Co = Oo = 0, ds = e), Oo);
      },
      movementY: function(e) {
        return "movementY" in e ? e.movementY : Co;
      }
    }), gd = Ct(kl), Dg = P({}, kl, {
      dataTransfer: 0
    }), Ug = Ct(Dg), zg = P({}, fs, {
      relatedTarget: 0
    }), _o2 = Ct(zg), kg = P({}, _a7, {
      animationName: 0,
      elapsedTime: 0,
      pseudoElement: 0
    }), Bg = Ct(kg), Hg = P({}, _a7, {
      clipboardData: function(e) {
        return "clipboardData" in e ? e.clipboardData : window.clipboardData;
      }
    }), Lg = Ct(Hg), qg = P({}, _a7, {
      data: 0
    }), bd = Ct(qg), Yg = {
      Esc: "Escape",
      Spacebar: " ",
      Left: "ArrowLeft",
      Up: "ArrowUp",
      Right: "ArrowRight",
      Down: "ArrowDown",
      Del: "Delete",
      Win: "OS",
      Menu: "ContextMenu",
      Apps: "ContextMenu",
      Scroll: "ScrollLock",
      MozPrintableKey: "Unidentified"
    }, Gg = {
      8: "Backspace",
      9: "Tab",
      12: "Clear",
      13: "Enter",
      16: "Shift",
      17: "Control",
      18: "Alt",
      19: "Pause",
      20: "CapsLock",
      27: "Escape",
      32: " ",
      33: "PageUp",
      34: "PageDown",
      35: "End",
      36: "Home",
      37: "ArrowLeft",
      38: "ArrowUp",
      39: "ArrowRight",
      40: "ArrowDown",
      45: "Insert",
      46: "Delete",
      112: "F1",
      113: "F2",
      114: "F3",
      115: "F4",
      116: "F5",
      117: "F6",
      118: "F7",
      119: "F8",
      120: "F9",
      121: "F10",
      122: "F11",
      123: "F12",
      144: "NumLock",
      145: "ScrollLock",
      224: "Meta"
    }, Vg = {
      Alt: "altKey",
      Control: "ctrlKey",
      Meta: "metaKey",
      Shift: "shiftKey"
    };
    function Xg(e) {
      var t = this.nativeEvent;
      return t.getModifierState ? t.getModifierState(e) : (e = Vg[e]) ? !!t[e] : false;
    }
    function No() {
      return Xg;
    }
    var Fg = P({}, fs, {
      key: function(e) {
        if (e.key) {
          var t = Yg[e.key] || e.key;
          if (t !== "Unidentified") return t;
        }
        return e.type === "keypress" ? (e = Dl(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? Gg[e.keyCode] || "Unidentified" : "";
      },
      code: 0,
      location: 0,
      ctrlKey: 0,
      shiftKey: 0,
      altKey: 0,
      metaKey: 0,
      repeat: 0,
      locale: 0,
      getModifierState: No,
      charCode: function(e) {
        return e.type === "keypress" ? Dl(e) : 0;
      },
      keyCode: function(e) {
        return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      },
      which: function(e) {
        return e.type === "keypress" ? Dl(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
      }
    }), Qg = Ct(Fg), Zg = P({}, kl, {
      pointerId: 0,
      width: 0,
      height: 0,
      pressure: 0,
      tangentialPressure: 0,
      tiltX: 0,
      tiltY: 0,
      twist: 0,
      pointerType: 0,
      isPrimary: 0
    }), vd = Ct(Zg), Kg = P({}, fs, {
      touches: 0,
      targetTouches: 0,
      changedTouches: 0,
      altKey: 0,
      metaKey: 0,
      ctrlKey: 0,
      shiftKey: 0,
      getModifierState: No
    }), $g = Ct(Kg), Jg = P({}, _a7, {
      propertyName: 0,
      elapsedTime: 0,
      pseudoElement: 0
    }), Ig = Ct(Jg), Wg = P({}, kl, {
      deltaX: function(e) {
        return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0;
      },
      deltaY: function(e) {
        return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0;
      },
      deltaZ: 0,
      deltaMode: 0
    }), Pg = Ct(Wg), eb = P({}, _a7, {
      newState: 0,
      oldState: 0
    }), tb = Ct(eb), nb = [
      9,
      13,
      27,
      32
    ], Ro = En && "CompositionEvent" in window, hs = null;
    En && "documentMode" in document && (hs = document.documentMode);
    var ab = En && "TextEvent" in window && !hs, xd = En && (!Ro || hs && 8 < hs && 11 >= hs), Sd = " ", wd = false;
    function Ed(e, t) {
      switch (e) {
        case "keyup":
          return nb.indexOf(t.keyCode) !== -1;
        case "keydown":
          return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
          return true;
        default:
          return false;
      }
    }
    function Ad(e) {
      return e = e.detail, typeof e == "object" && "data" in e ? e.data : null;
    }
    var hi = false;
    function ib(e, t) {
      switch (e) {
        case "compositionend":
          return Ad(t);
        case "keypress":
          return t.which !== 32 ? null : (wd = true, Sd);
        case "textInput":
          return e = t.data, e === Sd && wd ? null : e;
        default:
          return null;
      }
    }
    function sb(e, t) {
      if (hi) return e === "compositionend" || !Ro && Ed(e, t) ? (e = yd(), Ml = To = In = null, hi = false, e) : null;
      switch (e) {
        case "paste":
          return null;
        case "keypress":
          if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
            if (t.char && 1 < t.char.length) return t.char;
            if (t.which) return String.fromCharCode(t.which);
          }
          return null;
        case "compositionend":
          return xd && t.locale !== "ko" ? null : t.data;
        default:
          return null;
      }
    }
    var lb = {
      color: true,
      date: true,
      datetime: true,
      "datetime-local": true,
      email: true,
      month: true,
      number: true,
      password: true,
      range: true,
      search: true,
      tel: true,
      text: true,
      time: true,
      url: true,
      week: true
    };
    function Td(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t === "input" ? !!lb[e.type] : t === "textarea";
    }
    function Od(e, t, n, s) {
      fi ? di ? di.push(s) : di = [
        s
      ] : fi = s, t = vr(t, "onChange"), 0 < t.length && (n = new zl("onChange", "change", null, n, s), e.push({
        event: n,
        listeners: t
      }));
    }
    var ms = null, ys = null;
    function rb(e) {
      W0(e, 0);
    }
    function Bl(e) {
      var t = os(e);
      if (rd(t)) return e;
    }
    function Cd(e, t) {
      if (e === "change") return t;
    }
    var _d = false;
    if (En) {
      var jo;
      if (En) {
        var Mo = "oninput" in document;
        if (!Mo) {
          var Nd = document.createElement("div");
          Nd.setAttribute("oninput", "return;"), Mo = typeof Nd.oninput == "function";
        }
        jo = Mo;
      } else jo = false;
      _d = jo && (!document.documentMode || 9 < document.documentMode);
    }
    function Rd() {
      ms && (ms.detachEvent("onpropertychange", jd), ys = ms = null);
    }
    function jd(e) {
      if (e.propertyName === "value" && Bl(ys)) {
        var t = [];
        Od(t, ys, e, wo(e)), md(rb, t);
      }
    }
    function ob(e, t, n) {
      e === "focusin" ? (Rd(), ms = t, ys = n, ms.attachEvent("onpropertychange", jd)) : e === "focusout" && Rd();
    }
    function cb(e) {
      if (e === "selectionchange" || e === "keyup" || e === "keydown") return Bl(ys);
    }
    function ub(e, t) {
      if (e === "click") return Bl(t);
    }
    function fb(e, t) {
      if (e === "input" || e === "change") return Bl(t);
    }
    function db(e, t) {
      return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
    }
    var Ut = typeof Object.is == "function" ? Object.is : db;
    function ps(e, t) {
      if (Ut(e, t)) return true;
      if (typeof e != "object" || e === null || typeof t != "object" || t === null) return false;
      var n = Object.keys(e), s = Object.keys(t);
      if (n.length !== s.length) return false;
      for (s = 0; s < n.length; s++) {
        var o = n[s];
        if (!K.call(t, o) || !Ut(e[o], t[o])) return false;
      }
      return true;
    }
    function Md(e) {
      for (; e && e.firstChild; ) e = e.firstChild;
      return e;
    }
    function Dd(e, t) {
      var n = Md(e);
      e = 0;
      for (var s; n; ) {
        if (n.nodeType === 3) {
          if (s = e + n.textContent.length, e <= t && s >= t) return {
            node: n,
            offset: t - e
          };
          e = s;
        }
        e: {
          for (; n; ) {
            if (n.nextSibling) {
              n = n.nextSibling;
              break e;
            }
            n = n.parentNode;
          }
          n = void 0;
        }
        n = Md(n);
      }
    }
    function Ud(e, t) {
      return e && t ? e === t ? true : e && e.nodeType === 3 ? false : t && t.nodeType === 3 ? Ud(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : false : false;
    }
    function zd(e) {
      e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
      for (var t = Rl(e.document); t instanceof e.HTMLIFrameElement; ) {
        try {
          var n = typeof t.contentWindow.location.href == "string";
        } catch {
          n = false;
        }
        if (n) e = t.contentWindow;
        else break;
        t = Rl(e.document);
      }
      return t;
    }
    function Do(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
    }
    function hb(e, t) {
      var n = zd(t);
      t = e.focusedElem;
      var s = e.selectionRange;
      if (n !== t && t && t.ownerDocument && Ud(t.ownerDocument.documentElement, t)) {
        if (s !== null && Do(t)) {
          if (e = s.start, n = s.end, n === void 0 && (n = e), "selectionStart" in t) t.selectionStart = e, t.selectionEnd = Math.min(n, t.value.length);
          else if (n = (e = t.ownerDocument || document) && e.defaultView || window, n.getSelection) {
            n = n.getSelection();
            var o = t.textContent.length, u = Math.min(s.start, o);
            s = s.end === void 0 ? u : Math.min(s.end, o), !n.extend && u > s && (o = s, s = u, u = o), o = Dd(t, u);
            var m = Dd(t, s);
            o && m && (n.rangeCount !== 1 || n.anchorNode !== o.node || n.anchorOffset !== o.offset || n.focusNode !== m.node || n.focusOffset !== m.offset) && (e = e.createRange(), e.setStart(o.node, o.offset), n.removeAllRanges(), u > s ? (n.addRange(e), n.extend(m.node, m.offset)) : (e.setEnd(m.node, m.offset), n.addRange(e)));
          }
        }
        for (e = [], n = t; n = n.parentNode; ) n.nodeType === 1 && e.push({
          element: n,
          left: n.scrollLeft,
          top: n.scrollTop
        });
        for (typeof t.focus == "function" && t.focus(), t = 0; t < e.length; t++) n = e[t], n.element.scrollLeft = n.left, n.element.scrollTop = n.top;
      }
    }
    var mb = En && "documentMode" in document && 11 >= document.documentMode, mi = null, Uo = null, gs = null, zo = false;
    function kd(e, t, n) {
      var s = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
      zo || mi == null || mi !== Rl(s) || (s = mi, "selectionStart" in s && Do(s) ? s = {
        start: s.selectionStart,
        end: s.selectionEnd
      } : (s = (s.ownerDocument && s.ownerDocument.defaultView || window).getSelection(), s = {
        anchorNode: s.anchorNode,
        anchorOffset: s.anchorOffset,
        focusNode: s.focusNode,
        focusOffset: s.focusOffset
      }), gs && ps(gs, s) || (gs = s, s = vr(Uo, "onSelect"), 0 < s.length && (t = new zl("onSelect", "select", null, t, n), e.push({
        event: t,
        listeners: s
      }), t.target = mi)));
    }
    function Na(e, t) {
      var n = {};
      return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n;
    }
    var yi = {
      animationend: Na("Animation", "AnimationEnd"),
      animationiteration: Na("Animation", "AnimationIteration"),
      animationstart: Na("Animation", "AnimationStart"),
      transitionrun: Na("Transition", "TransitionRun"),
      transitionstart: Na("Transition", "TransitionStart"),
      transitioncancel: Na("Transition", "TransitionCancel"),
      transitionend: Na("Transition", "TransitionEnd")
    }, ko = {}, Bd = {};
    En && (Bd = document.createElement("div").style, "AnimationEvent" in window || (delete yi.animationend.animation, delete yi.animationiteration.animation, delete yi.animationstart.animation), "TransitionEvent" in window || delete yi.transitionend.transition);
    function Ra(e) {
      if (ko[e]) return ko[e];
      if (!yi[e]) return e;
      var t = yi[e], n;
      for (n in t) if (t.hasOwnProperty(n) && n in Bd) return ko[e] = t[n];
      return e;
    }
    var Hd = Ra("animationend"), Ld = Ra("animationiteration"), qd = Ra("animationstart"), yb = Ra("transitionrun"), pb = Ra("transitionstart"), gb = Ra("transitioncancel"), Yd = Ra("transitionend"), Gd = /* @__PURE__ */ new Map(), Vd = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll scrollEnd toggle touchMove waiting wheel".split(" ");
    function nn(e, t) {
      Gd.set(e, t), Ca(t, [
        e
      ]);
    }
    var Vt = [], pi = 0, Bo = 0;
    function Hl() {
      for (var e = pi, t = Bo = pi = 0; t < e; ) {
        var n = Vt[t];
        Vt[t++] = null;
        var s = Vt[t];
        Vt[t++] = null;
        var o = Vt[t];
        Vt[t++] = null;
        var u = Vt[t];
        if (Vt[t++] = null, s !== null && o !== null) {
          var m = s.pending;
          m === null ? o.next = o : (o.next = m.next, m.next = o), s.pending = o;
        }
        u !== 0 && Xd(n, o, u);
      }
    }
    function Ll(e, t, n, s) {
      Vt[pi++] = e, Vt[pi++] = t, Vt[pi++] = n, Vt[pi++] = s, Bo |= s, e.lanes |= s, e = e.alternate, e !== null && (e.lanes |= s);
    }
    function Ho(e, t, n, s) {
      return Ll(e, t, n, s), ql(e);
    }
    function Wn(e, t) {
      return Ll(e, null, null, t), ql(e);
    }
    function Xd(e, t, n) {
      e.lanes |= n;
      var s = e.alternate;
      s !== null && (s.lanes |= n);
      for (var o = false, u = e.return; u !== null; ) u.childLanes |= n, s = u.alternate, s !== null && (s.childLanes |= n), u.tag === 22 && (e = u.stateNode, e === null || e._visibility & 1 || (o = true)), e = u, u = u.return;
      o && t !== null && e.tag === 3 && (u = e.stateNode, o = 31 - Dt(n), u = u.hiddenUpdates, e = u[o], e === null ? u[o] = [
        t
      ] : e.push(t), t.lane = n | 536870912);
    }
    function ql(e) {
      if (50 < Gs) throw Gs = 0, Xc = null, Error(r(185));
      for (var t = e.return; t !== null; ) e = t, t = e.return;
      return e.tag === 3 ? e.stateNode : null;
    }
    var gi = {}, Fd = /* @__PURE__ */ new WeakMap();
    function Xt(e, t) {
      if (typeof e == "object" && e !== null) {
        var n = Fd.get(e);
        return n !== void 0 ? n : (t = {
          value: e,
          source: t,
          stack: k(t)
        }, Fd.set(e, t), t);
      }
      return {
        value: e,
        source: t,
        stack: k(t)
      };
    }
    var bi = [], vi = 0, Yl = null, Gl = 0, Ft = [], Qt = 0, ja = null, Tn = 1, On = "";
    function Ma(e, t) {
      bi[vi++] = Gl, bi[vi++] = Yl, Yl = e, Gl = t;
    }
    function Qd(e, t, n) {
      Ft[Qt++] = Tn, Ft[Qt++] = On, Ft[Qt++] = ja, ja = e;
      var s = Tn;
      e = On;
      var o = 32 - Dt(s) - 1;
      s &= ~(1 << o), n += 1;
      var u = 32 - Dt(t) + o;
      if (30 < u) {
        var m = o - o % 5;
        u = (s & (1 << m) - 1).toString(32), s >>= m, o -= m, Tn = 1 << 32 - Dt(t) + o | n << o | s, On = u + e;
      } else Tn = 1 << u | n << o | s, On = e;
    }
    function Lo(e) {
      e.return !== null && (Ma(e, 1), Qd(e, 1, 0));
    }
    function qo(e) {
      for (; e === Yl; ) Yl = bi[--vi], bi[vi] = null, Gl = bi[--vi], bi[vi] = null;
      for (; e === ja; ) ja = Ft[--Qt], Ft[Qt] = null, On = Ft[--Qt], Ft[Qt] = null, Tn = Ft[--Qt], Ft[Qt] = null;
    }
    var wt = null, mt = null, Re = false, an = null, un = false, Yo = Error(r(519));
    function Da(e) {
      var t = Error(r(418, ""));
      throw xs(Xt(t, e)), Yo;
    }
    function Zd(e) {
      var t = e.stateNode, n = e.type, s = e.memoizedProps;
      switch (t[vt] = e, t[Ot] = s, n) {
        case "dialog":
          Oe("cancel", t), Oe("close", t);
          break;
        case "iframe":
        case "object":
        case "embed":
          Oe("load", t);
          break;
        case "video":
        case "audio":
          for (n = 0; n < Xs.length; n++) Oe(Xs[n], t);
          break;
        case "source":
          Oe("error", t);
          break;
        case "img":
        case "image":
        case "link":
          Oe("error", t), Oe("load", t);
          break;
        case "details":
          Oe("toggle", t);
          break;
        case "input":
          Oe("invalid", t), od(t, s.value, s.defaultValue, s.checked, s.defaultChecked, s.type, s.name, true), Nl(t);
          break;
        case "select":
          Oe("invalid", t);
          break;
        case "textarea":
          Oe("invalid", t), ud(t, s.value, s.defaultValue, s.children), Nl(t);
      }
      n = s.children, typeof n != "string" && typeof n != "number" && typeof n != "bigint" || t.textContent === "" + n || s.suppressHydrationWarning === true || nm(t.textContent, n) ? (s.popover != null && (Oe("beforetoggle", t), Oe("toggle", t)), s.onScroll != null && Oe("scroll", t), s.onScrollEnd != null && Oe("scrollend", t), s.onClick != null && (t.onclick = xr), t = true) : t = false, t || Da(e);
    }
    function Kd(e) {
      for (wt = e.return; wt; ) switch (wt.tag) {
        case 3:
        case 27:
          un = true;
          return;
        case 5:
        case 13:
          un = false;
          return;
        default:
          wt = wt.return;
      }
    }
    function bs(e) {
      if (e !== wt) return false;
      if (!Re) return Kd(e), Re = true, false;
      var t = false, n;
      if ((n = e.tag !== 3 && e.tag !== 27) && ((n = e.tag === 5) && (n = e.type, n = !(n !== "form" && n !== "button") || ru(e.type, e.memoizedProps)), n = !n), n && (t = true), t && mt && Da(e), Kd(e), e.tag === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(r(317));
        e: {
          for (e = e.nextSibling, t = 0; e; ) {
            if (e.nodeType === 8) if (n = e.data, n === "/$") {
              if (t === 0) {
                mt = ln(e.nextSibling);
                break e;
              }
              t--;
            } else n !== "$" && n !== "$!" && n !== "$?" || t++;
            e = e.nextSibling;
          }
          mt = null;
        }
      } else mt = wt ? ln(e.stateNode.nextSibling) : null;
      return true;
    }
    function vs() {
      mt = wt = null, Re = false;
    }
    function xs(e) {
      an === null ? an = [
        e
      ] : an.push(e);
    }
    var Ss = Error(r(460)), $d = Error(r(474)), Go = {
      then: function() {
      }
    };
    function Jd(e) {
      return e = e.status, e === "fulfilled" || e === "rejected";
    }
    function Vl() {
    }
    function Id(e, t, n) {
      switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(Vl, Vl), t = n), t.status) {
        case "fulfilled":
          return t.value;
        case "rejected":
          throw e = t.reason, e === Ss ? Error(r(483)) : e;
        default:
          if (typeof t.status == "string") t.then(Vl, Vl);
          else {
            if (e = ke, e !== null && 100 < e.shellSuspendCounter) throw Error(r(482));
            e = t, e.status = "pending", e.then(function(s) {
              if (t.status === "pending") {
                var o = t;
                o.status = "fulfilled", o.value = s;
              }
            }, function(s) {
              if (t.status === "pending") {
                var o = t;
                o.status = "rejected", o.reason = s;
              }
            });
          }
          switch (t.status) {
            case "fulfilled":
              return t.value;
            case "rejected":
              throw e = t.reason, e === Ss ? Error(r(483)) : e;
          }
          throw ws = t, Ss;
      }
    }
    var ws = null;
    function Wd() {
      if (ws === null) throw Error(r(459));
      var e = ws;
      return ws = null, e;
    }
    var xi = null, Es = 0;
    function Xl(e) {
      var t = Es;
      return Es += 1, xi === null && (xi = []), Id(xi, e, t);
    }
    function As(e, t) {
      t = t.props.ref, e.ref = t !== void 0 ? t : null;
    }
    function Fl(e, t) {
      throw t.$$typeof === f ? Error(r(525)) : (e = Object.prototype.toString.call(t), Error(r(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e)));
    }
    function Pd(e) {
      var t = e._init;
      return t(e._payload);
    }
    function eh(e) {
      function t(M, _) {
        if (e) {
          var U = M.deletions;
          U === null ? (M.deletions = [
            _
          ], M.flags |= 16) : U.push(_);
        }
      }
      function n(M, _) {
        if (!e) return null;
        for (; _ !== null; ) t(M, _), _ = _.sibling;
        return null;
      }
      function s(M) {
        for (var _ = /* @__PURE__ */ new Map(); M !== null; ) M.key !== null ? _.set(M.key, M) : _.set(M.index, M), M = M.sibling;
        return _;
      }
      function o(M, _) {
        return M = ua(M, _), M.index = 0, M.sibling = null, M;
      }
      function u(M, _, U) {
        return M.index = U, e ? (U = M.alternate, U !== null ? (U = U.index, U < _ ? (M.flags |= 33554434, _) : U) : (M.flags |= 33554434, _)) : (M.flags |= 1048576, _);
      }
      function m(M) {
        return e && M.alternate === null && (M.flags |= 33554434), M;
      }
      function w(M, _, U, Z) {
        return _ === null || _.tag !== 6 ? (_ = kc(U, M.mode, Z), _.return = M, _) : (_ = o(_, U), _.return = M, _);
      }
      function T(M, _, U, Z) {
        var ie = U.type;
        return ie === g ? V(M, _, U.props.children, Z, U.key) : _ !== null && (_.elementType === ie || typeof ie == "object" && ie !== null && ie.$$typeof === B && Pd(ie) === _.type) ? (_ = o(_, U.props), As(_, U), _.return = M, _) : (_ = cr(U.type, U.key, U.props, null, M.mode, Z), As(_, U), _.return = M, _);
      }
      function N(M, _, U, Z) {
        return _ === null || _.tag !== 4 || _.stateNode.containerInfo !== U.containerInfo || _.stateNode.implementation !== U.implementation ? (_ = Bc(U, M.mode, Z), _.return = M, _) : (_ = o(_, U.children || []), _.return = M, _);
      }
      function V(M, _, U, Z, ie) {
        return _ === null || _.tag !== 7 ? (_ = Va(U, M.mode, Z, ie), _.return = M, _) : (_ = o(_, U), _.return = M, _);
      }
      function $(M, _, U) {
        if (typeof _ == "string" && _ !== "" || typeof _ == "number" || typeof _ == "bigint") return _ = kc("" + _, M.mode, U), _.return = M, _;
        if (typeof _ == "object" && _ !== null) {
          switch (_.$$typeof) {
            case d:
              return U = cr(_.type, _.key, _.props, null, M.mode, U), As(U, _), U.return = M, U;
            case h:
              return _ = Bc(_, M.mode, U), _.return = M, _;
            case B:
              var Z = _._init;
              return _ = Z(_._payload), $(M, _, U);
          }
          if (gt(_) || ae(_)) return _ = Va(_, M.mode, U, null), _.return = M, _;
          if (typeof _.then == "function") return $(M, Xl(_), U);
          if (_.$$typeof === x) return $(M, lr(M, _), U);
          Fl(M, _);
        }
        return null;
      }
      function H(M, _, U, Z) {
        var ie = _ !== null ? _.key : null;
        if (typeof U == "string" && U !== "" || typeof U == "number" || typeof U == "bigint") return ie !== null ? null : w(M, _, "" + U, Z);
        if (typeof U == "object" && U !== null) {
          switch (U.$$typeof) {
            case d:
              return U.key === ie ? T(M, _, U, Z) : null;
            case h:
              return U.key === ie ? N(M, _, U, Z) : null;
            case B:
              return ie = U._init, U = ie(U._payload), H(M, _, U, Z);
          }
          if (gt(U) || ae(U)) return ie !== null ? null : V(M, _, U, Z, null);
          if (typeof U.then == "function") return H(M, _, Xl(U), Z);
          if (U.$$typeof === x) return H(M, _, lr(M, U), Z);
          Fl(M, U);
        }
        return null;
      }
      function G(M, _, U, Z, ie) {
        if (typeof Z == "string" && Z !== "" || typeof Z == "number" || typeof Z == "bigint") return M = M.get(U) || null, w(_, M, "" + Z, ie);
        if (typeof Z == "object" && Z !== null) {
          switch (Z.$$typeof) {
            case d:
              return M = M.get(Z.key === null ? U : Z.key) || null, T(_, M, Z, ie);
            case h:
              return M = M.get(Z.key === null ? U : Z.key) || null, N(_, M, Z, ie);
            case B:
              var xe = Z._init;
              return Z = xe(Z._payload), G(M, _, U, Z, ie);
          }
          if (gt(Z) || ae(Z)) return M = M.get(U) || null, V(_, M, Z, ie, null);
          if (typeof Z.then == "function") return G(M, _, U, Xl(Z), ie);
          if (Z.$$typeof === x) return G(M, _, U, lr(_, Z), ie);
          Fl(_, Z);
        }
        return null;
      }
      function re(M, _, U, Z) {
        for (var ie = null, xe = null, ce = _, fe = _ = 0, dt = null; ce !== null && fe < U.length; fe++) {
          ce.index > fe ? (dt = ce, ce = null) : dt = ce.sibling;
          var je = H(M, ce, U[fe], Z);
          if (je === null) {
            ce === null && (ce = dt);
            break;
          }
          e && ce && je.alternate === null && t(M, ce), _ = u(je, _, fe), xe === null ? ie = je : xe.sibling = je, xe = je, ce = dt;
        }
        if (fe === U.length) return n(M, ce), Re && Ma(M, fe), ie;
        if (ce === null) {
          for (; fe < U.length; fe++) ce = $(M, U[fe], Z), ce !== null && (_ = u(ce, _, fe), xe === null ? ie = ce : xe.sibling = ce, xe = ce);
          return Re && Ma(M, fe), ie;
        }
        for (ce = s(ce); fe < U.length; fe++) dt = G(ce, M, fe, U[fe], Z), dt !== null && (e && dt.alternate !== null && ce.delete(dt.key === null ? fe : dt.key), _ = u(dt, _, fe), xe === null ? ie = dt : xe.sibling = dt, xe = dt);
        return e && ce.forEach(function(ga) {
          return t(M, ga);
        }), Re && Ma(M, fe), ie;
      }
      function ye(M, _, U, Z) {
        if (U == null) throw Error(r(151));
        for (var ie = null, xe = null, ce = _, fe = _ = 0, dt = null, je = U.next(); ce !== null && !je.done; fe++, je = U.next()) {
          ce.index > fe ? (dt = ce, ce = null) : dt = ce.sibling;
          var ga = H(M, ce, je.value, Z);
          if (ga === null) {
            ce === null && (ce = dt);
            break;
          }
          e && ce && ga.alternate === null && t(M, ce), _ = u(ga, _, fe), xe === null ? ie = ga : xe.sibling = ga, xe = ga, ce = dt;
        }
        if (je.done) return n(M, ce), Re && Ma(M, fe), ie;
        if (ce === null) {
          for (; !je.done; fe++, je = U.next()) je = $(M, je.value, Z), je !== null && (_ = u(je, _, fe), xe === null ? ie = je : xe.sibling = je, xe = je);
          return Re && Ma(M, fe), ie;
        }
        for (ce = s(ce); !je.done; fe++, je = U.next()) je = G(ce, M, fe, je.value, Z), je !== null && (e && je.alternate !== null && ce.delete(je.key === null ? fe : je.key), _ = u(je, _, fe), xe === null ? ie = je : xe.sibling = je, xe = je);
        return e && ce.forEach(function(jv) {
          return t(M, jv);
        }), Re && Ma(M, fe), ie;
      }
      function Qe(M, _, U, Z) {
        if (typeof U == "object" && U !== null && U.type === g && U.key === null && (U = U.props.children), typeof U == "object" && U !== null) {
          switch (U.$$typeof) {
            case d:
              e: {
                for (var ie = U.key; _ !== null; ) {
                  if (_.key === ie) {
                    if (ie = U.type, ie === g) {
                      if (_.tag === 7) {
                        n(M, _.sibling), Z = o(_, U.props.children), Z.return = M, M = Z;
                        break e;
                      }
                    } else if (_.elementType === ie || typeof ie == "object" && ie !== null && ie.$$typeof === B && Pd(ie) === _.type) {
                      n(M, _.sibling), Z = o(_, U.props), As(Z, U), Z.return = M, M = Z;
                      break e;
                    }
                    n(M, _);
                    break;
                  } else t(M, _);
                  _ = _.sibling;
                }
                U.type === g ? (Z = Va(U.props.children, M.mode, Z, U.key), Z.return = M, M = Z) : (Z = cr(U.type, U.key, U.props, null, M.mode, Z), As(Z, U), Z.return = M, M = Z);
              }
              return m(M);
            case h:
              e: {
                for (ie = U.key; _ !== null; ) {
                  if (_.key === ie) if (_.tag === 4 && _.stateNode.containerInfo === U.containerInfo && _.stateNode.implementation === U.implementation) {
                    n(M, _.sibling), Z = o(_, U.children || []), Z.return = M, M = Z;
                    break e;
                  } else {
                    n(M, _);
                    break;
                  }
                  else t(M, _);
                  _ = _.sibling;
                }
                Z = Bc(U, M.mode, Z), Z.return = M, M = Z;
              }
              return m(M);
            case B:
              return ie = U._init, U = ie(U._payload), Qe(M, _, U, Z);
          }
          if (gt(U)) return re(M, _, U, Z);
          if (ae(U)) {
            if (ie = ae(U), typeof ie != "function") throw Error(r(150));
            return U = ie.call(U), ye(M, _, U, Z);
          }
          if (typeof U.then == "function") return Qe(M, _, Xl(U), Z);
          if (U.$$typeof === x) return Qe(M, _, lr(M, U), Z);
          Fl(M, U);
        }
        return typeof U == "string" && U !== "" || typeof U == "number" || typeof U == "bigint" ? (U = "" + U, _ !== null && _.tag === 6 ? (n(M, _.sibling), Z = o(_, U), Z.return = M, M = Z) : (n(M, _), Z = kc(U, M.mode, Z), Z.return = M, M = Z), m(M)) : n(M, _);
      }
      return function(M, _, U, Z) {
        try {
          Es = 0;
          var ie = Qe(M, _, U, Z);
          return xi = null, ie;
        } catch (ce) {
          if (ce === Ss) throw ce;
          var xe = Jt(29, ce, null, M.mode);
          return xe.lanes = Z, xe.return = M, xe;
        } finally {
        }
      };
    }
    var Ua = eh(true), th = eh(false), Si = Tt(null), Ql = Tt(0);
    function nh(e, t) {
      e = Bn, ze(Ql, e), ze(Si, t), Bn = e | t.baseLanes;
    }
    function Vo() {
      ze(Ql, Bn), ze(Si, Si.current);
    }
    function Xo() {
      Bn = Ql.current, Ge(Si), Ge(Ql);
    }
    var Zt = Tt(null), fn = null;
    function Pn(e) {
      var t = e.alternate;
      ze(it, it.current & 1), ze(Zt, e), fn === null && (t === null || Si.current !== null || t.memoizedState !== null) && (fn = e);
    }
    function ah(e) {
      if (e.tag === 22) {
        if (ze(it, it.current), ze(Zt, e), fn === null) {
          var t = e.alternate;
          t !== null && t.memoizedState !== null && (fn = e);
        }
      } else ea();
    }
    function ea() {
      ze(it, it.current), ze(Zt, Zt.current);
    }
    function Cn(e) {
      Ge(Zt), fn === e && (fn = null), Ge(it);
    }
    var it = Tt(0);
    function Zl(e) {
      for (var t = e; t !== null; ) {
        if (t.tag === 13) {
          var n = t.memoizedState;
          if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t;
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
          if ((t.flags & 128) !== 0) return t;
        } else if (t.child !== null) {
          t.child.return = t, t = t.child;
          continue;
        }
        if (t === e) break;
        for (; t.sibling === null; ) {
          if (t.return === null || t.return === e) return null;
          t = t.return;
        }
        t.sibling.return = t.return, t = t.sibling;
      }
      return null;
    }
    var bb = typeof AbortController < "u" ? AbortController : function() {
      var e = [], t = this.signal = {
        aborted: false,
        addEventListener: function(n, s) {
          e.push(s);
        }
      };
      this.abort = function() {
        t.aborted = true, e.forEach(function(n) {
          return n();
        });
      };
    }, vb = i.unstable_scheduleCallback, xb = i.unstable_NormalPriority, st = {
      $$typeof: x,
      Consumer: null,
      Provider: null,
      _currentValue: null,
      _currentValue2: null,
      _threadCount: 0
    };
    function Fo() {
      return {
        controller: new bb(),
        data: /* @__PURE__ */ new Map(),
        refCount: 0
      };
    }
    function Ts(e) {
      e.refCount--, e.refCount === 0 && vb(xb, function() {
        e.controller.abort();
      });
    }
    var Os = null, Qo = 0, wi = 0, Ei = null;
    function Sb(e, t) {
      if (Os === null) {
        var n = Os = [];
        Qo = 0, wi = Wc(), Ei = {
          status: "pending",
          value: void 0,
          then: function(s) {
            n.push(s);
          }
        };
      }
      return Qo++, t.then(ih, ih), t;
    }
    function ih() {
      if (--Qo === 0 && Os !== null) {
        Ei !== null && (Ei.status = "fulfilled");
        var e = Os;
        Os = null, wi = 0, Ei = null;
        for (var t = 0; t < e.length; t++) (0, e[t])();
      }
    }
    function wb(e, t) {
      var n = [], s = {
        status: "pending",
        value: null,
        reason: null,
        then: function(o) {
          n.push(o);
        }
      };
      return e.then(function() {
        s.status = "fulfilled", s.value = t;
        for (var o = 0; o < n.length; o++) (0, n[o])(t);
      }, function(o) {
        for (s.status = "rejected", s.reason = o, o = 0; o < n.length; o++) (0, n[o])(void 0);
      }), s;
    }
    var sh = W.S;
    W.S = function(e, t) {
      typeof t == "object" && t !== null && typeof t.then == "function" && Sb(e, t), sh !== null && sh(e, t);
    };
    var za = Tt(null);
    function Zo() {
      var e = za.current;
      return e !== null ? e : ke.pooledCache;
    }
    function Kl(e, t) {
      t === null ? ze(za, za.current) : ze(za, t.pool);
    }
    function lh() {
      var e = Zo();
      return e === null ? null : {
        parent: st._currentValue,
        pool: e
      };
    }
    var ta = 0, ve = null, Me = null, Ie = null, $l = false, Ai = false, ka = false, Jl = 0, Cs = 0, Ti = null, Eb = 0;
    function Ke() {
      throw Error(r(321));
    }
    function Ko(e, t) {
      if (t === null) return false;
      for (var n = 0; n < t.length && n < e.length; n++) if (!Ut(e[n], t[n])) return false;
      return true;
    }
    function $o(e, t, n, s, o, u) {
      return ta = u, ve = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, W.H = e === null || e.memoizedState === null ? Ba : na, ka = false, u = n(s, o), ka = false, Ai && (u = oh(t, n, s, o)), rh(e), u;
    }
    function rh(e) {
      W.H = dn;
      var t = Me !== null && Me.next !== null;
      if (ta = 0, Ie = Me = ve = null, $l = false, Cs = 0, Ti = null, t) throw Error(r(300));
      e === null || ut || (e = e.dependencies, e !== null && sr(e) && (ut = true));
    }
    function oh(e, t, n, s) {
      ve = e;
      var o = 0;
      do {
        if (Ai && (Ti = null), Cs = 0, Ai = false, 25 <= o) throw Error(r(301));
        if (o += 1, Ie = Me = null, e.updateQueue != null) {
          var u = e.updateQueue;
          u.lastEffect = null, u.events = null, u.stores = null, u.memoCache != null && (u.memoCache.index = 0);
        }
        W.H = Ha, u = t(n, s);
      } while (Ai);
      return u;
    }
    function Ab() {
      var e = W.H, t = e.useState()[0];
      return t = typeof t.then == "function" ? _s4(t) : t, e = e.useState()[0], (Me !== null ? Me.memoizedState : null) !== e && (ve.flags |= 1024), t;
    }
    function Jo() {
      var e = Jl !== 0;
      return Jl = 0, e;
    }
    function Io(e, t, n) {
      t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~n;
    }
    function Wo(e) {
      if ($l) {
        for (e = e.memoizedState; e !== null; ) {
          var t = e.queue;
          t !== null && (t.pending = null), e = e.next;
        }
        $l = false;
      }
      ta = 0, Ie = Me = ve = null, Ai = false, Cs = Jl = 0, Ti = null;
    }
    function _t9() {
      var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
      };
      return Ie === null ? ve.memoizedState = Ie = e : Ie = Ie.next = e, Ie;
    }
    function We() {
      if (Me === null) {
        var e = ve.alternate;
        e = e !== null ? e.memoizedState : null;
      } else e = Me.next;
      var t = Ie === null ? ve.memoizedState : Ie.next;
      if (t !== null) Ie = t, Me = e;
      else {
        if (e === null) throw ve.alternate === null ? Error(r(467)) : Error(r(310));
        Me = e, e = {
          memoizedState: Me.memoizedState,
          baseState: Me.baseState,
          baseQueue: Me.baseQueue,
          queue: Me.queue,
          next: null
        }, Ie === null ? ve.memoizedState = Ie = e : Ie = Ie.next = e;
      }
      return Ie;
    }
    var Il;
    Il = function() {
      return {
        lastEffect: null,
        events: null,
        stores: null,
        memoCache: null
      };
    };
    function _s4(e) {
      var t = Cs;
      return Cs += 1, Ti === null && (Ti = []), e = Id(Ti, e, t), t = ve, (Ie === null ? t.memoizedState : Ie.next) === null && (t = t.alternate, W.H = t === null || t.memoizedState === null ? Ba : na), e;
    }
    function Wl(e) {
      if (e !== null && typeof e == "object") {
        if (typeof e.then == "function") return _s4(e);
        if (e.$$typeof === x) return xt(e);
      }
      throw Error(r(438, String(e)));
    }
    function Po(e) {
      var t = null, n = ve.updateQueue;
      if (n !== null && (t = n.memoCache), t == null) {
        var s = ve.alternate;
        s !== null && (s = s.updateQueue, s !== null && (s = s.memoCache, s != null && (t = {
          data: s.data.map(function(o) {
            return o.slice();
          }),
          index: 0
        })));
      }
      if (t == null && (t = {
        data: [],
        index: 0
      }), n === null && (n = Il(), ve.updateQueue = n), n.memoCache = t, n = t.data[t.index], n === void 0) for (n = t.data[t.index] = Array(e), s = 0; s < e; s++) n[s] = I;
      return t.index++, n;
    }
    function _n9(e, t) {
      return typeof t == "function" ? t(e) : t;
    }
    function Pl(e) {
      var t = We();
      return ec(t, Me, e);
    }
    function ec(e, t, n) {
      var s = e.queue;
      if (s === null) throw Error(r(311));
      s.lastRenderedReducer = n;
      var o = e.baseQueue, u = s.pending;
      if (u !== null) {
        if (o !== null) {
          var m = o.next;
          o.next = u.next, u.next = m;
        }
        t.baseQueue = o = u, s.pending = null;
      }
      if (u = e.baseState, o === null) e.memoizedState = u;
      else {
        t = o.next;
        var w = m = null, T = null, N = t, V = false;
        do {
          var $ = N.lane & -536870913;
          if ($ !== N.lane ? (_e9 & $) === $ : (ta & $) === $) {
            var H = N.revertLane;
            if (H === 0) T !== null && (T = T.next = {
              lane: 0,
              revertLane: 0,
              action: N.action,
              hasEagerState: N.hasEagerState,
              eagerState: N.eagerState,
              next: null
            }), $ === wi && (V = true);
            else if ((ta & H) === H) {
              N = N.next, H === wi && (V = true);
              continue;
            } else $ = {
              lane: 0,
              revertLane: N.revertLane,
              action: N.action,
              hasEagerState: N.hasEagerState,
              eagerState: N.eagerState,
              next: null
            }, T === null ? (w = T = $, m = u) : T = T.next = $, ve.lanes |= H, fa |= H;
            $ = N.action, ka && n(u, $), u = N.hasEagerState ? N.eagerState : n(u, $);
          } else H = {
            lane: $,
            revertLane: N.revertLane,
            action: N.action,
            hasEagerState: N.hasEagerState,
            eagerState: N.eagerState,
            next: null
          }, T === null ? (w = T = H, m = u) : T = T.next = H, ve.lanes |= $, fa |= $;
          N = N.next;
        } while (N !== null && N !== t);
        if (T === null ? m = u : T.next = w, !Ut(u, e.memoizedState) && (ut = true, V && (n = Ei, n !== null))) throw n;
        e.memoizedState = u, e.baseState = m, e.baseQueue = T, s.lastRenderedState = u;
      }
      return o === null && (s.lanes = 0), [
        e.memoizedState,
        s.dispatch
      ];
    }
    function tc(e) {
      var t = We(), n = t.queue;
      if (n === null) throw Error(r(311));
      n.lastRenderedReducer = e;
      var s = n.dispatch, o = n.pending, u = t.memoizedState;
      if (o !== null) {
        n.pending = null;
        var m = o = o.next;
        do
          u = e(u, m.action), m = m.next;
        while (m !== o);
        Ut(u, t.memoizedState) || (ut = true), t.memoizedState = u, t.baseQueue === null && (t.baseState = u), n.lastRenderedState = u;
      }
      return [
        u,
        s
      ];
    }
    function ch(e, t, n) {
      var s = ve, o = We(), u = Re;
      if (u) {
        if (n === void 0) throw Error(r(407));
        n = n();
      } else n = t();
      var m = !Ut((Me || o).memoizedState, n);
      if (m && (o.memoizedState = n, ut = true), o = o.queue, ic(dh.bind(null, s, o, e), [
        e
      ]), o.getSnapshot !== t || m || Ie !== null && Ie.memoizedState.tag & 1) {
        if (s.flags |= 2048, Oi(9, fh.bind(null, s, o, n, t), {
          destroy: void 0
        }, null), ke === null) throw Error(r(349));
        u || (ta & 60) !== 0 || uh(s, t, n);
      }
      return n;
    }
    function uh(e, t, n) {
      e.flags |= 16384, e = {
        getSnapshot: t,
        value: n
      }, t = ve.updateQueue, t === null ? (t = Il(), ve.updateQueue = t, t.stores = [
        e
      ]) : (n = t.stores, n === null ? t.stores = [
        e
      ] : n.push(e));
    }
    function fh(e, t, n, s) {
      t.value = n, t.getSnapshot = s, hh(t) && mh(e);
    }
    function dh(e, t, n) {
      return n(function() {
        hh(t) && mh(e);
      });
    }
    function hh(e) {
      var t = e.getSnapshot;
      e = e.value;
      try {
        var n = t();
        return !Ut(e, n);
      } catch {
        return true;
      }
    }
    function mh(e) {
      var t = Wn(e, 2);
      t !== null && Et(t, e, 2);
    }
    function nc(e) {
      var t = _t9();
      if (typeof e == "function") {
        var n = e;
        if (e = n(), ka) {
          $n(true);
          try {
            n();
          } finally {
            $n(false);
          }
        }
      }
      return t.memoizedState = t.baseState = e, t.queue = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: _n9,
        lastRenderedState: e
      }, t;
    }
    function yh(e, t, n, s) {
      return e.baseState = n, ec(e, Me, typeof s == "function" ? s : _n9);
    }
    function Tb(e, t, n, s, o) {
      if (nr(e)) throw Error(r(485));
      if (e = t.action, e !== null) {
        var u = {
          payload: o,
          action: e,
          next: null,
          isTransition: true,
          status: "pending",
          value: null,
          reason: null,
          listeners: [],
          then: function(m) {
            u.listeners.push(m);
          }
        };
        W.T !== null ? n(true) : u.isTransition = false, s(u), n = t.pending, n === null ? (u.next = t.pending = u, ph(t, u)) : (u.next = n.next, t.pending = n.next = u);
      }
    }
    function ph(e, t) {
      var n = t.action, s = t.payload, o = e.state;
      if (t.isTransition) {
        var u = W.T, m = {};
        W.T = m;
        try {
          var w = n(o, s), T = W.S;
          T !== null && T(m, w), gh(e, t, w);
        } catch (N) {
          ac(e, t, N);
        } finally {
          W.T = u;
        }
      } else try {
        u = n(o, s), gh(e, t, u);
      } catch (N) {
        ac(e, t, N);
      }
    }
    function gh(e, t, n) {
      n !== null && typeof n == "object" && typeof n.then == "function" ? n.then(function(s) {
        bh(e, t, s);
      }, function(s) {
        return ac(e, t, s);
      }) : bh(e, t, n);
    }
    function bh(e, t, n) {
      t.status = "fulfilled", t.value = n, vh(t), e.state = n, t = e.pending, t !== null && (n = t.next, n === t ? e.pending = null : (n = n.next, t.next = n, ph(e, n)));
    }
    function ac(e, t, n) {
      var s = e.pending;
      if (e.pending = null, s !== null) {
        s = s.next;
        do
          t.status = "rejected", t.reason = n, vh(t), t = t.next;
        while (t !== s);
      }
      e.action = null;
    }
    function vh(e) {
      e = e.listeners;
      for (var t = 0; t < e.length; t++) (0, e[t])();
    }
    function xh(e, t) {
      return t;
    }
    function Sh(e, t) {
      if (Re) {
        var n = ke.formState;
        if (n !== null) {
          e: {
            var s = ve;
            if (Re) {
              if (mt) {
                t: {
                  for (var o = mt, u = un; o.nodeType !== 8; ) {
                    if (!u) {
                      o = null;
                      break t;
                    }
                    if (o = ln(o.nextSibling), o === null) {
                      o = null;
                      break t;
                    }
                  }
                  u = o.data, o = u === "F!" || u === "F" ? o : null;
                }
                if (o) {
                  mt = ln(o.nextSibling), s = o.data === "F!";
                  break e;
                }
              }
              Da(s);
            }
            s = false;
          }
          s && (t = n[0]);
        }
      }
      return n = _t9(), n.memoizedState = n.baseState = t, s = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: xh,
        lastRenderedState: t
      }, n.queue = s, n = Lh.bind(null, ve, s), s.dispatch = n, s = nc(false), u = cc.bind(null, ve, false, s.queue), s = _t9(), o = {
        state: t,
        dispatch: null,
        action: e,
        pending: null
      }, s.queue = o, n = Tb.bind(null, ve, o, u, n), o.dispatch = n, s.memoizedState = e, [
        t,
        n,
        false
      ];
    }
    function wh(e) {
      var t = We();
      return Eh(t, Me, e);
    }
    function Eh(e, t, n) {
      t = ec(e, t, xh)[0], e = Pl(_n9)[0], t = typeof t == "object" && t !== null && typeof t.then == "function" ? _s4(t) : t;
      var s = We(), o = s.queue, u = o.dispatch;
      return n !== s.memoizedState && (ve.flags |= 2048, Oi(9, Ob.bind(null, o, n), {
        destroy: void 0
      }, null)), [
        t,
        u,
        e
      ];
    }
    function Ob(e, t) {
      e.action = t;
    }
    function Ah(e) {
      var t = We(), n = Me;
      if (n !== null) return Eh(t, n, e);
      We(), t = t.memoizedState, n = We();
      var s = n.queue.dispatch;
      return n.memoizedState = e, [
        t,
        s,
        false
      ];
    }
    function Oi(e, t, n, s) {
      return e = {
        tag: e,
        create: t,
        inst: n,
        deps: s,
        next: null
      }, t = ve.updateQueue, t === null && (t = Il(), ve.updateQueue = t), n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (s = n.next, n.next = e, e.next = s, t.lastEffect = e), e;
    }
    function Th() {
      return We().memoizedState;
    }
    function er(e, t, n, s) {
      var o = _t9();
      ve.flags |= e, o.memoizedState = Oi(1 | t, n, {
        destroy: void 0
      }, s === void 0 ? null : s);
    }
    function tr(e, t, n, s) {
      var o = We();
      s = s === void 0 ? null : s;
      var u = o.memoizedState.inst;
      Me !== null && s !== null && Ko(s, Me.memoizedState.deps) ? o.memoizedState = Oi(t, n, u, s) : (ve.flags |= e, o.memoizedState = Oi(1 | t, n, u, s));
    }
    function Oh(e, t) {
      er(8390656, 8, e, t);
    }
    function ic(e, t) {
      tr(2048, 8, e, t);
    }
    function Ch(e, t) {
      return tr(4, 2, e, t);
    }
    function _h(e, t) {
      return tr(4, 4, e, t);
    }
    function Nh(e, t) {
      if (typeof t == "function") {
        e = e();
        var n = t(e);
        return function() {
          typeof n == "function" ? n() : t(null);
        };
      }
      if (t != null) return e = e(), t.current = e, function() {
        t.current = null;
      };
    }
    function Rh(e, t, n) {
      n = n != null ? n.concat([
        e
      ]) : null, tr(4, 4, Nh.bind(null, t, e), n);
    }
    function sc() {
    }
    function jh(e, t) {
      var n = We();
      t = t === void 0 ? null : t;
      var s = n.memoizedState;
      return t !== null && Ko(t, s[1]) ? s[0] : (n.memoizedState = [
        e,
        t
      ], e);
    }
    function Mh(e, t) {
      var n = We();
      t = t === void 0 ? null : t;
      var s = n.memoizedState;
      if (t !== null && Ko(t, s[1])) return s[0];
      if (s = e(), ka) {
        $n(true);
        try {
          e();
        } finally {
          $n(false);
        }
      }
      return n.memoizedState = [
        s,
        t
      ], s;
    }
    function lc(e, t, n) {
      return n === void 0 || (ta & 1073741824) !== 0 ? e.memoizedState = t : (e.memoizedState = n, e = U0(), ve.lanes |= e, fa |= e, n);
    }
    function Dh(e, t, n, s) {
      return Ut(n, t) ? n : Si.current !== null ? (e = lc(e, n, s), Ut(e, t) || (ut = true), e) : (ta & 42) === 0 ? (ut = true, e.memoizedState = n) : (e = U0(), ve.lanes |= e, fa |= e, t);
    }
    function Uh(e, t, n, s, o) {
      var u = Ee.p;
      Ee.p = u !== 0 && 8 > u ? u : 8;
      var m = W.T, w = {};
      W.T = w, cc(e, false, t, n);
      try {
        var T = o(), N = W.S;
        if (N !== null && N(w, T), T !== null && typeof T == "object" && typeof T.then == "function") {
          var V = wb(T, s);
          Ns(e, t, V, Ht(e));
        } else Ns(e, t, s, Ht(e));
      } catch ($) {
        Ns(e, t, {
          then: function() {
          },
          status: "rejected",
          reason: $
        }, Ht());
      } finally {
        Ee.p = u, W.T = m;
      }
    }
    function Cb() {
    }
    function rc(e, t, n, s) {
      if (e.tag !== 5) throw Error(r(476));
      var o = zh(e).queue;
      Uh(e, o, t, bt, n === null ? Cb : function() {
        return kh(e), n(s);
      });
    }
    function zh(e) {
      var t = e.memoizedState;
      if (t !== null) return t;
      t = {
        memoizedState: bt,
        baseState: bt,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: _n9,
          lastRenderedState: bt
        },
        next: null
      };
      var n = {};
      return t.next = {
        memoizedState: n,
        baseState: n,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: _n9,
          lastRenderedState: n
        },
        next: null
      }, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t;
    }
    function kh(e) {
      var t = zh(e).next.queue;
      Ns(e, t, {}, Ht());
    }
    function oc() {
      return xt($s);
    }
    function Bh() {
      return We().memoizedState;
    }
    function Hh() {
      return We().memoizedState;
    }
    function _b(e) {
      for (var t = e.return; t !== null; ) {
        switch (t.tag) {
          case 24:
          case 3:
            var n = Ht();
            e = sa(n);
            var s = la(t, e, n);
            s !== null && (Et(s, t, n), Ms(s, t, n)), t = {
              cache: Fo()
            }, e.payload = t;
            return;
        }
        t = t.return;
      }
    }
    function Nb(e, t, n) {
      var s = Ht();
      n = {
        lane: s,
        revertLane: 0,
        action: n,
        hasEagerState: false,
        eagerState: null,
        next: null
      }, nr(e) ? qh(t, n) : (n = Ho(e, t, n, s), n !== null && (Et(n, e, s), Yh(n, t, s)));
    }
    function Lh(e, t, n) {
      var s = Ht();
      Ns(e, t, n, s);
    }
    function Ns(e, t, n, s) {
      var o = {
        lane: s,
        revertLane: 0,
        action: n,
        hasEagerState: false,
        eagerState: null,
        next: null
      };
      if (nr(e)) qh(t, o);
      else {
        var u = e.alternate;
        if (e.lanes === 0 && (u === null || u.lanes === 0) && (u = t.lastRenderedReducer, u !== null)) try {
          var m = t.lastRenderedState, w = u(m, n);
          if (o.hasEagerState = true, o.eagerState = w, Ut(w, m)) return Ll(e, t, o, 0), ke === null && Hl(), false;
        } catch {
        } finally {
        }
        if (n = Ho(e, t, o, s), n !== null) return Et(n, e, s), Yh(n, t, s), true;
      }
      return false;
    }
    function cc(e, t, n, s) {
      if (s = {
        lane: 2,
        revertLane: Wc(),
        action: s,
        hasEagerState: false,
        eagerState: null,
        next: null
      }, nr(e)) {
        if (t) throw Error(r(479));
      } else t = Ho(e, n, s, 2), t !== null && Et(t, e, 2);
    }
    function nr(e) {
      var t = e.alternate;
      return e === ve || t !== null && t === ve;
    }
    function qh(e, t) {
      Ai = $l = true;
      var n = e.pending;
      n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t;
    }
    function Yh(e, t, n) {
      if ((n & 4194176) !== 0) {
        var s = t.lanes;
        s &= e.pendingLanes, n |= s, t.lanes = n, Wf(e, n);
      }
    }
    var dn = {
      readContext: xt,
      use: Wl,
      useCallback: Ke,
      useContext: Ke,
      useEffect: Ke,
      useImperativeHandle: Ke,
      useLayoutEffect: Ke,
      useInsertionEffect: Ke,
      useMemo: Ke,
      useReducer: Ke,
      useRef: Ke,
      useState: Ke,
      useDebugValue: Ke,
      useDeferredValue: Ke,
      useTransition: Ke,
      useSyncExternalStore: Ke,
      useId: Ke
    };
    dn.useCacheRefresh = Ke, dn.useMemoCache = Ke, dn.useHostTransitionStatus = Ke, dn.useFormState = Ke, dn.useActionState = Ke, dn.useOptimistic = Ke;
    var Ba = {
      readContext: xt,
      use: Wl,
      useCallback: function(e, t) {
        return _t9().memoizedState = [
          e,
          t === void 0 ? null : t
        ], e;
      },
      useContext: xt,
      useEffect: Oh,
      useImperativeHandle: function(e, t, n) {
        n = n != null ? n.concat([
          e
        ]) : null, er(4194308, 4, Nh.bind(null, t, e), n);
      },
      useLayoutEffect: function(e, t) {
        return er(4194308, 4, e, t);
      },
      useInsertionEffect: function(e, t) {
        er(4, 2, e, t);
      },
      useMemo: function(e, t) {
        var n = _t9();
        t = t === void 0 ? null : t;
        var s = e();
        if (ka) {
          $n(true);
          try {
            e();
          } finally {
            $n(false);
          }
        }
        return n.memoizedState = [
          s,
          t
        ], s;
      },
      useReducer: function(e, t, n) {
        var s = _t9();
        if (n !== void 0) {
          var o = n(t);
          if (ka) {
            $n(true);
            try {
              n(t);
            } finally {
              $n(false);
            }
          }
        } else o = t;
        return s.memoizedState = s.baseState = o, e = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: e,
          lastRenderedState: o
        }, s.queue = e, e = e.dispatch = Nb.bind(null, ve, e), [
          s.memoizedState,
          e
        ];
      },
      useRef: function(e) {
        var t = _t9();
        return e = {
          current: e
        }, t.memoizedState = e;
      },
      useState: function(e) {
        e = nc(e);
        var t = e.queue, n = Lh.bind(null, ve, t);
        return t.dispatch = n, [
          e.memoizedState,
          n
        ];
      },
      useDebugValue: sc,
      useDeferredValue: function(e, t) {
        var n = _t9();
        return lc(n, e, t);
      },
      useTransition: function() {
        var e = nc(false);
        return e = Uh.bind(null, ve, e.queue, true, false), _t9().memoizedState = e, [
          false,
          e
        ];
      },
      useSyncExternalStore: function(e, t, n) {
        var s = ve, o = _t9();
        if (Re) {
          if (n === void 0) throw Error(r(407));
          n = n();
        } else {
          if (n = t(), ke === null) throw Error(r(349));
          (_e9 & 60) !== 0 || uh(s, t, n);
        }
        o.memoizedState = n;
        var u = {
          value: n,
          getSnapshot: t
        };
        return o.queue = u, Oh(dh.bind(null, s, u, e), [
          e
        ]), s.flags |= 2048, Oi(9, fh.bind(null, s, u, n, t), {
          destroy: void 0
        }, null), n;
      },
      useId: function() {
        var e = _t9(), t = ke.identifierPrefix;
        if (Re) {
          var n = On, s = Tn;
          n = (s & ~(1 << 32 - Dt(s) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = Jl++, 0 < n && (t += "H" + n.toString(32)), t += ":";
        } else n = Eb++, t = ":" + t + "r" + n.toString(32) + ":";
        return e.memoizedState = t;
      },
      useCacheRefresh: function() {
        return _t9().memoizedState = _b.bind(null, ve);
      }
    };
    Ba.useMemoCache = Po, Ba.useHostTransitionStatus = oc, Ba.useFormState = Sh, Ba.useActionState = Sh, Ba.useOptimistic = function(e) {
      var t = _t9();
      t.memoizedState = t.baseState = e;
      var n = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: null,
        lastRenderedState: null
      };
      return t.queue = n, t = cc.bind(null, ve, true, n), n.dispatch = t, [
        e,
        t
      ];
    };
    var na = {
      readContext: xt,
      use: Wl,
      useCallback: jh,
      useContext: xt,
      useEffect: ic,
      useImperativeHandle: Rh,
      useInsertionEffect: Ch,
      useLayoutEffect: _h,
      useMemo: Mh,
      useReducer: Pl,
      useRef: Th,
      useState: function() {
        return Pl(_n9);
      },
      useDebugValue: sc,
      useDeferredValue: function(e, t) {
        var n = We();
        return Dh(n, Me.memoizedState, e, t);
      },
      useTransition: function() {
        var e = Pl(_n9)[0], t = We().memoizedState;
        return [
          typeof e == "boolean" ? e : _s4(e),
          t
        ];
      },
      useSyncExternalStore: ch,
      useId: Bh
    };
    na.useCacheRefresh = Hh, na.useMemoCache = Po, na.useHostTransitionStatus = oc, na.useFormState = wh, na.useActionState = wh, na.useOptimistic = function(e, t) {
      var n = We();
      return yh(n, Me, e, t);
    };
    var Ha = {
      readContext: xt,
      use: Wl,
      useCallback: jh,
      useContext: xt,
      useEffect: ic,
      useImperativeHandle: Rh,
      useInsertionEffect: Ch,
      useLayoutEffect: _h,
      useMemo: Mh,
      useReducer: tc,
      useRef: Th,
      useState: function() {
        return tc(_n9);
      },
      useDebugValue: sc,
      useDeferredValue: function(e, t) {
        var n = We();
        return Me === null ? lc(n, e, t) : Dh(n, Me.memoizedState, e, t);
      },
      useTransition: function() {
        var e = tc(_n9)[0], t = We().memoizedState;
        return [
          typeof e == "boolean" ? e : _s4(e),
          t
        ];
      },
      useSyncExternalStore: ch,
      useId: Bh
    };
    Ha.useCacheRefresh = Hh, Ha.useMemoCache = Po, Ha.useHostTransitionStatus = oc, Ha.useFormState = Ah, Ha.useActionState = Ah, Ha.useOptimistic = function(e, t) {
      var n = We();
      return Me !== null ? yh(n, Me, e, t) : (n.baseState = e, [
        e,
        n.queue.dispatch
      ]);
    };
    function uc(e, t, n, s) {
      t = e.memoizedState, n = n(s, t), n = n == null ? t : P({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n);
    }
    var fc = {
      isMounted: function(e) {
        return (e = e._reactInternals) ? J(e) === e : false;
      },
      enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var s = Ht(), o = sa(s);
        o.payload = t, n != null && (o.callback = n), t = la(e, o, s), t !== null && (Et(t, e, s), Ms(t, e, s));
      },
      enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var s = Ht(), o = sa(s);
        o.tag = 1, o.payload = t, n != null && (o.callback = n), t = la(e, o, s), t !== null && (Et(t, e, s), Ms(t, e, s));
      },
      enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = Ht(), s = sa(n);
        s.tag = 2, t != null && (s.callback = t), t = la(e, s, n), t !== null && (Et(t, e, n), Ms(t, e, n));
      }
    };
    function Gh(e, t, n, s, o, u, m) {
      return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(s, u, m) : t.prototype && t.prototype.isPureReactComponent ? !ps(n, s) || !ps(o, u) : true;
    }
    function Vh(e, t, n, s) {
      e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, s), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, s), t.state !== e && fc.enqueueReplaceState(t, t.state, null);
    }
    function La(e, t) {
      var n = t;
      if ("ref" in t) {
        n = {};
        for (var s in t) s !== "ref" && (n[s] = t[s]);
      }
      if (e = e.defaultProps) {
        n === t && (n = P({}, n));
        for (var o in e) n[o] === void 0 && (n[o] = e[o]);
      }
      return n;
    }
    var ar = typeof reportError == "function" ? reportError : function(e) {
      if (typeof window == "object" && typeof window.ErrorEvent == "function") {
        var t = new window.ErrorEvent("error", {
          bubbles: true,
          cancelable: true,
          message: typeof e == "object" && e !== null && typeof e.message == "string" ? String(e.message) : String(e),
          error: e
        });
        if (!window.dispatchEvent(t)) return;
      } else if (typeof process == "object" && typeof process.emit == "function") {
        process.emit("uncaughtException", e);
        return;
      }
      console.error(e);
    };
    function Xh(e) {
      ar(e);
    }
    function Fh(e) {
      console.error(e);
    }
    function Qh(e) {
      ar(e);
    }
    function ir(e, t) {
      try {
        var n = e.onUncaughtError;
        n(t.value, {
          componentStack: t.stack
        });
      } catch (s) {
        setTimeout(function() {
          throw s;
        });
      }
    }
    function Zh(e, t, n) {
      try {
        var s = e.onCaughtError;
        s(n.value, {
          componentStack: n.stack,
          errorBoundary: t.tag === 1 ? t.stateNode : null
        });
      } catch (o) {
        setTimeout(function() {
          throw o;
        });
      }
    }
    function dc(e, t, n) {
      return n = sa(n), n.tag = 3, n.payload = {
        element: null
      }, n.callback = function() {
        ir(e, t);
      }, n;
    }
    function Kh(e) {
      return e = sa(e), e.tag = 3, e;
    }
    function $h(e, t, n, s) {
      var o = n.type.getDerivedStateFromError;
      if (typeof o == "function") {
        var u = s.value;
        e.payload = function() {
          return o(u);
        }, e.callback = function() {
          Zh(t, n, s);
        };
      }
      var m = n.stateNode;
      m !== null && typeof m.componentDidCatch == "function" && (e.callback = function() {
        Zh(t, n, s), typeof o != "function" && (da === null ? da = /* @__PURE__ */ new Set([
          this
        ]) : da.add(this));
        var w = s.stack;
        this.componentDidCatch(s.value, {
          componentStack: w !== null ? w : ""
        });
      });
    }
    function Rb(e, t, n, s, o) {
      if (n.flags |= 32768, s !== null && typeof s == "object" && typeof s.then == "function") {
        if (t = n.alternate, t !== null && js(t, n, o, true), n = Zt.current, n !== null) {
          switch (n.tag) {
            case 13:
              return fn === null ? Zc() : n.alternate === null && Fe === 0 && (Fe = 3), n.flags &= -257, n.flags |= 65536, n.lanes = o, s === Go ? n.flags |= 16384 : (t = n.updateQueue, t === null ? n.updateQueue = /* @__PURE__ */ new Set([
                s
              ]) : t.add(s), $c(e, s, o)), false;
            case 22:
              return n.flags |= 65536, s === Go ? n.flags |= 16384 : (t = n.updateQueue, t === null ? (t = {
                transitions: null,
                markerInstances: null,
                retryQueue: /* @__PURE__ */ new Set([
                  s
                ])
              }, n.updateQueue = t) : (n = t.retryQueue, n === null ? t.retryQueue = /* @__PURE__ */ new Set([
                s
              ]) : n.add(s)), $c(e, s, o)), false;
          }
          throw Error(r(435, n.tag));
        }
        return $c(e, s, o), Zc(), false;
      }
      if (Re) return t = Zt.current, t !== null ? ((t.flags & 65536) === 0 && (t.flags |= 256), t.flags |= 65536, t.lanes = o, s !== Yo && (e = Error(r(422), {
        cause: s
      }), xs(Xt(e, n)))) : (s !== Yo && (t = Error(r(423), {
        cause: s
      }), xs(Xt(t, n))), e = e.current.alternate, e.flags |= 65536, o &= -o, e.lanes |= o, s = Xt(s, n), o = dc(e.stateNode, s, o), Cc(e, o), Fe !== 4 && (Fe = 2)), false;
      var u = Error(r(520), {
        cause: s
      });
      if (u = Xt(u, n), qs === null ? qs = [
        u
      ] : qs.push(u), Fe !== 4 && (Fe = 2), t === null) return true;
      s = Xt(s, n), n = t;
      do {
        switch (n.tag) {
          case 3:
            return n.flags |= 65536, e = o & -o, n.lanes |= e, e = dc(n.stateNode, s, e), Cc(n, e), false;
          case 1:
            if (t = n.type, u = n.stateNode, (n.flags & 128) === 0 && (typeof t.getDerivedStateFromError == "function" || u !== null && typeof u.componentDidCatch == "function" && (da === null || !da.has(u)))) return n.flags |= 65536, o &= -o, n.lanes |= o, o = Kh(o), $h(o, e, n, s), Cc(n, o), false;
        }
        n = n.return;
      } while (n !== null);
      return false;
    }
    var Jh = Error(r(461)), ut = false;
    function yt(e, t, n, s) {
      t.child = e === null ? th(t, null, n, s) : Ua(t, e.child, n, s);
    }
    function Ih(e, t, n, s, o) {
      n = n.render;
      var u = t.ref;
      if ("ref" in s) {
        var m = {};
        for (var w in s) w !== "ref" && (m[w] = s[w]);
      } else m = s;
      return Ya(t), s = $o(e, t, n, m, u, o), w = Jo(), e !== null && !ut ? (Io(e, t, o), Nn(e, t, o)) : (Re && w && Lo(t), t.flags |= 1, yt(e, t, s, o), t.child);
    }
    function Wh(e, t, n, s, o) {
      if (e === null) {
        var u = n.type;
        return typeof u == "function" && !zc(u) && u.defaultProps === void 0 && n.compare === null ? (t.tag = 15, t.type = u, Ph(e, t, u, s, o)) : (e = cr(n.type, null, s, t, t.mode, o), e.ref = t.ref, e.return = t, t.child = e);
      }
      if (u = e.child, !Sc(e, o)) {
        var m = u.memoizedProps;
        if (n = n.compare, n = n !== null ? n : ps, n(m, s) && e.ref === t.ref) return Nn(e, t, o);
      }
      return t.flags |= 1, e = ua(u, s), e.ref = t.ref, e.return = t, t.child = e;
    }
    function Ph(e, t, n, s, o) {
      if (e !== null) {
        var u = e.memoizedProps;
        if (ps(u, s) && e.ref === t.ref) if (ut = false, t.pendingProps = s = u, Sc(e, o)) (e.flags & 131072) !== 0 && (ut = true);
        else return t.lanes = e.lanes, Nn(e, t, o);
      }
      return hc(e, t, n, s, o);
    }
    function e0(e, t, n) {
      var s = t.pendingProps, o = s.children, u = (t.stateNode._pendingVisibility & 2) !== 0, m = e !== null ? e.memoizedState : null;
      if (Rs(e, t), s.mode === "hidden" || u) {
        if ((t.flags & 128) !== 0) {
          if (s = m !== null ? m.baseLanes | n : n, e !== null) {
            for (o = t.child = e.child, u = 0; o !== null; ) u = u | o.lanes | o.childLanes, o = o.sibling;
            t.childLanes = u & ~s;
          } else t.childLanes = 0, t.child = null;
          return t0(e, t, s, n);
        }
        if ((n & 536870912) !== 0) t.memoizedState = {
          baseLanes: 0,
          cachePool: null
        }, e !== null && Kl(t, m !== null ? m.cachePool : null), m !== null ? nh(t, m) : Vo(), ah(t);
        else return t.lanes = t.childLanes = 536870912, t0(e, t, m !== null ? m.baseLanes | n : n, n);
      } else m !== null ? (Kl(t, m.cachePool), nh(t, m), ea(), t.memoizedState = null) : (e !== null && Kl(t, null), Vo(), ea());
      return yt(e, t, o, n), t.child;
    }
    function t0(e, t, n, s) {
      var o = Zo();
      return o = o === null ? null : {
        parent: st._currentValue,
        pool: o
      }, t.memoizedState = {
        baseLanes: n,
        cachePool: o
      }, e !== null && Kl(t, null), Vo(), ah(t), e !== null && js(e, t, s, true), null;
    }
    function Rs(e, t) {
      var n = t.ref;
      if (n === null) e !== null && e.ref !== null && (t.flags |= 2097664);
      else {
        if (typeof n != "function" && typeof n != "object") throw Error(r(284));
        (e === null || e.ref !== n) && (t.flags |= 2097664);
      }
    }
    function hc(e, t, n, s, o) {
      return Ya(t), n = $o(e, t, n, s, void 0, o), s = Jo(), e !== null && !ut ? (Io(e, t, o), Nn(e, t, o)) : (Re && s && Lo(t), t.flags |= 1, yt(e, t, n, o), t.child);
    }
    function n0(e, t, n, s, o, u) {
      return Ya(t), t.updateQueue = null, n = oh(t, s, n, o), rh(e), s = Jo(), e !== null && !ut ? (Io(e, t, u), Nn(e, t, u)) : (Re && s && Lo(t), t.flags |= 1, yt(e, t, n, u), t.child);
    }
    function a0(e, t, n, s, o) {
      if (Ya(t), t.stateNode === null) {
        var u = gi, m = n.contextType;
        typeof m == "object" && m !== null && (u = xt(m)), u = new n(s, u), t.memoizedState = u.state !== null && u.state !== void 0 ? u.state : null, u.updater = fc, t.stateNode = u, u._reactInternals = t, u = t.stateNode, u.props = s, u.state = t.memoizedState, u.refs = {}, Tc(t), m = n.contextType, u.context = typeof m == "object" && m !== null ? xt(m) : gi, u.state = t.memoizedState, m = n.getDerivedStateFromProps, typeof m == "function" && (uc(t, n, m, s), u.state = t.memoizedState), typeof n.getDerivedStateFromProps == "function" || typeof u.getSnapshotBeforeUpdate == "function" || typeof u.UNSAFE_componentWillMount != "function" && typeof u.componentWillMount != "function" || (m = u.state, typeof u.componentWillMount == "function" && u.componentWillMount(), typeof u.UNSAFE_componentWillMount == "function" && u.UNSAFE_componentWillMount(), m !== u.state && fc.enqueueReplaceState(u, u.state, null), Us(t, s, u, o), Ds(), u.state = t.memoizedState), typeof u.componentDidMount == "function" && (t.flags |= 4194308), s = true;
      } else if (e === null) {
        u = t.stateNode;
        var w = t.memoizedProps, T = La(n, w);
        u.props = T;
        var N = u.context, V = n.contextType;
        m = gi, typeof V == "object" && V !== null && (m = xt(V));
        var $ = n.getDerivedStateFromProps;
        V = typeof $ == "function" || typeof u.getSnapshotBeforeUpdate == "function", w = t.pendingProps !== w, V || typeof u.UNSAFE_componentWillReceiveProps != "function" && typeof u.componentWillReceiveProps != "function" || (w || N !== m) && Vh(t, u, s, m), ia = false;
        var H = t.memoizedState;
        u.state = H, Us(t, s, u, o), Ds(), N = t.memoizedState, w || H !== N || ia ? (typeof $ == "function" && (uc(t, n, $, s), N = t.memoizedState), (T = ia || Gh(t, n, T, s, H, N, m)) ? (V || typeof u.UNSAFE_componentWillMount != "function" && typeof u.componentWillMount != "function" || (typeof u.componentWillMount == "function" && u.componentWillMount(), typeof u.UNSAFE_componentWillMount == "function" && u.UNSAFE_componentWillMount()), typeof u.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof u.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = s, t.memoizedState = N), u.props = s, u.state = N, u.context = m, s = T) : (typeof u.componentDidMount == "function" && (t.flags |= 4194308), s = false);
      } else {
        u = t.stateNode, Oc(e, t), m = t.memoizedProps, V = La(n, m), u.props = V, $ = t.pendingProps, H = u.context, N = n.contextType, T = gi, typeof N == "object" && N !== null && (T = xt(N)), w = n.getDerivedStateFromProps, (N = typeof w == "function" || typeof u.getSnapshotBeforeUpdate == "function") || typeof u.UNSAFE_componentWillReceiveProps != "function" && typeof u.componentWillReceiveProps != "function" || (m !== $ || H !== T) && Vh(t, u, s, T), ia = false, H = t.memoizedState, u.state = H, Us(t, s, u, o), Ds();
        var G = t.memoizedState;
        m !== $ || H !== G || ia || e !== null && e.dependencies !== null && sr(e.dependencies) ? (typeof w == "function" && (uc(t, n, w, s), G = t.memoizedState), (V = ia || Gh(t, n, V, s, H, G, T) || e !== null && e.dependencies !== null && sr(e.dependencies)) ? (N || typeof u.UNSAFE_componentWillUpdate != "function" && typeof u.componentWillUpdate != "function" || (typeof u.componentWillUpdate == "function" && u.componentWillUpdate(s, G, T), typeof u.UNSAFE_componentWillUpdate == "function" && u.UNSAFE_componentWillUpdate(s, G, T)), typeof u.componentDidUpdate == "function" && (t.flags |= 4), typeof u.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof u.componentDidUpdate != "function" || m === e.memoizedProps && H === e.memoizedState || (t.flags |= 4), typeof u.getSnapshotBeforeUpdate != "function" || m === e.memoizedProps && H === e.memoizedState || (t.flags |= 1024), t.memoizedProps = s, t.memoizedState = G), u.props = s, u.state = G, u.context = T, s = V) : (typeof u.componentDidUpdate != "function" || m === e.memoizedProps && H === e.memoizedState || (t.flags |= 4), typeof u.getSnapshotBeforeUpdate != "function" || m === e.memoizedProps && H === e.memoizedState || (t.flags |= 1024), s = false);
      }
      return u = s, Rs(e, t), s = (t.flags & 128) !== 0, u || s ? (u = t.stateNode, n = s && typeof n.getDerivedStateFromError != "function" ? null : u.render(), t.flags |= 1, e !== null && s ? (t.child = Ua(t, e.child, null, o), t.child = Ua(t, null, n, o)) : yt(e, t, n, o), t.memoizedState = u.state, e = t.child) : e = Nn(e, t, o), e;
    }
    function i0(e, t, n, s) {
      return vs(), t.flags |= 256, yt(e, t, n, s), t.child;
    }
    var mc = {
      dehydrated: null,
      treeContext: null,
      retryLane: 0
    };
    function yc(e) {
      return {
        baseLanes: e,
        cachePool: lh()
      };
    }
    function pc(e, t, n) {
      return e = e !== null ? e.childLanes & ~n : 0, t && (e |= It), e;
    }
    function s0(e, t, n) {
      var s = t.pendingProps, o = false, u = (t.flags & 128) !== 0, m;
      if ((m = u) || (m = e !== null && e.memoizedState === null ? false : (it.current & 2) !== 0), m && (o = true, t.flags &= -129), m = (t.flags & 32) !== 0, t.flags &= -33, e === null) {
        if (Re) {
          if (o ? Pn(t) : ea(), Re) {
            var w = mt, T;
            if (T = w) {
              e: {
                for (T = w, w = un; T.nodeType !== 8; ) {
                  if (!w) {
                    w = null;
                    break e;
                  }
                  if (T = ln(T.nextSibling), T === null) {
                    w = null;
                    break e;
                  }
                }
                w = T;
              }
              w !== null ? (t.memoizedState = {
                dehydrated: w,
                treeContext: ja !== null ? {
                  id: Tn,
                  overflow: On
                } : null,
                retryLane: 536870912
              }, T = Jt(18, null, null, 0), T.stateNode = w, T.return = t, t.child = T, wt = t, mt = null, T = true) : T = false;
            }
            T || Da(t);
          }
          if (w = t.memoizedState, w !== null && (w = w.dehydrated, w !== null)) return w.data === "$!" ? t.lanes = 16 : t.lanes = 536870912, null;
          Cn(t);
        }
        return w = s.children, s = s.fallback, o ? (ea(), o = t.mode, w = bc({
          mode: "hidden",
          children: w
        }, o), s = Va(s, o, n, null), w.return = t, s.return = t, w.sibling = s, t.child = w, o = t.child, o.memoizedState = yc(n), o.childLanes = pc(e, m, n), t.memoizedState = mc, s) : (Pn(t), gc(t, w));
      }
      if (T = e.memoizedState, T !== null && (w = T.dehydrated, w !== null)) {
        if (u) t.flags & 256 ? (Pn(t), t.flags &= -257, t = vc(e, t, n)) : t.memoizedState !== null ? (ea(), t.child = e.child, t.flags |= 128, t = null) : (ea(), o = s.fallback, w = t.mode, s = bc({
          mode: "visible",
          children: s.children
        }, w), o = Va(o, w, n, null), o.flags |= 2, s.return = t, o.return = t, s.sibling = o, t.child = s, Ua(t, e.child, null, n), s = t.child, s.memoizedState = yc(n), s.childLanes = pc(e, m, n), t.memoizedState = mc, t = o);
        else if (Pn(t), w.data === "$!") {
          if (m = w.nextSibling && w.nextSibling.dataset, m) var N = m.dgst;
          m = N, s = Error(r(419)), s.stack = "", s.digest = m, xs({
            value: s,
            source: null,
            stack: null
          }), t = vc(e, t, n);
        } else if (ut || js(e, t, n, false), m = (n & e.childLanes) !== 0, ut || m) {
          if (m = ke, m !== null) {
            if (s = n & -n, (s & 42) !== 0) s = 1;
            else switch (s) {
              case 2:
                s = 1;
                break;
              case 8:
                s = 4;
                break;
              case 32:
                s = 16;
                break;
              case 128:
              case 256:
              case 512:
              case 1024:
              case 2048:
              case 4096:
              case 8192:
              case 16384:
              case 32768:
              case 65536:
              case 131072:
              case 262144:
              case 524288:
              case 1048576:
              case 2097152:
              case 4194304:
              case 8388608:
              case 16777216:
              case 33554432:
                s = 64;
                break;
              case 268435456:
                s = 134217728;
                break;
              default:
                s = 0;
            }
            if (s = (s & (m.suspendedLanes | n)) !== 0 ? 0 : s, s !== 0 && s !== T.retryLane) throw T.retryLane = s, Wn(e, s), Et(m, e, s), Jh;
          }
          w.data === "$?" || Zc(), t = vc(e, t, n);
        } else w.data === "$?" ? (t.flags |= 128, t.child = e.child, t = Fb.bind(null, e), w._reactRetry = t, t = null) : (e = T.treeContext, mt = ln(w.nextSibling), wt = t, Re = true, an = null, un = false, e !== null && (Ft[Qt++] = Tn, Ft[Qt++] = On, Ft[Qt++] = ja, Tn = e.id, On = e.overflow, ja = t), t = gc(t, s.children), t.flags |= 4096);
        return t;
      }
      return o ? (ea(), o = s.fallback, w = t.mode, T = e.child, N = T.sibling, s = ua(T, {
        mode: "hidden",
        children: s.children
      }), s.subtreeFlags = T.subtreeFlags & 31457280, N !== null ? o = ua(N, o) : (o = Va(o, w, n, null), o.flags |= 2), o.return = t, s.return = t, s.sibling = o, t.child = s, s = o, o = t.child, w = e.child.memoizedState, w === null ? w = yc(n) : (T = w.cachePool, T !== null ? (N = st._currentValue, T = T.parent !== N ? {
        parent: N,
        pool: N
      } : T) : T = lh(), w = {
        baseLanes: w.baseLanes | n,
        cachePool: T
      }), o.memoizedState = w, o.childLanes = pc(e, m, n), t.memoizedState = mc, s) : (Pn(t), n = e.child, e = n.sibling, n = ua(n, {
        mode: "visible",
        children: s.children
      }), n.return = t, n.sibling = null, e !== null && (m = t.deletions, m === null ? (t.deletions = [
        e
      ], t.flags |= 16) : m.push(e)), t.child = n, t.memoizedState = null, n);
    }
    function gc(e, t) {
      return t = bc({
        mode: "visible",
        children: t
      }, e.mode), t.return = e, e.child = t;
    }
    function bc(e, t) {
      return j0(e, t, 0, null);
    }
    function vc(e, t, n) {
      return Ua(t, e.child, null, n), e = gc(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e;
    }
    function l0(e, t, n) {
      e.lanes |= t;
      var s = e.alternate;
      s !== null && (s.lanes |= t), Ec(e.return, t, n);
    }
    function xc(e, t, n, s, o) {
      var u = e.memoizedState;
      u === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: s,
        tail: n,
        tailMode: o
      } : (u.isBackwards = t, u.rendering = null, u.renderingStartTime = 0, u.last = s, u.tail = n, u.tailMode = o);
    }
    function r0(e, t, n) {
      var s = t.pendingProps, o = s.revealOrder, u = s.tail;
      if (yt(e, t, s.children, n), s = it.current, (s & 2) !== 0) s = s & 1 | 2, t.flags |= 128;
      else {
        if (e !== null && (e.flags & 128) !== 0) e: for (e = t.child; e !== null; ) {
          if (e.tag === 13) e.memoizedState !== null && l0(e, n, t);
          else if (e.tag === 19) l0(e, n, t);
          else if (e.child !== null) {
            e.child.return = e, e = e.child;
            continue;
          }
          if (e === t) break e;
          for (; e.sibling === null; ) {
            if (e.return === null || e.return === t) break e;
            e = e.return;
          }
          e.sibling.return = e.return, e = e.sibling;
        }
        s &= 1;
      }
      switch (ze(it, s), o) {
        case "forwards":
          for (n = t.child, o = null; n !== null; ) e = n.alternate, e !== null && Zl(e) === null && (o = n), n = n.sibling;
          n = o, n === null ? (o = t.child, t.child = null) : (o = n.sibling, n.sibling = null), xc(t, false, o, n, u);
          break;
        case "backwards":
          for (n = null, o = t.child, t.child = null; o !== null; ) {
            if (e = o.alternate, e !== null && Zl(e) === null) {
              t.child = o;
              break;
            }
            e = o.sibling, o.sibling = n, n = o, o = e;
          }
          xc(t, true, n, null, u);
          break;
        case "together":
          xc(t, false, null, null, void 0);
          break;
        default:
          t.memoizedState = null;
      }
      return t.child;
    }
    function Nn(e, t, n) {
      if (e !== null && (t.dependencies = e.dependencies), fa |= t.lanes, (n & t.childLanes) === 0) if (e !== null) {
        if (js(e, t, n, false), (n & t.childLanes) === 0) return null;
      } else return null;
      if (e !== null && t.child !== e.child) throw Error(r(153));
      if (t.child !== null) {
        for (e = t.child, n = ua(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null; ) e = e.sibling, n = n.sibling = ua(e, e.pendingProps), n.return = t;
        n.sibling = null;
      }
      return t.child;
    }
    function Sc(e, t) {
      return (e.lanes & t) !== 0 ? true : (e = e.dependencies, !!(e !== null && sr(e)));
    }
    function jb(e, t, n) {
      switch (t.tag) {
        case 3:
          ai(t, t.stateNode.containerInfo), aa(t, st, e.memoizedState.cache), vs();
          break;
        case 27:
        case 5:
          is(t);
          break;
        case 4:
          ai(t, t.stateNode.containerInfo);
          break;
        case 10:
          aa(t, t.type, t.memoizedProps.value);
          break;
        case 13:
          var s = t.memoizedState;
          if (s !== null) return s.dehydrated !== null ? (Pn(t), t.flags |= 128, null) : (n & t.child.childLanes) !== 0 ? s0(e, t, n) : (Pn(t), e = Nn(e, t, n), e !== null ? e.sibling : null);
          Pn(t);
          break;
        case 19:
          var o = (e.flags & 128) !== 0;
          if (s = (n & t.childLanes) !== 0, s || (js(e, t, n, false), s = (n & t.childLanes) !== 0), o) {
            if (s) return r0(e, t, n);
            t.flags |= 128;
          }
          if (o = t.memoizedState, o !== null && (o.rendering = null, o.tail = null, o.lastEffect = null), ze(it, it.current), s) break;
          return null;
        case 22:
        case 23:
          return t.lanes = 0, e0(e, t, n);
        case 24:
          aa(t, st, e.memoizedState.cache);
      }
      return Nn(e, t, n);
    }
    function o0(e, t, n) {
      if (e !== null) if (e.memoizedProps !== t.pendingProps) ut = true;
      else {
        if (!Sc(e, n) && (t.flags & 128) === 0) return ut = false, jb(e, t, n);
        ut = (e.flags & 131072) !== 0;
      }
      else ut = false, Re && (t.flags & 1048576) !== 0 && Qd(t, Gl, t.index);
      switch (t.lanes = 0, t.tag) {
        case 16:
          e: {
            e = t.pendingProps;
            var s = t.elementType, o = s._init;
            if (s = o(s._payload), t.type = s, typeof s == "function") zc(s) ? (e = La(s, e), t.tag = 1, t = a0(null, t, s, e, n)) : (t.tag = 0, t = hc(null, t, s, e, n));
            else {
              if (s != null) {
                if (o = s.$$typeof, o === v) {
                  t.tag = 11, t = Ih(null, t, s, e, n);
                  break e;
                } else if (o === L) {
                  t.tag = 14, t = Wh(null, t, s, e, n);
                  break e;
                }
              }
              throw t = le(s) || s, Error(r(306, t, ""));
            }
          }
          return t;
        case 0:
          return hc(e, t, t.type, t.pendingProps, n);
        case 1:
          return s = t.type, o = La(s, t.pendingProps), a0(e, t, s, o, n);
        case 3:
          e: {
            if (ai(t, t.stateNode.containerInfo), e === null) throw Error(r(387));
            var u = t.pendingProps;
            o = t.memoizedState, s = o.element, Oc(e, t), Us(t, u, null, n);
            var m = t.memoizedState;
            if (u = m.cache, aa(t, st, u), u !== o.cache && Ac(t, [
              st
            ], n, true), Ds(), u = m.element, o.isDehydrated) if (o = {
              element: u,
              isDehydrated: false,
              cache: m.cache
            }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
              t = i0(e, t, u, n);
              break e;
            } else if (u !== s) {
              s = Xt(Error(r(424)), t), xs(s), t = i0(e, t, u, n);
              break e;
            } else for (mt = ln(t.stateNode.containerInfo.firstChild), wt = t, Re = true, an = null, un = true, n = th(t, null, u, n), t.child = n; n; ) n.flags = n.flags & -3 | 4096, n = n.sibling;
            else {
              if (vs(), u === s) {
                t = Nn(e, t, n);
                break e;
              }
              yt(e, t, u, n);
            }
            t = t.child;
          }
          return t;
        case 26:
          return Rs(e, t), e === null ? (n = fm(t.type, null, t.pendingProps, null)) ? t.memoizedState = n : Re || (n = t.type, e = t.pendingProps, s = Sr(tn.current).createElement(n), s[vt] = t, s[Ot] = e, pt(s, n, e), ct(s), t.stateNode = s) : t.memoizedState = fm(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
        case 27:
          return is(t), e === null && Re && (s = t.stateNode = om(t.type, t.pendingProps, tn.current), wt = t, un = true, mt = ln(s.firstChild)), s = t.pendingProps.children, e !== null || Re ? yt(e, t, s, n) : t.child = Ua(t, null, s, n), Rs(e, t), t.child;
        case 5:
          return e === null && Re && ((o = s = mt) && (s = rv(s, t.type, t.pendingProps, un), s !== null ? (t.stateNode = s, wt = t, mt = ln(s.firstChild), un = false, o = true) : o = false), o || Da(t)), is(t), o = t.type, u = t.pendingProps, m = e !== null ? e.memoizedProps : null, s = u.children, ru(o, u) ? s = null : m !== null && ru(o, m) && (t.flags |= 32), t.memoizedState !== null && (o = $o(e, t, Ab, null, null, n), $s._currentValue = o), Rs(e, t), yt(e, t, s, n), t.child;
        case 6:
          return e === null && Re && ((e = n = mt) && (n = ov(n, t.pendingProps, un), n !== null ? (t.stateNode = n, wt = t, mt = null, e = true) : e = false), e || Da(t)), null;
        case 13:
          return s0(e, t, n);
        case 4:
          return ai(t, t.stateNode.containerInfo), s = t.pendingProps, e === null ? t.child = Ua(t, null, s, n) : yt(e, t, s, n), t.child;
        case 11:
          return Ih(e, t, t.type, t.pendingProps, n);
        case 7:
          return yt(e, t, t.pendingProps, n), t.child;
        case 8:
          return yt(e, t, t.pendingProps.children, n), t.child;
        case 12:
          return yt(e, t, t.pendingProps.children, n), t.child;
        case 10:
          return s = t.pendingProps, aa(t, t.type, s.value), yt(e, t, s.children, n), t.child;
        case 9:
          return o = t.type._context, s = t.pendingProps.children, Ya(t), o = xt(o), s = s(o), t.flags |= 1, yt(e, t, s, n), t.child;
        case 14:
          return Wh(e, t, t.type, t.pendingProps, n);
        case 15:
          return Ph(e, t, t.type, t.pendingProps, n);
        case 19:
          return r0(e, t, n);
        case 22:
          return e0(e, t, n);
        case 24:
          return Ya(t), s = xt(st), e === null ? (o = Zo(), o === null && (o = ke, u = Fo(), o.pooledCache = u, u.refCount++, u !== null && (o.pooledCacheLanes |= n), o = u), t.memoizedState = {
            parent: s,
            cache: o
          }, Tc(t), aa(t, st, o)) : ((e.lanes & n) !== 0 && (Oc(e, t), Us(t, null, null, n), Ds()), o = e.memoizedState, u = t.memoizedState, o.parent !== s ? (o = {
            parent: s,
            cache: s
          }, t.memoizedState = o, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = o), aa(t, st, s)) : (s = u.cache, aa(t, st, s), s !== o.cache && Ac(t, [
            st
          ], n, true))), yt(e, t, t.pendingProps.children, n), t.child;
        case 29:
          throw t.pendingProps;
      }
      throw Error(r(156, t.tag));
    }
    var wc = Tt(null), qa = null, Rn = null;
    function aa(e, t, n) {
      ze(wc, t._currentValue), t._currentValue = n;
    }
    function jn(e) {
      e._currentValue = wc.current, Ge(wc);
    }
    function Ec(e, t, n) {
      for (; e !== null; ) {
        var s = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t, s !== null && (s.childLanes |= t)) : s !== null && (s.childLanes & t) !== t && (s.childLanes |= t), e === n) break;
        e = e.return;
      }
    }
    function Ac(e, t, n, s) {
      var o = e.child;
      for (o !== null && (o.return = e); o !== null; ) {
        var u = o.dependencies;
        if (u !== null) {
          var m = o.child;
          u = u.firstContext;
          e: for (; u !== null; ) {
            var w = u;
            u = o;
            for (var T = 0; T < t.length; T++) if (w.context === t[T]) {
              u.lanes |= n, w = u.alternate, w !== null && (w.lanes |= n), Ec(u.return, n, e), s || (m = null);
              break e;
            }
            u = w.next;
          }
        } else if (o.tag === 18) {
          if (m = o.return, m === null) throw Error(r(341));
          m.lanes |= n, u = m.alternate, u !== null && (u.lanes |= n), Ec(m, n, e), m = null;
        } else m = o.child;
        if (m !== null) m.return = o;
        else for (m = o; m !== null; ) {
          if (m === e) {
            m = null;
            break;
          }
          if (o = m.sibling, o !== null) {
            o.return = m.return, m = o;
            break;
          }
          m = m.return;
        }
        o = m;
      }
    }
    function js(e, t, n, s) {
      e = null;
      for (var o = t, u = false; o !== null; ) {
        if (!u) {
          if ((o.flags & 524288) !== 0) u = true;
          else if ((o.flags & 262144) !== 0) break;
        }
        if (o.tag === 10) {
          var m = o.alternate;
          if (m === null) throw Error(r(387));
          if (m = m.memoizedProps, m !== null) {
            var w = o.type;
            Ut(o.pendingProps.value, m.value) || (e !== null ? e.push(w) : e = [
              w
            ]);
          }
        } else if (o === ni.current) {
          if (m = o.alternate, m === null) throw Error(r(387));
          m.memoizedState.memoizedState !== o.memoizedState.memoizedState && (e !== null ? e.push($s) : e = [
            $s
          ]);
        }
        o = o.return;
      }
      e !== null && Ac(t, e, n, s), t.flags |= 262144;
    }
    function sr(e) {
      for (e = e.firstContext; e !== null; ) {
        if (!Ut(e.context._currentValue, e.memoizedValue)) return true;
        e = e.next;
      }
      return false;
    }
    function Ya(e) {
      qa = e, Rn = null, e = e.dependencies, e !== null && (e.firstContext = null);
    }
    function xt(e) {
      return c0(qa, e);
    }
    function lr(e, t) {
      return qa === null && Ya(e), c0(e, t);
    }
    function c0(e, t) {
      var n = t._currentValue;
      if (t = {
        context: t,
        memoizedValue: n,
        next: null
      }, Rn === null) {
        if (e === null) throw Error(r(308));
        Rn = t, e.dependencies = {
          lanes: 0,
          firstContext: t
        }, e.flags |= 524288;
      } else Rn = Rn.next = t;
      return n;
    }
    var ia = false;
    function Tc(e) {
      e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
          pending: null,
          lanes: 0,
          hiddenCallbacks: null
        },
        callbacks: null
      };
    }
    function Oc(e, t) {
      e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        callbacks: null
      });
    }
    function sa(e) {
      return {
        lane: e,
        tag: 0,
        payload: null,
        callback: null,
        next: null
      };
    }
    function la(e, t, n) {
      var s = e.updateQueue;
      if (s === null) return null;
      if (s = s.shared, (Ye & 2) !== 0) {
        var o = s.pending;
        return o === null ? t.next = t : (t.next = o.next, o.next = t), s.pending = t, t = ql(e), Xd(e, null, n), t;
      }
      return Ll(e, s, t, n), ql(e);
    }
    function Ms(e, t, n) {
      if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194176) !== 0)) {
        var s = t.lanes;
        s &= e.pendingLanes, n |= s, t.lanes = n, Wf(e, n);
      }
    }
    function Cc(e, t) {
      var n = e.updateQueue, s = e.alternate;
      if (s !== null && (s = s.updateQueue, n === s)) {
        var o = null, u = null;
        if (n = n.firstBaseUpdate, n !== null) {
          do {
            var m = {
              lane: n.lane,
              tag: n.tag,
              payload: n.payload,
              callback: null,
              next: null
            };
            u === null ? o = u = m : u = u.next = m, n = n.next;
          } while (n !== null);
          u === null ? o = u = t : u = u.next = t;
        } else o = u = t;
        n = {
          baseState: s.baseState,
          firstBaseUpdate: o,
          lastBaseUpdate: u,
          shared: s.shared,
          callbacks: s.callbacks
        }, e.updateQueue = n;
        return;
      }
      e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t;
    }
    var _c = false;
    function Ds() {
      if (_c) {
        var e = Ei;
        if (e !== null) throw e;
      }
    }
    function Us(e, t, n, s) {
      _c = false;
      var o = e.updateQueue;
      ia = false;
      var u = o.firstBaseUpdate, m = o.lastBaseUpdate, w = o.shared.pending;
      if (w !== null) {
        o.shared.pending = null;
        var T = w, N = T.next;
        T.next = null, m === null ? u = N : m.next = N, m = T;
        var V = e.alternate;
        V !== null && (V = V.updateQueue, w = V.lastBaseUpdate, w !== m && (w === null ? V.firstBaseUpdate = N : w.next = N, V.lastBaseUpdate = T));
      }
      if (u !== null) {
        var $ = o.baseState;
        m = 0, V = N = T = null, w = u;
        do {
          var H = w.lane & -536870913, G = H !== w.lane;
          if (G ? (_e9 & H) === H : (s & H) === H) {
            H !== 0 && H === wi && (_c = true), V !== null && (V = V.next = {
              lane: 0,
              tag: w.tag,
              payload: w.payload,
              callback: null,
              next: null
            });
            e: {
              var re = e, ye = w;
              H = t;
              var Qe = n;
              switch (ye.tag) {
                case 1:
                  if (re = ye.payload, typeof re == "function") {
                    $ = re.call(Qe, $, H);
                    break e;
                  }
                  $ = re;
                  break e;
                case 3:
                  re.flags = re.flags & -65537 | 128;
                case 0:
                  if (re = ye.payload, H = typeof re == "function" ? re.call(Qe, $, H) : re, H == null) break e;
                  $ = P({}, $, H);
                  break e;
                case 2:
                  ia = true;
              }
            }
            H = w.callback, H !== null && (e.flags |= 64, G && (e.flags |= 8192), G = o.callbacks, G === null ? o.callbacks = [
              H
            ] : G.push(H));
          } else G = {
            lane: H,
            tag: w.tag,
            payload: w.payload,
            callback: w.callback,
            next: null
          }, V === null ? (N = V = G, T = $) : V = V.next = G, m |= H;
          if (w = w.next, w === null) {
            if (w = o.shared.pending, w === null) break;
            G = w, w = G.next, G.next = null, o.lastBaseUpdate = G, o.shared.pending = null;
          }
        } while (true);
        V === null && (T = $), o.baseState = T, o.firstBaseUpdate = N, o.lastBaseUpdate = V, u === null && (o.shared.lanes = 0), fa |= m, e.lanes = m, e.memoizedState = $;
      }
    }
    function u0(e, t) {
      if (typeof e != "function") throw Error(r(191, e));
      e.call(t);
    }
    function f0(e, t) {
      var n = e.callbacks;
      if (n !== null) for (e.callbacks = null, e = 0; e < n.length; e++) u0(n[e], t);
    }
    function zs(e, t) {
      try {
        var n = t.updateQueue, s = n !== null ? n.lastEffect : null;
        if (s !== null) {
          var o = s.next;
          n = o;
          do {
            if ((n.tag & e) === e) {
              s = void 0;
              var u = n.create, m = n.inst;
              s = u(), m.destroy = s;
            }
            n = n.next;
          } while (n !== o);
        }
      } catch (w) {
        Ue(t, t.return, w);
      }
    }
    function ra(e, t, n) {
      try {
        var s = t.updateQueue, o = s !== null ? s.lastEffect : null;
        if (o !== null) {
          var u = o.next;
          s = u;
          do {
            if ((s.tag & e) === e) {
              var m = s.inst, w = m.destroy;
              if (w !== void 0) {
                m.destroy = void 0, o = t;
                var T = n;
                try {
                  w();
                } catch (N) {
                  Ue(o, T, N);
                }
              }
            }
            s = s.next;
          } while (s !== u);
        }
      } catch (N) {
        Ue(t, t.return, N);
      }
    }
    function d0(e) {
      var t = e.updateQueue;
      if (t !== null) {
        var n = e.stateNode;
        try {
          f0(t, n);
        } catch (s) {
          Ue(e, e.return, s);
        }
      }
    }
    function h0(e, t, n) {
      n.props = La(e.type, e.memoizedProps), n.state = e.memoizedState;
      try {
        n.componentWillUnmount();
      } catch (s) {
        Ue(e, t, s);
      }
    }
    function Ga(e, t) {
      try {
        var n = e.ref;
        if (n !== null) {
          var s = e.stateNode;
          switch (e.tag) {
            case 26:
            case 27:
            case 5:
              var o = s;
              break;
            default:
              o = s;
          }
          typeof n == "function" ? e.refCleanup = n(o) : n.current = o;
        }
      } catch (u) {
        Ue(e, t, u);
      }
    }
    function zt(e, t) {
      var n = e.ref, s = e.refCleanup;
      if (n !== null) if (typeof s == "function") try {
        s();
      } catch (o) {
        Ue(e, t, o);
      } finally {
        e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null);
      }
      else if (typeof n == "function") try {
        n(null);
      } catch (o) {
        Ue(e, t, o);
      }
      else n.current = null;
    }
    function m0(e) {
      var t = e.type, n = e.memoizedProps, s = e.stateNode;
      try {
        e: switch (t) {
          case "button":
          case "input":
          case "select":
          case "textarea":
            n.autoFocus && s.focus();
            break e;
          case "img":
            n.src ? s.src = n.src : n.srcSet && (s.srcset = n.srcSet);
        }
      } catch (o) {
        Ue(e, e.return, o);
      }
    }
    function y0(e, t, n) {
      try {
        var s = e.stateNode;
        nv(s, e.type, n, t), s[Ot] = t;
      } catch (o) {
        Ue(e, e.return, o);
      }
    }
    function p0(e) {
      return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 || e.tag === 4;
    }
    function Nc(e) {
      e: for (; ; ) {
        for (; e.sibling === null; ) {
          if (e.return === null || p0(e.return)) return null;
          e = e.return;
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 27 && e.tag !== 18; ) {
          if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
          e.child.return = e, e = e.child;
        }
        if (!(e.flags & 2)) return e.stateNode;
      }
    }
    function Rc(e, t, n) {
      var s = e.tag;
      if (s === 5 || s === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = xr));
      else if (s !== 4 && s !== 27 && (e = e.child, e !== null)) for (Rc(e, t, n), e = e.sibling; e !== null; ) Rc(e, t, n), e = e.sibling;
    }
    function rr(e, t, n) {
      var s = e.tag;
      if (s === 5 || s === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
      else if (s !== 4 && s !== 27 && (e = e.child, e !== null)) for (rr(e, t, n), e = e.sibling; e !== null; ) rr(e, t, n), e = e.sibling;
    }
    var Mn = false, Xe = false, jc = false, g0 = typeof WeakSet == "function" ? WeakSet : Set, ft = null, b0 = false;
    function Mb(e, t) {
      if (e = e.containerInfo, su = Cr, e = zd(e), Do(e)) {
        if ("selectionStart" in e) var n = {
          start: e.selectionStart,
          end: e.selectionEnd
        };
        else e: {
          n = (n = e.ownerDocument) && n.defaultView || window;
          var s = n.getSelection && n.getSelection();
          if (s && s.rangeCount !== 0) {
            n = s.anchorNode;
            var o = s.anchorOffset, u = s.focusNode;
            s = s.focusOffset;
            try {
              n.nodeType, u.nodeType;
            } catch {
              n = null;
              break e;
            }
            var m = 0, w = -1, T = -1, N = 0, V = 0, $ = e, H = null;
            t: for (; ; ) {
              for (var G; $ !== n || o !== 0 && $.nodeType !== 3 || (w = m + o), $ !== u || s !== 0 && $.nodeType !== 3 || (T = m + s), $.nodeType === 3 && (m += $.nodeValue.length), (G = $.firstChild) !== null; ) H = $, $ = G;
              for (; ; ) {
                if ($ === e) break t;
                if (H === n && ++N === o && (w = m), H === u && ++V === s && (T = m), (G = $.nextSibling) !== null) break;
                $ = H, H = $.parentNode;
              }
              $ = G;
            }
            n = w === -1 || T === -1 ? null : {
              start: w,
              end: T
            };
          } else n = null;
        }
        n = n || {
          start: 0,
          end: 0
        };
      } else n = null;
      for (lu = {
        focusedElem: e,
        selectionRange: n
      }, Cr = false, ft = t; ft !== null; ) if (t = ft, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, ft = e;
      else for (; ft !== null; ) {
        switch (t = ft, u = t.alternate, e = t.flags, t.tag) {
          case 0:
            break;
          case 11:
          case 15:
            break;
          case 1:
            if ((e & 1024) !== 0 && u !== null) {
              e = void 0, n = t, o = u.memoizedProps, u = u.memoizedState, s = n.stateNode;
              try {
                var re = La(n.type, o, n.elementType === n.type);
                e = s.getSnapshotBeforeUpdate(re, u), s.__reactInternalSnapshotBeforeUpdate = e;
              } catch (ye) {
                Ue(n, n.return, ye);
              }
            }
            break;
          case 3:
            if ((e & 1024) !== 0) {
              if (e = t.stateNode.containerInfo, n = e.nodeType, n === 9) uu(e);
              else if (n === 1) switch (e.nodeName) {
                case "HEAD":
                case "HTML":
                case "BODY":
                  uu(e);
                  break;
                default:
                  e.textContent = "";
              }
            }
            break;
          case 5:
          case 26:
          case 27:
          case 6:
          case 4:
          case 17:
            break;
          default:
            if ((e & 1024) !== 0) throw Error(r(163));
        }
        if (e = t.sibling, e !== null) {
          e.return = t.return, ft = e;
          break;
        }
        ft = t.return;
      }
      return re = b0, b0 = false, re;
    }
    function v0(e, t, n) {
      var s = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          Un(e, n), s & 4 && zs(5, n);
          break;
        case 1:
          if (Un(e, n), s & 4) if (e = n.stateNode, t === null) try {
            e.componentDidMount();
          } catch (w) {
            Ue(n, n.return, w);
          }
          else {
            var o = La(n.type, t.memoizedProps);
            t = t.memoizedState;
            try {
              e.componentDidUpdate(o, t, e.__reactInternalSnapshotBeforeUpdate);
            } catch (w) {
              Ue(n, n.return, w);
            }
          }
          s & 64 && d0(n), s & 512 && Ga(n, n.return);
          break;
        case 3:
          if (Un(e, n), s & 64 && (s = n.updateQueue, s !== null)) {
            if (e = null, n.child !== null) switch (n.child.tag) {
              case 27:
              case 5:
                e = n.child.stateNode;
                break;
              case 1:
                e = n.child.stateNode;
            }
            try {
              f0(s, e);
            } catch (w) {
              Ue(n, n.return, w);
            }
          }
          break;
        case 26:
          Un(e, n), s & 512 && Ga(n, n.return);
          break;
        case 27:
        case 5:
          Un(e, n), t === null && s & 4 && m0(n), s & 512 && Ga(n, n.return);
          break;
        case 12:
          Un(e, n);
          break;
        case 13:
          Un(e, n), s & 4 && w0(e, n);
          break;
        case 22:
          if (o = n.memoizedState !== null || Mn, !o) {
            t = t !== null && t.memoizedState !== null || Xe;
            var u = Mn, m = Xe;
            Mn = o, (Xe = t) && !m ? oa(e, n, (n.subtreeFlags & 8772) !== 0) : Un(e, n), Mn = u, Xe = m;
          }
          s & 512 && (n.memoizedProps.mode === "manual" ? Ga(n, n.return) : zt(n, n.return));
          break;
        default:
          Un(e, n);
      }
    }
    function x0(e) {
      var t = e.alternate;
      t !== null && (e.alternate = null, x0(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && go(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
    }
    var Pe = null, kt = false;
    function Dn(e, t, n) {
      for (n = n.child; n !== null; ) S0(e, t, n), n = n.sibling;
    }
    function S0(e, t, n) {
      if (at && typeof at.onCommitFiberUnmount == "function") try {
        at.onCommitFiberUnmount(qt, n);
      } catch {
      }
      switch (n.tag) {
        case 26:
          Xe || zt(n, t), Dn(e, t, n), n.memoizedState ? n.memoizedState.count-- : n.stateNode && (n = n.stateNode, n.parentNode.removeChild(n));
          break;
        case 27:
          Xe || zt(n, t);
          var s = Pe, o = kt;
          for (Pe = n.stateNode, Dn(e, t, n), n = n.stateNode, t = n.attributes; t.length; ) n.removeAttributeNode(t[0]);
          go(n), Pe = s, kt = o;
          break;
        case 5:
          Xe || zt(n, t);
        case 6:
          o = Pe;
          var u = kt;
          if (Pe = null, Dn(e, t, n), Pe = o, kt = u, Pe !== null) if (kt) try {
            e = Pe, s = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(s) : e.removeChild(s);
          } catch (m) {
            Ue(n, t, m);
          }
          else try {
            Pe.removeChild(n.stateNode);
          } catch (m) {
            Ue(n, t, m);
          }
          break;
        case 18:
          Pe !== null && (kt ? (t = Pe, n = n.stateNode, t.nodeType === 8 ? cu(t.parentNode, n) : t.nodeType === 1 && cu(t, n), Ps(t)) : cu(Pe, n.stateNode));
          break;
        case 4:
          s = Pe, o = kt, Pe = n.stateNode.containerInfo, kt = true, Dn(e, t, n), Pe = s, kt = o;
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          Xe || ra(2, n, t), Xe || ra(4, n, t), Dn(e, t, n);
          break;
        case 1:
          Xe || (zt(n, t), s = n.stateNode, typeof s.componentWillUnmount == "function" && h0(n, t, s)), Dn(e, t, n);
          break;
        case 21:
          Dn(e, t, n);
          break;
        case 22:
          Xe || zt(n, t), Xe = (s = Xe) || n.memoizedState !== null, Dn(e, t, n), Xe = s;
          break;
        default:
          Dn(e, t, n);
      }
    }
    function w0(e, t) {
      if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
        Ps(e);
      } catch (n) {
        Ue(t, t.return, n);
      }
    }
    function Db(e) {
      switch (e.tag) {
        case 13:
        case 19:
          var t = e.stateNode;
          return t === null && (t = e.stateNode = new g0()), t;
        case 22:
          return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new g0()), t;
        default:
          throw Error(r(435, e.tag));
      }
    }
    function Mc(e, t) {
      var n = Db(e);
      t.forEach(function(s) {
        var o = Qb.bind(null, e, s);
        n.has(s) || (n.add(s), s.then(o, o));
      });
    }
    function Kt(e, t) {
      var n = t.deletions;
      if (n !== null) for (var s = 0; s < n.length; s++) {
        var o = n[s], u = e, m = t, w = m;
        e: for (; w !== null; ) {
          switch (w.tag) {
            case 27:
            case 5:
              Pe = w.stateNode, kt = false;
              break e;
            case 3:
              Pe = w.stateNode.containerInfo, kt = true;
              break e;
            case 4:
              Pe = w.stateNode.containerInfo, kt = true;
              break e;
          }
          w = w.return;
        }
        if (Pe === null) throw Error(r(160));
        S0(u, m, o), Pe = null, kt = false, u = o.alternate, u !== null && (u.return = null), o.return = null;
      }
      if (t.subtreeFlags & 13878) for (t = t.child; t !== null; ) E0(t, e), t = t.sibling;
    }
    var sn = null;
    function E0(e, t) {
      var n = e.alternate, s = e.flags;
      switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          Kt(t, e), $t(e), s & 4 && (ra(3, e, e.return), zs(3, e), ra(5, e, e.return));
          break;
        case 1:
          Kt(t, e), $t(e), s & 512 && (Xe || n === null || zt(n, n.return)), s & 64 && Mn && (e = e.updateQueue, e !== null && (s = e.callbacks, s !== null && (n = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = n === null ? s : n.concat(s))));
          break;
        case 26:
          var o = sn;
          if (Kt(t, e), $t(e), s & 512 && (Xe || n === null || zt(n, n.return)), s & 4) {
            var u = n !== null ? n.memoizedState : null;
            if (s = e.memoizedState, n === null) if (s === null) if (e.stateNode === null) {
              e: {
                s = e.type, n = e.memoizedProps, o = o.ownerDocument || o;
                t: switch (s) {
                  case "title":
                    u = o.getElementsByTagName("title")[0], (!u || u[rs] || u[vt] || u.namespaceURI === "http://www.w3.org/2000/svg" || u.hasAttribute("itemprop")) && (u = o.createElement(s), o.head.insertBefore(u, o.querySelector("head > title"))), pt(u, s, n), u[vt] = e, ct(u), s = u;
                    break e;
                  case "link":
                    var m = mm("link", "href", o).get(s + (n.href || ""));
                    if (m) {
                      for (var w = 0; w < m.length; w++) if (u = m[w], u.getAttribute("href") === (n.href == null ? null : n.href) && u.getAttribute("rel") === (n.rel == null ? null : n.rel) && u.getAttribute("title") === (n.title == null ? null : n.title) && u.getAttribute("crossorigin") === (n.crossOrigin == null ? null : n.crossOrigin)) {
                        m.splice(w, 1);
                        break t;
                      }
                    }
                    u = o.createElement(s), pt(u, s, n), o.head.appendChild(u);
                    break;
                  case "meta":
                    if (m = mm("meta", "content", o).get(s + (n.content || ""))) {
                      for (w = 0; w < m.length; w++) if (u = m[w], u.getAttribute("content") === (n.content == null ? null : "" + n.content) && u.getAttribute("name") === (n.name == null ? null : n.name) && u.getAttribute("property") === (n.property == null ? null : n.property) && u.getAttribute("http-equiv") === (n.httpEquiv == null ? null : n.httpEquiv) && u.getAttribute("charset") === (n.charSet == null ? null : n.charSet)) {
                        m.splice(w, 1);
                        break t;
                      }
                    }
                    u = o.createElement(s), pt(u, s, n), o.head.appendChild(u);
                    break;
                  default:
                    throw Error(r(468, s));
                }
                u[vt] = e, ct(u), s = u;
              }
              e.stateNode = s;
            } else ym(o, e.type, e.stateNode);
            else e.stateNode = hm(o, s, e.memoizedProps);
            else u !== s ? (u === null ? n.stateNode !== null && (n = n.stateNode, n.parentNode.removeChild(n)) : u.count--, s === null ? ym(o, e.type, e.stateNode) : hm(o, s, e.memoizedProps)) : s === null && e.stateNode !== null && y0(e, e.memoizedProps, n.memoizedProps);
          }
          break;
        case 27:
          if (s & 4 && e.alternate === null) {
            o = e.stateNode, u = e.memoizedProps;
            try {
              for (var T = o.firstChild; T; ) {
                var N = T.nextSibling, V = T.nodeName;
                T[rs] || V === "HEAD" || V === "BODY" || V === "SCRIPT" || V === "STYLE" || V === "LINK" && T.rel.toLowerCase() === "stylesheet" || o.removeChild(T), T = N;
              }
              for (var $ = e.type, H = o.attributes; H.length; ) o.removeAttributeNode(H[0]);
              pt(o, $, u), o[vt] = e, o[Ot] = u;
            } catch (re) {
              Ue(e, e.return, re);
            }
          }
        case 5:
          if (Kt(t, e), $t(e), s & 512 && (Xe || n === null || zt(n, n.return)), e.flags & 32) {
            o = e.stateNode;
            try {
              ui(o, "");
            } catch (re) {
              Ue(e, e.return, re);
            }
          }
          s & 4 && e.stateNode != null && (o = e.memoizedProps, y0(e, o, n !== null ? n.memoizedProps : o)), s & 1024 && (jc = true);
          break;
        case 6:
          if (Kt(t, e), $t(e), s & 4) {
            if (e.stateNode === null) throw Error(r(162));
            s = e.memoizedProps, n = e.stateNode;
            try {
              n.nodeValue = s;
            } catch (re) {
              Ue(e, e.return, re);
            }
          }
          break;
        case 3:
          if (Ar = null, o = sn, sn = wr(t.containerInfo), Kt(t, e), sn = o, $t(e), s & 4 && n !== null && n.memoizedState.isDehydrated) try {
            Ps(t.containerInfo);
          } catch (re) {
            Ue(e, e.return, re);
          }
          jc && (jc = false, A0(e));
          break;
        case 4:
          s = sn, sn = wr(e.stateNode.containerInfo), Kt(t, e), $t(e), sn = s;
          break;
        case 12:
          Kt(t, e), $t(e);
          break;
        case 13:
          Kt(t, e), $t(e), e.child.flags & 8192 && e.memoizedState !== null != (n !== null && n.memoizedState !== null) && (Yc = Je()), s & 4 && (s = e.updateQueue, s !== null && (e.updateQueue = null, Mc(e, s)));
          break;
        case 22:
          if (s & 512 && (Xe || n === null || zt(n, n.return)), T = e.memoizedState !== null, N = n !== null && n.memoizedState !== null, V = Mn, $ = Xe, Mn = V || T, Xe = $ || N, Kt(t, e), Xe = $, Mn = V, $t(e), t = e.stateNode, t._current = e, t._visibility &= -3, t._visibility |= t._pendingVisibility & 2, s & 8192 && (t._visibility = T ? t._visibility & -2 : t._visibility | 1, T && (t = Mn || Xe, n === null || N || t || Ci(e)), e.memoizedProps === null || e.memoizedProps.mode !== "manual")) e: for (n = null, t = e; ; ) {
            if (t.tag === 5 || t.tag === 26 || t.tag === 27) {
              if (n === null) {
                N = n = t;
                try {
                  if (o = N.stateNode, T) u = o.style, typeof u.setProperty == "function" ? u.setProperty("display", "none", "important") : u.display = "none";
                  else {
                    m = N.stateNode, w = N.memoizedProps.style;
                    var G = w != null && w.hasOwnProperty("display") ? w.display : null;
                    m.style.display = G == null || typeof G == "boolean" ? "" : ("" + G).trim();
                  }
                } catch (re) {
                  Ue(N, N.return, re);
                }
              }
            } else if (t.tag === 6) {
              if (n === null) {
                N = t;
                try {
                  N.stateNode.nodeValue = T ? "" : N.memoizedProps;
                } catch (re) {
                  Ue(N, N.return, re);
                }
              }
            } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === e) && t.child !== null) {
              t.child.return = t, t = t.child;
              continue;
            }
            if (t === e) break e;
            for (; t.sibling === null; ) {
              if (t.return === null || t.return === e) break e;
              n === t && (n = null), t = t.return;
            }
            n === t && (n = null), t.sibling.return = t.return, t = t.sibling;
          }
          s & 4 && (s = e.updateQueue, s !== null && (n = s.retryQueue, n !== null && (s.retryQueue = null, Mc(e, n))));
          break;
        case 19:
          Kt(t, e), $t(e), s & 4 && (s = e.updateQueue, s !== null && (e.updateQueue = null, Mc(e, s)));
          break;
        case 21:
          break;
        default:
          Kt(t, e), $t(e);
      }
    }
    function $t(e) {
      var t = e.flags;
      if (t & 2) {
        try {
          if (e.tag !== 27) {
            e: {
              for (var n = e.return; n !== null; ) {
                if (p0(n)) {
                  var s = n;
                  break e;
                }
                n = n.return;
              }
              throw Error(r(160));
            }
            switch (s.tag) {
              case 27:
                var o = s.stateNode, u = Nc(e);
                rr(e, u, o);
                break;
              case 5:
                var m = s.stateNode;
                s.flags & 32 && (ui(m, ""), s.flags &= -33);
                var w = Nc(e);
                rr(e, w, m);
                break;
              case 3:
              case 4:
                var T = s.stateNode.containerInfo, N = Nc(e);
                Rc(e, N, T);
                break;
              default:
                throw Error(r(161));
            }
          }
        } catch (V) {
          Ue(e, e.return, V);
        }
        e.flags &= -3;
      }
      t & 4096 && (e.flags &= -4097);
    }
    function A0(e) {
      if (e.subtreeFlags & 1024) for (e = e.child; e !== null; ) {
        var t = e;
        A0(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), e = e.sibling;
      }
    }
    function Un(e, t) {
      if (t.subtreeFlags & 8772) for (t = t.child; t !== null; ) v0(e, t.alternate, t), t = t.sibling;
    }
    function Ci(e) {
      for (e = e.child; e !== null; ) {
        var t = e;
        switch (t.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            ra(4, t, t.return), Ci(t);
            break;
          case 1:
            zt(t, t.return);
            var n = t.stateNode;
            typeof n.componentWillUnmount == "function" && h0(t, t.return, n), Ci(t);
            break;
          case 26:
          case 27:
          case 5:
            zt(t, t.return), Ci(t);
            break;
          case 22:
            zt(t, t.return), t.memoizedState === null && Ci(t);
            break;
          default:
            Ci(t);
        }
        e = e.sibling;
      }
    }
    function oa(e, t, n) {
      for (n = n && (t.subtreeFlags & 8772) !== 0, t = t.child; t !== null; ) {
        var s = t.alternate, o = e, u = t, m = u.flags;
        switch (u.tag) {
          case 0:
          case 11:
          case 15:
            oa(o, u, n), zs(4, u);
            break;
          case 1:
            if (oa(o, u, n), s = u, o = s.stateNode, typeof o.componentDidMount == "function") try {
              o.componentDidMount();
            } catch (N) {
              Ue(s, s.return, N);
            }
            if (s = u, o = s.updateQueue, o !== null) {
              var w = s.stateNode;
              try {
                var T = o.shared.hiddenCallbacks;
                if (T !== null) for (o.shared.hiddenCallbacks = null, o = 0; o < T.length; o++) u0(T[o], w);
              } catch (N) {
                Ue(s, s.return, N);
              }
            }
            n && m & 64 && d0(u), Ga(u, u.return);
            break;
          case 26:
          case 27:
          case 5:
            oa(o, u, n), n && s === null && m & 4 && m0(u), Ga(u, u.return);
            break;
          case 12:
            oa(o, u, n);
            break;
          case 13:
            oa(o, u, n), n && m & 4 && w0(o, u);
            break;
          case 22:
            u.memoizedState === null && oa(o, u, n), Ga(u, u.return);
            break;
          default:
            oa(o, u, n);
        }
        t = t.sibling;
      }
    }
    function Dc(e, t) {
      var n = null;
      e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== n && (e != null && e.refCount++, n != null && Ts(n));
    }
    function Uc(e, t) {
      e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && Ts(e));
    }
    function ca(e, t, n, s) {
      if (t.subtreeFlags & 10256) for (t = t.child; t !== null; ) T0(e, t, n, s), t = t.sibling;
    }
    function T0(e, t, n, s) {
      var o = t.flags;
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          ca(e, t, n, s), o & 2048 && zs(9, t);
          break;
        case 3:
          ca(e, t, n, s), o & 2048 && (e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && Ts(e)));
          break;
        case 12:
          if (o & 2048) {
            ca(e, t, n, s), e = t.stateNode;
            try {
              var u = t.memoizedProps, m = u.id, w = u.onPostCommit;
              typeof w == "function" && w(m, t.alternate === null ? "mount" : "update", e.passiveEffectDuration, -0);
            } catch (T) {
              Ue(t, t.return, T);
            }
          } else ca(e, t, n, s);
          break;
        case 23:
          break;
        case 22:
          u = t.stateNode, t.memoizedState !== null ? u._visibility & 4 ? ca(e, t, n, s) : ks(e, t) : u._visibility & 4 ? ca(e, t, n, s) : (u._visibility |= 4, _i7(e, t, n, s, (t.subtreeFlags & 10256) !== 0)), o & 2048 && Dc(t.alternate, t);
          break;
        case 24:
          ca(e, t, n, s), o & 2048 && Uc(t.alternate, t);
          break;
        default:
          ca(e, t, n, s);
      }
    }
    function _i7(e, t, n, s, o) {
      for (o = o && (t.subtreeFlags & 10256) !== 0, t = t.child; t !== null; ) {
        var u = e, m = t, w = n, T = s, N = m.flags;
        switch (m.tag) {
          case 0:
          case 11:
          case 15:
            _i7(u, m, w, T, o), zs(8, m);
            break;
          case 23:
            break;
          case 22:
            var V = m.stateNode;
            m.memoizedState !== null ? V._visibility & 4 ? _i7(u, m, w, T, o) : ks(u, m) : (V._visibility |= 4, _i7(u, m, w, T, o)), o && N & 2048 && Dc(m.alternate, m);
            break;
          case 24:
            _i7(u, m, w, T, o), o && N & 2048 && Uc(m.alternate, m);
            break;
          default:
            _i7(u, m, w, T, o);
        }
        t = t.sibling;
      }
    }
    function ks(e, t) {
      if (t.subtreeFlags & 10256) for (t = t.child; t !== null; ) {
        var n = e, s = t, o = s.flags;
        switch (s.tag) {
          case 22:
            ks(n, s), o & 2048 && Dc(s.alternate, s);
            break;
          case 24:
            ks(n, s), o & 2048 && Uc(s.alternate, s);
            break;
          default:
            ks(n, s);
        }
        t = t.sibling;
      }
    }
    var Bs = 8192;
    function Ni(e) {
      if (e.subtreeFlags & Bs) for (e = e.child; e !== null; ) O0(e), e = e.sibling;
    }
    function O0(e) {
      switch (e.tag) {
        case 26:
          Ni(e), e.flags & Bs && e.memoizedState !== null && Sv(sn, e.memoizedState, e.memoizedProps);
          break;
        case 5:
          Ni(e);
          break;
        case 3:
        case 4:
          var t = sn;
          sn = wr(e.stateNode.containerInfo), Ni(e), sn = t;
          break;
        case 22:
          e.memoizedState === null && (t = e.alternate, t !== null && t.memoizedState !== null ? (t = Bs, Bs = 16777216, Ni(e), Bs = t) : Ni(e));
          break;
        default:
          Ni(e);
      }
    }
    function C0(e) {
      var t = e.alternate;
      if (t !== null && (e = t.child, e !== null)) {
        t.child = null;
        do
          t = e.sibling, e.sibling = null, e = t;
        while (e !== null);
      }
    }
    function Hs(e) {
      var t = e.deletions;
      if ((e.flags & 16) !== 0) {
        if (t !== null) for (var n = 0; n < t.length; n++) {
          var s = t[n];
          ft = s, N0(s, e);
        }
        C0(e);
      }
      if (e.subtreeFlags & 10256) for (e = e.child; e !== null; ) _0(e), e = e.sibling;
    }
    function _0(e) {
      switch (e.tag) {
        case 0:
        case 11:
        case 15:
          Hs(e), e.flags & 2048 && ra(9, e, e.return);
          break;
        case 3:
          Hs(e);
          break;
        case 12:
          Hs(e);
          break;
        case 22:
          var t = e.stateNode;
          e.memoizedState !== null && t._visibility & 4 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -5, or(e)) : Hs(e);
          break;
        default:
          Hs(e);
      }
    }
    function or(e) {
      var t = e.deletions;
      if ((e.flags & 16) !== 0) {
        if (t !== null) for (var n = 0; n < t.length; n++) {
          var s = t[n];
          ft = s, N0(s, e);
        }
        C0(e);
      }
      for (e = e.child; e !== null; ) {
        switch (t = e, t.tag) {
          case 0:
          case 11:
          case 15:
            ra(8, t, t.return), or(t);
            break;
          case 22:
            n = t.stateNode, n._visibility & 4 && (n._visibility &= -5, or(t));
            break;
          default:
            or(t);
        }
        e = e.sibling;
      }
    }
    function N0(e, t) {
      for (; ft !== null; ) {
        var n = ft;
        switch (n.tag) {
          case 0:
          case 11:
          case 15:
            ra(8, n, t);
            break;
          case 23:
          case 22:
            if (n.memoizedState !== null && n.memoizedState.cachePool !== null) {
              var s = n.memoizedState.cachePool.pool;
              s != null && s.refCount++;
            }
            break;
          case 24:
            Ts(n.memoizedState.cache);
        }
        if (s = n.child, s !== null) s.return = n, ft = s;
        else e: for (n = e; ft !== null; ) {
          s = ft;
          var o = s.sibling, u = s.return;
          if (x0(s), s === n) {
            ft = null;
            break e;
          }
          if (o !== null) {
            o.return = u, ft = o;
            break e;
          }
          ft = u;
        }
      }
    }
    function Ub(e, t, n, s) {
      this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = s, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null;
    }
    function Jt(e, t, n, s) {
      return new Ub(e, t, n, s);
    }
    function zc(e) {
      return e = e.prototype, !(!e || !e.isReactComponent);
    }
    function ua(e, t) {
      var n = e.alternate;
      return n === null ? (n = Jt(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 31457280, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
      }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n.refCleanup = e.refCleanup, n;
    }
    function R0(e, t) {
      e.flags &= 31457282;
      var n = e.alternate;
      return n === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type, t = n.dependencies, e.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
      }), e;
    }
    function cr(e, t, n, s, o, u) {
      var m = 0;
      if (s = e, typeof e == "function") zc(e) && (m = 1);
      else if (typeof e == "string") m = vv(e, n, oe.current) ? 26 : e === "html" || e === "head" || e === "body" ? 27 : 5;
      else e: switch (e) {
        case g:
          return Va(n.children, o, u, t);
        case y:
          m = 8, o |= 24;
          break;
        case p:
          return e = Jt(12, n, t, o | 2), e.elementType = p, e.lanes = u, e;
        case A:
          return e = Jt(13, n, t, o), e.elementType = A, e.lanes = u, e;
        case j:
          return e = Jt(19, n, t, o), e.elementType = j, e.lanes = u, e;
        case D:
          return j0(n, o, u, t);
        default:
          if (typeof e == "object" && e !== null) switch (e.$$typeof) {
            case b:
            case x:
              m = 10;
              break e;
            case S:
              m = 9;
              break e;
            case v:
              m = 11;
              break e;
            case L:
              m = 14;
              break e;
            case B:
              m = 16, s = null;
              break e;
          }
          m = 29, n = Error(r(130, e === null ? "null" : typeof e, "")), s = null;
      }
      return t = Jt(m, n, t, o), t.elementType = e, t.type = s, t.lanes = u, t;
    }
    function Va(e, t, n, s) {
      return e = Jt(7, e, s, t), e.lanes = n, e;
    }
    function j0(e, t, n, s) {
      e = Jt(22, e, s, t), e.elementType = D, e.lanes = n;
      var o = {
        _visibility: 1,
        _pendingVisibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null,
        _current: null,
        detach: function() {
          var u = o._current;
          if (u === null) throw Error(r(456));
          if ((o._pendingVisibility & 2) === 0) {
            var m = Wn(u, 2);
            m !== null && (o._pendingVisibility |= 2, Et(m, u, 2));
          }
        },
        attach: function() {
          var u = o._current;
          if (u === null) throw Error(r(456));
          if ((o._pendingVisibility & 2) !== 0) {
            var m = Wn(u, 2);
            m !== null && (o._pendingVisibility &= -3, Et(m, u, 2));
          }
        }
      };
      return e.stateNode = o, e;
    }
    function kc(e, t, n) {
      return e = Jt(6, e, null, t), e.lanes = n, e;
    }
    function Bc(e, t, n) {
      return t = Jt(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
      }, t;
    }
    function zn(e) {
      e.flags |= 4;
    }
    function M0(e, t) {
      if (t.type !== "stylesheet" || (t.state.loading & 4) !== 0) e.flags &= -16777217;
      else if (e.flags |= 16777216, !pm(t)) {
        if (t = Zt.current, t !== null && ((_e9 & 4194176) === _e9 ? fn !== null : (_e9 & 62914560) !== _e9 && (_e9 & 536870912) === 0 || t !== fn)) throw ws = Go, $d;
        e.flags |= 8192;
      }
    }
    function ur(e, t) {
      t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag !== 22 ? Jf() : 536870912, e.lanes |= t, ji |= t);
    }
    function Ls(e, t) {
      if (!Re) switch (e.tailMode) {
        case "hidden":
          t = e.tail;
          for (var n = null; t !== null; ) t.alternate !== null && (n = t), t = t.sibling;
          n === null ? e.tail = null : n.sibling = null;
          break;
        case "collapsed":
          n = e.tail;
          for (var s = null; n !== null; ) n.alternate !== null && (s = n), n = n.sibling;
          s === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : s.sibling = null;
      }
    }
    function qe(e) {
      var t = e.alternate !== null && e.alternate.child === e.child, n = 0, s = 0;
      if (t) for (var o = e.child; o !== null; ) n |= o.lanes | o.childLanes, s |= o.subtreeFlags & 31457280, s |= o.flags & 31457280, o.return = e, o = o.sibling;
      else for (o = e.child; o !== null; ) n |= o.lanes | o.childLanes, s |= o.subtreeFlags, s |= o.flags, o.return = e, o = o.sibling;
      return e.subtreeFlags |= s, e.childLanes = n, t;
    }
    function zb(e, t, n) {
      var s = t.pendingProps;
      switch (qo(t), t.tag) {
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return qe(t), null;
        case 1:
          return qe(t), null;
        case 3:
          return n = t.stateNode, s = null, e !== null && (s = e.memoizedState.cache), t.memoizedState.cache !== s && (t.flags |= 2048), jn(st), Sn(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (e === null || e.child === null) && (bs(t) ? zn(t) : e === null || e.memoizedState.isDehydrated && (t.flags & 256) === 0 || (t.flags |= 1024, an !== null && (Fc(an), an = null))), qe(t), null;
        case 26:
          return n = t.memoizedState, e === null ? (zn(t), n !== null ? (qe(t), M0(t, n)) : (qe(t), t.flags &= -16777217)) : n ? n !== e.memoizedState ? (zn(t), qe(t), M0(t, n)) : (qe(t), t.flags &= -16777217) : (e.memoizedProps !== s && zn(t), qe(t), t.flags &= -16777217), null;
        case 27:
          ii(t), n = tn.current;
          var o = t.type;
          if (e !== null && t.stateNode != null) e.memoizedProps !== s && zn(t);
          else {
            if (!s) {
              if (t.stateNode === null) throw Error(r(166));
              return qe(t), null;
            }
            e = oe.current, bs(t) ? Zd(t) : (e = om(o, s, n), t.stateNode = e, zn(t));
          }
          return qe(t), null;
        case 5:
          if (ii(t), n = t.type, e !== null && t.stateNode != null) e.memoizedProps !== s && zn(t);
          else {
            if (!s) {
              if (t.stateNode === null) throw Error(r(166));
              return qe(t), null;
            }
            if (e = oe.current, bs(t)) Zd(t);
            else {
              switch (o = Sr(tn.current), e) {
                case 1:
                  e = o.createElementNS("http://www.w3.org/2000/svg", n);
                  break;
                case 2:
                  e = o.createElementNS("http://www.w3.org/1998/Math/MathML", n);
                  break;
                default:
                  switch (n) {
                    case "svg":
                      e = o.createElementNS("http://www.w3.org/2000/svg", n);
                      break;
                    case "math":
                      e = o.createElementNS("http://www.w3.org/1998/Math/MathML", n);
                      break;
                    case "script":
                      e = o.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild);
                      break;
                    case "select":
                      e = typeof s.is == "string" ? o.createElement("select", {
                        is: s.is
                      }) : o.createElement("select"), s.multiple ? e.multiple = true : s.size && (e.size = s.size);
                      break;
                    default:
                      e = typeof s.is == "string" ? o.createElement(n, {
                        is: s.is
                      }) : o.createElement(n);
                  }
              }
              e[vt] = t, e[Ot] = s;
              e: for (o = t.child; o !== null; ) {
                if (o.tag === 5 || o.tag === 6) e.appendChild(o.stateNode);
                else if (o.tag !== 4 && o.tag !== 27 && o.child !== null) {
                  o.child.return = o, o = o.child;
                  continue;
                }
                if (o === t) break e;
                for (; o.sibling === null; ) {
                  if (o.return === null || o.return === t) break e;
                  o = o.return;
                }
                o.sibling.return = o.return, o = o.sibling;
              }
              t.stateNode = e;
              e: switch (pt(e, n, s), n) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                  e = !!s.autoFocus;
                  break e;
                case "img":
                  e = true;
                  break e;
                default:
                  e = false;
              }
              e && zn(t);
            }
          }
          return qe(t), t.flags &= -16777217, null;
        case 6:
          if (e && t.stateNode != null) e.memoizedProps !== s && zn(t);
          else {
            if (typeof s != "string" && t.stateNode === null) throw Error(r(166));
            if (e = tn.current, bs(t)) {
              if (e = t.stateNode, n = t.memoizedProps, s = null, o = wt, o !== null) switch (o.tag) {
                case 27:
                case 5:
                  s = o.memoizedProps;
              }
              e[vt] = t, e = !!(e.nodeValue === n || s !== null && s.suppressHydrationWarning === true || nm(e.nodeValue, n)), e || Da(t);
            } else e = Sr(e).createTextNode(s), e[vt] = t, t.stateNode = e;
          }
          return qe(t), null;
        case 13:
          if (s = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
            if (o = bs(t), s !== null && s.dehydrated !== null) {
              if (e === null) {
                if (!o) throw Error(r(318));
                if (o = t.memoizedState, o = o !== null ? o.dehydrated : null, !o) throw Error(r(317));
                o[vt] = t;
              } else vs(), (t.flags & 128) === 0 && (t.memoizedState = null), t.flags |= 4;
              qe(t), o = false;
            } else an !== null && (Fc(an), an = null), o = true;
            if (!o) return t.flags & 256 ? (Cn(t), t) : (Cn(t), null);
          }
          if (Cn(t), (t.flags & 128) !== 0) return t.lanes = n, t;
          if (n = s !== null, e = e !== null && e.memoizedState !== null, n) {
            s = t.child, o = null, s.alternate !== null && s.alternate.memoizedState !== null && s.alternate.memoizedState.cachePool !== null && (o = s.alternate.memoizedState.cachePool.pool);
            var u = null;
            s.memoizedState !== null && s.memoizedState.cachePool !== null && (u = s.memoizedState.cachePool.pool), u !== o && (s.flags |= 2048);
          }
          return n !== e && n && (t.child.flags |= 8192), ur(t, t.updateQueue), qe(t), null;
        case 4:
          return Sn(), e === null && nu(t.stateNode.containerInfo), qe(t), null;
        case 10:
          return jn(t.type), qe(t), null;
        case 19:
          if (Ge(it), o = t.memoizedState, o === null) return qe(t), null;
          if (s = (t.flags & 128) !== 0, u = o.rendering, u === null) if (s) Ls(o, false);
          else {
            if (Fe !== 0 || e !== null && (e.flags & 128) !== 0) for (e = t.child; e !== null; ) {
              if (u = Zl(e), u !== null) {
                for (t.flags |= 128, Ls(o, false), e = u.updateQueue, t.updateQueue = e, ur(t, e), t.subtreeFlags = 0, e = n, n = t.child; n !== null; ) R0(n, e), n = n.sibling;
                return ze(it, it.current & 1 | 2), t.child;
              }
              e = e.sibling;
            }
            o.tail !== null && Je() > fr && (t.flags |= 128, s = true, Ls(o, false), t.lanes = 4194304);
          }
          else {
            if (!s) if (e = Zl(u), e !== null) {
              if (t.flags |= 128, s = true, e = e.updateQueue, t.updateQueue = e, ur(t, e), Ls(o, true), o.tail === null && o.tailMode === "hidden" && !u.alternate && !Re) return qe(t), null;
            } else 2 * Je() - o.renderingStartTime > fr && n !== 536870912 && (t.flags |= 128, s = true, Ls(o, false), t.lanes = 4194304);
            o.isBackwards ? (u.sibling = t.child, t.child = u) : (e = o.last, e !== null ? e.sibling = u : t.child = u, o.last = u);
          }
          return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = Je(), t.sibling = null, e = it.current, ze(it, s ? e & 1 | 2 : e & 1), t) : (qe(t), null);
        case 22:
        case 23:
          return Cn(t), Xo(), s = t.memoizedState !== null, e !== null ? e.memoizedState !== null !== s && (t.flags |= 8192) : s && (t.flags |= 8192), s ? (n & 536870912) !== 0 && (t.flags & 128) === 0 && (qe(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : qe(t), n = t.updateQueue, n !== null && ur(t, n.retryQueue), n = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), s = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (s = t.memoizedState.cachePool.pool), s !== n && (t.flags |= 2048), e !== null && Ge(za), null;
        case 24:
          return n = null, e !== null && (n = e.memoizedState.cache), t.memoizedState.cache !== n && (t.flags |= 2048), jn(st), qe(t), null;
        case 25:
          return null;
      }
      throw Error(r(156, t.tag));
    }
    function kb(e, t) {
      switch (qo(t), t.tag) {
        case 1:
          return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
          return jn(st), Sn(), e = t.flags, (e & 65536) !== 0 && (e & 128) === 0 ? (t.flags = e & -65537 | 128, t) : null;
        case 26:
        case 27:
        case 5:
          return ii(t), null;
        case 13:
          if (Cn(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
            if (t.alternate === null) throw Error(r(340));
            vs();
          }
          return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
          return Ge(it), null;
        case 4:
          return Sn(), null;
        case 10:
          return jn(t.type), null;
        case 22:
        case 23:
          return Cn(t), Xo(), e !== null && Ge(za), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 24:
          return jn(st), null;
        case 25:
          return null;
        default:
          return null;
      }
    }
    function D0(e, t) {
      switch (qo(t), t.tag) {
        case 3:
          jn(st), Sn();
          break;
        case 26:
        case 27:
        case 5:
          ii(t);
          break;
        case 4:
          Sn();
          break;
        case 13:
          Cn(t);
          break;
        case 19:
          Ge(it);
          break;
        case 10:
          jn(t.type);
          break;
        case 22:
        case 23:
          Cn(t), Xo(), e !== null && Ge(za);
          break;
        case 24:
          jn(st);
      }
    }
    var Bb = {
      getCacheForType: function(e) {
        var t = xt(st), n = t.data.get(e);
        return n === void 0 && (n = e(), t.data.set(e, n)), n;
      }
    }, Hb = typeof WeakMap == "function" ? WeakMap : Map, Ye = 0, ke = null, Se = null, _e9 = 0, Be = 0, Bt = null, kn = false, Ri = false, Hc = false, Bn = 0, Fe = 0, fa = 0, Xa = 0, Lc = 0, It = 0, ji = 0, qs = null, hn = null, qc = false, Yc = 0, fr = 1 / 0, dr = null, da = null, hr = false, Fa = null, Ys = 0, Gc = 0, Vc = null, Gs = 0, Xc = null;
    function Ht() {
      if ((Ye & 2) !== 0 && _e9 !== 0) return _e9 & -_e9;
      if (W.T !== null) {
        var e = wi;
        return e !== 0 ? e : Wc();
      }
      return ed();
    }
    function U0() {
      It === 0 && (It = (_e9 & 536870912) === 0 || Re ? $f() : 536870912);
      var e = Zt.current;
      return e !== null && (e.flags |= 32), It;
    }
    function Et(e, t, n) {
      (e === ke && Be === 2 || e.cancelPendingCommit !== null) && (Mi(e, 0), Hn(e, _e9, It, false)), ls(e, n), ((Ye & 2) === 0 || e !== ke) && (e === ke && ((Ye & 2) === 0 && (Xa |= n), Fe === 4 && Hn(e, _e9, It, false)), mn(e));
    }
    function z0(e, t, n) {
      if ((Ye & 6) !== 0) throw Error(r(327));
      var s = !n && (t & 60) === 0 && (t & e.expiredLanes) === 0 || ss(e, t), o = s ? Yb(e, t) : Kc(e, t, true), u = s;
      do {
        if (o === 0) {
          Ri && !s && Hn(e, t, 0, false);
          break;
        } else if (o === 6) Hn(e, t, 0, !kn);
        else {
          if (n = e.current.alternate, u && !Lb(n)) {
            o = Kc(e, t, false), u = false;
            continue;
          }
          if (o === 2) {
            if (u = t, e.errorRecoveryDisabledLanes & u) var m = 0;
            else m = e.pendingLanes & -536870913, m = m !== 0 ? m : m & 536870912 ? 536870912 : 0;
            if (m !== 0) {
              t = m;
              e: {
                var w = e;
                o = qs;
                var T = w.current.memoizedState.isDehydrated;
                if (T && (Mi(w, m).flags |= 256), m = Kc(w, m, false), m !== 2) {
                  if (Hc && !T) {
                    w.errorRecoveryDisabledLanes |= u, Xa |= u, o = 4;
                    break e;
                  }
                  u = hn, hn = o, u !== null && Fc(u);
                }
                o = m;
              }
              if (u = false, o !== 2) continue;
            }
          }
          if (o === 1) {
            Mi(e, 0), Hn(e, t, 0, true);
            break;
          }
          e: {
            switch (s = e, o) {
              case 0:
              case 1:
                throw Error(r(345));
              case 4:
                if ((t & 4194176) === t) {
                  Hn(s, t, It, !kn);
                  break e;
                }
                break;
              case 2:
                hn = null;
                break;
              case 3:
              case 5:
                break;
              default:
                throw Error(r(329));
            }
            if (s.finishedWork = n, s.finishedLanes = t, (t & 62914560) === t && (u = Yc + 300 - Je(), 10 < u)) {
              if (Hn(s, t, It, !kn), Ol(s, 0) !== 0) break e;
              s.timeoutHandle = sm(k0.bind(null, s, n, hn, dr, qc, t, It, Xa, ji, kn, 2, -0, 0), u);
              break e;
            }
            k0(s, n, hn, dr, qc, t, It, Xa, ji, kn, 0, -0, 0);
          }
        }
        break;
      } while (true);
      mn(e);
    }
    function Fc(e) {
      hn === null ? hn = e : hn.push.apply(hn, e);
    }
    function k0(e, t, n, s, o, u, m, w, T, N, V, $, H) {
      var G = t.subtreeFlags;
      if ((G & 8192 || (G & 16785408) === 16785408) && (Ks = {
        stylesheets: null,
        count: 0,
        unsuspend: xv
      }, O0(t), t = wv(), t !== null)) {
        e.cancelPendingCommit = t(V0.bind(null, e, n, s, o, m, w, T, 1, $, H)), Hn(e, u, m, !N);
        return;
      }
      V0(e, n, s, o, m, w, T, V, $, H);
    }
    function Lb(e) {
      for (var t = e; ; ) {
        var n = t.tag;
        if ((n === 0 || n === 11 || n === 15) && t.flags & 16384 && (n = t.updateQueue, n !== null && (n = n.stores, n !== null))) for (var s = 0; s < n.length; s++) {
          var o = n[s], u = o.getSnapshot;
          o = o.value;
          try {
            if (!Ut(u(), o)) return false;
          } catch {
            return false;
          }
        }
        if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
        else {
          if (t === e) break;
          for (; t.sibling === null; ) {
            if (t.return === null || t.return === e) return true;
            t = t.return;
          }
          t.sibling.return = t.return, t = t.sibling;
        }
      }
      return true;
    }
    function Hn(e, t, n, s) {
      t &= ~Lc, t &= ~Xa, e.suspendedLanes |= t, e.pingedLanes &= ~t, s && (e.warmLanes |= t), s = e.expirationTimes;
      for (var o = t; 0 < o; ) {
        var u = 31 - Dt(o), m = 1 << u;
        s[u] = -1, o &= ~m;
      }
      n !== 0 && If(e, n, t);
    }
    function mr() {
      return (Ye & 6) === 0 ? (Vs(0), false) : true;
    }
    function Qc() {
      if (Se !== null) {
        if (Be === 0) var e = Se.return;
        else e = Se, Rn = qa = null, Wo(e), xi = null, Es = 0, e = Se;
        for (; e !== null; ) D0(e.alternate, e), e = e.return;
        Se = null;
      }
    }
    function Mi(e, t) {
      e.finishedWork = null, e.finishedLanes = 0;
      var n = e.timeoutHandle;
      n !== -1 && (e.timeoutHandle = -1, iv(n)), n = e.cancelPendingCommit, n !== null && (e.cancelPendingCommit = null, n()), Qc(), ke = e, Se = n = ua(e.current, null), _e9 = t, Be = 0, Bt = null, kn = false, Ri = ss(e, t), Hc = false, ji = It = Lc = Xa = fa = Fe = 0, hn = qs = null, qc = false, (t & 8) !== 0 && (t |= t & 32);
      var s = e.entangledLanes;
      if (s !== 0) for (e = e.entanglements, s &= t; 0 < s; ) {
        var o = 31 - Dt(s), u = 1 << o;
        t |= e[o], s &= ~u;
      }
      return Bn = t, Hl(), n;
    }
    function B0(e, t) {
      ve = null, W.H = dn, t === Ss ? (t = Wd(), Be = 3) : t === $d ? (t = Wd(), Be = 4) : Be = t === Jh ? 8 : t !== null && typeof t == "object" && typeof t.then == "function" ? 6 : 1, Bt = t, Se === null && (Fe = 1, ir(e, Xt(t, e.current)));
    }
    function H0() {
      var e = W.H;
      return W.H = dn, e === null ? dn : e;
    }
    function L0() {
      var e = W.A;
      return W.A = Bb, e;
    }
    function Zc() {
      Fe = 4, kn || (_e9 & 4194176) !== _e9 && Zt.current !== null || (Ri = true), (fa & 134217727) === 0 && (Xa & 134217727) === 0 || ke === null || Hn(ke, _e9, It, false);
    }
    function Kc(e, t, n) {
      var s = Ye;
      Ye |= 2;
      var o = H0(), u = L0();
      (ke !== e || _e9 !== t) && (dr = null, Mi(e, t)), t = false;
      var m = Fe;
      e: do
        try {
          if (Be !== 0 && Se !== null) {
            var w = Se, T = Bt;
            switch (Be) {
              case 8:
                Qc(), m = 6;
                break e;
              case 3:
              case 2:
              case 6:
                Zt.current === null && (t = true);
                var N = Be;
                if (Be = 0, Bt = null, Di(e, w, T, N), n && Ri) {
                  m = 0;
                  break e;
                }
                break;
              default:
                N = Be, Be = 0, Bt = null, Di(e, w, T, N);
            }
          }
          qb(), m = Fe;
          break;
        } catch (V) {
          B0(e, V);
        }
      while (true);
      return t && e.shellSuspendCounter++, Rn = qa = null, Ye = s, W.H = o, W.A = u, Se === null && (ke = null, _e9 = 0, Hl()), m;
    }
    function qb() {
      for (; Se !== null; ) q0(Se);
    }
    function Yb(e, t) {
      var n = Ye;
      Ye |= 2;
      var s = H0(), o = L0();
      ke !== e || _e9 !== t ? (dr = null, fr = Je() + 500, Mi(e, t)) : Ri = ss(e, t);
      e: do
        try {
          if (Be !== 0 && Se !== null) {
            t = Se;
            var u = Bt;
            t: switch (Be) {
              case 1:
                Be = 0, Bt = null, Di(e, t, u, 1);
                break;
              case 2:
                if (Jd(u)) {
                  Be = 0, Bt = null, Y0(t);
                  break;
                }
                t = function() {
                  Be === 2 && ke === e && (Be = 7), mn(e);
                }, u.then(t, t);
                break e;
              case 3:
                Be = 7;
                break e;
              case 4:
                Be = 5;
                break e;
              case 7:
                Jd(u) ? (Be = 0, Bt = null, Y0(t)) : (Be = 0, Bt = null, Di(e, t, u, 7));
                break;
              case 5:
                var m = null;
                switch (Se.tag) {
                  case 26:
                    m = Se.memoizedState;
                  case 5:
                  case 27:
                    var w = Se;
                    if (!m || pm(m)) {
                      Be = 0, Bt = null;
                      var T = w.sibling;
                      if (T !== null) Se = T;
                      else {
                        var N = w.return;
                        N !== null ? (Se = N, yr(N)) : Se = null;
                      }
                      break t;
                    }
                }
                Be = 0, Bt = null, Di(e, t, u, 5);
                break;
              case 6:
                Be = 0, Bt = null, Di(e, t, u, 6);
                break;
              case 8:
                Qc(), Fe = 6;
                break e;
              default:
                throw Error(r(462));
            }
          }
          Gb();
          break;
        } catch (V) {
          B0(e, V);
        }
      while (true);
      return Rn = qa = null, W.H = s, W.A = o, Ye = n, Se !== null ? 0 : (ke = null, _e9 = 0, Hl(), Fe);
    }
    function Gb() {
      for (; Se !== null && !Ne(); ) q0(Se);
    }
    function q0(e) {
      var t = o0(e.alternate, e, Bn);
      e.memoizedProps = e.pendingProps, t === null ? yr(e) : Se = t;
    }
    function Y0(e) {
      var t = e, n = t.alternate;
      switch (t.tag) {
        case 15:
        case 0:
          t = n0(n, t, t.pendingProps, t.type, void 0, _e9);
          break;
        case 11:
          t = n0(n, t, t.pendingProps, t.type.render, t.ref, _e9);
          break;
        case 5:
          Wo(t);
        default:
          D0(n, t), t = Se = R0(t, Bn), t = o0(n, t, Bn);
      }
      e.memoizedProps = e.pendingProps, t === null ? yr(e) : Se = t;
    }
    function Di(e, t, n, s) {
      Rn = qa = null, Wo(t), xi = null, Es = 0;
      var o = t.return;
      try {
        if (Rb(e, o, t, n, _e9)) {
          Fe = 1, ir(e, Xt(n, e.current)), Se = null;
          return;
        }
      } catch (u) {
        if (o !== null) throw Se = o, u;
        Fe = 1, ir(e, Xt(n, e.current)), Se = null;
        return;
      }
      t.flags & 32768 ? (Re || s === 1 ? e = true : Ri || (_e9 & 536870912) !== 0 ? e = false : (kn = e = true, (s === 2 || s === 3 || s === 6) && (s = Zt.current, s !== null && s.tag === 13 && (s.flags |= 16384))), G0(t, e)) : yr(t);
    }
    function yr(e) {
      var t = e;
      do {
        if ((t.flags & 32768) !== 0) {
          G0(t, kn);
          return;
        }
        e = t.return;
        var n = zb(t.alternate, t, Bn);
        if (n !== null) {
          Se = n;
          return;
        }
        if (t = t.sibling, t !== null) {
          Se = t;
          return;
        }
        Se = t = e;
      } while (t !== null);
      Fe === 0 && (Fe = 5);
    }
    function G0(e, t) {
      do {
        var n = kb(e.alternate, e);
        if (n !== null) {
          n.flags &= 32767, Se = n;
          return;
        }
        if (n = e.return, n !== null && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !t && (e = e.sibling, e !== null)) {
          Se = e;
          return;
        }
        Se = e = n;
      } while (e !== null);
      Fe = 6, Se = null;
    }
    function V0(e, t, n, s, o, u, m, w, T, N) {
      var V = W.T, $ = Ee.p;
      try {
        Ee.p = 2, W.T = null, Vb(e, t, n, s, $, o, u, m, w, T, N);
      } finally {
        W.T = V, Ee.p = $;
      }
    }
    function Vb(e, t, n, s, o, u, m, w) {
      do
        Ui();
      while (Fa !== null);
      if ((Ye & 6) !== 0) throw Error(r(327));
      var T = e.finishedWork;
      if (s = e.finishedLanes, T === null) return null;
      if (e.finishedWork = null, e.finishedLanes = 0, T === e.current) throw Error(r(177));
      e.callbackNode = null, e.callbackPriority = 0, e.cancelPendingCommit = null;
      var N = T.lanes | T.childLanes;
      if (N |= Bo, Sg(e, s, N, u, m, w), e === ke && (Se = ke = null, _e9 = 0), (T.subtreeFlags & 10256) === 0 && (T.flags & 10256) === 0 || hr || (hr = true, Gc = N, Vc = n, Zb(wn, function() {
        return Ui(), null;
      })), n = (T.flags & 15990) !== 0, (T.subtreeFlags & 15990) !== 0 || n ? (n = W.T, W.T = null, u = Ee.p, Ee.p = 2, m = Ye, Ye |= 4, Mb(e, T), E0(T, e), hb(lu, e.containerInfo), Cr = !!su, lu = su = null, e.current = T, v0(e, T.alternate, T), Ve(), Ye = m, Ee.p = u, W.T = n) : e.current = T, hr ? (hr = false, Fa = e, Ys = s) : X0(e, N), N = e.pendingLanes, N === 0 && (da = null), pg(T.stateNode), mn(e), t !== null) for (o = e.onRecoverableError, T = 0; T < t.length; T++) N = t[T], o(N.value, {
        componentStack: N.stack
      });
      return (Ys & 3) !== 0 && Ui(), N = e.pendingLanes, (s & 4194218) !== 0 && (N & 42) !== 0 ? e === Xc ? Gs++ : (Gs = 0, Xc = e) : Gs = 0, Vs(0), null;
    }
    function X0(e, t) {
      (e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, Ts(t)));
    }
    function Ui() {
      if (Fa !== null) {
        var e = Fa, t = Gc;
        Gc = 0;
        var n = Pf(Ys), s = W.T, o = Ee.p;
        try {
          if (Ee.p = 32 > n ? 32 : n, W.T = null, Fa === null) var u = false;
          else {
            n = Vc, Vc = null;
            var m = Fa, w = Ys;
            if (Fa = null, Ys = 0, (Ye & 6) !== 0) throw Error(r(331));
            var T = Ye;
            if (Ye |= 4, _0(m.current), T0(m, m.current, w, n), Ye = T, Vs(0, false), at && typeof at.onPostCommitFiberRoot == "function") try {
              at.onPostCommitFiberRoot(qt, m);
            } catch {
            }
            u = true;
          }
          return u;
        } finally {
          Ee.p = o, W.T = s, X0(e, t);
        }
      }
      return false;
    }
    function F0(e, t, n) {
      t = Xt(n, t), t = dc(e.stateNode, t, 2), e = la(e, t, 2), e !== null && (ls(e, 2), mn(e));
    }
    function Ue(e, t, n) {
      if (e.tag === 3) F0(e, e, n);
      else for (; t !== null; ) {
        if (t.tag === 3) {
          F0(t, e, n);
          break;
        } else if (t.tag === 1) {
          var s = t.stateNode;
          if (typeof t.type.getDerivedStateFromError == "function" || typeof s.componentDidCatch == "function" && (da === null || !da.has(s))) {
            e = Xt(n, e), n = Kh(2), s = la(t, n, 2), s !== null && ($h(n, s, t, e), ls(s, 2), mn(s));
            break;
          }
        }
        t = t.return;
      }
    }
    function $c(e, t, n) {
      var s = e.pingCache;
      if (s === null) {
        s = e.pingCache = new Hb();
        var o = /* @__PURE__ */ new Set();
        s.set(t, o);
      } else o = s.get(t), o === void 0 && (o = /* @__PURE__ */ new Set(), s.set(t, o));
      o.has(n) || (Hc = true, o.add(n), e = Xb.bind(null, e, t, n), t.then(e, e));
    }
    function Xb(e, t, n) {
      var s = e.pingCache;
      s !== null && s.delete(t), e.pingedLanes |= e.suspendedLanes & n, e.warmLanes &= ~n, ke === e && (_e9 & n) === n && (Fe === 4 || Fe === 3 && (_e9 & 62914560) === _e9 && 300 > Je() - Yc ? (Ye & 2) === 0 && Mi(e, 0) : Lc |= n, ji === _e9 && (ji = 0)), mn(e);
    }
    function Q0(e, t) {
      t === 0 && (t = Jf()), e = Wn(e, t), e !== null && (ls(e, t), mn(e));
    }
    function Fb(e) {
      var t = e.memoizedState, n = 0;
      t !== null && (n = t.retryLane), Q0(e, n);
    }
    function Qb(e, t) {
      var n = 0;
      switch (e.tag) {
        case 13:
          var s = e.stateNode, o = e.memoizedState;
          o !== null && (n = o.retryLane);
          break;
        case 19:
          s = e.stateNode;
          break;
        case 22:
          s = e.stateNode._retryCache;
          break;
        default:
          throw Error(r(314));
      }
      s !== null && s.delete(t), Q0(e, n);
    }
    function Zb(e, t) {
      return he(e, t);
    }
    var pr = null, zi = null, Jc = false, gr = false, Ic = false, Qa = 0;
    function mn(e) {
      e !== zi && e.next === null && (zi === null ? pr = zi = e : zi = zi.next = e), gr = true, Jc || (Jc = true, $b(Kb));
    }
    function Vs(e, t) {
      if (!Ic && gr) {
        Ic = true;
        do
          for (var n = false, s = pr; s !== null; ) {
            if (e !== 0) {
              var o = s.pendingLanes;
              if (o === 0) var u = 0;
              else {
                var m = s.suspendedLanes, w = s.pingedLanes;
                u = (1 << 31 - Dt(42 | e) + 1) - 1, u &= o & ~(m & ~w), u = u & 201326677 ? u & 201326677 | 1 : u ? u | 2 : 0;
              }
              u !== 0 && (n = true, $0(s, u));
            } else u = _e9, u = Ol(s, s === ke ? u : 0), (u & 3) === 0 || ss(s, u) || (n = true, $0(s, u));
            s = s.next;
          }
        while (n);
        Ic = false;
      }
    }
    function Kb() {
      gr = Jc = false;
      var e = 0;
      Qa !== 0 && (av() && (e = Qa), Qa = 0);
      for (var t = Je(), n = null, s = pr; s !== null; ) {
        var o = s.next, u = Z0(s, t);
        u === 0 ? (s.next = null, n === null ? pr = o : n.next = o, o === null && (zi = n)) : (n = s, (e !== 0 || (u & 3) !== 0) && (gr = true)), s = o;
      }
      Vs(e);
    }
    function Z0(e, t) {
      for (var n = e.suspendedLanes, s = e.pingedLanes, o = e.expirationTimes, u = e.pendingLanes & -62914561; 0 < u; ) {
        var m = 31 - Dt(u), w = 1 << m, T = o[m];
        T === -1 ? ((w & n) === 0 || (w & s) !== 0) && (o[m] = xg(w, t)) : T <= t && (e.expiredLanes |= w), u &= ~w;
      }
      if (t = ke, n = _e9, n = Ol(e, e === t ? n : 0), s = e.callbackNode, n === 0 || e === t && Be === 2 || e.cancelPendingCommit !== null) return s !== null && s !== null && Ae(s), e.callbackNode = null, e.callbackPriority = 0;
      if ((n & 3) === 0 || ss(e, n)) {
        if (t = n & -n, t === e.callbackPriority) return t;
        switch (s !== null && Ae(s), Pf(n)) {
          case 2:
          case 8:
            n = Te;
            break;
          case 32:
            n = wn;
            break;
          case 268435456:
            n = El;
            break;
          default:
            n = wn;
        }
        return s = K0.bind(null, e), n = he(n, s), e.callbackPriority = t, e.callbackNode = n, t;
      }
      return s !== null && s !== null && Ae(s), e.callbackPriority = 2, e.callbackNode = null, 2;
    }
    function K0(e, t) {
      var n = e.callbackNode;
      if (Ui() && e.callbackNode !== n) return null;
      var s = _e9;
      return s = Ol(e, e === ke ? s : 0), s === 0 ? null : (z0(e, s, t), Z0(e, Je()), e.callbackNode != null && e.callbackNode === n ? K0.bind(null, e) : null);
    }
    function $0(e, t) {
      if (Ui()) return null;
      z0(e, t, true);
    }
    function $b(e) {
      sv(function() {
        (Ye & 6) !== 0 ? he(nt, e) : e();
      });
    }
    function Wc() {
      return Qa === 0 && (Qa = $f()), Qa;
    }
    function J0(e) {
      return e == null || typeof e == "symbol" || typeof e == "boolean" ? null : typeof e == "function" ? e : jl("" + e);
    }
    function I0(e, t) {
      var n = t.ownerDocument.createElement("input");
      return n.name = t.name, n.value = t.value, e.id && n.setAttribute("form", e.id), t.parentNode.insertBefore(n, t), e = new FormData(e), n.parentNode.removeChild(n), e;
    }
    function Jb(e, t, n, s, o) {
      if (t === "submit" && n && n.stateNode === o) {
        var u = J0((o[Ot] || null).action), m = s.submitter;
        m && (t = (t = m[Ot] || null) ? J0(t.formAction) : m.getAttribute("formAction"), t !== null && (u = t, m = null));
        var w = new zl("action", "action", null, s, o);
        e.push({
          event: w,
          listeners: [
            {
              instance: null,
              listener: function() {
                if (s.defaultPrevented) {
                  if (Qa !== 0) {
                    var T = m ? I0(o, m) : new FormData(o);
                    rc(n, {
                      pending: true,
                      data: T,
                      method: o.method,
                      action: u
                    }, null, T);
                  }
                } else typeof u == "function" && (w.preventDefault(), T = m ? I0(o, m) : new FormData(o), rc(n, {
                  pending: true,
                  data: T,
                  method: o.method,
                  action: u
                }, u, T));
              },
              currentTarget: o
            }
          ]
        });
      }
    }
    for (var Pc = 0; Pc < Vd.length; Pc++) {
      var eu = Vd[Pc], Ib = eu.toLowerCase(), Wb = eu[0].toUpperCase() + eu.slice(1);
      nn(Ib, "on" + Wb);
    }
    nn(Hd, "onAnimationEnd"), nn(Ld, "onAnimationIteration"), nn(qd, "onAnimationStart"), nn("dblclick", "onDoubleClick"), nn("focusin", "onFocus"), nn("focusout", "onBlur"), nn(yb, "onTransitionRun"), nn(pb, "onTransitionStart"), nn(gb, "onTransitionCancel"), nn(Yd, "onTransitionEnd"), oi("onMouseEnter", [
      "mouseout",
      "mouseover"
    ]), oi("onMouseLeave", [
      "mouseout",
      "mouseover"
    ]), oi("onPointerEnter", [
      "pointerout",
      "pointerover"
    ]), oi("onPointerLeave", [
      "pointerout",
      "pointerover"
    ]), Ca("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), Ca("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), Ca("onBeforeInput", [
      "compositionend",
      "keypress",
      "textInput",
      "paste"
    ]), Ca("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), Ca("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), Ca("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var Xs = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "), Pb = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Xs));
    function W0(e, t) {
      t = (t & 4) !== 0;
      for (var n = 0; n < e.length; n++) {
        var s = e[n], o = s.event;
        s = s.listeners;
        e: {
          var u = void 0;
          if (t) for (var m = s.length - 1; 0 <= m; m--) {
            var w = s[m], T = w.instance, N = w.currentTarget;
            if (w = w.listener, T !== u && o.isPropagationStopped()) break e;
            u = w, o.currentTarget = N;
            try {
              u(o);
            } catch (V) {
              ar(V);
            }
            o.currentTarget = null, u = T;
          }
          else for (m = 0; m < s.length; m++) {
            if (w = s[m], T = w.instance, N = w.currentTarget, w = w.listener, T !== u && o.isPropagationStopped()) break e;
            u = w, o.currentTarget = N;
            try {
              u(o);
            } catch (V) {
              ar(V);
            }
            o.currentTarget = null, u = T;
          }
        }
      }
    }
    function Oe(e, t) {
      var n = t[po];
      n === void 0 && (n = t[po] = /* @__PURE__ */ new Set());
      var s = e + "__bubble";
      n.has(s) || (P0(t, e, 2, false), n.add(s));
    }
    function tu(e, t, n) {
      var s = 0;
      t && (s |= 4), P0(n, e, s, t);
    }
    var br = "_reactListening" + Math.random().toString(36).slice(2);
    function nu(e) {
      if (!e[br]) {
        e[br] = true, nd.forEach(function(n) {
          n !== "selectionchange" && (Pb.has(n) || tu(n, false, e), tu(n, true, e));
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[br] || (t[br] = true, tu("selectionchange", false, t));
      }
    }
    function P0(e, t, n, s) {
      switch (wm(t)) {
        case 2:
          var o = Tv;
          break;
        case 8:
          o = Ov;
          break;
        default:
          o = yu;
      }
      n = o.bind(null, t, n, e), o = void 0, !Ao || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (o = true), s ? o !== void 0 ? e.addEventListener(t, n, {
        capture: true,
        passive: o
      }) : e.addEventListener(t, n, true) : o !== void 0 ? e.addEventListener(t, n, {
        passive: o
      }) : e.addEventListener(t, n, false);
    }
    function au(e, t, n, s, o) {
      var u = s;
      if ((t & 1) === 0 && (t & 2) === 0 && s !== null) e: for (; ; ) {
        if (s === null) return;
        var m = s.tag;
        if (m === 3 || m === 4) {
          var w = s.stateNode.containerInfo;
          if (w === o || w.nodeType === 8 && w.parentNode === o) break;
          if (m === 4) for (m = s.return; m !== null; ) {
            var T = m.tag;
            if ((T === 3 || T === 4) && (T = m.stateNode.containerInfo, T === o || T.nodeType === 8 && T.parentNode === o)) return;
            m = m.return;
          }
          for (; w !== null; ) {
            if (m = Oa(w), m === null) return;
            if (T = m.tag, T === 5 || T === 6 || T === 26 || T === 27) {
              s = u = m;
              continue e;
            }
            w = w.parentNode;
          }
        }
        s = s.return;
      }
      md(function() {
        var N = u, V = wo(n), $ = [];
        e: {
          var H = Gd.get(e);
          if (H !== void 0) {
            var G = zl, re = e;
            switch (e) {
              case "keypress":
                if (Dl(n) === 0) break e;
              case "keydown":
              case "keyup":
                G = Qg;
                break;
              case "focusin":
                re = "focus", G = _o2;
                break;
              case "focusout":
                re = "blur", G = _o2;
                break;
              case "beforeblur":
              case "afterblur":
                G = _o2;
                break;
              case "click":
                if (n.button === 2) break e;
              case "auxclick":
              case "dblclick":
              case "mousedown":
              case "mousemove":
              case "mouseup":
              case "mouseout":
              case "mouseover":
              case "contextmenu":
                G = gd;
                break;
              case "drag":
              case "dragend":
              case "dragenter":
              case "dragexit":
              case "dragleave":
              case "dragover":
              case "dragstart":
              case "drop":
                G = Ug;
                break;
              case "touchcancel":
              case "touchend":
              case "touchmove":
              case "touchstart":
                G = $g;
                break;
              case Hd:
              case Ld:
              case qd:
                G = Bg;
                break;
              case Yd:
                G = Ig;
                break;
              case "scroll":
              case "scrollend":
                G = Mg;
                break;
              case "wheel":
                G = Pg;
                break;
              case "copy":
              case "cut":
              case "paste":
                G = Lg;
                break;
              case "gotpointercapture":
              case "lostpointercapture":
              case "pointercancel":
              case "pointerdown":
              case "pointermove":
              case "pointerout":
              case "pointerover":
              case "pointerup":
                G = vd;
                break;
              case "toggle":
              case "beforetoggle":
                G = tb;
            }
            var ye = (t & 4) !== 0, Qe = !ye && (e === "scroll" || e === "scrollend"), M = ye ? H !== null ? H + "Capture" : null : H;
            ye = [];
            for (var _ = N, U; _ !== null; ) {
              var Z = _;
              if (U = Z.stateNode, Z = Z.tag, Z !== 5 && Z !== 26 && Z !== 27 || U === null || M === null || (Z = cs(_, M), Z != null && ye.push(Fs(_, Z, U))), Qe) break;
              _ = _.return;
            }
            0 < ye.length && (H = new G(H, re, null, n, V), $.push({
              event: H,
              listeners: ye
            }));
          }
        }
        if ((t & 7) === 0) {
          e: {
            if (H = e === "mouseover" || e === "pointerover", G = e === "mouseout" || e === "pointerout", H && n !== So && (re = n.relatedTarget || n.fromElement) && (Oa(re) || re[si])) break e;
            if ((G || H) && (H = V.window === V ? V : (H = V.ownerDocument) ? H.defaultView || H.parentWindow : window, G ? (re = n.relatedTarget || n.toElement, G = N, re = re ? Oa(re) : null, re !== null && (Qe = J(re), ye = re.tag, re !== Qe || ye !== 5 && ye !== 27 && ye !== 6) && (re = null)) : (G = null, re = N), G !== re)) {
              if (ye = gd, Z = "onMouseLeave", M = "onMouseEnter", _ = "mouse", (e === "pointerout" || e === "pointerover") && (ye = vd, Z = "onPointerLeave", M = "onPointerEnter", _ = "pointer"), Qe = G == null ? H : os(G), U = re == null ? H : os(re), H = new ye(Z, _ + "leave", G, n, V), H.target = Qe, H.relatedTarget = U, Z = null, Oa(V) === N && (ye = new ye(M, _ + "enter", re, n, V), ye.target = U, ye.relatedTarget = Qe, Z = ye), Qe = Z, G && re) t: {
                for (ye = G, M = re, _ = 0, U = ye; U; U = ki(U)) _++;
                for (U = 0, Z = M; Z; Z = ki(Z)) U++;
                for (; 0 < _ - U; ) ye = ki(ye), _--;
                for (; 0 < U - _; ) M = ki(M), U--;
                for (; _--; ) {
                  if (ye === M || M !== null && ye === M.alternate) break t;
                  ye = ki(ye), M = ki(M);
                }
                ye = null;
              }
              else ye = null;
              G !== null && em($, H, G, ye, false), re !== null && Qe !== null && em($, Qe, re, ye, true);
            }
          }
          e: {
            if (H = N ? os(N) : window, G = H.nodeName && H.nodeName.toLowerCase(), G === "select" || G === "input" && H.type === "file") var ie = Cd;
            else if (Td(H)) if (_d) ie = fb;
            else {
              ie = cb;
              var xe = ob;
            }
            else G = H.nodeName, !G || G.toLowerCase() !== "input" || H.type !== "checkbox" && H.type !== "radio" ? N && xo(N.elementType) && (ie = Cd) : ie = ub;
            if (ie && (ie = ie(e, N))) {
              Od($, ie, n, V);
              break e;
            }
            xe && xe(e, H, N), e === "focusout" && N && H.type === "number" && N.memoizedProps.value != null && vo(H, "number", H.value);
          }
          switch (xe = N ? os(N) : window, e) {
            case "focusin":
              (Td(xe) || xe.contentEditable === "true") && (mi = xe, Uo = N, gs = null);
              break;
            case "focusout":
              gs = Uo = mi = null;
              break;
            case "mousedown":
              zo = true;
              break;
            case "contextmenu":
            case "mouseup":
            case "dragend":
              zo = false, kd($, n, V);
              break;
            case "selectionchange":
              if (mb) break;
            case "keydown":
            case "keyup":
              kd($, n, V);
          }
          var ce;
          if (Ro) e: {
            switch (e) {
              case "compositionstart":
                var fe = "onCompositionStart";
                break e;
              case "compositionend":
                fe = "onCompositionEnd";
                break e;
              case "compositionupdate":
                fe = "onCompositionUpdate";
                break e;
            }
            fe = void 0;
          }
          else hi ? Ed(e, n) && (fe = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (fe = "onCompositionStart");
          fe && (xd && n.locale !== "ko" && (hi || fe !== "onCompositionStart" ? fe === "onCompositionEnd" && hi && (ce = yd()) : (In = V, To = "value" in In ? In.value : In.textContent, hi = true)), xe = vr(N, fe), 0 < xe.length && (fe = new bd(fe, e, null, n, V), $.push({
            event: fe,
            listeners: xe
          }), ce ? fe.data = ce : (ce = Ad(n), ce !== null && (fe.data = ce)))), (ce = ab ? ib(e, n) : sb(e, n)) && (fe = vr(N, "onBeforeInput"), 0 < fe.length && (xe = new bd("onBeforeInput", "beforeinput", null, n, V), $.push({
            event: xe,
            listeners: fe
          }), xe.data = ce)), Jb($, e, N, n, V);
        }
        W0($, t);
      });
    }
    function Fs(e, t, n) {
      return {
        instance: e,
        listener: t,
        currentTarget: n
      };
    }
    function vr(e, t) {
      for (var n = t + "Capture", s = []; e !== null; ) {
        var o = e, u = o.stateNode;
        o = o.tag, o !== 5 && o !== 26 && o !== 27 || u === null || (o = cs(e, n), o != null && s.unshift(Fs(e, o, u)), o = cs(e, t), o != null && s.push(Fs(e, o, u))), e = e.return;
      }
      return s;
    }
    function ki(e) {
      if (e === null) return null;
      do
        e = e.return;
      while (e && e.tag !== 5 && e.tag !== 27);
      return e || null;
    }
    function em(e, t, n, s, o) {
      for (var u = t._reactName, m = []; n !== null && n !== s; ) {
        var w = n, T = w.alternate, N = w.stateNode;
        if (w = w.tag, T !== null && T === s) break;
        w !== 5 && w !== 26 && w !== 27 || N === null || (T = N, o ? (N = cs(n, u), N != null && m.unshift(Fs(n, N, T))) : o || (N = cs(n, u), N != null && m.push(Fs(n, N, T)))), n = n.return;
      }
      m.length !== 0 && e.push({
        event: t,
        listeners: m
      });
    }
    var ev = /\r\n?/g, tv = /\u0000|\uFFFD/g;
    function tm(e) {
      return (typeof e == "string" ? e : "" + e).replace(ev, `
`).replace(tv, "");
    }
    function nm(e, t) {
      return t = tm(t), tm(e) === t;
    }
    function xr() {
    }
    function De(e, t, n, s, o, u) {
      switch (n) {
        case "children":
          typeof s == "string" ? t === "body" || t === "textarea" && s === "" || ui(e, s) : (typeof s == "number" || typeof s == "bigint") && t !== "body" && ui(e, "" + s);
          break;
        case "className":
          _l2(e, "class", s);
          break;
        case "tabIndex":
          _l2(e, "tabindex", s);
          break;
        case "dir":
        case "role":
        case "viewBox":
        case "width":
        case "height":
          _l2(e, n, s);
          break;
        case "style":
          dd(e, s, u);
          break;
        case "data":
          if (t !== "object") {
            _l2(e, "data", s);
            break;
          }
        case "src":
        case "href":
          if (s === "" && (t !== "a" || n !== "href")) {
            e.removeAttribute(n);
            break;
          }
          if (s == null || typeof s == "function" || typeof s == "symbol" || typeof s == "boolean") {
            e.removeAttribute(n);
            break;
          }
          s = jl("" + s), e.setAttribute(n, s);
          break;
        case "action":
        case "formAction":
          if (typeof s == "function") {
            e.setAttribute(n, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
            break;
          } else typeof u == "function" && (n === "formAction" ? (t !== "input" && De(e, t, "name", o.name, o, null), De(e, t, "formEncType", o.formEncType, o, null), De(e, t, "formMethod", o.formMethod, o, null), De(e, t, "formTarget", o.formTarget, o, null)) : (De(e, t, "encType", o.encType, o, null), De(e, t, "method", o.method, o, null), De(e, t, "target", o.target, o, null)));
          if (s == null || typeof s == "symbol" || typeof s == "boolean") {
            e.removeAttribute(n);
            break;
          }
          s = jl("" + s), e.setAttribute(n, s);
          break;
        case "onClick":
          s != null && (e.onclick = xr);
          break;
        case "onScroll":
          s != null && Oe("scroll", e);
          break;
        case "onScrollEnd":
          s != null && Oe("scrollend", e);
          break;
        case "dangerouslySetInnerHTML":
          if (s != null) {
            if (typeof s != "object" || !("__html" in s)) throw Error(r(61));
            if (n = s.__html, n != null) {
              if (o.children != null) throw Error(r(60));
              e.innerHTML = n;
            }
          }
          break;
        case "multiple":
          e.multiple = s && typeof s != "function" && typeof s != "symbol";
          break;
        case "muted":
          e.muted = s && typeof s != "function" && typeof s != "symbol";
          break;
        case "suppressContentEditableWarning":
        case "suppressHydrationWarning":
        case "defaultValue":
        case "defaultChecked":
        case "innerHTML":
        case "ref":
          break;
        case "autoFocus":
          break;
        case "xlinkHref":
          if (s == null || typeof s == "function" || typeof s == "boolean" || typeof s == "symbol") {
            e.removeAttribute("xlink:href");
            break;
          }
          n = jl("" + s), e.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", n);
          break;
        case "contentEditable":
        case "spellCheck":
        case "draggable":
        case "value":
        case "autoReverse":
        case "externalResourcesRequired":
        case "focusable":
        case "preserveAlpha":
          s != null && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(n, "" + s) : e.removeAttribute(n);
          break;
        case "inert":
        case "allowFullScreen":
        case "async":
        case "autoPlay":
        case "controls":
        case "default":
        case "defer":
        case "disabled":
        case "disablePictureInPicture":
        case "disableRemotePlayback":
        case "formNoValidate":
        case "hidden":
        case "loop":
        case "noModule":
        case "noValidate":
        case "open":
        case "playsInline":
        case "readOnly":
        case "required":
        case "reversed":
        case "scoped":
        case "seamless":
        case "itemScope":
          s && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(n, "") : e.removeAttribute(n);
          break;
        case "capture":
        case "download":
          s === true ? e.setAttribute(n, "") : s !== false && s != null && typeof s != "function" && typeof s != "symbol" ? e.setAttribute(n, s) : e.removeAttribute(n);
          break;
        case "cols":
        case "rows":
        case "size":
        case "span":
          s != null && typeof s != "function" && typeof s != "symbol" && !isNaN(s) && 1 <= s ? e.setAttribute(n, s) : e.removeAttribute(n);
          break;
        case "rowSpan":
        case "start":
          s == null || typeof s == "function" || typeof s == "symbol" || isNaN(s) ? e.removeAttribute(n) : e.setAttribute(n, s);
          break;
        case "popover":
          Oe("beforetoggle", e), Oe("toggle", e), Cl(e, "popover", s);
          break;
        case "xlinkActuate":
          An(e, "http://www.w3.org/1999/xlink", "xlink:actuate", s);
          break;
        case "xlinkArcrole":
          An(e, "http://www.w3.org/1999/xlink", "xlink:arcrole", s);
          break;
        case "xlinkRole":
          An(e, "http://www.w3.org/1999/xlink", "xlink:role", s);
          break;
        case "xlinkShow":
          An(e, "http://www.w3.org/1999/xlink", "xlink:show", s);
          break;
        case "xlinkTitle":
          An(e, "http://www.w3.org/1999/xlink", "xlink:title", s);
          break;
        case "xlinkType":
          An(e, "http://www.w3.org/1999/xlink", "xlink:type", s);
          break;
        case "xmlBase":
          An(e, "http://www.w3.org/XML/1998/namespace", "xml:base", s);
          break;
        case "xmlLang":
          An(e, "http://www.w3.org/XML/1998/namespace", "xml:lang", s);
          break;
        case "xmlSpace":
          An(e, "http://www.w3.org/XML/1998/namespace", "xml:space", s);
          break;
        case "is":
          Cl(e, "is", s);
          break;
        case "innerText":
        case "textContent":
          break;
        default:
          (!(2 < n.length) || n[0] !== "o" && n[0] !== "O" || n[1] !== "n" && n[1] !== "N") && (n = Rg.get(n) || n, Cl(e, n, s));
      }
    }
    function iu(e, t, n, s, o, u) {
      switch (n) {
        case "style":
          dd(e, s, u);
          break;
        case "dangerouslySetInnerHTML":
          if (s != null) {
            if (typeof s != "object" || !("__html" in s)) throw Error(r(61));
            if (n = s.__html, n != null) {
              if (o.children != null) throw Error(r(60));
              e.innerHTML = n;
            }
          }
          break;
        case "children":
          typeof s == "string" ? ui(e, s) : (typeof s == "number" || typeof s == "bigint") && ui(e, "" + s);
          break;
        case "onScroll":
          s != null && Oe("scroll", e);
          break;
        case "onScrollEnd":
          s != null && Oe("scrollend", e);
          break;
        case "onClick":
          s != null && (e.onclick = xr);
          break;
        case "suppressContentEditableWarning":
        case "suppressHydrationWarning":
        case "innerHTML":
        case "ref":
          break;
        case "innerText":
        case "textContent":
          break;
        default:
          if (!ad.hasOwnProperty(n)) e: {
            if (n[0] === "o" && n[1] === "n" && (o = n.endsWith("Capture"), t = n.slice(2, o ? n.length - 7 : void 0), u = e[Ot] || null, u = u != null ? u[n] : null, typeof u == "function" && e.removeEventListener(t, u, o), typeof s == "function")) {
              typeof u != "function" && u !== null && (n in e ? e[n] = null : e.hasAttribute(n) && e.removeAttribute(n)), e.addEventListener(t, s, o);
              break e;
            }
            n in e ? e[n] = s : s === true ? e.setAttribute(n, "") : Cl(e, n, s);
          }
      }
    }
    function pt(e, t, n) {
      switch (t) {
        case "div":
        case "span":
        case "svg":
        case "path":
        case "a":
        case "g":
        case "p":
        case "li":
          break;
        case "img":
          Oe("error", e), Oe("load", e);
          var s = false, o = false, u;
          for (u in n) if (n.hasOwnProperty(u)) {
            var m = n[u];
            if (m != null) switch (u) {
              case "src":
                s = true;
                break;
              case "srcSet":
                o = true;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                throw Error(r(137, t));
              default:
                De(e, t, u, m, n, null);
            }
          }
          o && De(e, t, "srcSet", n.srcSet, n, null), s && De(e, t, "src", n.src, n, null);
          return;
        case "input":
          Oe("invalid", e);
          var w = u = m = o = null, T = null, N = null;
          for (s in n) if (n.hasOwnProperty(s)) {
            var V = n[s];
            if (V != null) switch (s) {
              case "name":
                o = V;
                break;
              case "type":
                m = V;
                break;
              case "checked":
                T = V;
                break;
              case "defaultChecked":
                N = V;
                break;
              case "value":
                u = V;
                break;
              case "defaultValue":
                w = V;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (V != null) throw Error(r(137, t));
                break;
              default:
                De(e, t, s, V, n, null);
            }
          }
          od(e, u, w, T, N, m, o, false), Nl(e);
          return;
        case "select":
          Oe("invalid", e), s = m = u = null;
          for (o in n) if (n.hasOwnProperty(o) && (w = n[o], w != null)) switch (o) {
            case "value":
              u = w;
              break;
            case "defaultValue":
              m = w;
              break;
            case "multiple":
              s = w;
            default:
              De(e, t, o, w, n, null);
          }
          t = u, n = m, e.multiple = !!s, t != null ? ci(e, !!s, t, false) : n != null && ci(e, !!s, n, true);
          return;
        case "textarea":
          Oe("invalid", e), u = o = s = null;
          for (m in n) if (n.hasOwnProperty(m) && (w = n[m], w != null)) switch (m) {
            case "value":
              s = w;
              break;
            case "defaultValue":
              o = w;
              break;
            case "children":
              u = w;
              break;
            case "dangerouslySetInnerHTML":
              if (w != null) throw Error(r(91));
              break;
            default:
              De(e, t, m, w, n, null);
          }
          ud(e, s, o, u), Nl(e);
          return;
        case "option":
          for (T in n) if (n.hasOwnProperty(T) && (s = n[T], s != null)) switch (T) {
            case "selected":
              e.selected = s && typeof s != "function" && typeof s != "symbol";
              break;
            default:
              De(e, t, T, s, n, null);
          }
          return;
        case "dialog":
          Oe("cancel", e), Oe("close", e);
          break;
        case "iframe":
        case "object":
          Oe("load", e);
          break;
        case "video":
        case "audio":
          for (s = 0; s < Xs.length; s++) Oe(Xs[s], e);
          break;
        case "image":
          Oe("error", e), Oe("load", e);
          break;
        case "details":
          Oe("toggle", e);
          break;
        case "embed":
        case "source":
        case "link":
          Oe("error", e), Oe("load", e);
        case "area":
        case "base":
        case "br":
        case "col":
        case "hr":
        case "keygen":
        case "meta":
        case "param":
        case "track":
        case "wbr":
        case "menuitem":
          for (N in n) if (n.hasOwnProperty(N) && (s = n[N], s != null)) switch (N) {
            case "children":
            case "dangerouslySetInnerHTML":
              throw Error(r(137, t));
            default:
              De(e, t, N, s, n, null);
          }
          return;
        default:
          if (xo(t)) {
            for (V in n) n.hasOwnProperty(V) && (s = n[V], s !== void 0 && iu(e, t, V, s, n, void 0));
            return;
          }
      }
      for (w in n) n.hasOwnProperty(w) && (s = n[w], s != null && De(e, t, w, s, n, null));
    }
    function nv(e, t, n, s) {
      switch (t) {
        case "div":
        case "span":
        case "svg":
        case "path":
        case "a":
        case "g":
        case "p":
        case "li":
          break;
        case "input":
          var o = null, u = null, m = null, w = null, T = null, N = null, V = null;
          for (G in n) {
            var $ = n[G];
            if (n.hasOwnProperty(G) && $ != null) switch (G) {
              case "checked":
                break;
              case "value":
                break;
              case "defaultValue":
                T = $;
              default:
                s.hasOwnProperty(G) || De(e, t, G, null, s, $);
            }
          }
          for (var H in s) {
            var G = s[H];
            if ($ = n[H], s.hasOwnProperty(H) && (G != null || $ != null)) switch (H) {
              case "type":
                u = G;
                break;
              case "name":
                o = G;
                break;
              case "checked":
                N = G;
                break;
              case "defaultChecked":
                V = G;
                break;
              case "value":
                m = G;
                break;
              case "defaultValue":
                w = G;
                break;
              case "children":
              case "dangerouslySetInnerHTML":
                if (G != null) throw Error(r(137, t));
                break;
              default:
                G !== $ && De(e, t, H, G, s, $);
            }
          }
          bo(e, m, w, T, N, V, u, o);
          return;
        case "select":
          G = m = w = H = null;
          for (u in n) if (T = n[u], n.hasOwnProperty(u) && T != null) switch (u) {
            case "value":
              break;
            case "multiple":
              G = T;
            default:
              s.hasOwnProperty(u) || De(e, t, u, null, s, T);
          }
          for (o in s) if (u = s[o], T = n[o], s.hasOwnProperty(o) && (u != null || T != null)) switch (o) {
            case "value":
              H = u;
              break;
            case "defaultValue":
              w = u;
              break;
            case "multiple":
              m = u;
            default:
              u !== T && De(e, t, o, u, s, T);
          }
          t = w, n = m, s = G, H != null ? ci(e, !!n, H, false) : !!s != !!n && (t != null ? ci(e, !!n, t, true) : ci(e, !!n, n ? [] : "", false));
          return;
        case "textarea":
          G = H = null;
          for (w in n) if (o = n[w], n.hasOwnProperty(w) && o != null && !s.hasOwnProperty(w)) switch (w) {
            case "value":
              break;
            case "children":
              break;
            default:
              De(e, t, w, null, s, o);
          }
          for (m in s) if (o = s[m], u = n[m], s.hasOwnProperty(m) && (o != null || u != null)) switch (m) {
            case "value":
              H = o;
              break;
            case "defaultValue":
              G = o;
              break;
            case "children":
              break;
            case "dangerouslySetInnerHTML":
              if (o != null) throw Error(r(91));
              break;
            default:
              o !== u && De(e, t, m, o, s, u);
          }
          cd(e, H, G);
          return;
        case "option":
          for (var re in n) if (H = n[re], n.hasOwnProperty(re) && H != null && !s.hasOwnProperty(re)) switch (re) {
            case "selected":
              e.selected = false;
              break;
            default:
              De(e, t, re, null, s, H);
          }
          for (T in s) if (H = s[T], G = n[T], s.hasOwnProperty(T) && H !== G && (H != null || G != null)) switch (T) {
            case "selected":
              e.selected = H && typeof H != "function" && typeof H != "symbol";
              break;
            default:
              De(e, t, T, H, s, G);
          }
          return;
        case "img":
        case "link":
        case "area":
        case "base":
        case "br":
        case "col":
        case "embed":
        case "hr":
        case "keygen":
        case "meta":
        case "param":
        case "source":
        case "track":
        case "wbr":
        case "menuitem":
          for (var ye in n) H = n[ye], n.hasOwnProperty(ye) && H != null && !s.hasOwnProperty(ye) && De(e, t, ye, null, s, H);
          for (N in s) if (H = s[N], G = n[N], s.hasOwnProperty(N) && H !== G && (H != null || G != null)) switch (N) {
            case "children":
            case "dangerouslySetInnerHTML":
              if (H != null) throw Error(r(137, t));
              break;
            default:
              De(e, t, N, H, s, G);
          }
          return;
        default:
          if (xo(t)) {
            for (var Qe in n) H = n[Qe], n.hasOwnProperty(Qe) && H !== void 0 && !s.hasOwnProperty(Qe) && iu(e, t, Qe, void 0, s, H);
            for (V in s) H = s[V], G = n[V], !s.hasOwnProperty(V) || H === G || H === void 0 && G === void 0 || iu(e, t, V, H, s, G);
            return;
          }
      }
      for (var M in n) H = n[M], n.hasOwnProperty(M) && H != null && !s.hasOwnProperty(M) && De(e, t, M, null, s, H);
      for ($ in s) H = s[$], G = n[$], !s.hasOwnProperty($) || H === G || H == null && G == null || De(e, t, $, H, s, G);
    }
    var su = null, lu = null;
    function Sr(e) {
      return e.nodeType === 9 ? e : e.ownerDocument;
    }
    function am(e) {
      switch (e) {
        case "http://www.w3.org/2000/svg":
          return 1;
        case "http://www.w3.org/1998/Math/MathML":
          return 2;
        default:
          return 0;
      }
    }
    function im(e, t) {
      if (e === 0) switch (t) {
        case "svg":
          return 1;
        case "math":
          return 2;
        default:
          return 0;
      }
      return e === 1 && t === "foreignObject" ? 0 : e;
    }
    function ru(e, t) {
      return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.children == "bigint" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
    }
    var ou = null;
    function av() {
      var e = window.event;
      return e && e.type === "popstate" ? e === ou ? false : (ou = e, true) : (ou = null, false);
    }
    var sm = typeof setTimeout == "function" ? setTimeout : void 0, iv = typeof clearTimeout == "function" ? clearTimeout : void 0, lm = typeof Promise == "function" ? Promise : void 0, sv = typeof queueMicrotask == "function" ? queueMicrotask : typeof lm < "u" ? function(e) {
      return lm.resolve(null).then(e).catch(lv);
    } : sm;
    function lv(e) {
      setTimeout(function() {
        throw e;
      });
    }
    function cu(e, t) {
      var n = t, s = 0;
      do {
        var o = n.nextSibling;
        if (e.removeChild(n), o && o.nodeType === 8) if (n = o.data, n === "/$") {
          if (s === 0) {
            e.removeChild(o), Ps(t);
            return;
          }
          s--;
        } else n !== "$" && n !== "$?" && n !== "$!" || s++;
        n = o;
      } while (n);
      Ps(t);
    }
    function uu(e) {
      var t = e.firstChild;
      for (t && t.nodeType === 10 && (t = t.nextSibling); t; ) {
        var n = t;
        switch (t = t.nextSibling, n.nodeName) {
          case "HTML":
          case "HEAD":
          case "BODY":
            uu(n), go(n);
            continue;
          case "SCRIPT":
          case "STYLE":
            continue;
          case "LINK":
            if (n.rel.toLowerCase() === "stylesheet") continue;
        }
        e.removeChild(n);
      }
    }
    function rv(e, t, n, s) {
      for (; e.nodeType === 1; ) {
        var o = n;
        if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
          if (!s && (e.nodeName !== "INPUT" || e.type !== "hidden")) break;
        } else if (s) {
          if (!e[rs]) switch (t) {
            case "meta":
              if (!e.hasAttribute("itemprop")) break;
              return e;
            case "link":
              if (u = e.getAttribute("rel"), u === "stylesheet" && e.hasAttribute("data-precedence")) break;
              if (u !== o.rel || e.getAttribute("href") !== (o.href == null ? null : o.href) || e.getAttribute("crossorigin") !== (o.crossOrigin == null ? null : o.crossOrigin) || e.getAttribute("title") !== (o.title == null ? null : o.title)) break;
              return e;
            case "style":
              if (e.hasAttribute("data-precedence")) break;
              return e;
            case "script":
              if (u = e.getAttribute("src"), (u !== (o.src == null ? null : o.src) || e.getAttribute("type") !== (o.type == null ? null : o.type) || e.getAttribute("crossorigin") !== (o.crossOrigin == null ? null : o.crossOrigin)) && u && e.hasAttribute("async") && !e.hasAttribute("itemprop")) break;
              return e;
            default:
              return e;
          }
        } else if (t === "input" && e.type === "hidden") {
          var u = o.name == null ? null : "" + o.name;
          if (o.type === "hidden" && e.getAttribute("name") === u) return e;
        } else return e;
        if (e = ln(e.nextSibling), e === null) break;
      }
      return null;
    }
    function ov(e, t, n) {
      if (t === "") return null;
      for (; e.nodeType !== 3; ) if ((e.nodeType !== 1 || e.nodeName !== "INPUT" || e.type !== "hidden") && !n || (e = ln(e.nextSibling), e === null)) return null;
      return e;
    }
    function ln(e) {
      for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
          if (t = e.data, t === "$" || t === "$!" || t === "$?" || t === "F!" || t === "F") break;
          if (t === "/$") return null;
        }
      }
      return e;
    }
    function rm(e) {
      e = e.previousSibling;
      for (var t = 0; e; ) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === "$" || n === "$!" || n === "$?") {
            if (t === 0) return e;
            t--;
          } else n === "/$" && t++;
        }
        e = e.previousSibling;
      }
      return null;
    }
    function om(e, t, n) {
      switch (t = Sr(n), e) {
        case "html":
          if (e = t.documentElement, !e) throw Error(r(452));
          return e;
        case "head":
          if (e = t.head, !e) throw Error(r(453));
          return e;
        case "body":
          if (e = t.body, !e) throw Error(r(454));
          return e;
        default:
          throw Error(r(451));
      }
    }
    var Wt = /* @__PURE__ */ new Map(), cm = /* @__PURE__ */ new Set();
    function wr(e) {
      return typeof e.getRootNode == "function" ? e.getRootNode() : e.ownerDocument;
    }
    var Ln = Ee.d;
    Ee.d = {
      f: cv,
      r: uv,
      D: fv,
      C: dv,
      L: hv,
      m: mv,
      X: pv,
      S: yv,
      M: gv
    };
    function cv() {
      var e = Ln.f(), t = mr();
      return e || t;
    }
    function uv(e) {
      var t = li(e);
      t !== null && t.tag === 5 && t.type === "form" ? kh(t) : Ln.r(e);
    }
    var Bi = typeof document > "u" ? null : document;
    function um(e, t, n) {
      var s = Bi;
      if (s && typeof t == "string" && t) {
        var o = Gt(t);
        o = 'link[rel="' + e + '"][href="' + o + '"]', typeof n == "string" && (o += '[crossorigin="' + n + '"]'), cm.has(o) || (cm.add(o), e = {
          rel: e,
          crossOrigin: n,
          href: t
        }, s.querySelector(o) === null && (t = s.createElement("link"), pt(t, "link", e), ct(t), s.head.appendChild(t)));
      }
    }
    function fv(e) {
      Ln.D(e), um("dns-prefetch", e, null);
    }
    function dv(e, t) {
      Ln.C(e, t), um("preconnect", e, t);
    }
    function hv(e, t, n) {
      Ln.L(e, t, n);
      var s = Bi;
      if (s && e && t) {
        var o = 'link[rel="preload"][as="' + Gt(t) + '"]';
        t === "image" && n && n.imageSrcSet ? (o += '[imagesrcset="' + Gt(n.imageSrcSet) + '"]', typeof n.imageSizes == "string" && (o += '[imagesizes="' + Gt(n.imageSizes) + '"]')) : o += '[href="' + Gt(e) + '"]';
        var u = o;
        switch (t) {
          case "style":
            u = Hi(e);
            break;
          case "script":
            u = Li(e);
        }
        Wt.has(u) || (e = P({
          rel: "preload",
          href: t === "image" && n && n.imageSrcSet ? void 0 : e,
          as: t
        }, n), Wt.set(u, e), s.querySelector(o) !== null || t === "style" && s.querySelector(Qs(u)) || t === "script" && s.querySelector(Zs(u)) || (t = s.createElement("link"), pt(t, "link", e), ct(t), s.head.appendChild(t)));
      }
    }
    function mv(e, t) {
      Ln.m(e, t);
      var n = Bi;
      if (n && e) {
        var s = t && typeof t.as == "string" ? t.as : "script", o = 'link[rel="modulepreload"][as="' + Gt(s) + '"][href="' + Gt(e) + '"]', u = o;
        switch (s) {
          case "audioworklet":
          case "paintworklet":
          case "serviceworker":
          case "sharedworker":
          case "worker":
          case "script":
            u = Li(e);
        }
        if (!Wt.has(u) && (e = P({
          rel: "modulepreload",
          href: e
        }, t), Wt.set(u, e), n.querySelector(o) === null)) {
          switch (s) {
            case "audioworklet":
            case "paintworklet":
            case "serviceworker":
            case "sharedworker":
            case "worker":
            case "script":
              if (n.querySelector(Zs(u))) return;
          }
          s = n.createElement("link"), pt(s, "link", e), ct(s), n.head.appendChild(s);
        }
      }
    }
    function yv(e, t, n) {
      Ln.S(e, t, n);
      var s = Bi;
      if (s && e) {
        var o = ri(s).hoistableStyles, u = Hi(e);
        t = t || "default";
        var m = o.get(u);
        if (!m) {
          var w = {
            loading: 0,
            preload: null
          };
          if (m = s.querySelector(Qs(u))) w.loading = 5;
          else {
            e = P({
              rel: "stylesheet",
              href: e,
              "data-precedence": t
            }, n), (n = Wt.get(u)) && fu(e, n);
            var T = m = s.createElement("link");
            ct(T), pt(T, "link", e), T._p = new Promise(function(N, V) {
              T.onload = N, T.onerror = V;
            }), T.addEventListener("load", function() {
              w.loading |= 1;
            }), T.addEventListener("error", function() {
              w.loading |= 2;
            }), w.loading |= 4, Er(m, t, s);
          }
          m = {
            type: "stylesheet",
            instance: m,
            count: 1,
            state: w
          }, o.set(u, m);
        }
      }
    }
    function pv(e, t) {
      Ln.X(e, t);
      var n = Bi;
      if (n && e) {
        var s = ri(n).hoistableScripts, o = Li(e), u = s.get(o);
        u || (u = n.querySelector(Zs(o)), u || (e = P({
          src: e,
          async: true
        }, t), (t = Wt.get(o)) && du(e, t), u = n.createElement("script"), ct(u), pt(u, "link", e), n.head.appendChild(u)), u = {
          type: "script",
          instance: u,
          count: 1,
          state: null
        }, s.set(o, u));
      }
    }
    function gv(e, t) {
      Ln.M(e, t);
      var n = Bi;
      if (n && e) {
        var s = ri(n).hoistableScripts, o = Li(e), u = s.get(o);
        u || (u = n.querySelector(Zs(o)), u || (e = P({
          src: e,
          async: true,
          type: "module"
        }, t), (t = Wt.get(o)) && du(e, t), u = n.createElement("script"), ct(u), pt(u, "link", e), n.head.appendChild(u)), u = {
          type: "script",
          instance: u,
          count: 1,
          state: null
        }, s.set(o, u));
      }
    }
    function fm(e, t, n, s) {
      var o = (o = tn.current) ? wr(o) : null;
      if (!o) throw Error(r(446));
      switch (e) {
        case "meta":
        case "title":
          return null;
        case "style":
          return typeof n.precedence == "string" && typeof n.href == "string" ? (t = Hi(n.href), n = ri(o).hoistableStyles, s = n.get(t), s || (s = {
            type: "style",
            instance: null,
            count: 0,
            state: null
          }, n.set(t, s)), s) : {
            type: "void",
            instance: null,
            count: 0,
            state: null
          };
        case "link":
          if (n.rel === "stylesheet" && typeof n.href == "string" && typeof n.precedence == "string") {
            e = Hi(n.href);
            var u = ri(o).hoistableStyles, m = u.get(e);
            if (m || (o = o.ownerDocument || o, m = {
              type: "stylesheet",
              instance: null,
              count: 0,
              state: {
                loading: 0,
                preload: null
              }
            }, u.set(e, m), (u = o.querySelector(Qs(e))) && !u._p && (m.instance = u, m.state.loading = 5), Wt.has(e) || (n = {
              rel: "preload",
              as: "style",
              href: n.href,
              crossOrigin: n.crossOrigin,
              integrity: n.integrity,
              media: n.media,
              hrefLang: n.hrefLang,
              referrerPolicy: n.referrerPolicy
            }, Wt.set(e, n), u || bv(o, e, n, m.state))), t && s === null) throw Error(r(528, ""));
            return m;
          }
          if (t && s !== null) throw Error(r(529, ""));
          return null;
        case "script":
          return t = n.async, n = n.src, typeof n == "string" && t && typeof t != "function" && typeof t != "symbol" ? (t = Li(n), n = ri(o).hoistableScripts, s = n.get(t), s || (s = {
            type: "script",
            instance: null,
            count: 0,
            state: null
          }, n.set(t, s)), s) : {
            type: "void",
            instance: null,
            count: 0,
            state: null
          };
        default:
          throw Error(r(444, e));
      }
    }
    function Hi(e) {
      return 'href="' + Gt(e) + '"';
    }
    function Qs(e) {
      return 'link[rel="stylesheet"][' + e + "]";
    }
    function dm(e) {
      return P({}, e, {
        "data-precedence": e.precedence,
        precedence: null
      });
    }
    function bv(e, t, n, s) {
      e.querySelector('link[rel="preload"][as="style"][' + t + "]") ? s.loading = 1 : (t = e.createElement("link"), s.preload = t, t.addEventListener("load", function() {
        return s.loading |= 1;
      }), t.addEventListener("error", function() {
        return s.loading |= 2;
      }), pt(t, "link", n), ct(t), e.head.appendChild(t));
    }
    function Li(e) {
      return '[src="' + Gt(e) + '"]';
    }
    function Zs(e) {
      return "script[async]" + e;
    }
    function hm(e, t, n) {
      if (t.count++, t.instance === null) switch (t.type) {
        case "style":
          var s = e.querySelector('style[data-href~="' + Gt(n.href) + '"]');
          if (s) return t.instance = s, ct(s), s;
          var o = P({}, n, {
            "data-href": n.href,
            "data-precedence": n.precedence,
            href: null,
            precedence: null
          });
          return s = (e.ownerDocument || e).createElement("style"), ct(s), pt(s, "style", o), Er(s, n.precedence, e), t.instance = s;
        case "stylesheet":
          o = Hi(n.href);
          var u = e.querySelector(Qs(o));
          if (u) return t.state.loading |= 4, t.instance = u, ct(u), u;
          s = dm(n), (o = Wt.get(o)) && fu(s, o), u = (e.ownerDocument || e).createElement("link"), ct(u);
          var m = u;
          return m._p = new Promise(function(w, T) {
            m.onload = w, m.onerror = T;
          }), pt(u, "link", s), t.state.loading |= 4, Er(u, n.precedence, e), t.instance = u;
        case "script":
          return u = Li(n.src), (o = e.querySelector(Zs(u))) ? (t.instance = o, ct(o), o) : (s = n, (o = Wt.get(u)) && (s = P({}, n), du(s, o)), e = e.ownerDocument || e, o = e.createElement("script"), ct(o), pt(o, "link", s), e.head.appendChild(o), t.instance = o);
        case "void":
          return null;
        default:
          throw Error(r(443, t.type));
      }
      else t.type === "stylesheet" && (t.state.loading & 4) === 0 && (s = t.instance, t.state.loading |= 4, Er(s, n.precedence, e));
      return t.instance;
    }
    function Er(e, t, n) {
      for (var s = n.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), o = s.length ? s[s.length - 1] : null, u = o, m = 0; m < s.length; m++) {
        var w = s[m];
        if (w.dataset.precedence === t) u = w;
        else if (u !== o) break;
      }
      u ? u.parentNode.insertBefore(e, u.nextSibling) : (t = n.nodeType === 9 ? n.head : n, t.insertBefore(e, t.firstChild));
    }
    function fu(e, t) {
      e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.title == null && (e.title = t.title);
    }
    function du(e, t) {
      e.crossOrigin == null && (e.crossOrigin = t.crossOrigin), e.referrerPolicy == null && (e.referrerPolicy = t.referrerPolicy), e.integrity == null && (e.integrity = t.integrity);
    }
    var Ar = null;
    function mm(e, t, n) {
      if (Ar === null) {
        var s = /* @__PURE__ */ new Map(), o = Ar = /* @__PURE__ */ new Map();
        o.set(n, s);
      } else o = Ar, s = o.get(n), s || (s = /* @__PURE__ */ new Map(), o.set(n, s));
      if (s.has(e)) return s;
      for (s.set(e, null), n = n.getElementsByTagName(e), o = 0; o < n.length; o++) {
        var u = n[o];
        if (!(u[rs] || u[vt] || e === "link" && u.getAttribute("rel") === "stylesheet") && u.namespaceURI !== "http://www.w3.org/2000/svg") {
          var m = u.getAttribute(t) || "";
          m = e + m;
          var w = s.get(m);
          w ? w.push(u) : s.set(m, [
            u
          ]);
        }
      }
      return s;
    }
    function ym(e, t, n) {
      e = e.ownerDocument || e, e.head.insertBefore(n, t === "title" ? e.querySelector("head > title") : null);
    }
    function vv(e, t, n) {
      if (n === 1 || t.itemProp != null) return false;
      switch (e) {
        case "meta":
        case "title":
          return true;
        case "style":
          if (typeof t.precedence != "string" || typeof t.href != "string" || t.href === "") break;
          return true;
        case "link":
          if (typeof t.rel != "string" || typeof t.href != "string" || t.href === "" || t.onLoad || t.onError) break;
          switch (t.rel) {
            case "stylesheet":
              return e = t.disabled, typeof t.precedence == "string" && e == null;
            default:
              return true;
          }
        case "script":
          if (t.async && typeof t.async != "function" && typeof t.async != "symbol" && !t.onLoad && !t.onError && t.src && typeof t.src == "string") return true;
      }
      return false;
    }
    function pm(e) {
      return !(e.type === "stylesheet" && (e.state.loading & 3) === 0);
    }
    var Ks = null;
    function xv() {
    }
    function Sv(e, t, n) {
      if (Ks === null) throw Error(r(475));
      var s = Ks;
      if (t.type === "stylesheet" && (typeof n.media != "string" || matchMedia(n.media).matches !== false) && (t.state.loading & 4) === 0) {
        if (t.instance === null) {
          var o = Hi(n.href), u = e.querySelector(Qs(o));
          if (u) {
            e = u._p, e !== null && typeof e == "object" && typeof e.then == "function" && (s.count++, s = Tr.bind(s), e.then(s, s)), t.state.loading |= 4, t.instance = u, ct(u);
            return;
          }
          u = e.ownerDocument || e, n = dm(n), (o = Wt.get(o)) && fu(n, o), u = u.createElement("link"), ct(u);
          var m = u;
          m._p = new Promise(function(w, T) {
            m.onload = w, m.onerror = T;
          }), pt(u, "link", n), t.instance = u;
        }
        s.stylesheets === null && (s.stylesheets = /* @__PURE__ */ new Map()), s.stylesheets.set(t, e), (e = t.state.preload) && (t.state.loading & 3) === 0 && (s.count++, t = Tr.bind(s), e.addEventListener("load", t), e.addEventListener("error", t));
      }
    }
    function wv() {
      if (Ks === null) throw Error(r(475));
      var e = Ks;
      return e.stylesheets && e.count === 0 && hu(e, e.stylesheets), 0 < e.count ? function(t) {
        var n = setTimeout(function() {
          if (e.stylesheets && hu(e, e.stylesheets), e.unsuspend) {
            var s = e.unsuspend;
            e.unsuspend = null, s();
          }
        }, 6e4);
        return e.unsuspend = t, function() {
          e.unsuspend = null, clearTimeout(n);
        };
      } : null;
    }
    function Tr() {
      if (this.count--, this.count === 0) {
        if (this.stylesheets) hu(this, this.stylesheets);
        else if (this.unsuspend) {
          var e = this.unsuspend;
          this.unsuspend = null, e();
        }
      }
    }
    var Or = null;
    function hu(e, t) {
      e.stylesheets = null, e.unsuspend !== null && (e.count++, Or = /* @__PURE__ */ new Map(), t.forEach(Ev, e), Or = null, Tr.call(e));
    }
    function Ev(e, t) {
      if (!(t.state.loading & 4)) {
        var n = Or.get(e);
        if (n) var s = n.get(null);
        else {
          n = /* @__PURE__ */ new Map(), Or.set(e, n);
          for (var o = e.querySelectorAll("link[data-precedence],style[data-precedence]"), u = 0; u < o.length; u++) {
            var m = o[u];
            (m.nodeName === "LINK" || m.getAttribute("media") !== "not all") && (n.set(m.dataset.precedence, m), s = m);
          }
          s && n.set(null, s);
        }
        o = t.instance, m = o.getAttribute("data-precedence"), u = n.get(m) || s, u === s && n.set(null, o), n.set(m, o), this.count++, s = Tr.bind(this), o.addEventListener("load", s), o.addEventListener("error", s), u ? u.parentNode.insertBefore(o, u.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(o, e.firstChild)), t.state.loading |= 4;
      }
    }
    var $s = {
      $$typeof: x,
      Provider: null,
      Consumer: null,
      _currentValue: bt,
      _currentValue2: bt,
      _threadCount: 0
    };
    function Av(e, t, n, s, o, u, m, w) {
      this.tag = 1, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = yo(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.finishedLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = yo(0), this.hiddenUpdates = yo(null), this.identifierPrefix = s, this.onUncaughtError = o, this.onCaughtError = u, this.onRecoverableError = m, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = w, this.incompleteTransitions = /* @__PURE__ */ new Map();
    }
    function gm(e, t, n, s, o, u, m, w, T, N, V, $) {
      return e = new Av(e, t, n, m, w, T, N, $), t = 1, u === true && (t |= 24), u = Jt(3, null, null, t), e.current = u, u.stateNode = e, t = Fo(), t.refCount++, e.pooledCache = t, t.refCount++, u.memoizedState = {
        element: s,
        isDehydrated: n,
        cache: t
      }, Tc(u), e;
    }
    function bm(e) {
      return e ? (e = gi, e) : gi;
    }
    function vm(e, t, n, s, o, u) {
      o = bm(o), s.context === null ? s.context = o : s.pendingContext = o, s = sa(t), s.payload = {
        element: n
      }, u = u === void 0 ? null : u, u !== null && (s.callback = u), n = la(e, s, t), n !== null && (Et(n, e, t), Ms(n, e, t));
    }
    function xm(e, t) {
      if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t;
      }
    }
    function mu(e, t) {
      xm(e, t), (e = e.alternate) && xm(e, t);
    }
    function Sm(e) {
      if (e.tag === 13) {
        var t = Wn(e, 67108864);
        t !== null && Et(t, e, 67108864), mu(e, 67108864);
      }
    }
    var Cr = true;
    function Tv(e, t, n, s) {
      var o = W.T;
      W.T = null;
      var u = Ee.p;
      try {
        Ee.p = 2, yu(e, t, n, s);
      } finally {
        Ee.p = u, W.T = o;
      }
    }
    function Ov(e, t, n, s) {
      var o = W.T;
      W.T = null;
      var u = Ee.p;
      try {
        Ee.p = 8, yu(e, t, n, s);
      } finally {
        Ee.p = u, W.T = o;
      }
    }
    function yu(e, t, n, s) {
      if (Cr) {
        var o = pu(s);
        if (o === null) au(e, t, s, _r4, n), Em(e, s);
        else if (_v(o, e, t, n, s)) s.stopPropagation();
        else if (Em(e, s), t & 4 && -1 < Cv.indexOf(e)) {
          for (; o !== null; ) {
            var u = li(o);
            if (u !== null) switch (u.tag) {
              case 3:
                if (u = u.stateNode, u.current.memoizedState.isDehydrated) {
                  var m = Ta(u.pendingLanes);
                  if (m !== 0) {
                    var w = u;
                    for (w.pendingLanes |= 2, w.entangledLanes |= 2; m; ) {
                      var T = 1 << 31 - Dt(m);
                      w.entanglements[1] |= T, m &= ~T;
                    }
                    mn(u), (Ye & 6) === 0 && (fr = Je() + 500, Vs(0));
                  }
                }
                break;
              case 13:
                w = Wn(u, 2), w !== null && Et(w, u, 2), mr(), mu(u, 2);
            }
            if (u = pu(s), u === null && au(e, t, s, _r4, n), u === o) break;
            o = u;
          }
          o !== null && s.stopPropagation();
        } else au(e, t, s, null, n);
      }
    }
    function pu(e) {
      return e = wo(e), gu(e);
    }
    var _r4 = null;
    function gu(e) {
      if (_r4 = null, e = Oa(e), e !== null) {
        var t = J(e);
        if (t === null) e = null;
        else {
          var n = t.tag;
          if (n === 13) {
            if (e = ne(t), e !== null) return e;
            e = null;
          } else if (n === 3) {
            if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
            e = null;
          } else t !== e && (e = null);
        }
      }
      return _r4 = e, null;
    }
    function wm(e) {
      switch (e) {
        case "beforetoggle":
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "toggle":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
          return 2;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
          return 8;
        case "message":
          switch (Aa()) {
            case nt:
              return 2;
            case Te:
              return 8;
            case wn:
            case mo:
              return 32;
            case El:
              return 268435456;
            default:
              return 32;
          }
        default:
          return 32;
      }
    }
    var bu = false, ha = null, ma = null, ya = null, Js = /* @__PURE__ */ new Map(), Is = /* @__PURE__ */ new Map(), pa = [], Cv = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");
    function Em(e, t) {
      switch (e) {
        case "focusin":
        case "focusout":
          ha = null;
          break;
        case "dragenter":
        case "dragleave":
          ma = null;
          break;
        case "mouseover":
        case "mouseout":
          ya = null;
          break;
        case "pointerover":
        case "pointerout":
          Js.delete(t.pointerId);
          break;
        case "gotpointercapture":
        case "lostpointercapture":
          Is.delete(t.pointerId);
      }
    }
    function Ws(e, t, n, s, o, u) {
      return e === null || e.nativeEvent !== u ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: s,
        nativeEvent: u,
        targetContainers: [
          o
        ]
      }, t !== null && (t = li(t), t !== null && Sm(t)), e) : (e.eventSystemFlags |= s, t = e.targetContainers, o !== null && t.indexOf(o) === -1 && t.push(o), e);
    }
    function _v(e, t, n, s, o) {
      switch (t) {
        case "focusin":
          return ha = Ws(ha, e, t, n, s, o), true;
        case "dragenter":
          return ma = Ws(ma, e, t, n, s, o), true;
        case "mouseover":
          return ya = Ws(ya, e, t, n, s, o), true;
        case "pointerover":
          var u = o.pointerId;
          return Js.set(u, Ws(Js.get(u) || null, e, t, n, s, o)), true;
        case "gotpointercapture":
          return u = o.pointerId, Is.set(u, Ws(Is.get(u) || null, e, t, n, s, o)), true;
      }
      return false;
    }
    function Am(e) {
      var t = Oa(e.target);
      if (t !== null) {
        var n = J(t);
        if (n !== null) {
          if (t = n.tag, t === 13) {
            if (t = ne(n), t !== null) {
              e.blockedOn = t, wg(e.priority, function() {
                if (n.tag === 13) {
                  var s = Ht(), o = Wn(n, s);
                  o !== null && Et(o, n, s), mu(n, s);
                }
              });
              return;
            }
          } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
            e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
            return;
          }
        }
      }
      e.blockedOn = null;
    }
    function Nr(e) {
      if (e.blockedOn !== null) return false;
      for (var t = e.targetContainers; 0 < t.length; ) {
        var n = pu(e.nativeEvent);
        if (n === null) {
          n = e.nativeEvent;
          var s = new n.constructor(n.type, n);
          So = s, n.target.dispatchEvent(s), So = null;
        } else return t = li(n), t !== null && Sm(t), e.blockedOn = n, false;
        t.shift();
      }
      return true;
    }
    function Tm(e, t, n) {
      Nr(e) && n.delete(t);
    }
    function Nv() {
      bu = false, ha !== null && Nr(ha) && (ha = null), ma !== null && Nr(ma) && (ma = null), ya !== null && Nr(ya) && (ya = null), Js.forEach(Tm), Is.forEach(Tm);
    }
    function Rr(e, t) {
      e.blockedOn === t && (e.blockedOn = null, bu || (bu = true, i.unstable_scheduleCallback(i.unstable_NormalPriority, Nv)));
    }
    var jr = null;
    function Om(e) {
      jr !== e && (jr = e, i.unstable_scheduleCallback(i.unstable_NormalPriority, function() {
        jr === e && (jr = null);
        for (var t = 0; t < e.length; t += 3) {
          var n = e[t], s = e[t + 1], o = e[t + 2];
          if (typeof s != "function") {
            if (gu(s || n) === null) continue;
            break;
          }
          var u = li(n);
          u !== null && (e.splice(t, 3), t -= 3, rc(u, {
            pending: true,
            data: o,
            method: n.method,
            action: s
          }, s, o));
        }
      }));
    }
    function Ps(e) {
      function t(T) {
        return Rr(T, e);
      }
      ha !== null && Rr(ha, e), ma !== null && Rr(ma, e), ya !== null && Rr(ya, e), Js.forEach(t), Is.forEach(t);
      for (var n = 0; n < pa.length; n++) {
        var s = pa[n];
        s.blockedOn === e && (s.blockedOn = null);
      }
      for (; 0 < pa.length && (n = pa[0], n.blockedOn === null); ) Am(n), n.blockedOn === null && pa.shift();
      if (n = (e.ownerDocument || e).$$reactFormReplay, n != null) for (s = 0; s < n.length; s += 3) {
        var o = n[s], u = n[s + 1], m = o[Ot] || null;
        if (typeof u == "function") m || Om(n);
        else if (m) {
          var w = null;
          if (u && u.hasAttribute("formAction")) {
            if (o = u, m = u[Ot] || null) w = m.formAction;
            else if (gu(o) !== null) continue;
          } else w = m.action;
          typeof w == "function" ? n[s + 1] = w : (n.splice(s, 3), s -= 3), Om(n);
        }
      }
    }
    function vu(e) {
      this._internalRoot = e;
    }
    Mr.prototype.render = vu.prototype.render = function(e) {
      var t = this._internalRoot;
      if (t === null) throw Error(r(409));
      var n = t.current, s = Ht();
      vm(n, s, e, t, null, null);
    }, Mr.prototype.unmount = vu.prototype.unmount = function() {
      var e = this._internalRoot;
      if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        e.tag === 0 && Ui(), vm(e.current, 2, null, e, null, null), mr(), t[si] = null;
      }
    };
    function Mr(e) {
      this._internalRoot = e;
    }
    Mr.prototype.unstable_scheduleHydration = function(e) {
      if (e) {
        var t = ed();
        e = {
          blockedOn: null,
          target: e,
          priority: t
        };
        for (var n = 0; n < pa.length && t !== 0 && t < pa[n].priority; n++) ;
        pa.splice(n, 0, e), n === 0 && Am(e);
      }
    };
    var Cm = a.version;
    if (Cm !== "19.0.0") throw Error(r(527, Cm, "19.0.0"));
    Ee.findDOMNode = function(e) {
      var t = e._reactInternals;
      if (t === void 0) throw typeof e.render == "function" ? Error(r(188)) : (e = Object.keys(e).join(","), Error(r(268, e)));
      return e = de(t), e = e !== null ? me(e) : null, e = e === null ? null : e.stateNode, e;
    };
    var Rv = {
      bundleType: 0,
      version: "19.0.0",
      rendererPackageName: "react-dom",
      currentDispatcherRef: W,
      findFiberByHostInstance: Oa,
      reconcilerVersion: "19.0.0"
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
      var Dr = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!Dr.isDisabled && Dr.supportsFiber) try {
        qt = Dr.inject(Rv), at = Dr;
      } catch {
      }
    }
    return tl.createRoot = function(e, t) {
      if (!c(e)) throw Error(r(299));
      var n = false, s = "", o = Xh, u = Fh, m = Qh, w = null;
      return t != null && (t.unstable_strictMode === true && (n = true), t.identifierPrefix !== void 0 && (s = t.identifierPrefix), t.onUncaughtError !== void 0 && (o = t.onUncaughtError), t.onCaughtError !== void 0 && (u = t.onCaughtError), t.onRecoverableError !== void 0 && (m = t.onRecoverableError), t.unstable_transitionCallbacks !== void 0 && (w = t.unstable_transitionCallbacks)), t = gm(e, 1, false, null, null, n, s, o, u, m, w, null), e[si] = t.current, nu(e.nodeType === 8 ? e.parentNode : e), new vu(t);
    }, tl.hydrateRoot = function(e, t, n) {
      if (!c(e)) throw Error(r(299));
      var s = false, o = "", u = Xh, m = Fh, w = Qh, T = null, N = null;
      return n != null && (n.unstable_strictMode === true && (s = true), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onUncaughtError !== void 0 && (u = n.onUncaughtError), n.onCaughtError !== void 0 && (m = n.onCaughtError), n.onRecoverableError !== void 0 && (w = n.onRecoverableError), n.unstable_transitionCallbacks !== void 0 && (T = n.unstable_transitionCallbacks), n.formState !== void 0 && (N = n.formState)), t = gm(e, 1, true, t, n ?? null, s, o, u, m, w, T, N), t.context = bm(null), n = t.current, s = Ht(), o = sa(s), o.callback = null, la(n, o, s), t.current.lanes = s, ls(t, s), mn(t), e[si] = t.current, nu(e), new Mr(t);
    }, tl.version = "19.0.0", tl;
  }
  var Um;
  function t1() {
    if (Um) return Su.exports;
    Um = 1;
    function i() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(i);
      } catch (a) {
        console.error(a);
      }
    }
    return i(), Su.exports = e1(), Su.exports;
  }
  var n1 = t1();
  const zm = (i) => {
    let a;
    const l = /* @__PURE__ */ new Set(), r = (y, p) => {
      const b = typeof y == "function" ? y(a) : y;
      if (!Object.is(b, a)) {
        const S = a;
        a = p ?? (typeof b != "object" || b === null) ? b : Object.assign({}, a, b), l.forEach((x) => x(a, S));
      }
    }, c = () => a, h = {
      setState: r,
      getState: c,
      getInitialState: () => g,
      subscribe: (y) => (l.add(y), () => l.delete(y))
    }, g = a = i(r, c, h);
    return h;
  }, a1 = (i) => i ? zm(i) : zm, i1 = (i) => i;
  function s1(i, a = i1) {
    const l = Ku.useSyncExternalStore(i.subscribe, () => a(i.getState()), () => a(i.getInitialState()));
    return Ku.useDebugValue(l), l;
  }
  const km = (i) => {
    const a = a1(i), l = (r) => s1(a, r);
    return Object.assign(l, a), l;
  }, Of = (i) => i ? km(i) : km;
  var Ur = {
    exports: {}
  }, Au, Bm;
  function l1() {
    if (Bm) return Au;
    Bm = 1;
    var i = 1e3, a = i * 60, l = a * 60, r = l * 24, c = r * 7, f = r * 365.25;
    Au = function(p, b) {
      b = b || {};
      var S = typeof p;
      if (S === "string" && p.length > 0) return d(p);
      if (S === "number" && isFinite(p)) return b.long ? g(p) : h(p);
      throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(p));
    };
    function d(p) {
      if (p = String(p), !(p.length > 100)) {
        var b = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(p);
        if (b) {
          var S = parseFloat(b[1]), x = (b[2] || "ms").toLowerCase();
          switch (x) {
            case "years":
            case "year":
            case "yrs":
            case "yr":
            case "y":
              return S * f;
            case "weeks":
            case "week":
            case "w":
              return S * c;
            case "days":
            case "day":
            case "d":
              return S * r;
            case "hours":
            case "hour":
            case "hrs":
            case "hr":
            case "h":
              return S * l;
            case "minutes":
            case "minute":
            case "mins":
            case "min":
            case "m":
              return S * a;
            case "seconds":
            case "second":
            case "secs":
            case "sec":
            case "s":
              return S * i;
            case "milliseconds":
            case "millisecond":
            case "msecs":
            case "msec":
            case "ms":
              return S;
            default:
              return;
          }
        }
      }
    }
    function h(p) {
      var b = Math.abs(p);
      return b >= r ? Math.round(p / r) + "d" : b >= l ? Math.round(p / l) + "h" : b >= a ? Math.round(p / a) + "m" : b >= i ? Math.round(p / i) + "s" : p + "ms";
    }
    function g(p) {
      var b = Math.abs(p);
      return b >= r ? y(p, b, r, "day") : b >= l ? y(p, b, l, "hour") : b >= a ? y(p, b, a, "minute") : b >= i ? y(p, b, i, "second") : p + " ms";
    }
    function y(p, b, S, x) {
      var v = b >= S * 1.5;
      return Math.round(p / S) + " " + x + (v ? "s" : "");
    }
    return Au;
  }
  var Tu, Hm;
  function r1() {
    if (Hm) return Tu;
    Hm = 1;
    function i(a) {
      r.debug = r, r.default = r, r.coerce = y, r.disable = h, r.enable = f, r.enabled = g, r.humanize = l1(), r.destroy = p, Object.keys(a).forEach((b) => {
        r[b] = a[b];
      }), r.names = [], r.skips = [], r.formatters = {};
      function l(b) {
        let S = 0;
        for (let x = 0; x < b.length; x++) S = (S << 5) - S + b.charCodeAt(x), S |= 0;
        return r.colors[Math.abs(S) % r.colors.length];
      }
      r.selectColor = l;
      function r(b) {
        let S, x = null, v, A;
        function j(...L) {
          if (!j.enabled) return;
          const B = j, D = Number(/* @__PURE__ */ new Date()), I = D - (S || D);
          B.diff = I, B.prev = S, B.curr = D, S = D, L[0] = r.coerce(L[0]), typeof L[0] != "string" && L.unshift("%O");
          let ee = 0;
          L[0] = L[0].replace(/%([a-zA-Z%])/g, (be, le) => {
            if (be === "%%") return "%";
            ee++;
            const W = r.formatters[le];
            if (typeof W == "function") {
              const P = L[ee];
              be = W.call(B, P), L.splice(ee, 1), ee--;
            }
            return be;
          }), r.formatArgs.call(B, L), (B.log || r.log).apply(B, L);
        }
        return j.namespace = b, j.useColors = r.useColors(), j.color = r.selectColor(b), j.extend = c, j.destroy = r.destroy, Object.defineProperty(j, "enabled", {
          enumerable: true,
          configurable: false,
          get: () => x !== null ? x : (v !== r.namespaces && (v = r.namespaces, A = r.enabled(b)), A),
          set: (L) => {
            x = L;
          }
        }), typeof r.init == "function" && r.init(j), j;
      }
      function c(b, S) {
        const x = r(this.namespace + (typeof S > "u" ? ":" : S) + b);
        return x.log = this.log, x;
      }
      function f(b) {
        r.save(b), r.namespaces = b, r.names = [], r.skips = [];
        const S = (typeof b == "string" ? b : "").trim().replace(" ", ",").split(",").filter(Boolean);
        for (const x of S) x[0] === "-" ? r.skips.push(x.slice(1)) : r.names.push(x);
      }
      function d(b, S) {
        let x = 0, v = 0, A = -1, j = 0;
        for (; x < b.length; ) if (v < S.length && (S[v] === b[x] || S[v] === "*")) S[v] === "*" ? (A = v, j = x, v++) : (x++, v++);
        else if (A !== -1) v = A + 1, j++, x = j;
        else return false;
        for (; v < S.length && S[v] === "*"; ) v++;
        return v === S.length;
      }
      function h() {
        const b = [
          ...r.names,
          ...r.skips.map((S) => "-" + S)
        ].join(",");
        return r.enable(""), b;
      }
      function g(b) {
        for (const S of r.skips) if (d(b, S)) return false;
        for (const S of r.names) if (d(b, S)) return true;
        return false;
      }
      function y(b) {
        return b instanceof Error ? b.stack || b.message : b;
      }
      function p() {
        console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
      }
      return r.enable(r.load()), r;
    }
    return Tu = i, Tu;
  }
  var Lm;
  function o1() {
    return Lm || (Lm = 1, function(i, a) {
      var l = {};
      a.formatArgs = c, a.save = f, a.load = d, a.useColors = r, a.storage = h(), a.destroy = /* @__PURE__ */ (() => {
        let y = false;
        return () => {
          y || (y = true, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."));
        };
      })(), a.colors = [
        "#0000CC",
        "#0000FF",
        "#0033CC",
        "#0033FF",
        "#0066CC",
        "#0066FF",
        "#0099CC",
        "#0099FF",
        "#00CC00",
        "#00CC33",
        "#00CC66",
        "#00CC99",
        "#00CCCC",
        "#00CCFF",
        "#3300CC",
        "#3300FF",
        "#3333CC",
        "#3333FF",
        "#3366CC",
        "#3366FF",
        "#3399CC",
        "#3399FF",
        "#33CC00",
        "#33CC33",
        "#33CC66",
        "#33CC99",
        "#33CCCC",
        "#33CCFF",
        "#6600CC",
        "#6600FF",
        "#6633CC",
        "#6633FF",
        "#66CC00",
        "#66CC33",
        "#9900CC",
        "#9900FF",
        "#9933CC",
        "#9933FF",
        "#99CC00",
        "#99CC33",
        "#CC0000",
        "#CC0033",
        "#CC0066",
        "#CC0099",
        "#CC00CC",
        "#CC00FF",
        "#CC3300",
        "#CC3333",
        "#CC3366",
        "#CC3399",
        "#CC33CC",
        "#CC33FF",
        "#CC6600",
        "#CC6633",
        "#CC9900",
        "#CC9933",
        "#CCCC00",
        "#CCCC33",
        "#FF0000",
        "#FF0033",
        "#FF0066",
        "#FF0099",
        "#FF00CC",
        "#FF00FF",
        "#FF3300",
        "#FF3333",
        "#FF3366",
        "#FF3399",
        "#FF33CC",
        "#FF33FF",
        "#FF6600",
        "#FF6633",
        "#FF9900",
        "#FF9933",
        "#FFCC00",
        "#FFCC33"
      ];
      function r() {
        if (typeof window < "u" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) return true;
        if (typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return false;
        let y;
        return typeof document < "u" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || typeof window < "u" && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator < "u" && navigator.userAgent && (y = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(y[1], 10) >= 31 || typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
      }
      function c(y) {
        if (y[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + y[0] + (this.useColors ? "%c " : " ") + "+" + i.exports.humanize(this.diff), !this.useColors) return;
        const p = "color: " + this.color;
        y.splice(1, 0, p, "color: inherit");
        let b = 0, S = 0;
        y[0].replace(/%[a-zA-Z%]/g, (x) => {
          x !== "%%" && (b++, x === "%c" && (S = b));
        }), y.splice(S, 0, p);
      }
      a.log = console.debug || console.log || (() => {
      });
      function f(y) {
        try {
          y ? a.storage.setItem("debug", y) : a.storage.removeItem("debug");
        } catch {
        }
      }
      function d() {
        let y;
        try {
          y = a.storage.getItem("debug");
        } catch {
        }
        return !y && typeof process < "u" && "env" in process && (y = l.DEBUG), y;
      }
      function h() {
        try {
          return localStorage;
        } catch {
        }
      }
      i.exports = r1()(a);
      const { formatters: g } = i.exports;
      g.j = function(y) {
        try {
          return JSON.stringify(y);
        } catch (p) {
          return "[UnexpectedJSONParseError]: " + p.message;
        }
      };
    }(Ur, Ur.exports)), Ur.exports;
  }
  var c1 = o1();
  const Qn = Tf(c1);
  var Ou = {
    exports: {}
  }, qm;
  function u1() {
    return qm || (qm = 1, function(i) {
      var a = Object.prototype.hasOwnProperty, l = "~";
      function r() {
      }
      Object.create && (r.prototype = /* @__PURE__ */ Object.create(null), new r().__proto__ || (l = false));
      function c(g, y, p) {
        this.fn = g, this.context = y, this.once = p || false;
      }
      function f(g, y, p, b, S) {
        if (typeof p != "function") throw new TypeError("The listener must be a function");
        var x = new c(p, b || g, S), v = l ? l + y : y;
        return g._events[v] ? g._events[v].fn ? g._events[v] = [
          g._events[v],
          x
        ] : g._events[v].push(x) : (g._events[v] = x, g._eventsCount++), g;
      }
      function d(g, y) {
        --g._eventsCount === 0 ? g._events = new r() : delete g._events[y];
      }
      function h() {
        this._events = new r(), this._eventsCount = 0;
      }
      h.prototype.eventNames = function() {
        var y = [], p, b;
        if (this._eventsCount === 0) return y;
        for (b in p = this._events) a.call(p, b) && y.push(l ? b.slice(1) : b);
        return Object.getOwnPropertySymbols ? y.concat(Object.getOwnPropertySymbols(p)) : y;
      }, h.prototype.listeners = function(y) {
        var p = l ? l + y : y, b = this._events[p];
        if (!b) return [];
        if (b.fn) return [
          b.fn
        ];
        for (var S = 0, x = b.length, v = new Array(x); S < x; S++) v[S] = b[S].fn;
        return v;
      }, h.prototype.listenerCount = function(y) {
        var p = l ? l + y : y, b = this._events[p];
        return b ? b.fn ? 1 : b.length : 0;
      }, h.prototype.emit = function(y, p, b, S, x, v) {
        var A = l ? l + y : y;
        if (!this._events[A]) return false;
        var j = this._events[A], L = arguments.length, B, D;
        if (j.fn) {
          switch (j.once && this.removeListener(y, j.fn, void 0, true), L) {
            case 1:
              return j.fn.call(j.context), true;
            case 2:
              return j.fn.call(j.context, p), true;
            case 3:
              return j.fn.call(j.context, p, b), true;
            case 4:
              return j.fn.call(j.context, p, b, S), true;
            case 5:
              return j.fn.call(j.context, p, b, S, x), true;
            case 6:
              return j.fn.call(j.context, p, b, S, x, v), true;
          }
          for (D = 1, B = new Array(L - 1); D < L; D++) B[D - 1] = arguments[D];
          j.fn.apply(j.context, B);
        } else {
          var I = j.length, ee;
          for (D = 0; D < I; D++) switch (j[D].once && this.removeListener(y, j[D].fn, void 0, true), L) {
            case 1:
              j[D].fn.call(j[D].context);
              break;
            case 2:
              j[D].fn.call(j[D].context, p);
              break;
            case 3:
              j[D].fn.call(j[D].context, p, b);
              break;
            case 4:
              j[D].fn.call(j[D].context, p, b, S);
              break;
            default:
              if (!B) for (ee = 1, B = new Array(L - 1); ee < L; ee++) B[ee - 1] = arguments[ee];
              j[D].fn.apply(j[D].context, B);
          }
        }
        return true;
      }, h.prototype.on = function(y, p, b) {
        return f(this, y, p, b, false);
      }, h.prototype.once = function(y, p, b) {
        return f(this, y, p, b, true);
      }, h.prototype.removeListener = function(y, p, b, S) {
        var x = l ? l + y : y;
        if (!this._events[x]) return this;
        if (!p) return d(this, x), this;
        var v = this._events[x];
        if (v.fn) v.fn === p && (!S || v.once) && (!b || v.context === b) && d(this, x);
        else {
          for (var A = 0, j = [], L = v.length; A < L; A++) (v[A].fn !== p || S && !v[A].once || b && v[A].context !== b) && j.push(v[A]);
          j.length ? this._events[x] = j.length === 1 ? j[0] : j : d(this, x);
        }
        return this;
      }, h.prototype.removeAllListeners = function(y) {
        var p;
        return y ? (p = l ? l + y : y, this._events[p] && d(this, p)) : (this._events = new r(), this._eventsCount = 0), this;
      }, h.prototype.off = h.prototype.removeListener, h.prototype.addListener = h.prototype.on, h.prefixed = l, h.EventEmitter = h, i.exports = h;
    }(Ou)), Ou.exports;
  }
  var f1 = u1();
  const ts = Tf(f1);
  function d1() {
    if (typeof globalThis < "u") return globalThis;
    if (typeof self < "u") return self;
    if (typeof window < "u") return window;
    if (typeof global < "u") return global;
  }
  function h1() {
    const i = d1();
    if (i.__xstate__) return i.__xstate__;
  }
  const m1 = (i) => {
    if (typeof window > "u") return;
    const a = h1();
    a && a.register(i);
  };
  class Ym {
    constructor(a) {
      this._process = a, this._active = false, this._current = null, this._last = null;
    }
    start() {
      this._active = true, this.flush();
    }
    clear() {
      this._current && (this._current.next = null, this._last = this._current);
    }
    enqueue(a) {
      const l = {
        value: a,
        next: null
      };
      if (this._current) {
        this._last.next = l, this._last = l;
        return;
      }
      this._current = l, this._last = l, this._active && this.flush();
    }
    flush() {
      for (; this._current; ) {
        const a = this._current;
        this._process(a.value), this._current = a.next;
      }
      this._last = null;
    }
  }
  const Qy = ".", y1 = "", Zy = "", p1 = "#", g1 = "*", Ky = "xstate.init", $u = "xstate.stop";
  function b1(i, a) {
    return {
      type: `xstate.after.${i}.${a}`
    };
  }
  function Ju(i, a) {
    return {
      type: `xstate.done.state.${i}`,
      output: a
    };
  }
  function v1(i, a) {
    return {
      type: `xstate.done.actor.${i}`,
      output: a,
      actorId: i
    };
  }
  function x1(i, a) {
    return {
      type: `xstate.error.actor.${i}`,
      error: a,
      actorId: i
    };
  }
  function $y(i) {
    return {
      type: Ky,
      input: i
    };
  }
  function qn(i) {
    setTimeout(() => {
      throw i;
    });
  }
  const S1 = typeof Symbol == "function" && Symbol.observable || "@@observable";
  function Jy(i, a) {
    const l = Gm(i), r = Gm(a);
    return typeof r == "string" ? typeof l == "string" ? r === l : false : typeof l == "string" ? l in r : Object.keys(l).every((c) => c in r ? Jy(l[c], r[c]) : false);
  }
  function Cf(i) {
    if (Wy(i)) return i;
    const a = [];
    let l = "";
    for (let r = 0; r < i.length; r++) {
      switch (i.charCodeAt(r)) {
        case 92:
          l += i[r + 1], r++;
          continue;
        case 46:
          a.push(l), l = "";
          continue;
      }
      l += i[r];
    }
    return a.push(l), a;
  }
  function Gm(i) {
    if (tx(i)) return i.value;
    if (typeof i != "string") return i;
    const a = Cf(i);
    return w1(a);
  }
  function w1(i) {
    if (i.length === 1) return i[0];
    const a = {};
    let l = a;
    for (let r = 0; r < i.length - 1; r++) if (r === i.length - 2) l[i[r]] = i[r + 1];
    else {
      const c = l;
      l = {}, c[i[r]] = l;
    }
    return a;
  }
  function Vm(i, a) {
    const l = {}, r = Object.keys(i);
    for (let c = 0; c < r.length; c++) {
      const f = r[c];
      l[f] = a(i[f], f, i, c);
    }
    return l;
  }
  function Iy(i) {
    return Wy(i) ? i : [
      i
    ];
  }
  function Xn(i) {
    return i === void 0 ? [] : Iy(i);
  }
  function Iu(i, a, l, r) {
    return typeof i == "function" ? i({
      context: a,
      event: l,
      self: r
    }) : i;
  }
  function Wy(i) {
    return Array.isArray(i);
  }
  function E1(i) {
    return i.type.startsWith("xstate.error.actor");
  }
  function Vi(i) {
    return Iy(i).map((a) => typeof a > "u" || typeof a == "string" ? {
      target: a
    } : a);
  }
  function Py(i) {
    if (!(i === void 0 || i === y1)) return Xn(i);
  }
  function Wu(i, a, l) {
    var _a7, _b, _c;
    const r = typeof i == "object", c = r ? i : void 0;
    return {
      next: (_a7 = r ? i.next : i) == null ? void 0 : _a7.bind(c),
      error: (_b = r ? i.error : a) == null ? void 0 : _b.bind(c),
      complete: (_c = r ? i.complete : l) == null ? void 0 : _c.bind(c)
    };
  }
  function Xm(i, a) {
    return `${a}.${i}`;
  }
  function _f(i, a) {
    const l = a.match(/^xstate\.invoke\.(\d+)\.(.*)/);
    if (!l) return i.implementations.actors[a];
    const [, r, c] = l, d = i.getStateNodeById(c).config.invoke;
    return (Array.isArray(d) ? d[r] : d).src;
  }
  function Fm(i, a) {
    return `${i.sessionId}.${a}`;
  }
  let A1 = 0;
  function T1(i, a) {
    const l = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new WeakMap(), f = /* @__PURE__ */ new Set(), d = {}, { clock: h, logger: g } = a, y = {
      schedule: (S, x, v, A, j = Math.random().toString(36).slice(2)) => {
        const L = {
          source: S,
          target: x,
          event: v,
          delay: A,
          id: j,
          startedAt: Date.now()
        }, B = Fm(S, j);
        b._snapshot._scheduledEvents[B] = L;
        const D = h.setTimeout(() => {
          delete d[B], delete b._snapshot._scheduledEvents[B], b._relay(S, x, v);
        }, A);
        d[B] = D;
      },
      cancel: (S, x) => {
        const v = Fm(S, x), A = d[v];
        delete d[v], delete b._snapshot._scheduledEvents[v], A !== void 0 && h.clearTimeout(A);
      },
      cancelAll: (S) => {
        for (const x in b._snapshot._scheduledEvents) {
          const v = b._snapshot._scheduledEvents[x];
          v.source === S && y.cancel(S, v.id);
        }
      }
    }, p = (S) => {
      if (!f.size) return;
      const x = {
        ...S,
        rootId: i.sessionId
      };
      f.forEach((v) => {
        var _a7;
        return (_a7 = v.next) == null ? void 0 : _a7.call(v, x);
      });
    }, b = {
      _snapshot: {
        _scheduledEvents: ((a == null ? void 0 : a.snapshot) && a.snapshot.scheduler) ?? {}
      },
      _bookId: () => `x:${A1++}`,
      _register: (S, x) => (l.set(S, x), S),
      _unregister: (S) => {
        l.delete(S.sessionId);
        const x = c.get(S);
        x !== void 0 && (r.delete(x), c.delete(S));
      },
      get: (S) => r.get(S),
      _set: (S, x) => {
        const v = r.get(S);
        if (v && v !== x) throw new Error(`Actor with system ID '${S}' already exists.`);
        r.set(S, x), c.set(x, S);
      },
      inspect: (S) => {
        const x = Wu(S);
        return f.add(x), {
          unsubscribe() {
            f.delete(x);
          }
        };
      },
      _sendInspectionEvent: p,
      _relay: (S, x, v) => {
        b._sendInspectionEvent({
          type: "@xstate.event",
          sourceRef: S,
          actorRef: x,
          event: v
        }), x._send(v);
      },
      scheduler: y,
      getSnapshot: () => ({
        _scheduledEvents: {
          ...b._snapshot._scheduledEvents
        }
      }),
      start: () => {
        const S = b._snapshot._scheduledEvents;
        b._snapshot._scheduledEvents = {};
        for (const x in S) {
          const { source: v, target: A, event: j, delay: L, id: B } = S[x];
          y.schedule(v, A, j, L, B);
        }
      },
      _clock: h,
      _logger: g
    };
    return b;
  }
  let Cu = false;
  const Nf = 1;
  let Nt = function(i) {
    return i[i.NotStarted = 0] = "NotStarted", i[i.Running = 1] = "Running", i[i.Stopped = 2] = "Stopped", i;
  }({});
  const O1 = {
    clock: {
      setTimeout: (i, a) => setTimeout(i, a),
      clearTimeout: (i) => clearTimeout(i)
    },
    logger: console.log.bind(console),
    devTools: false
  };
  class C1 {
    constructor(a, l) {
      this.logic = a, this._snapshot = void 0, this.clock = void 0, this.options = void 0, this.id = void 0, this.mailbox = new Ym(this._process.bind(this)), this.observers = /* @__PURE__ */ new Set(), this.eventListeners = /* @__PURE__ */ new Map(), this.logger = void 0, this._processingStatus = Nt.NotStarted, this._parent = void 0, this._syncSnapshot = void 0, this.ref = void 0, this._actorScope = void 0, this._systemId = void 0, this.sessionId = void 0, this.system = void 0, this._doneEvent = void 0, this.src = void 0, this._deferred = [];
      const r = {
        ...O1,
        ...l
      }, { clock: c, logger: f, parent: d, syncSnapshot: h, id: g, systemId: y, inspect: p } = r;
      this.system = d ? d.system : T1(this, {
        clock: c,
        logger: f
      }), p && !d && this.system.inspect(Wu(p)), this.sessionId = this.system._bookId(), this.id = g ?? this.sessionId, this.logger = (l == null ? void 0 : l.logger) ?? this.system._logger, this.clock = (l == null ? void 0 : l.clock) ?? this.system._clock, this._parent = d, this._syncSnapshot = h, this.options = r, this.src = r.src ?? a, this.ref = this, this._actorScope = {
        self: this,
        id: this.id,
        sessionId: this.sessionId,
        logger: this.logger,
        defer: (b) => {
          this._deferred.push(b);
        },
        system: this.system,
        stopChild: (b) => {
          if (b._parent !== this) throw new Error(`Cannot stop child actor ${b.id} of ${this.id} because it is not a child`);
          b._stop();
        },
        emit: (b) => {
          const S = this.eventListeners.get(b.type), x = this.eventListeners.get("*");
          if (!S && !x) return;
          const v = [
            ...S ? S.values() : [],
            ...x ? x.values() : []
          ];
          for (const A of v) A(b);
        },
        actionExecutor: (b) => {
          const S = () => {
            if (this._actorScope.system._sendInspectionEvent({
              type: "@xstate.action",
              actorRef: this,
              action: {
                type: b.type,
                params: b.params
              }
            }), !b.exec) return;
            const x = Cu;
            try {
              Cu = true, b.exec(b.info, b.params);
            } finally {
              Cu = x;
            }
          };
          this._processingStatus === Nt.Running ? S() : this._deferred.push(S);
        }
      }, this.send = this.send.bind(this), this.system._sendInspectionEvent({
        type: "@xstate.actor",
        actorRef: this
      }), y && (this._systemId = y, this.system._set(y, this)), this._initState((l == null ? void 0 : l.snapshot) ?? (l == null ? void 0 : l.state)), y && this._snapshot.status !== "active" && this.system._unregister(this);
    }
    _initState(a) {
      var _a7;
      try {
        this._snapshot = a ? this.logic.restoreSnapshot ? this.logic.restoreSnapshot(a, this._actorScope) : a : this.logic.getInitialSnapshot(this._actorScope, (_a7 = this.options) == null ? void 0 : _a7.input);
      } catch (l) {
        this._snapshot = {
          status: "error",
          output: void 0,
          error: l
        };
      }
    }
    update(a, l) {
      var _a7, _b;
      this._snapshot = a;
      let r;
      for (; r = this._deferred.shift(); ) try {
        r();
      } catch (c) {
        this._deferred.length = 0, this._snapshot = {
          ...a,
          status: "error",
          error: c
        };
      }
      switch (this._snapshot.status) {
        case "active":
          for (const c of this.observers) try {
            (_a7 = c.next) == null ? void 0 : _a7.call(c, a);
          } catch (f) {
            qn(f);
          }
          break;
        case "done":
          for (const c of this.observers) try {
            (_b = c.next) == null ? void 0 : _b.call(c, a);
          } catch (f) {
            qn(f);
          }
          this._stopProcedure(), this._complete(), this._doneEvent = v1(this.id, this._snapshot.output), this._parent && this.system._relay(this, this._parent, this._doneEvent);
          break;
        case "error":
          this._error(this._snapshot.error);
          break;
      }
      this.system._sendInspectionEvent({
        type: "@xstate.snapshot",
        actorRef: this,
        event: l,
        snapshot: a
      });
    }
    subscribe(a, l, r) {
      var _a7;
      const c = Wu(a, l, r);
      if (this._processingStatus !== Nt.Stopped) this.observers.add(c);
      else switch (this._snapshot.status) {
        case "done":
          try {
            (_a7 = c.complete) == null ? void 0 : _a7.call(c);
          } catch (f) {
            qn(f);
          }
          break;
        case "error": {
          const f = this._snapshot.error;
          if (!c.error) qn(f);
          else try {
            c.error(f);
          } catch (d) {
            qn(d);
          }
          break;
        }
      }
      return {
        unsubscribe: () => {
          this.observers.delete(c);
        }
      };
    }
    on(a, l) {
      let r = this.eventListeners.get(a);
      r || (r = /* @__PURE__ */ new Set(), this.eventListeners.set(a, r));
      const c = l.bind(void 0);
      return r.add(c), {
        unsubscribe: () => {
          r.delete(c);
        }
      };
    }
    start() {
      if (this._processingStatus === Nt.Running) return this;
      this._syncSnapshot && this.subscribe({
        next: (r) => {
          r.status === "active" && this.system._relay(this, this._parent, {
            type: `xstate.snapshot.${this.id}`,
            snapshot: r
          });
        },
        error: () => {
        }
      }), this.system._register(this.sessionId, this), this._systemId && this.system._set(this._systemId, this), this._processingStatus = Nt.Running;
      const a = $y(this.options.input);
      switch (this.system._sendInspectionEvent({
        type: "@xstate.event",
        sourceRef: this._parent,
        actorRef: this,
        event: a
      }), this._snapshot.status) {
        case "done":
          return this.update(this._snapshot, a), this;
        case "error":
          return this._error(this._snapshot.error), this;
      }
      if (this._parent || this.system.start(), this.logic.start) try {
        this.logic.start(this._snapshot, this._actorScope);
      } catch (r) {
        return this._snapshot = {
          ...this._snapshot,
          status: "error",
          error: r
        }, this._error(r), this;
      }
      return this.update(this._snapshot, a), this.options.devTools && this.attachDevTools(), this.mailbox.start(), this;
    }
    _process(a) {
      let l, r;
      try {
        l = this.logic.transition(this._snapshot, a, this._actorScope);
      } catch (c) {
        r = {
          err: c
        };
      }
      if (r) {
        const { err: c } = r;
        this._snapshot = {
          ...this._snapshot,
          status: "error",
          error: c
        }, this._error(c);
        return;
      }
      this.update(l, a), a.type === $u && (this._stopProcedure(), this._complete());
    }
    _stop() {
      return this._processingStatus === Nt.Stopped ? this : (this.mailbox.clear(), this._processingStatus === Nt.NotStarted ? (this._processingStatus = Nt.Stopped, this) : (this.mailbox.enqueue({
        type: $u
      }), this));
    }
    stop() {
      if (this._parent) throw new Error("A non-root actor cannot be stopped directly.");
      return this._stop();
    }
    _complete() {
      var _a7;
      for (const a of this.observers) try {
        (_a7 = a.complete) == null ? void 0 : _a7.call(a);
      } catch (l) {
        qn(l);
      }
      this.observers.clear();
    }
    _reportError(a) {
      if (!this.observers.size) {
        this._parent || qn(a);
        return;
      }
      let l = false;
      for (const r of this.observers) {
        const c = r.error;
        l || (l = !c);
        try {
          c == null ? void 0 : c(a);
        } catch (f) {
          qn(f);
        }
      }
      this.observers.clear(), l && qn(a);
    }
    _error(a) {
      this._stopProcedure(), this._reportError(a), this._parent && this.system._relay(this, this._parent, x1(this.id, a));
    }
    _stopProcedure() {
      return this._processingStatus !== Nt.Running ? this : (this.system.scheduler.cancelAll(this), this.mailbox.clear(), this.mailbox = new Ym(this._process.bind(this)), this._processingStatus = Nt.Stopped, this.system._unregister(this), this);
    }
    _send(a) {
      this._processingStatus !== Nt.Stopped && this.mailbox.enqueue(a);
    }
    send(a) {
      this.system._relay(void 0, this, a);
    }
    attachDevTools() {
      const { devTools: a } = this.options;
      a && (typeof a == "function" ? a : m1)(this);
    }
    toJSON() {
      return {
        xstate$$type: Nf,
        id: this.id
      };
    }
    getPersistedSnapshot(a) {
      return this.logic.getPersistedSnapshot(this._snapshot, a);
    }
    [S1]() {
      return this;
    }
    getSnapshot() {
      return this._snapshot;
    }
  }
  function fl(i, ...[a]) {
    return new C1(i, a);
  }
  function _1(i, a, l, r, { sendId: c }) {
    const f = typeof c == "function" ? c(l, r) : c;
    return [
      a,
      {
        sendId: f
      },
      void 0
    ];
  }
  function N1(i, a) {
    i.defer(() => {
      i.system.scheduler.cancel(i.self, a.sendId);
    });
  }
  function R1(i) {
    function a(l, r) {
    }
    return a.type = "xstate.cancel", a.sendId = i, a.resolve = _1, a.execute = N1, a;
  }
  function j1(i, a, l, r, { id: c, systemId: f, src: d, input: h, syncSnapshot: g }) {
    const y = typeof d == "string" ? _f(a.machine, d) : d, p = typeof c == "function" ? c(l) : c;
    let b, S;
    return y && (S = typeof h == "function" ? h({
      context: a.context,
      event: l.event,
      self: i.self
    }) : h, b = fl(y, {
      id: p,
      src: d,
      parent: i.self,
      syncSnapshot: g,
      systemId: f,
      input: S
    })), [
      Pa(a, {
        children: {
          ...a.children,
          [p]: b
        }
      }),
      {
        id: c,
        systemId: f,
        actorRef: b,
        src: d,
        input: S
      },
      void 0
    ];
  }
  function M1(i, { actorRef: a }) {
    a && i.defer(() => {
      a._processingStatus !== Nt.Stopped && a.start();
    });
  }
  function D1(...[i, { id: a, systemId: l, input: r, syncSnapshot: c = false } = {}]) {
    function f(d, h) {
    }
    return f.type = "xstate.spawnChild", f.id = a, f.systemId = l, f.src = i, f.input = r, f.syncSnapshot = c, f.resolve = j1, f.execute = M1, f;
  }
  function U1(i, a, l, r, { actorRef: c }) {
    const f = typeof c == "function" ? c(l, r) : c, d = typeof f == "string" ? a.children[f] : f;
    let h = a.children;
    return d && (h = {
      ...h
    }, delete h[d.id]), [
      Pa(a, {
        children: h
      }),
      d,
      void 0
    ];
  }
  function z1(i, a) {
    if (a) {
      if (i.system._unregister(a), a._processingStatus !== Nt.Running) {
        i.stopChild(a);
        return;
      }
      i.defer(() => {
        i.stopChild(a);
      });
    }
  }
  function ep(i) {
    function a(l, r) {
    }
    return a.type = "xstate.stopChild", a.actorRef = i, a.resolve = U1, a.execute = z1, a;
  }
  function Rf(i, a, l, r) {
    const { machine: c } = r, f = typeof i == "function", d = f ? i : c.implementations.guards[typeof i == "string" ? i : i.type];
    if (!f && !d) throw new Error(`Guard '${typeof i == "string" ? i : i.type}' is not implemented.'.`);
    if (typeof d != "function") return Rf(d, a, l, r);
    const h = {
      context: a,
      event: l
    }, g = f || typeof i == "string" ? void 0 : "params" in i ? typeof i.params == "function" ? i.params({
      context: a,
      event: l
    }) : i.params : void 0;
    return "check" in d ? d.check(r, h, d) : d(h, g);
  }
  const jf = (i) => i.type === "atomic" || i.type === "final";
  function Ji(i) {
    return Object.values(i.states).filter((a) => a.type !== "history");
  }
  function bl(i, a) {
    const l = [];
    if (a === i) return l;
    let r = i.parent;
    for (; r && r !== a; ) l.push(r), r = r.parent;
    return l;
  }
  function $r(i) {
    const a = new Set(i), l = np(a);
    for (const r of a) if (r.type === "compound" && (!l.get(r) || !l.get(r).length)) Qm(r).forEach((c) => a.add(c));
    else if (r.type === "parallel") {
      for (const c of Ji(r)) if (c.type !== "history" && !a.has(c)) {
        const f = Qm(c);
        for (const d of f) a.add(d);
      }
    }
    for (const r of a) {
      let c = r.parent;
      for (; c; ) a.add(c), c = c.parent;
    }
    return a;
  }
  function tp(i, a) {
    const l = a.get(i);
    if (!l) return {};
    if (i.type === "compound") {
      const c = l[0];
      if (c) {
        if (jf(c)) return c.key;
      } else return {};
    }
    const r = {};
    for (const c of l) r[c.key] = tp(c, a);
    return r;
  }
  function np(i) {
    const a = /* @__PURE__ */ new Map();
    for (const l of i) a.has(l) || a.set(l, []), l.parent && (a.has(l.parent) || a.set(l.parent, []), a.get(l.parent).push(l));
    return a;
  }
  function ap(i, a) {
    const l = $r(a);
    return tp(i, np(l));
  }
  function Mf(i, a) {
    return a.type === "compound" ? Ji(a).some((l) => l.type === "final" && i.has(l)) : a.type === "parallel" ? Ji(a).every((l) => Mf(i, l)) : a.type === "final";
  }
  const io = (i) => i[0] === p1;
  function k1(i, a) {
    return i.transitions.get(a) || [
      ...i.transitions.keys()
    ].filter((r) => {
      if (r === g1) return true;
      if (!r.endsWith(".*")) return false;
      const c = r.split("."), f = a.split(".");
      for (let d = 0; d < c.length; d++) {
        const h = c[d], g = f[d];
        if (h === "*") return d === c.length - 1;
        if (h !== g) return false;
      }
      return true;
    }).sort((r, c) => c.length - r.length).flatMap((r) => i.transitions.get(r));
  }
  function B1(i) {
    const a = i.config.after;
    if (!a) return [];
    const l = (c) => {
      const f = b1(c, i.id), d = f.type;
      return i.entry.push(ux(f, {
        id: d,
        delay: c
      })), i.exit.push(R1(d)), d;
    };
    return Object.keys(a).flatMap((c) => {
      const f = a[c], d = typeof f == "string" ? {
        target: f
      } : f, h = Number.isNaN(+c) ? c : +c, g = l(h);
      return Xn(d).map((y) => ({
        ...y,
        event: g,
        delay: h
      }));
    }).map((c) => {
      const { delay: f } = c;
      return {
        ...Ka(i, c.event, c),
        delay: f
      };
    });
  }
  function Ka(i, a, l) {
    const r = Py(l.target), c = l.reenter ?? false, f = q1(i, r), d = {
      ...l,
      actions: Xn(l.actions),
      guard: l.guard,
      target: f,
      source: i,
      reenter: c,
      eventType: a,
      toJSON: () => ({
        ...d,
        source: `#${i.id}`,
        target: f ? f.map((h) => `#${h.id}`) : void 0
      })
    };
    return d;
  }
  function H1(i) {
    const a = /* @__PURE__ */ new Map();
    if (i.config.on) for (const l of Object.keys(i.config.on)) {
      if (l === Zy) throw new Error('Null events ("") cannot be specified as a transition key. Use `always: { ... }` instead.');
      const r = i.config.on[l];
      a.set(l, Vi(r).map((c) => Ka(i, l, c)));
    }
    if (i.config.onDone) {
      const l = `xstate.done.state.${i.id}`;
      a.set(l, Vi(i.config.onDone).map((r) => Ka(i, l, r)));
    }
    for (const l of i.invoke) {
      if (l.onDone) {
        const r = `xstate.done.actor.${l.id}`;
        a.set(r, Vi(l.onDone).map((c) => Ka(i, r, c)));
      }
      if (l.onError) {
        const r = `xstate.error.actor.${l.id}`;
        a.set(r, Vi(l.onError).map((c) => Ka(i, r, c)));
      }
      if (l.onSnapshot) {
        const r = `xstate.snapshot.${l.id}`;
        a.set(r, Vi(l.onSnapshot).map((c) => Ka(i, r, c)));
      }
    }
    for (const l of i.after) {
      let r = a.get(l.eventType);
      r || (r = [], a.set(l.eventType, r)), r.push(l);
    }
    return a;
  }
  function L1(i, a) {
    const l = typeof a == "string" ? i.states[a] : a ? i.states[a.target] : void 0;
    if (!l && a) throw new Error(`Initial state node "${a}" not found on parent state node #${i.id}`);
    const r = {
      source: i,
      actions: !a || typeof a == "string" ? [] : Xn(a.actions),
      eventType: null,
      reenter: false,
      target: l ? [
        l
      ] : [],
      toJSON: () => ({
        ...r,
        source: `#${i.id}`,
        target: l ? [
          `#${l.id}`
        ] : []
      })
    };
    return r;
  }
  function q1(i, a) {
    if (a !== void 0) return a.map((l) => {
      if (typeof l != "string") return l;
      if (io(l)) return i.machine.getStateNodeById(l);
      const r = l[0] === Qy;
      if (r && !i.parent) return Jr(i, l.slice(1));
      const c = r ? i.key + l : l;
      if (i.parent) try {
        return Jr(i.parent, c);
      } catch (f) {
        throw new Error(`Invalid transition definition for state node '${i.id}':
${f.message}`);
      }
      else throw new Error(`Invalid target: "${l}" is not a valid target from the root node. Did you mean ".${l}"?`);
    });
  }
  function ip(i) {
    const a = Py(i.config.target);
    return a ? {
      target: a.map((l) => typeof l == "string" ? Jr(i.parent, l) : l)
    } : i.parent.initial;
  }
  function $a(i) {
    return i.type === "history";
  }
  function Qm(i) {
    const a = sp(i);
    for (const l of a) for (const r of bl(l, i)) a.add(r);
    return a;
  }
  function sp(i) {
    const a = /* @__PURE__ */ new Set();
    function l(r) {
      if (!a.has(r)) {
        if (a.add(r), r.type === "compound") l(r.initial.target[0]);
        else if (r.type === "parallel") for (const c of Ji(r)) l(c);
      }
    }
    return l(i), a;
  }
  function Ii(i, a) {
    if (io(a)) return i.machine.getStateNodeById(a);
    if (!i.states) throw new Error(`Unable to retrieve child state '${a}' from '${i.id}'; no child states exist.`);
    const l = i.states[a];
    if (!l) throw new Error(`Child state '${a}' does not exist on '${i.id}'`);
    return l;
  }
  function Jr(i, a) {
    if (typeof a == "string" && io(a)) try {
      return i.machine.getStateNodeById(a);
    } catch {
    }
    const l = Cf(a).slice();
    let r = i;
    for (; l.length; ) {
      const c = l.shift();
      if (!c.length) break;
      r = Ii(r, c);
    }
    return r;
  }
  function Ir(i, a) {
    if (typeof a == "string") {
      const c = i.states[a];
      if (!c) throw new Error(`State '${a}' does not exist on '${i.id}'`);
      return [
        i,
        c
      ];
    }
    const l = Object.keys(a), r = l.map((c) => Ii(i, c)).filter(Boolean);
    return [
      i.machine.root,
      i
    ].concat(r, l.reduce((c, f) => {
      const d = Ii(i, f);
      if (!d) return c;
      const h = Ir(d, a[f]);
      return c.concat(h);
    }, []));
  }
  function Y1(i, a, l, r) {
    const f = Ii(i, a).next(l, r);
    return !f || !f.length ? i.next(l, r) : f;
  }
  function G1(i, a, l, r) {
    const c = Object.keys(a), f = Ii(i, c[0]), d = Df(f, a[c[0]], l, r);
    return !d || !d.length ? i.next(l, r) : d;
  }
  function V1(i, a, l, r) {
    const c = [];
    for (const f of Object.keys(a)) {
      const d = a[f];
      if (!d) continue;
      const h = Ii(i, f), g = Df(h, d, l, r);
      g && c.push(...g);
    }
    return c.length ? c : i.next(l, r);
  }
  function Df(i, a, l, r) {
    return typeof a == "string" ? Y1(i, a, l, r) : Object.keys(a).length === 1 ? G1(i, a, l, r) : V1(i, a, l, r);
  }
  function X1(i) {
    return Object.keys(i.states).map((a) => i.states[a]).filter((a) => a.type === "history");
  }
  function Sa(i, a) {
    let l = i;
    for (; l.parent && l.parent !== a; ) l = l.parent;
    return l.parent === a;
  }
  function F1(i, a) {
    const l = new Set(i), r = new Set(a);
    for (const c of l) if (r.has(c)) return true;
    for (const c of r) if (l.has(c)) return true;
    return false;
  }
  function lp(i, a, l) {
    const r = /* @__PURE__ */ new Set();
    for (const c of i) {
      let f = false;
      const d = /* @__PURE__ */ new Set();
      for (const h of r) if (F1(Pu([
        c
      ], a, l), Pu([
        h
      ], a, l))) if (Sa(c.source, h.source)) d.add(h);
      else {
        f = true;
        break;
      }
      if (!f) {
        for (const h of d) r.delete(h);
        r.add(c);
      }
    }
    return Array.from(r);
  }
  function Q1(i) {
    const [a, ...l] = i;
    for (const r of bl(a, void 0)) if (l.every((c) => Sa(c, r))) return r;
  }
  function Uf(i, a) {
    if (!i.target) return [];
    const l = /* @__PURE__ */ new Set();
    for (const r of i.target) if ($a(r)) if (a[r.id]) for (const c of a[r.id]) l.add(c);
    else for (const c of Uf(ip(r), a)) l.add(c);
    else l.add(r);
    return [
      ...l
    ];
  }
  function rp(i, a) {
    const l = Uf(i, a);
    if (!l) return;
    if (!i.reenter && l.every((c) => c === i.source || Sa(c, i.source))) return i.source;
    const r = Q1(l.concat(i.source));
    if (r) return r;
    if (!i.reenter) return i.source.machine.root;
  }
  function Pu(i, a, l) {
    var _a7;
    const r = /* @__PURE__ */ new Set();
    for (const c of i) if ((_a7 = c.target) == null ? void 0 : _a7.length) {
      const f = rp(c, l);
      c.reenter && c.source === f && r.add(f);
      for (const d of a) Sa(d, f) && r.add(d);
    }
    return [
      ...r
    ];
  }
  function Z1(i, a) {
    if (i.length !== a.size) return false;
    for (const l of i) if (!a.has(l)) return false;
    return true;
  }
  function ef(i, a, l, r, c, f) {
    if (!i.length) return a;
    const d = new Set(a._nodes);
    let h = a.historyValue;
    const g = lp(i, d, h);
    let y = a;
    c || ([y, h] = I1(y, r, l, g, d, h, f, l.actionExecutor)), y = Wi(y, r, l, g.flatMap((b) => b.actions), f, void 0), y = $1(y, r, l, g, d, f, h, c);
    const p = [
      ...d
    ];
    y.status === "done" && (y = Wi(y, r, l, p.sort((b, S) => S.order - b.order).flatMap((b) => b.exit), f, void 0));
    try {
      return h === a.historyValue && Z1(a._nodes, d) ? y : Pa(y, {
        _nodes: p,
        historyValue: h
      });
    } catch (b) {
      throw b;
    }
  }
  function K1(i, a, l, r, c) {
    if (r.output === void 0) return;
    const f = Ju(c.id, c.output !== void 0 && c.parent ? Iu(c.output, i.context, a, l.self) : void 0);
    return Iu(r.output, i.context, f, l.self);
  }
  function $1(i, a, l, r, c, f, d, h) {
    let g = i;
    const y = /* @__PURE__ */ new Set(), p = /* @__PURE__ */ new Set();
    J1(r, d, p, y), h && p.add(i.machine.root);
    const b = /* @__PURE__ */ new Set();
    for (const S of [
      ...y
    ].sort((x, v) => x.order - v.order)) {
      c.add(S);
      const x = [];
      x.push(...S.entry);
      for (const v of S.invoke) x.push(D1(v.src, {
        ...v,
        syncSnapshot: !!v.onSnapshot
      }));
      if (p.has(S)) {
        const v = S.initial.actions;
        x.push(...v);
      }
      if (g = Wi(g, a, l, x, f, S.invoke.map((v) => v.id)), S.type === "final") {
        const v = S.parent;
        let A = (v == null ? void 0 : v.type) === "parallel" ? v : v == null ? void 0 : v.parent, j = A || S;
        for ((v == null ? void 0 : v.type) === "compound" && f.push(Ju(v.id, S.output !== void 0 ? Iu(S.output, g.context, a, l.self) : void 0)); (A == null ? void 0 : A.type) === "parallel" && !b.has(A) && Mf(c, A); ) b.add(A), f.push(Ju(A.id)), j = A, A = A.parent;
        if (A) continue;
        g = Pa(g, {
          status: "done",
          output: K1(g, a, l, g.machine.root, j)
        });
      }
    }
    return g;
  }
  function J1(i, a, l, r) {
    for (const c of i) {
      const f = rp(c, a);
      for (const h of c.target || []) !$a(h) && (c.source !== h || c.source !== f || c.reenter) && (r.add(h), l.add(h)), Zi(h, a, l, r);
      const d = Uf(c, a);
      for (const h of d) {
        const g = bl(h, f);
        (f == null ? void 0 : f.type) === "parallel" && g.push(f), op(r, a, l, g, !c.source.parent && c.reenter ? void 0 : f);
      }
    }
  }
  function Zi(i, a, l, r) {
    var _a7;
    if ($a(i)) if (a[i.id]) {
      const c = a[i.id];
      for (const f of c) r.add(f), Zi(f, a, l, r);
      for (const f of c) _u(f, i.parent, r, a, l);
    } else {
      const c = ip(i);
      for (const f of c.target) r.add(f), c === ((_a7 = i.parent) == null ? void 0 : _a7.initial) && l.add(i.parent), Zi(f, a, l, r);
      for (const f of c.target) _u(f, i.parent, r, a, l);
    }
    else if (i.type === "compound") {
      const [c] = i.initial.target;
      $a(c) || (r.add(c), l.add(c)), Zi(c, a, l, r), _u(c, i, r, a, l);
    } else if (i.type === "parallel") for (const c of Ji(i).filter((f) => !$a(f))) [
      ...r
    ].some((f) => Sa(f, c)) || ($a(c) || (r.add(c), l.add(c)), Zi(c, a, l, r));
  }
  function op(i, a, l, r, c) {
    for (const f of r) if ((!c || Sa(f, c)) && i.add(f), f.type === "parallel") for (const d of Ji(f).filter((h) => !$a(h))) [
      ...i
    ].some((h) => Sa(h, d)) || (i.add(d), Zi(d, a, l, i));
  }
  function _u(i, a, l, r, c) {
    op(l, r, c, bl(i, a));
  }
  function I1(i, a, l, r, c, f, d, h) {
    let g = i;
    const y = Pu(r, c, f);
    y.sort((b, S) => S.order - b.order);
    let p;
    for (const b of y) for (const S of X1(b)) {
      let x;
      S.history === "deep" ? x = (v) => jf(v) && Sa(v, b) : x = (v) => v.parent === b, p ?? (p = {
        ...f
      }), p[S.id] = Array.from(c).filter(x);
    }
    for (const b of y) g = Wi(g, a, l, [
      ...b.exit,
      ...b.invoke.map((S) => ep(S.id))
    ], d, void 0), c.delete(b);
    return [
      g,
      p || f
    ];
  }
  function W1(i, a) {
    return i.implementations.actions[a];
  }
  function cp(i, a, l, r, c, f) {
    const { machine: d } = i;
    let h = i;
    for (const g of r) {
      const y = typeof g == "function", p = y ? g : W1(d, typeof g == "string" ? g : g.type), b = {
        context: h.context,
        event: a,
        self: l.self,
        system: l.system
      }, S = y || typeof g == "string" ? void 0 : "params" in g ? typeof g.params == "function" ? g.params({
        context: h.context,
        event: a
      }) : g.params : void 0;
      if (!p || !("resolve" in p)) {
        l.actionExecutor({
          type: typeof g == "string" ? g : typeof g == "object" ? g.type : g.name || "(anonymous)",
          info: b,
          params: S,
          exec: p
        });
        continue;
      }
      const x = p, [v, A, j] = x.resolve(l, h, b, S, p, c);
      h = v, "retryResolve" in x && (f == null ? void 0 : f.push([
        x,
        A
      ])), "execute" in x && l.actionExecutor({
        type: x.type,
        info: b,
        params: A,
        exec: x.execute.bind(null, l, A)
      }), j && (h = cp(h, a, l, j, c, f));
    }
    return h;
  }
  function Wi(i, a, l, r, c, f) {
    const d = f ? [] : void 0, h = cp(i, a, l, r, {
      internalQueue: c,
      deferredActorIds: f
    }, d);
    return d == null ? void 0 : d.forEach(([g, y]) => {
      g.retryResolve(l, h, y);
    }), h;
  }
  function Nu(i, a, l, r) {
    let c = i;
    const f = [];
    function d(y, p, b) {
      l.system._sendInspectionEvent({
        type: "@xstate.microstep",
        actorRef: l.self,
        event: p,
        snapshot: y,
        _transitions: b
      }), f.push(y);
    }
    if (a.type === $u) return c = Pa(Zm(c, a, l), {
      status: "stopped"
    }), d(c, a, []), {
      snapshot: c,
      microstates: f
    };
    let h = a;
    if (h.type !== Ky) {
      const y = h, p = E1(y), b = Km(y, c);
      if (p && !b.length) return c = Pa(i, {
        status: "error",
        error: y.error
      }), d(c, y, []), {
        snapshot: c,
        microstates: f
      };
      c = ef(b, i, l, h, false, r), d(c, y, b);
    }
    let g = true;
    for (; c.status === "active"; ) {
      let y = g ? P1(c, h) : [];
      const p = y.length ? c : void 0;
      if (!y.length) {
        if (!r.length) break;
        h = r.shift(), y = Km(h, c);
      }
      c = ef(y, c, l, h, false, r), g = c !== p, d(c, h, y);
    }
    return c.status !== "active" && Zm(c, h, l), {
      snapshot: c,
      microstates: f
    };
  }
  function Zm(i, a, l) {
    return Wi(i, a, l, Object.values(i.children).map((r) => ep(r)), [], void 0);
  }
  function Km(i, a) {
    return a.machine.getTransitionData(a, i);
  }
  function P1(i, a) {
    const l = /* @__PURE__ */ new Set(), r = i._nodes.filter(jf);
    for (const c of r) e: for (const f of [
      c
    ].concat(bl(c, void 0))) if (f.always) {
      for (const d of f.always) if (d.guard === void 0 || Rf(d.guard, i.context, a, i)) {
        l.add(d);
        break e;
      }
    }
    return lp(Array.from(l), new Set(i._nodes), i.historyValue);
  }
  function ex(i, a) {
    const l = $r(Ir(i, a));
    return ap(i, [
      ...l
    ]);
  }
  function tx(i) {
    return !!i && typeof i == "object" && "machine" in i && "value" in i;
  }
  const nx = function(a) {
    return Jy(a, this.value);
  }, ax = function(a) {
    return this.tags.has(a);
  }, ix = function(a) {
    const l = this.machine.getTransitionData(this, a);
    return !!(l == null ? void 0 : l.length) && l.some((r) => r.target !== void 0 || r.actions.length);
  }, sx = function() {
    const { _nodes: a, tags: l, machine: r, getMeta: c, toJSON: f, can: d, hasTag: h, matches: g, ...y } = this;
    return {
      ...y,
      tags: Array.from(l)
    };
  }, lx = function() {
    return this._nodes.reduce((a, l) => (l.meta !== void 0 && (a[l.id] = l.meta), a), {});
  };
  function Yr(i, a) {
    return {
      status: i.status,
      output: i.output,
      error: i.error,
      machine: a,
      context: i.context,
      _nodes: i._nodes,
      value: ap(a.root, i._nodes),
      tags: new Set(i._nodes.flatMap((l) => l.tags)),
      children: i.children,
      historyValue: i.historyValue || {},
      matches: nx,
      hasTag: ax,
      can: ix,
      getMeta: lx,
      toJSON: sx
    };
  }
  function Pa(i, a = {}) {
    return Yr({
      ...i,
      ...a
    }, i.machine);
  }
  function rx(i, a) {
    const { _nodes: l, tags: r, machine: c, children: f, context: d, can: h, hasTag: g, matches: y, getMeta: p, toJSON: b, ...S } = i, x = {};
    for (const A in f) {
      const j = f[A];
      x[A] = {
        snapshot: j.getPersistedSnapshot(a),
        src: j.src,
        systemId: j._systemId,
        syncSnapshot: j._syncSnapshot
      };
    }
    return {
      ...S,
      context: up(d),
      children: x
    };
  }
  function up(i) {
    let a;
    for (const l in i) {
      const r = i[l];
      if (r && typeof r == "object") if ("sessionId" in r && "send" in r && "ref" in r) a ?? (a = Array.isArray(i) ? i.slice() : {
        ...i
      }), a[l] = {
        xstate$$type: Nf,
        id: r.id
      };
      else {
        const c = up(r);
        c !== r && (a ?? (a = Array.isArray(i) ? i.slice() : {
          ...i
        }), a[l] = c);
      }
    }
    return a ?? i;
  }
  function ox(i, a, l, r, { event: c, id: f, delay: d }, { internalQueue: h }) {
    const g = a.machine.implementations.delays;
    if (typeof c == "string") throw new Error(`Only event objects may be used with raise; use raise({ type: "${c}" }) instead`);
    const y = typeof c == "function" ? c(l, r) : c;
    let p;
    if (typeof d == "string") {
      const b = g && g[d];
      p = typeof b == "function" ? b(l, r) : b;
    } else p = typeof d == "function" ? d(l, r) : d;
    return typeof p != "number" && h.push(y), [
      a,
      {
        event: y,
        id: f,
        delay: p
      },
      void 0
    ];
  }
  function cx(i, a) {
    const { event: l, delay: r, id: c } = a;
    if (typeof r == "number") {
      i.defer(() => {
        const f = i.self;
        i.system.scheduler.schedule(f, f, l, r, c);
      });
      return;
    }
  }
  function ux(i, a) {
    function l(r, c) {
    }
    return l.type = "xstate.raise", l.event = i, l.id = a == null ? void 0 : a.id, l.delay = a == null ? void 0 : a.delay, l.resolve = ox, l.execute = cx, l;
  }
  function fx(i, { machine: a, context: l }, r, c) {
    const f = (d, h) => {
      if (typeof d == "string") {
        const g = _f(a, d);
        if (!g) throw new Error(`Actor logic '${d}' not implemented in machine '${a.id}'`);
        const y = fl(g, {
          id: h == null ? void 0 : h.id,
          parent: i.self,
          syncSnapshot: h == null ? void 0 : h.syncSnapshot,
          input: typeof (h == null ? void 0 : h.input) == "function" ? h.input({
            context: l,
            event: r,
            self: i.self
          }) : h == null ? void 0 : h.input,
          src: d,
          systemId: h == null ? void 0 : h.systemId
        });
        return c[y.id] = y, y;
      } else return fl(d, {
        id: h == null ? void 0 : h.id,
        parent: i.self,
        syncSnapshot: h == null ? void 0 : h.syncSnapshot,
        input: h == null ? void 0 : h.input,
        src: d,
        systemId: h == null ? void 0 : h.systemId
      });
    };
    return (d, h) => {
      const g = f(d, h);
      return c[g.id] = g, i.defer(() => {
        g._processingStatus !== Nt.Stopped && g.start();
      }), g;
    };
  }
  function dx(i, a, l, r, { assignment: c }) {
    if (!a.context) throw new Error("Cannot assign to undefined `context`. Ensure that `context` is defined in the machine config.");
    const f = {}, d = {
      context: a.context,
      event: l.event,
      spawn: fx(i, a, l.event, f),
      self: i.self,
      system: i.system
    };
    let h = {};
    if (typeof c == "function") h = c(d, r);
    else for (const y of Object.keys(c)) {
      const p = c[y];
      h[y] = typeof p == "function" ? p(d, r) : p;
    }
    const g = Object.assign({}, a.context, h);
    return [
      Pa(a, {
        context: g,
        children: Object.keys(f).length ? {
          ...a.children,
          ...f
        } : a.children
      }),
      void 0,
      void 0
    ];
  }
  function tf(i) {
    function a(l, r) {
    }
    return a.type = "xstate.assign", a.assignment = i, a.resolve = dx, a;
  }
  function hx(i, a) {
    const l = Xn(a);
    if (!l.includes(i.type)) {
      const r = l.length === 1 ? `type "${l[0]}"` : `one of types "${l.join('", "')}"`;
      throw new Error(`Expected event ${JSON.stringify(i)} to have ${r}`);
    }
  }
  const $m = /* @__PURE__ */ new WeakMap();
  function qi(i, a, l) {
    let r = $m.get(i);
    return r ? a in r || (r[a] = l()) : (r = {
      [a]: l()
    }, $m.set(i, r)), r[a];
  }
  const mx = {}, nl = (i) => typeof i == "string" ? {
    type: i
  } : typeof i == "function" ? "resolve" in i ? {
    type: i.type
  } : {
    type: i.name
  } : i;
  class zf {
    constructor(a, l) {
      if (this.config = a, this.key = void 0, this.id = void 0, this.type = void 0, this.path = void 0, this.states = void 0, this.history = void 0, this.entry = void 0, this.exit = void 0, this.parent = void 0, this.machine = void 0, this.meta = void 0, this.output = void 0, this.order = -1, this.description = void 0, this.tags = [], this.transitions = void 0, this.always = void 0, this.parent = l._parent, this.key = l._key, this.machine = l._machine, this.path = this.parent ? this.parent.path.concat(this.key) : [], this.id = this.config.id || [
        this.machine.id,
        ...this.path
      ].join(Qy), this.type = this.config.type || (this.config.states && Object.keys(this.config.states).length ? "compound" : this.config.history ? "history" : "atomic"), this.description = this.config.description, this.order = this.machine.idMap.size, this.machine.idMap.set(this.id, this), this.states = this.config.states ? Vm(this.config.states, (r, c) => new zf(r, {
        _parent: this,
        _key: c,
        _machine: this.machine
      })) : mx, this.type === "compound" && !this.config.initial) throw new Error(`No initial state specified for compound state node "#${this.id}". Try adding { initial: "${Object.keys(this.states)[0]}" } to the state config.`);
      this.history = this.config.history === true ? "shallow" : this.config.history || false, this.entry = Xn(this.config.entry).slice(), this.exit = Xn(this.config.exit).slice(), this.meta = this.config.meta, this.output = this.type === "final" || !this.parent ? this.config.output : void 0, this.tags = Xn(a.tags).slice();
    }
    _initialize() {
      this.transitions = H1(this), this.config.always && (this.always = Vi(this.config.always).map((a) => Ka(this, Zy, a))), Object.keys(this.states).forEach((a) => {
        this.states[a]._initialize();
      });
    }
    get definition() {
      return {
        id: this.id,
        key: this.key,
        version: this.machine.version,
        type: this.type,
        initial: this.initial ? {
          target: this.initial.target,
          source: this,
          actions: this.initial.actions.map(nl),
          eventType: null,
          reenter: false,
          toJSON: () => ({
            target: this.initial.target.map((a) => `#${a.id}`),
            source: `#${this.id}`,
            actions: this.initial.actions.map(nl),
            eventType: null
          })
        } : void 0,
        history: this.history,
        states: Vm(this.states, (a) => a.definition),
        on: this.on,
        transitions: [
          ...this.transitions.values()
        ].flat().map((a) => ({
          ...a,
          actions: a.actions.map(nl)
        })),
        entry: this.entry.map(nl),
        exit: this.exit.map(nl),
        meta: this.meta,
        order: this.order || -1,
        output: this.output,
        invoke: this.invoke,
        description: this.description,
        tags: this.tags
      };
    }
    toJSON() {
      return this.definition;
    }
    get invoke() {
      return qi(this, "invoke", () => Xn(this.config.invoke).map((a, l) => {
        const { src: r, systemId: c } = a, f = a.id ?? Xm(this.id, l), d = typeof r == "string" ? r : `xstate.invoke.${Xm(this.id, l)}`;
        return {
          ...a,
          src: d,
          id: f,
          systemId: c,
          toJSON() {
            const { onDone: h, onError: g, ...y } = a;
            return {
              ...y,
              type: "xstate.invoke",
              src: d,
              id: f
            };
          }
        };
      }));
    }
    get on() {
      return qi(this, "on", () => [
        ...this.transitions
      ].flatMap(([l, r]) => r.map((c) => [
        l,
        c
      ])).reduce((l, [r, c]) => (l[r] = l[r] || [], l[r].push(c), l), {}));
    }
    get after() {
      return qi(this, "delayedTransitions", () => B1(this));
    }
    get initial() {
      return qi(this, "initial", () => L1(this, this.config.initial));
    }
    next(a, l) {
      const r = l.type, c = [];
      let f;
      const d = qi(this, `candidates-${r}`, () => k1(this, r));
      for (const h of d) {
        const { guard: g } = h, y = a.context;
        let p = false;
        try {
          p = !g || Rf(g, y, l, a);
        } catch (b) {
          const S = typeof g == "string" ? g : typeof g == "object" ? g.type : void 0;
          throw new Error(`Unable to evaluate guard ${S ? `'${S}' ` : ""}in transition for event '${r}' in state node '${this.id}':
${b.message}`);
        }
        if (p) {
          c.push(...h.actions), f = h;
          break;
        }
      }
      return f ? [
        f
      ] : void 0;
    }
    get events() {
      return qi(this, "events", () => {
        const { states: a } = this, l = new Set(this.ownEvents);
        if (a) for (const r of Object.keys(a)) {
          const c = a[r];
          if (c.states) for (const f of c.events) l.add(`${f}`);
        }
        return Array.from(l);
      });
    }
    get ownEvents() {
      const a = new Set([
        ...this.transitions.keys()
      ].filter((l) => this.transitions.get(l).some((r) => !(!r.target && !r.actions.length && !r.reenter))));
      return Array.from(a);
    }
  }
  const yx = "#";
  class kf {
    constructor(a, l) {
      this.config = a, this.version = void 0, this.schemas = void 0, this.implementations = void 0, this.__xstatenode = true, this.idMap = /* @__PURE__ */ new Map(), this.root = void 0, this.id = void 0, this.states = void 0, this.events = void 0, this.id = a.id || "(machine)", this.implementations = {
        actors: (l == null ? void 0 : l.actors) ?? {},
        actions: (l == null ? void 0 : l.actions) ?? {},
        delays: (l == null ? void 0 : l.delays) ?? {},
        guards: (l == null ? void 0 : l.guards) ?? {}
      }, this.version = this.config.version, this.schemas = this.config.schemas, this.transition = this.transition.bind(this), this.getInitialSnapshot = this.getInitialSnapshot.bind(this), this.getPersistedSnapshot = this.getPersistedSnapshot.bind(this), this.restoreSnapshot = this.restoreSnapshot.bind(this), this.start = this.start.bind(this), this.root = new zf(a, {
        _key: this.id,
        _machine: this
      }), this.root._initialize(), this.states = this.root.states, this.events = this.root.events;
    }
    provide(a) {
      const { actions: l, guards: r, actors: c, delays: f } = this.implementations;
      return new kf(this.config, {
        actions: {
          ...l,
          ...a.actions
        },
        guards: {
          ...r,
          ...a.guards
        },
        actors: {
          ...c,
          ...a.actors
        },
        delays: {
          ...f,
          ...a.delays
        }
      });
    }
    resolveState(a) {
      const l = ex(this.root, a.value), r = $r(Ir(this.root, l));
      return Yr({
        _nodes: [
          ...r
        ],
        context: a.context || {},
        children: {},
        status: Mf(r, this.root) ? "done" : a.status || "active",
        output: a.output,
        error: a.error,
        historyValue: a.historyValue
      }, this);
    }
    transition(a, l, r) {
      return Nu(a, l, r, []).snapshot;
    }
    microstep(a, l, r) {
      return Nu(a, l, r, []).microstates;
    }
    getTransitionData(a, l) {
      return Df(this.root, a.value, a, l) || [];
    }
    getPreInitialState(a, l, r) {
      const { context: c } = this.config, f = Yr({
        context: typeof c != "function" && c ? c : {},
        _nodes: [
          this.root
        ],
        children: {},
        status: "active"
      }, this);
      return typeof c == "function" ? Wi(f, l, a, [
        tf(({ spawn: h, event: g, self: y }) => c({
          spawn: h,
          input: g.input,
          self: y
        }))
      ], r, void 0) : f;
    }
    getInitialSnapshot(a, l) {
      const r = $y(l), c = [], f = this.getPreInitialState(a, r, c), d = ef([
        {
          target: [
            ...sp(this.root)
          ],
          source: this.root,
          reenter: true,
          actions: [],
          eventType: null,
          toJSON: null
        }
      ], f, a, r, true, c), { snapshot: h } = Nu(d, r, a, c);
      return h;
    }
    start(a) {
      Object.values(a.children).forEach((l) => {
        l.getSnapshot().status === "active" && l.start();
      });
    }
    getStateNodeById(a) {
      const l = Cf(a), r = l.slice(1), c = io(l[0]) ? l[0].slice(yx.length) : l[0], f = this.idMap.get(c);
      if (!f) throw new Error(`Child state node '#${c}' does not exist on machine '${this.id}'`);
      return Jr(f, r);
    }
    get definition() {
      return this.root.definition;
    }
    toJSON() {
      return this.definition;
    }
    getPersistedSnapshot(a, l) {
      return rx(a, l);
    }
    restoreSnapshot(a, l) {
      const r = {}, c = a.children;
      Object.keys(c).forEach((g) => {
        const y = c[g], p = y.snapshot, b = y.src, S = typeof b == "string" ? _f(this, b) : b;
        if (!S) return;
        const x = fl(S, {
          id: g,
          parent: l.self,
          syncSnapshot: y.syncSnapshot,
          snapshot: p,
          src: b,
          systemId: y.systemId
        });
        r[g] = x;
      });
      const f = Yr({
        ...a,
        children: r,
        _nodes: Array.from($r(Ir(this.root, a.value)))
      }, this), d = /* @__PURE__ */ new Set();
      function h(g, y) {
        if (!d.has(g)) {
          d.add(g);
          for (const p in g) {
            const b = g[p];
            if (b && typeof b == "object") {
              if ("xstate$$type" in b && b.xstate$$type === Nf) {
                g[p] = y[b.id];
                continue;
              }
              h(b, y);
            }
          }
        }
      }
      return h(f.context, r), f;
    }
  }
  function px(i, a) {
    return new kf(i, a);
  }
  function gx({ schemas: i, actors: a, actions: l, guards: r, delays: c }) {
    return {
      createMachine: (f) => px({
        ...f,
        schemas: i
      }, {
        actors: a,
        actions: l,
        guards: r,
        delays: c
      })
    };
  }
  const bx = {
    timeout: 1 / 0
  };
  function vx(i, a, l) {
    const r = {
      ...bx,
      ...l
    };
    return new Promise((c, f) => {
      const { signal: d } = r;
      if (d == null ? void 0 : d.aborted) {
        f(d.reason);
        return;
      }
      let h = false;
      const g = r.timeout === 1 / 0 ? void 0 : setTimeout(() => {
        y(), f(new Error(`Timeout of ${r.timeout} ms exceeded`));
      }, r.timeout), y = () => {
        clearTimeout(g), h = true, S == null ? void 0 : S.unsubscribe(), b && d.removeEventListener("abort", b);
      };
      function p(x) {
        a(x) && (y(), c(x));
      }
      let b, S;
      p(i.getSnapshot()), !h && (d && (b = () => {
        y(), f(d.reason);
      }, d.addEventListener("abort", b)), S = i.subscribe({
        next: p,
        error: (x) => {
          y(), f(x);
        },
        complete: () => {
          y(), f(new Error("Actor terminated without satisfying predicate"));
        }
      }), h && S.unsubscribe());
    });
  }
  var Yn = {}, ba = {}, va = {}, Jm;
  function fp() {
    if (Jm) return va;
    Jm = 1, Object.defineProperty(va, "__esModule", {
      value: true
    }), va.anumber = i, va.abytes = l, va.ahash = r, va.aexists = c, va.aoutput = f;
    function i(d) {
      if (!Number.isSafeInteger(d) || d < 0) throw new Error("positive integer expected, got " + d);
    }
    function a(d) {
      return d instanceof Uint8Array || ArrayBuffer.isView(d) && d.constructor.name === "Uint8Array";
    }
    function l(d, ...h) {
      if (!a(d)) throw new Error("Uint8Array expected");
      if (h.length > 0 && !h.includes(d.length)) throw new Error("Uint8Array expected of length " + h + ", got length=" + d.length);
    }
    function r(d) {
      if (typeof d != "function" || typeof d.create != "function") throw new Error("Hash should be wrapped by utils.wrapConstructor");
      i(d.outputLen), i(d.blockLen);
    }
    function c(d, h = true) {
      if (d.destroyed) throw new Error("Hash instance has been destroyed");
      if (h && d.finished) throw new Error("Hash#digest() has already been called");
    }
    function f(d, h) {
      l(d);
      const g = h.outputLen;
      if (d.length < g) throw new Error("digestInto() expects output buffer of length at least " + g);
    }
    return va;
  }
  var Ru = {}, al = {}, Im;
  function xx() {
    return Im || (Im = 1, Object.defineProperty(al, "__esModule", {
      value: true
    }), al.crypto = void 0, al.crypto = typeof globalThis == "object" && "crypto" in globalThis ? globalThis.crypto : void 0), al;
  }
  var Wm;
  function dp() {
    return Wm || (Wm = 1, function(i) {
      Object.defineProperty(i, "__esModule", {
        value: true
      }), i.Hash = i.nextTick = i.byteSwapIfBE = i.isLE = void 0, i.isBytes = r, i.u8 = c, i.u32 = f, i.createView = d, i.rotr = h, i.rotl = g, i.byteSwap = y, i.byteSwap32 = p, i.bytesToHex = x, i.hexToBytes = j, i.asyncLoop = B, i.utf8ToBytes = D, i.toBytes = I, i.concatBytes = ee, i.checkOpts = be, i.wrapConstructor = le, i.wrapConstructorWithOpts = W, i.wrapXOFConstructorWithOpts = P, i.randomBytes = pe;
      const a = xx(), l = fp();
      function r(F) {
        return F instanceof Uint8Array || ArrayBuffer.isView(F) && F.constructor.name === "Uint8Array";
      }
      function c(F) {
        return new Uint8Array(F.buffer, F.byteOffset, F.byteLength);
      }
      function f(F) {
        return new Uint32Array(F.buffer, F.byteOffset, Math.floor(F.byteLength / 4));
      }
      function d(F) {
        return new DataView(F.buffer, F.byteOffset, F.byteLength);
      }
      function h(F, O) {
        return F << 32 - O | F >>> O;
      }
      function g(F, O) {
        return F << O | F >>> 32 - O >>> 0;
      }
      i.isLE = new Uint8Array(new Uint32Array([
        287454020
      ]).buffer)[0] === 68;
      function y(F) {
        return F << 24 & 4278190080 | F << 8 & 16711680 | F >>> 8 & 65280 | F >>> 24 & 255;
      }
      i.byteSwapIfBE = i.isLE ? (F) => F : (F) => y(F);
      function p(F) {
        for (let O = 0; O < F.length; O++) F[O] = y(F[O]);
      }
      const b = typeof Uint8Array.from([]).toHex == "function" && typeof Uint8Array.fromHex == "function", S = Array.from({
        length: 256
      }, (F, O) => O.toString(16).padStart(2, "0"));
      function x(F) {
        if ((0, l.abytes)(F), b) return F.toHex();
        let O = "";
        for (let Q = 0; Q < F.length; Q++) O += S[F[Q]];
        return O;
      }
      const v = {
        _0: 48,
        _9: 57,
        A: 65,
        F: 70,
        a: 97,
        f: 102
      };
      function A(F) {
        if (F >= v._0 && F <= v._9) return F - v._0;
        if (F >= v.A && F <= v.F) return F - (v.A - 10);
        if (F >= v.a && F <= v.f) return F - (v.a - 10);
      }
      function j(F) {
        if (typeof F != "string") throw new Error("hex string expected, got " + typeof F);
        if (b) return Uint8Array.fromHex(F);
        const O = F.length, Q = O / 2;
        if (O % 2) throw new Error("hex string expected, got unpadded hex of length " + O);
        const Y = new Uint8Array(Q);
        for (let R = 0, k = 0; R < Q; R++, k += 2) {
          const J = A(F.charCodeAt(k)), ne = A(F.charCodeAt(k + 1));
          if (J === void 0 || ne === void 0) {
            const te = F[k] + F[k + 1];
            throw new Error('hex string expected, got non-hex character "' + te + '" at index ' + k);
          }
          Y[R] = J * 16 + ne;
        }
        return Y;
      }
      const L = async () => {
      };
      i.nextTick = L;
      async function B(F, O, Q) {
        let Y = Date.now();
        for (let R = 0; R < F; R++) {
          Q(R);
          const k = Date.now() - Y;
          k >= 0 && k < O || (await (0, i.nextTick)(), Y += k);
        }
      }
      function D(F) {
        if (typeof F != "string") throw new Error("utf8ToBytes expected string, got " + typeof F);
        return new Uint8Array(new TextEncoder().encode(F));
      }
      function I(F) {
        return typeof F == "string" && (F = D(F)), (0, l.abytes)(F), F;
      }
      function ee(...F) {
        let O = 0;
        for (let Y = 0; Y < F.length; Y++) {
          const R = F[Y];
          (0, l.abytes)(R), O += R.length;
        }
        const Q = new Uint8Array(O);
        for (let Y = 0, R = 0; Y < F.length; Y++) {
          const k = F[Y];
          Q.set(k, R), R += k.length;
        }
        return Q;
      }
      class ae {
        clone() {
          return this._cloneInto();
        }
      }
      i.Hash = ae;
      function be(F, O) {
        if (O !== void 0 && {}.toString.call(O) !== "[object Object]") throw new Error("Options should be object or undefined");
        return Object.assign(F, O);
      }
      function le(F) {
        const O = (Y) => F().update(I(Y)).digest(), Q = F();
        return O.outputLen = Q.outputLen, O.blockLen = Q.blockLen, O.create = () => F(), O;
      }
      function W(F) {
        const O = (Y, R) => F(R).update(I(Y)).digest(), Q = F({});
        return O.outputLen = Q.outputLen, O.blockLen = Q.blockLen, O.create = (Y) => F(Y), O;
      }
      function P(F) {
        const O = (Y, R) => F(R).update(I(Y)).digest(), Q = F({});
        return O.outputLen = Q.outputLen, O.blockLen = Q.blockLen, O.create = (Y) => F(Y), O;
      }
      function pe(F = 32) {
        if (a.crypto && typeof a.crypto.getRandomValues == "function") return a.crypto.getRandomValues(new Uint8Array(F));
        if (a.crypto && typeof a.crypto.randomBytes == "function") return Uint8Array.from(a.crypto.randomBytes(F));
        throw new Error("crypto.getRandomValues must be defined");
      }
    }(Ru)), Ru;
  }
  var Pm;
  function Sx() {
    if (Pm) return ba;
    Pm = 1, Object.defineProperty(ba, "__esModule", {
      value: true
    }), ba.HashMD = void 0, ba.setBigUint64 = l, ba.Chi = r, ba.Maj = c;
    const i = fp(), a = dp();
    function l(d, h, g, y) {
      if (typeof d.setBigUint64 == "function") return d.setBigUint64(h, g, y);
      const p = BigInt(32), b = BigInt(4294967295), S = Number(g >> p & b), x = Number(g & b), v = y ? 4 : 0, A = y ? 0 : 4;
      d.setUint32(h + v, S, y), d.setUint32(h + A, x, y);
    }
    function r(d, h, g) {
      return d & h ^ ~d & g;
    }
    function c(d, h, g) {
      return d & h ^ d & g ^ h & g;
    }
    class f extends a.Hash {
      constructor(h, g, y, p) {
        super(), this.finished = false, this.length = 0, this.pos = 0, this.destroyed = false, this.blockLen = h, this.outputLen = g, this.padOffset = y, this.isLE = p, this.buffer = new Uint8Array(h), this.view = (0, a.createView)(this.buffer);
      }
      update(h) {
        (0, i.aexists)(this);
        const { view: g, buffer: y, blockLen: p } = this;
        h = (0, a.toBytes)(h);
        const b = h.length;
        for (let S = 0; S < b; ) {
          const x = Math.min(p - this.pos, b - S);
          if (x === p) {
            const v = (0, a.createView)(h);
            for (; p <= b - S; S += p) this.process(v, S);
            continue;
          }
          y.set(h.subarray(S, S + x), this.pos), this.pos += x, S += x, this.pos === p && (this.process(g, 0), this.pos = 0);
        }
        return this.length += h.length, this.roundClean(), this;
      }
      digestInto(h) {
        (0, i.aexists)(this), (0, i.aoutput)(h, this), this.finished = true;
        const { buffer: g, view: y, blockLen: p, isLE: b } = this;
        let { pos: S } = this;
        g[S++] = 128, this.buffer.subarray(S).fill(0), this.padOffset > p - S && (this.process(y, 0), S = 0);
        for (let L = S; L < p; L++) g[L] = 0;
        l(y, p - 8, BigInt(this.length * 8), b), this.process(y, 0);
        const x = (0, a.createView)(h), v = this.outputLen;
        if (v % 4) throw new Error("_sha2: outputLen should be aligned to 32bit");
        const A = v / 4, j = this.get();
        if (A > j.length) throw new Error("_sha2: outputLen bigger than state");
        for (let L = 0; L < A; L++) x.setUint32(4 * L, j[L], b);
      }
      digest() {
        const { buffer: h, outputLen: g } = this;
        this.digestInto(h);
        const y = h.slice(0, g);
        return this.destroy(), y;
      }
      _cloneInto(h) {
        h || (h = new this.constructor()), h.set(...this.get());
        const { blockLen: g, buffer: y, length: p, finished: b, destroyed: S, pos: x } = this;
        return h.length = p, h.pos = x, h.finished = b, h.destroyed = S, p % g && h.buffer.set(y), h;
      }
    }
    return ba.HashMD = f, ba;
  }
  var ey;
  function wx() {
    if (ey) return Yn;
    ey = 1, Object.defineProperty(Yn, "__esModule", {
      value: true
    }), Yn.sha224 = Yn.sha256 = Yn.SHA256 = void 0;
    const i = Sx(), a = dp(), l = new Uint32Array([
      1116352408,
      1899447441,
      3049323471,
      3921009573,
      961987163,
      1508970993,
      2453635748,
      2870763221,
      3624381080,
      310598401,
      607225278,
      1426881987,
      1925078388,
      2162078206,
      2614888103,
      3248222580,
      3835390401,
      4022224774,
      264347078,
      604807628,
      770255983,
      1249150122,
      1555081692,
      1996064986,
      2554220882,
      2821834349,
      2952996808,
      3210313671,
      3336571891,
      3584528711,
      113926993,
      338241895,
      666307205,
      773529912,
      1294757372,
      1396182291,
      1695183700,
      1986661051,
      2177026350,
      2456956037,
      2730485921,
      2820302411,
      3259730800,
      3345764771,
      3516065817,
      3600352804,
      4094571909,
      275423344,
      430227734,
      506948616,
      659060556,
      883997877,
      958139571,
      1322822218,
      1537002063,
      1747873779,
      1955562222,
      2024104815,
      2227730452,
      2361852424,
      2428436474,
      2756734187,
      3204031479,
      3329325298
    ]), r = new Uint32Array([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]), c = new Uint32Array(64);
    class f extends i.HashMD {
      constructor(g = 32) {
        super(64, g, 8, false), this.A = r[0] | 0, this.B = r[1] | 0, this.C = r[2] | 0, this.D = r[3] | 0, this.E = r[4] | 0, this.F = r[5] | 0, this.G = r[6] | 0, this.H = r[7] | 0;
      }
      get() {
        const { A: g, B: y, C: p, D: b, E: S, F: x, G: v, H: A } = this;
        return [
          g,
          y,
          p,
          b,
          S,
          x,
          v,
          A
        ];
      }
      set(g, y, p, b, S, x, v, A) {
        this.A = g | 0, this.B = y | 0, this.C = p | 0, this.D = b | 0, this.E = S | 0, this.F = x | 0, this.G = v | 0, this.H = A | 0;
      }
      process(g, y) {
        for (let B = 0; B < 16; B++, y += 4) c[B] = g.getUint32(y, false);
        for (let B = 16; B < 64; B++) {
          const D = c[B - 15], I = c[B - 2], ee = (0, a.rotr)(D, 7) ^ (0, a.rotr)(D, 18) ^ D >>> 3, ae = (0, a.rotr)(I, 17) ^ (0, a.rotr)(I, 19) ^ I >>> 10;
          c[B] = ae + c[B - 7] + ee + c[B - 16] | 0;
        }
        let { A: p, B: b, C: S, D: x, E: v, F: A, G: j, H: L } = this;
        for (let B = 0; B < 64; B++) {
          const D = (0, a.rotr)(v, 6) ^ (0, a.rotr)(v, 11) ^ (0, a.rotr)(v, 25), I = L + D + (0, i.Chi)(v, A, j) + l[B] + c[B] | 0, ae = ((0, a.rotr)(p, 2) ^ (0, a.rotr)(p, 13) ^ (0, a.rotr)(p, 22)) + (0, i.Maj)(p, b, S) | 0;
          L = j, j = A, A = v, v = x + I | 0, x = S, S = b, b = p, p = I + ae | 0;
        }
        p = p + this.A | 0, b = b + this.B | 0, S = S + this.C | 0, x = x + this.D | 0, v = v + this.E | 0, A = A + this.F | 0, j = j + this.G | 0, L = L + this.H | 0, this.set(p, b, S, x, v, A, j, L);
      }
      roundClean() {
        c.fill(0);
      }
      destroy() {
        this.set(0, 0, 0, 0, 0, 0, 0, 0), this.buffer.fill(0);
      }
    }
    Yn.SHA256 = f;
    class d extends f {
      constructor() {
        super(28), this.A = -1056596264, this.B = 914150663, this.C = 812702999, this.D = -150054599, this.E = -4191439, this.F = 1750603025, this.G = 1694076839, this.H = -1090891868;
      }
    }
    return Yn.sha256 = (0, a.wrapConstructor)(() => new f()), Yn.sha224 = (0, a.wrapConstructor)(() => new d()), Yn;
  }
  var ju, ty;
  function Ex() {
    if (ty) return ju;
    ty = 1;
    function i(a) {
      if (a.length >= 255) throw new TypeError("Alphabet too long");
      for (var l = new Uint8Array(256), r = 0; r < l.length; r++) l[r] = 255;
      for (var c = 0; c < a.length; c++) {
        var f = a.charAt(c), d = f.charCodeAt(0);
        if (l[d] !== 255) throw new TypeError(f + " is ambiguous");
        l[d] = c;
      }
      var h = a.length, g = a.charAt(0), y = Math.log(h) / Math.log(256), p = Math.log(256) / Math.log(h);
      function b(v) {
        if (v instanceof Uint8Array || (ArrayBuffer.isView(v) ? v = new Uint8Array(v.buffer, v.byteOffset, v.byteLength) : Array.isArray(v) && (v = Uint8Array.from(v))), !(v instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
        if (v.length === 0) return "";
        for (var A = 0, j = 0, L = 0, B = v.length; L !== B && v[L] === 0; ) L++, A++;
        for (var D = (B - L) * p + 1 >>> 0, I = new Uint8Array(D); L !== B; ) {
          for (var ee = v[L], ae = 0, be = D - 1; (ee !== 0 || ae < j) && be !== -1; be--, ae++) ee += 256 * I[be] >>> 0, I[be] = ee % h >>> 0, ee = ee / h >>> 0;
          if (ee !== 0) throw new Error("Non-zero carry");
          j = ae, L++;
        }
        for (var le = D - j; le !== D && I[le] === 0; ) le++;
        for (var W = g.repeat(A); le < D; ++le) W += a.charAt(I[le]);
        return W;
      }
      function S(v) {
        if (typeof v != "string") throw new TypeError("Expected String");
        if (v.length === 0) return new Uint8Array();
        for (var A = 0, j = 0, L = 0; v[A] === g; ) j++, A++;
        for (var B = (v.length - A) * y + 1 >>> 0, D = new Uint8Array(B); v[A]; ) {
          var I = v.charCodeAt(A);
          if (I > 255) return;
          var ee = l[I];
          if (ee === 255) return;
          for (var ae = 0, be = B - 1; (ee !== 0 || ae < L) && be !== -1; be--, ae++) ee += h * D[be] >>> 0, D[be] = ee % 256 >>> 0, ee = ee / 256 >>> 0;
          if (ee !== 0) throw new Error("Non-zero carry");
          L = ae, A++;
        }
        for (var le = B - L; le !== B && D[le] === 0; ) le++;
        for (var W = new Uint8Array(j + (B - le)), P = j; le !== B; ) W[P++] = D[le++];
        return W;
      }
      function x(v) {
        var A = S(v);
        if (A) return A;
        throw new Error("Non-base" + h + " character");
      }
      return {
        encode: b,
        decodeUnsafe: S,
        decode: x
      };
    }
    return ju = i, ju;
  }
  var Mu, ny;
  function Ax() {
    return ny || (ny = 1, Mu = Ex()("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz")), Mu;
  }
  var Du, ay;
  function Tx() {
    if (ay) return Du;
    ay = 1;
    var i = Ax();
    return Du = function(a) {
      function l(d) {
        var h = Uint8Array.from(d), g = a(h), y = h.length + 4, p = new Uint8Array(y);
        return p.set(h, 0), p.set(g.subarray(0, 4), h.length), i.encode(p, y);
      }
      function r(d) {
        var h = d.slice(0, -4), g = d.slice(-4), y = a(h);
        if (!(g[0] ^ y[0] | g[1] ^ y[1] | g[2] ^ y[2] | g[3] ^ y[3])) return h;
      }
      function c(d) {
        var h = i.decodeUnsafe(d);
        if (h) return r(h);
      }
      function f(d) {
        var h = i.decode(d), g = r(h);
        if (!g) throw new Error("Invalid checksum");
        return g;
      }
      return {
        encode: l,
        decode: f,
        decodeUnsafe: c
      };
    }, Du;
  }
  var Uu, iy;
  function Ox() {
    if (iy) return Uu;
    iy = 1;
    var { sha256: i } = wx(), a = Tx();
    function l(r) {
      return i(i(r));
    }
    return Uu = a(l), Uu;
  }
  var Cx = Ox();
  const hp = Tf(Cx), Bf = "automerge:", Hf = (i) => {
    const a = new RegExp(`^${Bf}(\\w+)$`), [, l] = i.match(a) || [], r = l, c = yp(r);
    if (!c) throw new Error("Invalid document URL: " + i);
    return {
      binaryDocumentId: c,
      documentId: r
    };
  }, Lf = (i) => {
    const a = i instanceof Uint8Array || typeof i == "string" ? i : "documentId" in i ? i.documentId : void 0, l = a instanceof Uint8Array ? nf(a) : typeof a == "string" ? a : void 0;
    if (l === void 0) throw new Error("Invalid documentId: " + a);
    return Bf + l;
  }, _x = (i) => {
    if (!i || !i.startsWith(Bf)) return false;
    const a = i;
    try {
      const { documentId: l } = Hf(a);
      return mp(l);
    } catch {
      return false;
    }
  }, mp = (i) => {
    const a = yp(i);
    if (a === void 0) return false;
    const l = kv(a);
    return Gy(l);
  }, Nx = (i) => Gy(i), Rx = () => {
    const i = Yy(null, new Uint8Array(16));
    return Lf({
      documentId: i
    });
  }, yp = (i) => hp.decodeUnsafe(i), nf = (i) => hp.encode(i), zu = (i) => {
    if (i instanceof Uint8Array) return nf(i);
    if (_x(i)) return Hf(i).documentId;
    if (mp(i)) return i;
    if (Nx(i)) {
      console.warn("Future versions will not support UUIDs as document IDs; use Automerge URLs instead.");
      const a = zv(i);
      return nf(a);
    }
    throw new Error(`Invalid AutomergeUrl: '${i}'`);
  };
  let af;
  try {
    af = new TextDecoder();
  } catch {
  }
  let se, Ia, X = 0;
  const jx = 105, Mx = 57342, Dx = 57343, sy = 57337, ly = 6, Yi = {};
  let il = 11281e4, Gn = 1681e4, we = {}, Ze, Wr, Pr = 0, dl = 0, ot, Pt, et = [], sf = [], Rt, At, ol, ry = {
    useRecords: false,
    mapsAsObjects: true
  }, hl = false, pp = 2;
  try {
    new Function("");
  } catch {
    pp = 1 / 0;
  }
  class ml {
    constructor(a) {
      if (a && ((a.keyMap || a._keyMap) && !a.useRecords && (a.useRecords = false, a.mapsAsObjects = true), a.useRecords === false && a.mapsAsObjects === void 0 && (a.mapsAsObjects = true), a.getStructures && (a.getShared = a.getStructures), a.getShared && !a.structures && ((a.structures = []).uninitialized = true), a.keyMap)) {
        this.mapKey = /* @__PURE__ */ new Map();
        for (let [l, r] of Object.entries(a.keyMap)) this.mapKey.set(r, l);
      }
      Object.assign(this, a);
    }
    decodeKey(a) {
      return this.keyMap && this.mapKey.get(a) || a;
    }
    encodeKey(a) {
      return this.keyMap && this.keyMap.hasOwnProperty(a) ? this.keyMap[a] : a;
    }
    encodeKeys(a) {
      if (!this._keyMap) return a;
      let l = /* @__PURE__ */ new Map();
      for (let [r, c] of Object.entries(a)) l.set(this._keyMap.hasOwnProperty(r) ? this._keyMap[r] : r, c);
      return l;
    }
    decodeKeys(a) {
      if (!this._keyMap || a.constructor.name != "Map") return a;
      if (!this._mapKey) {
        this._mapKey = /* @__PURE__ */ new Map();
        for (let [r, c] of Object.entries(this._keyMap)) this._mapKey.set(c, r);
      }
      let l = {};
      return a.forEach((r, c) => l[en(this._mapKey.has(c) ? this._mapKey.get(c) : c)] = r), l;
    }
    mapDecode(a, l) {
      let r = this.decode(a);
      if (this._keyMap) switch (r.constructor.name) {
        case "Array":
          return r.map((c) => this.decodeKeys(c));
      }
      return r;
    }
    decode(a, l) {
      if (se) return xp(() => (cf(), this ? this.decode(a, l) : ml.prototype.decode.call(ry, a, l)));
      Ia = l > -1 ? l : a.length, X = 0, dl = 0, Wr = null, ot = null, se = a;
      try {
        At = a.dataView || (a.dataView = new DataView(a.buffer, a.byteOffset, a.byteLength));
      } catch (r) {
        throw se = null, a instanceof Uint8Array ? r : new Error("Source must be a Uint8Array or Buffer but was a " + (a && typeof a == "object" ? a.constructor.name : typeof a));
      }
      if (this instanceof ml) {
        if (we = this, Rt = this.sharedValues && (this.pack ? new Array(this.maxPrivatePackedValues || 16).concat(this.sharedValues) : this.sharedValues), this.structures) return Ze = this.structures, zr();
        (!Ze || Ze.length > 0) && (Ze = []);
      } else we = ry, (!Ze || Ze.length > 0) && (Ze = []), Rt = null;
      return zr();
    }
    decodeMultiple(a, l) {
      let r, c = 0;
      try {
        let f = a.length;
        hl = true;
        let d = this ? this.decode(a, f) : Gf.decode(a, f);
        if (l) {
          if (l(d) === false) return;
          for (; X < f; ) if (c = X, l(zr()) === false) return;
        } else {
          for (r = [
            d
          ]; X < f; ) c = X, r.push(zr());
          return r;
        }
      } catch (f) {
        throw f.lastPosition = c, f.values = r, f;
      } finally {
        hl = false, cf();
      }
    }
  }
  function zr() {
    try {
      let i = Ce();
      if (ot) {
        if (X >= ot.postBundlePosition) {
          let a = new Error("Unexpected bundle position");
          throw a.incomplete = true, a;
        }
        X = ot.postBundlePosition, ot = null;
      }
      if (X == Ia) Ze = null, se = null, Pt && (Pt = null);
      else if (X > Ia) {
        let a = new Error("Unexpected end of CBOR data");
        throw a.incomplete = true, a;
      } else if (!hl) throw new Error("Data read, but end of buffer not reached");
      return i;
    } catch (i) {
      throw cf(), (i instanceof RangeError || i.message.startsWith("Unexpected end of buffer")) && (i.incomplete = true), i;
    }
  }
  function Ce() {
    let i = se[X++], a = i >> 5;
    if (i = i & 31, i > 23) switch (i) {
      case 24:
        i = se[X++];
        break;
      case 25:
        if (a == 7) return Bx();
        i = At.getUint16(X), X += 2;
        break;
      case 26:
        if (a == 7) {
          let l = At.getFloat32(X);
          if (we.useFloat32 > 2) {
            let r = Yf[(se[X] & 127) << 1 | se[X + 1] >> 7];
            return X += 4, (r * l + (l > 0 ? 0.5 : -0.5) >> 0) / r;
          }
          return X += 4, l;
        }
        i = At.getUint32(X), X += 4;
        break;
      case 27:
        if (a == 7) {
          let l = At.getFloat64(X);
          return X += 8, l;
        }
        if (a > 1) {
          if (At.getUint32(X) > 0) throw new Error("JavaScript does not support arrays, maps, or strings with length over 4294967295");
          i = At.getUint32(X + 4);
        } else we.int64AsNumber ? (i = At.getUint32(X) * 4294967296, i += At.getUint32(X + 4)) : i = At.getBigUint64(X);
        X += 8;
        break;
      case 31:
        switch (a) {
          case 2:
          case 3:
            throw new Error("Indefinite length not supported for byte or text strings");
          case 4:
            let l = [], r, c = 0;
            for (; (r = Ce()) != Yi; ) {
              if (c >= il) throw new Error(`Array length exceeds ${il}`);
              l[c++] = r;
            }
            return a == 4 ? l : a == 3 ? l.join("") : Buffer.concat(l);
          case 5:
            let f;
            if (we.mapsAsObjects) {
              let d = {}, h = 0;
              if (we.keyMap) for (; (f = Ce()) != Yi; ) {
                if (h++ >= Gn) throw new Error(`Property count exceeds ${Gn}`);
                d[en(we.decodeKey(f))] = Ce();
              }
              else for (; (f = Ce()) != Yi; ) {
                if (h++ >= Gn) throw new Error(`Property count exceeds ${Gn}`);
                d[en(f)] = Ce();
              }
              return d;
            } else {
              ol && (we.mapsAsObjects = true, ol = false);
              let d = /* @__PURE__ */ new Map();
              if (we.keyMap) {
                let h = 0;
                for (; (f = Ce()) != Yi; ) {
                  if (h++ >= Gn) throw new Error(`Map size exceeds ${Gn}`);
                  d.set(we.decodeKey(f), Ce());
                }
              } else {
                let h = 0;
                for (; (f = Ce()) != Yi; ) {
                  if (h++ >= Gn) throw new Error(`Map size exceeds ${Gn}`);
                  d.set(f, Ce());
                }
              }
              return d;
            }
          case 7:
            return Yi;
          default:
            throw new Error("Invalid major type for indefinite length " + a);
        }
      default:
        throw new Error("Unknown token " + i);
    }
    switch (a) {
      case 0:
        return i;
      case 1:
        return ~i;
      case 2:
        return kx(i);
      case 3:
        if (dl >= X) return Wr.slice(X - Pr, (X += i) - Pr);
        if (dl == 0 && Ia < 140 && i < 32) {
          let c = i < 16 ? gp(i) : zx(i);
          if (c != null) return c;
        }
        return Ux(i);
      case 4:
        if (i >= il) throw new Error(`Array length exceeds ${il}`);
        let l = new Array(i);
        for (let c = 0; c < i; c++) l[c] = Ce();
        return l;
      case 5:
        if (i >= Gn) throw new Error(`Map size exceeds ${il}`);
        if (we.mapsAsObjects) {
          let c = {};
          if (we.keyMap) for (let f = 0; f < i; f++) c[en(we.decodeKey(Ce()))] = Ce();
          else for (let f = 0; f < i; f++) c[en(Ce())] = Ce();
          return c;
        } else {
          ol && (we.mapsAsObjects = true, ol = false);
          let c = /* @__PURE__ */ new Map();
          if (we.keyMap) for (let f = 0; f < i; f++) c.set(we.decodeKey(Ce()), Ce());
          else for (let f = 0; f < i; f++) c.set(Ce(), Ce());
          return c;
        }
      case 6:
        if (i >= sy) {
          let c = Ze[i & 8191];
          if (c) return c.read || (c.read = lf(c)), c.read();
          if (i < 65536) {
            if (i == Dx) {
              let f = Ki(), d = Ce(), h = Ce();
              of(d, h);
              let g = {};
              if (we.keyMap) for (let y = 2; y < f; y++) {
                let p = we.decodeKey(h[y - 2]);
                g[en(p)] = Ce();
              }
              else for (let y = 2; y < f; y++) {
                let p = h[y - 2];
                g[en(p)] = Ce();
              }
              return g;
            } else if (i == Mx) {
              let f = Ki(), d = Ce();
              for (let h = 2; h < f; h++) of(d++, Ce());
              return Ce();
            } else if (i == sy) return Vx();
            if (we.getShared && (qf(), c = Ze[i & 8191], c)) return c.read || (c.read = lf(c)), c.read();
          }
        }
        let r = et[i];
        if (r) return r.handlesRead ? r(Ce) : r(Ce());
        {
          let c = Ce();
          for (let f = 0; f < sf.length; f++) {
            let d = sf[f](i, c);
            if (d !== void 0) return d;
          }
          return new ei(c, i);
        }
      case 7:
        switch (i) {
          case 20:
            return false;
          case 21:
            return true;
          case 22:
            return null;
          case 23:
            return;
          case 31:
          default:
            let c = (Rt || Za())[i];
            if (c !== void 0) return c;
            throw new Error("Unknown token " + i);
        }
      default:
        if (isNaN(i)) {
          let c = new Error("Unexpected end of CBOR data");
          throw c.incomplete = true, c;
        }
        throw new Error("Unknown CBOR token " + i);
    }
  }
  const oy = /^[a-zA-Z_$][a-zA-Z\d_$]*$/;
  function lf(i) {
    if (!i) throw new Error("Structure is required in record definition");
    function a() {
      let l = se[X++];
      if (l = l & 31, l > 23) switch (l) {
        case 24:
          l = se[X++];
          break;
        case 25:
          l = At.getUint16(X), X += 2;
          break;
        case 26:
          l = At.getUint32(X), X += 4;
          break;
        default:
          throw new Error("Expected array header, but got " + se[X - 1]);
      }
      let r = this.compiledReader;
      for (; r; ) {
        if (r.propertyCount === l) return r(Ce);
        r = r.next;
      }
      if (this.slowReads++ >= pp) {
        let f = this.length == l ? this : this.slice(0, l);
        return r = we.keyMap ? new Function("r", "return {" + f.map((d) => we.decodeKey(d)).map((d) => oy.test(d) ? en(d) + ":r()" : "[" + JSON.stringify(d) + "]:r()").join(",") + "}") : new Function("r", "return {" + f.map((d) => oy.test(d) ? en(d) + ":r()" : "[" + JSON.stringify(d) + "]:r()").join(",") + "}"), this.compiledReader && (r.next = this.compiledReader), r.propertyCount = l, this.compiledReader = r, r(Ce);
      }
      let c = {};
      if (we.keyMap) for (let f = 0; f < l; f++) c[en(we.decodeKey(this[f]))] = Ce();
      else for (let f = 0; f < l; f++) c[en(this[f])] = Ce();
      return c;
    }
    return i.slowReads = 0, a;
  }
  function en(i) {
    if (typeof i == "string") return i === "__proto__" ? "__proto_" : i;
    if (typeof i == "number" || typeof i == "boolean" || typeof i == "bigint") return i.toString();
    if (i == null) return i + "";
    throw new Error("Invalid property name type " + typeof i);
  }
  let Ux = rf;
  function rf(i) {
    let a;
    if (i < 16 && (a = gp(i))) return a;
    if (i > 64 && af) return af.decode(se.subarray(X, X += i));
    const l = X + i, r = [];
    for (a = ""; X < l; ) {
      const c = se[X++];
      if ((c & 128) === 0) r.push(c);
      else if ((c & 224) === 192) {
        const f = se[X++] & 63;
        r.push((c & 31) << 6 | f);
      } else if ((c & 240) === 224) {
        const f = se[X++] & 63, d = se[X++] & 63;
        r.push((c & 31) << 12 | f << 6 | d);
      } else if ((c & 248) === 240) {
        const f = se[X++] & 63, d = se[X++] & 63, h = se[X++] & 63;
        let g = (c & 7) << 18 | f << 12 | d << 6 | h;
        g > 65535 && (g -= 65536, r.push(g >>> 10 & 1023 | 55296), g = 56320 | g & 1023), r.push(g);
      } else r.push(c);
      r.length >= 4096 && (a += ht.apply(String, r), r.length = 0);
    }
    return r.length > 0 && (a += ht.apply(String, r)), a;
  }
  let ht = String.fromCharCode;
  function zx(i) {
    let a = X, l = new Array(i);
    for (let r = 0; r < i; r++) {
      const c = se[X++];
      if ((c & 128) > 0) {
        X = a;
        return;
      }
      l[r] = c;
    }
    return ht.apply(String, l);
  }
  function gp(i) {
    if (i < 4) if (i < 2) {
      if (i === 0) return "";
      {
        let a = se[X++];
        if ((a & 128) > 1) {
          X -= 1;
          return;
        }
        return ht(a);
      }
    } else {
      let a = se[X++], l = se[X++];
      if ((a & 128) > 0 || (l & 128) > 0) {
        X -= 2;
        return;
      }
      if (i < 3) return ht(a, l);
      let r = se[X++];
      if ((r & 128) > 0) {
        X -= 3;
        return;
      }
      return ht(a, l, r);
    }
    else {
      let a = se[X++], l = se[X++], r = se[X++], c = se[X++];
      if ((a & 128) > 0 || (l & 128) > 0 || (r & 128) > 0 || (c & 128) > 0) {
        X -= 4;
        return;
      }
      if (i < 6) {
        if (i === 4) return ht(a, l, r, c);
        {
          let f = se[X++];
          if ((f & 128) > 0) {
            X -= 5;
            return;
          }
          return ht(a, l, r, c, f);
        }
      } else if (i < 8) {
        let f = se[X++], d = se[X++];
        if ((f & 128) > 0 || (d & 128) > 0) {
          X -= 6;
          return;
        }
        if (i < 7) return ht(a, l, r, c, f, d);
        let h = se[X++];
        if ((h & 128) > 0) {
          X -= 7;
          return;
        }
        return ht(a, l, r, c, f, d, h);
      } else {
        let f = se[X++], d = se[X++], h = se[X++], g = se[X++];
        if ((f & 128) > 0 || (d & 128) > 0 || (h & 128) > 0 || (g & 128) > 0) {
          X -= 8;
          return;
        }
        if (i < 10) {
          if (i === 8) return ht(a, l, r, c, f, d, h, g);
          {
            let y = se[X++];
            if ((y & 128) > 0) {
              X -= 9;
              return;
            }
            return ht(a, l, r, c, f, d, h, g, y);
          }
        } else if (i < 12) {
          let y = se[X++], p = se[X++];
          if ((y & 128) > 0 || (p & 128) > 0) {
            X -= 10;
            return;
          }
          if (i < 11) return ht(a, l, r, c, f, d, h, g, y, p);
          let b = se[X++];
          if ((b & 128) > 0) {
            X -= 11;
            return;
          }
          return ht(a, l, r, c, f, d, h, g, y, p, b);
        } else {
          let y = se[X++], p = se[X++], b = se[X++], S = se[X++];
          if ((y & 128) > 0 || (p & 128) > 0 || (b & 128) > 0 || (S & 128) > 0) {
            X -= 12;
            return;
          }
          if (i < 14) {
            if (i === 12) return ht(a, l, r, c, f, d, h, g, y, p, b, S);
            {
              let x = se[X++];
              if ((x & 128) > 0) {
                X -= 13;
                return;
              }
              return ht(a, l, r, c, f, d, h, g, y, p, b, S, x);
            }
          } else {
            let x = se[X++], v = se[X++];
            if ((x & 128) > 0 || (v & 128) > 0) {
              X -= 14;
              return;
            }
            if (i < 15) return ht(a, l, r, c, f, d, h, g, y, p, b, S, x, v);
            let A = se[X++];
            if ((A & 128) > 0) {
              X -= 15;
              return;
            }
            return ht(a, l, r, c, f, d, h, g, y, p, b, S, x, v, A);
          }
        }
      }
    }
  }
  function kx(i) {
    return we.copyBuffers ? Uint8Array.prototype.slice.call(se, X, X += i) : se.subarray(X, X += i);
  }
  let bp = new Float32Array(1), kr = new Uint8Array(bp.buffer, 0, 4);
  function Bx() {
    let i = se[X++], a = se[X++], l = (i & 127) >> 2;
    if (l === 31) return a || i & 3 ? NaN : i & 128 ? -1 / 0 : 1 / 0;
    if (l === 0) {
      let r = ((i & 3) << 8 | a) / 16777216;
      return i & 128 ? -r : r;
    }
    return kr[3] = i & 128 | (l >> 1) + 56, kr[2] = (i & 7) << 5 | a >> 3, kr[1] = a << 5, kr[0] = 0, bp[0];
  }
  new Array(4096);
  let ei = class {
    constructor(a, l) {
      this.value = a, this.tag = l;
    }
  };
  et[0] = (i) => new Date(i);
  et[1] = (i) => new Date(Math.round(i * 1e3));
  et[2] = (i) => {
    let a = BigInt(0);
    for (let l = 0, r = i.byteLength; l < r; l++) a = BigInt(i[l]) + (a << BigInt(8));
    return a;
  };
  et[3] = (i) => BigInt(-1) - et[2](i);
  et[4] = (i) => +(i[1] + "e" + i[0]);
  et[5] = (i) => i[1] * Math.exp(i[0] * Math.log(2));
  const of = (i, a) => {
    i = i - 57344;
    let l = Ze[i];
    l && l.isShared && ((Ze.restoreStructures || (Ze.restoreStructures = []))[i] = l), Ze[i] = a, a.read = lf(a);
  };
  et[jx] = (i) => {
    let a = i.length, l = i[1];
    of(i[0], l);
    let r = {};
    for (let c = 2; c < a; c++) {
      let f = l[c - 2];
      r[en(f)] = i[c];
    }
    return r;
  };
  et[14] = (i) => ot ? ot[0].slice(ot.position0, ot.position0 += i) : new ei(i, 14);
  et[15] = (i) => ot ? ot[1].slice(ot.position1, ot.position1 += i) : new ei(i, 15);
  let Hx = {
    Error,
    RegExp
  };
  et[27] = (i) => (Hx[i[0]] || Error)(i[1], i[2]);
  const vp = (i) => {
    if (se[X++] != 132) {
      let l = new Error("Packed values structure must be followed by a 4 element array");
      throw se.length < X && (l.incomplete = true), l;
    }
    let a = i();
    if (!a || !a.length) {
      let l = new Error("Packed values structure must be followed by a 4 element array");
      throw l.incomplete = true, l;
    }
    return Rt = Rt ? a.concat(Rt.slice(a.length)) : a, Rt.prefixes = i(), Rt.suffixes = i(), i();
  };
  vp.handlesRead = true;
  et[51] = vp;
  et[ly] = (i) => {
    if (!Rt) if (we.getShared) qf();
    else return new ei(i, ly);
    if (typeof i == "number") return Rt[16 + (i >= 0 ? 2 * i : -2 * i - 1)];
    let a = new Error("No support for non-integer packed references yet");
    throw i === void 0 && (a.incomplete = true), a;
  };
  et[28] = (i) => {
    Pt || (Pt = /* @__PURE__ */ new Map(), Pt.id = 0);
    let a = Pt.id++, l = X, r = se[X], c;
    r >> 5 == 4 ? c = [] : c = {};
    let f = {
      target: c
    };
    Pt.set(a, f);
    let d = i();
    return f.used ? (Object.getPrototypeOf(c) !== Object.getPrototypeOf(d) && (X = l, c = d, Pt.set(a, {
      target: c
    }), d = i()), Object.assign(c, d)) : (f.target = d, d);
  };
  et[28].handlesRead = true;
  et[29] = (i) => {
    let a = Pt.get(i);
    return a.used = true, a.target;
  };
  et[258] = (i) => new Set(i);
  (et[259] = (i) => (we.mapsAsObjects && (we.mapsAsObjects = false, ol = true), i())).handlesRead = true;
  function Gi(i, a) {
    return typeof i == "string" ? i + a : i instanceof Array ? i.concat(a) : Object.assign({}, i, a);
  }
  function Za() {
    if (!Rt) if (we.getShared) qf();
    else throw new Error("No packed values available");
    return Rt;
  }
  const Lx = 1399353956;
  sf.push((i, a) => {
    if (i >= 225 && i <= 255) return Gi(Za().prefixes[i - 224], a);
    if (i >= 28704 && i <= 32767) return Gi(Za().prefixes[i - 28672], a);
    if (i >= 1879052288 && i <= 2147483647) return Gi(Za().prefixes[i - 1879048192], a);
    if (i >= 216 && i <= 223) return Gi(a, Za().suffixes[i - 216]);
    if (i >= 27647 && i <= 28671) return Gi(a, Za().suffixes[i - 27639]);
    if (i >= 1811940352 && i <= 1879048191) return Gi(a, Za().suffixes[i - 1811939328]);
    if (i == Lx) return {
      packedValues: Rt,
      structures: Ze.slice(0),
      version: a
    };
    if (i == 55799) return a;
  });
  const qx = new Uint8Array(new Uint16Array([
    1
  ]).buffer)[0] == 1, cy = [
    Uint8Array,
    Uint8ClampedArray,
    Uint16Array,
    Uint32Array,
    typeof BigUint64Array > "u" ? {
      name: "BigUint64Array"
    } : BigUint64Array,
    Int8Array,
    Int16Array,
    Int32Array,
    typeof BigInt64Array > "u" ? {
      name: "BigInt64Array"
    } : BigInt64Array,
    Float32Array,
    Float64Array
  ], Yx = [
    64,
    68,
    69,
    70,
    71,
    72,
    77,
    78,
    79,
    85,
    86
  ];
  for (let i = 0; i < cy.length; i++) Gx(cy[i], Yx[i]);
  function Gx(i, a) {
    let l = "get" + i.name.slice(0, -5), r;
    typeof i == "function" ? r = i.BYTES_PER_ELEMENT : i = null;
    for (let c = 0; c < 2; c++) {
      if (!c && r == 1) continue;
      let f = r == 2 ? 1 : r == 4 ? 2 : r == 8 ? 3 : 0;
      et[c ? a : a - 4] = r == 1 || c == qx ? (d) => {
        if (!i) throw new Error("Could not find typed array for code " + a);
        return !we.copyBuffers && (r === 1 || r === 2 && !(d.byteOffset & 1) || r === 4 && !(d.byteOffset & 3) || r === 8 && !(d.byteOffset & 7)) ? new i(d.buffer, d.byteOffset, d.byteLength >> f) : new i(Uint8Array.prototype.slice.call(d, 0).buffer);
      } : (d) => {
        if (!i) throw new Error("Could not find typed array for code " + a);
        let h = new DataView(d.buffer, d.byteOffset, d.byteLength), g = d.length >> f, y = new i(g), p = h[l];
        for (let b = 0; b < g; b++) y[b] = p.call(h, b << f, c);
        return y;
      };
    }
  }
  function Vx() {
    let i = Ki(), a = X + Ce();
    for (let r = 2; r < i; r++) {
      let c = Ki();
      X += c;
    }
    let l = X;
    return X = a, ot = [
      rf(Ki()),
      rf(Ki())
    ], ot.position0 = 0, ot.position1 = 0, ot.postBundlePosition = X, X = l, Ce();
  }
  function Ki() {
    let i = se[X++] & 31;
    if (i > 23) switch (i) {
      case 24:
        i = se[X++];
        break;
      case 25:
        i = At.getUint16(X), X += 2;
        break;
      case 26:
        i = At.getUint32(X), X += 4;
        break;
    }
    return i;
  }
  function qf() {
    if (we.getShared) {
      let i = xp(() => (se = null, we.getShared())) || {}, a = i.structures || [];
      we.sharedVersion = i.version, Rt = we.sharedValues = i.packedValues, Ze === true ? we.structures = Ze = a : Ze.splice.apply(Ze, [
        0,
        a.length
      ].concat(a));
    }
  }
  function xp(i) {
    let a = Ia, l = X, r = Pr, c = dl, f = Wr, d = Pt, h = ot, g = new Uint8Array(se.slice(0, Ia)), y = Ze, p = we, b = hl, S = i();
    return Ia = a, X = l, Pr = r, dl = c, Wr = f, Pt = d, ot = h, se = g, hl = b, Ze = y, we = p, At = new DataView(se.buffer, se.byteOffset, se.byteLength), S;
  }
  function cf() {
    se = null, Pt = null, Ze = null;
  }
  const Yf = new Array(147);
  for (let i = 0; i < 256; i++) Yf[i] = +("1e" + Math.floor(45.15 - i * 0.30103));
  let Gf = new ml({
    useRecords: false
  });
  const Sp = Gf.decode;
  Gf.decodeMultiple;
  let Gr;
  try {
    Gr = new TextEncoder();
  } catch {
  }
  let uf, wp;
  const so = typeof globalThis == "object" && globalThis.Buffer, vl = typeof so < "u", ku = vl ? so.allocUnsafeSlow : Uint8Array, uy = vl ? so : Uint8Array, fy = 256, dy = vl ? 4294967296 : 2144337920;
  let Bu, z, He, C = 0, xa, lt = null;
  const Xx = 61440, Fx = /[\u0080-\uFFFF]/, Lt = Symbol("record-id");
  class Ep extends ml {
    constructor(a) {
      super(a), this.offset = 0;
      let l, r, c, f, d;
      a = a || {};
      let h = uy.prototype.utf8Write ? function(O, Q, Y) {
        return z.utf8Write(O, Q, Y);
      } : Gr && Gr.encodeInto ? function(O, Q) {
        return Gr.encodeInto(O, z.subarray(Q)).written;
      } : false, g = this, y = a.structures || a.saveStructures, p = a.maxSharedStructures;
      if (p == null && (p = y ? 128 : 0), p > 8190) throw new Error("Maximum maxSharedStructure is 8190");
      let b = a.sequential;
      b && (p = 0), this.structures || (this.structures = []), this.saveStructures && (this.saveShared = this.saveStructures);
      let S, x, v = a.sharedValues, A;
      if (v) {
        A = /* @__PURE__ */ Object.create(null);
        for (let O = 0, Q = v.length; O < Q; O++) A[v[O]] = O;
      }
      let j = [], L = 0, B = 0;
      this.mapEncode = function(O, Q) {
        if (this._keyMap && !this._mapped) switch (O.constructor.name) {
          case "Array":
            O = O.map((Y) => this.encodeKeys(Y));
            break;
        }
        return this.encode(O, Q);
      }, this.encode = function(O, Q) {
        if (z || (z = new ku(8192), He = new DataView(z.buffer, 0, 8192), C = 0), xa = z.length - 10, xa - C < 2048 ? (z = new ku(z.length), He = new DataView(z.buffer, 0, z.length), xa = z.length - 10, C = 0) : Q === yy && (C = C + 7 & 2147483640), l = C, g.useSelfDescribedHeader && (He.setUint32(C, 3654940416), C += 3), d = g.structuredClone ? /* @__PURE__ */ new Map() : null, g.bundleStrings && typeof O != "string" ? (lt = [], lt.size = 1 / 0) : lt = null, r = g.structures, r) {
          if (r.uninitialized) {
            let R = g.getShared() || {};
            g.structures = r = R.structures || [], g.sharedVersion = R.version;
            let k = g.sharedValues = R.packedValues;
            if (k) {
              A = {};
              for (let J = 0, ne = k.length; J < ne; J++) A[k[J]] = J;
            }
          }
          let Y = r.length;
          if (Y > p && !b && (Y = p), !r.transitions) {
            r.transitions = /* @__PURE__ */ Object.create(null);
            for (let R = 0; R < Y; R++) {
              let k = r[R];
              if (!k) continue;
              let J, ne = r.transitions;
              for (let te = 0, de = k.length; te < de; te++) {
                ne[Lt] === void 0 && (ne[Lt] = R);
                let me = k[te];
                J = ne[me], J || (J = ne[me] = /* @__PURE__ */ Object.create(null)), ne = J;
              }
              ne[Lt] = R | 1048576;
            }
          }
          b || (r.nextId = Y);
        }
        if (c && (c = false), f = r || [], x = A, a.pack) {
          let Y = /* @__PURE__ */ new Map();
          if (Y.values = [], Y.encoder = g, Y.maxValues = a.maxPrivatePackedValues || (A ? 16 : 1 / 0), Y.objectMap = A || false, Y.samplingPackedValues = S, Vr(O, Y), Y.values.length > 0) {
            z[C++] = 216, z[C++] = 51, bn(4);
            let R = Y.values;
            D(R), bn(0), bn(0), x = Object.create(A || null);
            for (let k = 0, J = R.length; k < J; k++) x[R[k]] = k;
          }
        }
        Bu = Q & Lu;
        try {
          if (Bu) return;
          if (D(O), lt && my(l, D), g.offset = C, d && d.idsToInsert) {
            C += d.idsToInsert.length * 2, C > xa && ee(C), g.offset = C;
            let Y = Kx(z.subarray(l, C), d.idsToInsert);
            return d = null, Y;
          }
          return Q & yy ? (z.start = l, z.end = C, z) : z.subarray(l, C);
        } finally {
          if (r) {
            if (B < 10 && B++, r.length > p && (r.length = p), L > 1e4) r.transitions = null, B = 0, L = 0, j.length > 0 && (j = []);
            else if (j.length > 0 && !b) {
              for (let Y = 0, R = j.length; Y < R; Y++) j[Y][Lt] = void 0;
              j = [];
            }
          }
          if (c && g.saveShared) {
            g.structures.length > p && (g.structures = g.structures.slice(0, p));
            let Y = z.subarray(l, C);
            return g.updateSharedData() === false ? g.encode(O) : Y;
          }
          Q & $x && (C = l);
        }
      }, this.findCommonStringsToPack = () => (S = /* @__PURE__ */ new Map(), A || (A = /* @__PURE__ */ Object.create(null)), (O) => {
        let Q = O && O.threshold || 4, Y = this.pack ? O.maxPrivatePackedValues || 16 : 0;
        v || (v = this.sharedValues = []);
        for (let [R, k] of S) k.count > Q && (A[R] = Y++, v.push(R), c = true);
        for (; this.saveShared && this.updateSharedData() === false; ) ;
        S = null;
      });
      const D = (O) => {
        C > xa && (z = ee(C));
        var Q = typeof O, Y;
        if (Q === "string") {
          if (x) {
            let ne = x[O];
            if (ne >= 0) {
              ne < 16 ? z[C++] = ne + 224 : (z[C++] = 198, ne & 1 ? D(15 - ne >> 1) : D(ne - 16 >> 1));
              return;
            } else if (S && !a.pack) {
              let te = S.get(O);
              te ? te.count++ : S.set(O, {
                count: 1
              });
            }
          }
          let R = O.length;
          if (lt && R >= 4 && R < 1024) {
            if ((lt.size += R) > Xx) {
              let te, de = (lt[0] ? lt[0].length * 3 + lt[1].length : 0) + 10;
              C + de > xa && (z = ee(C + de)), z[C++] = 217, z[C++] = 223, z[C++] = 249, z[C++] = lt.position ? 132 : 130, z[C++] = 26, te = C - l, C += 4, lt.position && my(l, D), lt = [
                "",
                ""
              ], lt.size = 0, lt.position = te;
            }
            let ne = Fx.test(O);
            lt[ne ? 0 : 1] += O, z[C++] = ne ? 206 : 207, D(R);
            return;
          }
          let k;
          R < 32 ? k = 1 : R < 256 ? k = 2 : R < 65536 ? k = 3 : k = 5;
          let J = R * 3;
          if (C + J > xa && (z = ee(C + J)), R < 64 || !h) {
            let ne, te, de, me = C + k;
            for (ne = 0; ne < R; ne++) te = O.charCodeAt(ne), te < 128 ? z[me++] = te : te < 2048 ? (z[me++] = te >> 6 | 192, z[me++] = te & 63 | 128) : (te & 64512) === 55296 && ((de = O.charCodeAt(ne + 1)) & 64512) === 56320 ? (te = 65536 + ((te & 1023) << 10) + (de & 1023), ne++, z[me++] = te >> 18 | 240, z[me++] = te >> 12 & 63 | 128, z[me++] = te >> 6 & 63 | 128, z[me++] = te & 63 | 128) : (z[me++] = te >> 12 | 224, z[me++] = te >> 6 & 63 | 128, z[me++] = te & 63 | 128);
            Y = me - C - k;
          } else Y = h(O, C + k, J);
          Y < 24 ? z[C++] = 96 | Y : Y < 256 ? (k < 2 && z.copyWithin(C + 2, C + 1, C + 1 + Y), z[C++] = 120, z[C++] = Y) : Y < 65536 ? (k < 3 && z.copyWithin(C + 3, C + 2, C + 2 + Y), z[C++] = 121, z[C++] = Y >> 8, z[C++] = Y & 255) : (k < 5 && z.copyWithin(C + 5, C + 3, C + 3 + Y), z[C++] = 122, He.setUint32(C, Y), C += 4), C += Y;
        } else if (Q === "number") if (!this.alwaysUseFloat && O >>> 0 === O) O < 24 ? z[C++] = O : O < 256 ? (z[C++] = 24, z[C++] = O) : O < 65536 ? (z[C++] = 25, z[C++] = O >> 8, z[C++] = O & 255) : (z[C++] = 26, He.setUint32(C, O), C += 4);
        else if (!this.alwaysUseFloat && O >> 0 === O) O >= -24 ? z[C++] = 31 - O : O >= -256 ? (z[C++] = 56, z[C++] = ~O) : O >= -65536 ? (z[C++] = 57, He.setUint16(C, ~O), C += 2) : (z[C++] = 58, He.setUint32(C, ~O), C += 4);
        else {
          let R;
          if ((R = this.useFloat32) > 0 && O < 4294967296 && O >= -2147483648) {
            z[C++] = 250, He.setFloat32(C, O);
            let k;
            if (R < 4 || (k = O * Yf[(z[C] & 127) << 1 | z[C + 1] >> 7]) >> 0 === k) {
              C += 4;
              return;
            } else C--;
          }
          z[C++] = 251, He.setFloat64(C, O), C += 8;
        }
        else if (Q === "object") if (!O) z[C++] = 246;
        else {
          if (d) {
            let k = d.get(O);
            if (k) {
              if (z[C++] = 216, z[C++] = 29, z[C++] = 25, !k.references) {
                let J = d.idsToInsert || (d.idsToInsert = []);
                k.references = [], J.push(k);
              }
              k.references.push(C - l), C += 2;
              return;
            } else d.set(O, {
              offset: C - l
            });
          }
          let R = O.constructor;
          if (R === Object) I(O);
          else if (R === Array) {
            Y = O.length, Y < 24 ? z[C++] = 128 | Y : bn(Y);
            for (let k = 0; k < Y; k++) D(O[k]);
          } else if (R === Map) if ((this.mapsAsObjects ? this.useTag259ForMaps !== false : this.useTag259ForMaps) && (z[C++] = 217, z[C++] = 1, z[C++] = 3), Y = O.size, Y < 24 ? z[C++] = 160 | Y : Y < 256 ? (z[C++] = 184, z[C++] = Y) : Y < 65536 ? (z[C++] = 185, z[C++] = Y >> 8, z[C++] = Y & 255) : (z[C++] = 186, He.setUint32(C, Y), C += 4), g.keyMap) for (let [k, J] of O) D(g.encodeKey(k)), D(J);
          else for (let [k, J] of O) D(k), D(J);
          else {
            for (let k = 0, J = uf.length; k < J; k++) {
              let ne = wp[k];
              if (O instanceof ne) {
                let te = uf[k], de = te.tag;
                de == null && (de = te.getTag && te.getTag.call(this, O)), de < 24 ? z[C++] = 192 | de : de < 256 ? (z[C++] = 216, z[C++] = de) : de < 65536 ? (z[C++] = 217, z[C++] = de >> 8, z[C++] = de & 255) : de > -1 && (z[C++] = 218, He.setUint32(C, de), C += 4), te.encode.call(this, O, D, ee);
                return;
              }
            }
            if (O[Symbol.iterator]) {
              if (Bu) {
                let k = new Error("Iterable should be serialized as iterator");
                throw k.iteratorNotHandled = true, k;
              }
              z[C++] = 159;
              for (let k of O) D(k);
              z[C++] = 255;
              return;
            }
            if (O[Symbol.asyncIterator] || Hu(O)) {
              let k = new Error("Iterable/blob should be serialized as iterator");
              throw k.iteratorNotHandled = true, k;
            }
            if (this.useToJSON && O.toJSON) {
              const k = O.toJSON();
              if (k !== O) return D(k);
            }
            I(O);
          }
        }
        else if (Q === "boolean") z[C++] = O ? 245 : 244;
        else if (Q === "bigint") {
          if (O < BigInt(1) << BigInt(64) && O >= 0) z[C++] = 27, He.setBigUint64(C, O);
          else if (O > -(BigInt(1) << BigInt(64)) && O < 0) z[C++] = 59, He.setBigUint64(C, -O - BigInt(1));
          else if (this.largeBigIntToFloat) z[C++] = 251, He.setFloat64(C, Number(O));
          else {
            O >= BigInt(0) ? z[C++] = 194 : (z[C++] = 195, O = BigInt(-1) - O);
            let R = [];
            for (; O; ) R.push(Number(O & BigInt(255))), O >>= BigInt(8);
            ff(new Uint8Array(R.reverse()), ee);
            return;
          }
          C += 8;
        } else if (Q === "undefined") z[C++] = 247;
        else throw new Error("Unknown type: " + Q);
      }, I = this.useRecords === false ? this.variableMapSize ? (O) => {
        let Q = Object.keys(O), Y = Object.values(O), R = Q.length;
        if (R < 24 ? z[C++] = 160 | R : R < 256 ? (z[C++] = 184, z[C++] = R) : R < 65536 ? (z[C++] = 185, z[C++] = R >> 8, z[C++] = R & 255) : (z[C++] = 186, He.setUint32(C, R), C += 4), g.keyMap) for (let k = 0; k < R; k++) D(g.encodeKey(Q[k])), D(Y[k]);
        else for (let k = 0; k < R; k++) D(Q[k]), D(Y[k]);
      } : (O) => {
        z[C++] = 185;
        let Q = C - l;
        C += 2;
        let Y = 0;
        if (g.keyMap) for (let R in O) (typeof O.hasOwnProperty != "function" || O.hasOwnProperty(R)) && (D(g.encodeKey(R)), D(O[R]), Y++);
        else for (let R in O) (typeof O.hasOwnProperty != "function" || O.hasOwnProperty(R)) && (D(R), D(O[R]), Y++);
        z[Q++ + l] = Y >> 8, z[Q + l] = Y & 255;
      } : (O, Q) => {
        let Y, R = f.transitions || (f.transitions = /* @__PURE__ */ Object.create(null)), k = 0, J = 0, ne, te;
        if (this.keyMap) {
          te = Object.keys(O).map((me) => this.encodeKey(me)), J = te.length;
          for (let me = 0; me < J; me++) {
            let gt = te[me];
            Y = R[gt], Y || (Y = R[gt] = /* @__PURE__ */ Object.create(null), k++), R = Y;
          }
        } else for (let me in O) (typeof O.hasOwnProperty != "function" || O.hasOwnProperty(me)) && (Y = R[me], Y || (R[Lt] & 1048576 && (ne = R[Lt] & 65535), Y = R[me] = /* @__PURE__ */ Object.create(null), k++), R = Y, J++);
        let de = R[Lt];
        if (de !== void 0) de &= 65535, z[C++] = 217, z[C++] = de >> 8 | 224, z[C++] = de & 255;
        else if (te || (te = R.__keys__ || (R.__keys__ = Object.keys(O))), ne === void 0 ? (de = f.nextId++, de || (de = 0, f.nextId = 1), de >= fy && (f.nextId = (de = p) + 1)) : de = ne, f[de] = te, de < p) {
          z[C++] = 217, z[C++] = de >> 8 | 224, z[C++] = de & 255, R = f.transitions;
          for (let me = 0; me < J; me++) (R[Lt] === void 0 || R[Lt] & 1048576) && (R[Lt] = de), R = R[te[me]];
          R[Lt] = de | 1048576, c = true;
        } else {
          if (R[Lt] = de, He.setUint32(C, 3655335680), C += 3, k && (L += B * k), j.length >= fy - p && (j.shift()[Lt] = void 0), j.push(R), bn(J + 2), D(57344 + de), D(te), Q) return;
          for (let me in O) (typeof O.hasOwnProperty != "function" || O.hasOwnProperty(me)) && D(O[me]);
          return;
        }
        if (J < 24 ? z[C++] = 128 | J : bn(J), !Q) for (let me in O) (typeof O.hasOwnProperty != "function" || O.hasOwnProperty(me)) && D(O[me]);
      }, ee = (O) => {
        let Q;
        if (O > 16777216) {
          if (O - l > dy) throw new Error("Encoded buffer would be larger than maximum buffer size");
          Q = Math.min(dy, Math.round(Math.max((O - l) * (O > 67108864 ? 1.25 : 2), 4194304) / 4096) * 4096);
        } else Q = (Math.max(O - l << 2, z.length - 1) >> 12) + 1 << 12;
        let Y = new ku(Q);
        return He = new DataView(Y.buffer, 0, Q), z.copy ? z.copy(Y, 0, l, O) : Y.set(z.slice(l, O)), C -= l, l = 0, xa = Y.length - 10, z = Y;
      };
      let ae = 100, be = 1e3;
      this.encodeAsIterable = function(O, Q) {
        return pe(O, Q, le);
      }, this.encodeAsAsyncIterable = function(O, Q) {
        return pe(O, Q, F);
      };
      function* le(O, Q, Y) {
        let R = O.constructor;
        if (R === Object) {
          let k = g.useRecords !== false;
          k ? I(O, true) : hy(Object.keys(O).length, 160);
          for (let J in O) {
            let ne = O[J];
            k || D(J), ne && typeof ne == "object" ? Q[J] ? yield* le(ne, Q[J]) : yield* W(ne, Q, J) : D(ne);
          }
        } else if (R === Array) {
          let k = O.length;
          bn(k);
          for (let J = 0; J < k; J++) {
            let ne = O[J];
            ne && (typeof ne == "object" || C - l > ae) ? Q.element ? yield* le(ne, Q.element) : yield* W(ne, Q, "element") : D(ne);
          }
        } else if (O[Symbol.iterator] && !O.buffer) {
          z[C++] = 159;
          for (let k of O) k && (typeof k == "object" || C - l > ae) ? Q.element ? yield* le(k, Q.element) : yield* W(k, Q, "element") : D(k);
          z[C++] = 255;
        } else Hu(O) ? (hy(O.size, 64), yield z.subarray(l, C), yield O, P()) : O[Symbol.asyncIterator] ? (z[C++] = 159, yield z.subarray(l, C), yield O, P(), z[C++] = 255) : D(O);
        Y && C > l ? yield z.subarray(l, C) : C - l > ae && (yield z.subarray(l, C), P());
      }
      function* W(O, Q, Y) {
        let R = C - l;
        try {
          D(O), C - l > ae && (yield z.subarray(l, C), P());
        } catch (k) {
          if (k.iteratorNotHandled) Q[Y] = {}, C = l + R, yield* le.call(this, O, Q[Y]);
          else throw k;
        }
      }
      function P() {
        ae = be, g.encode(null, Lu);
      }
      function pe(O, Q, Y) {
        return Q && Q.chunkThreshold ? ae = be = Q.chunkThreshold : ae = 100, O && typeof O == "object" ? (g.encode(null, Lu), Y(O, g.iterateProperties || (g.iterateProperties = {}), true)) : [
          g.encode(O)
        ];
      }
      async function* F(O, Q) {
        for (let Y of le(O, Q, true)) {
          let R = Y.constructor;
          if (R === uy || R === Uint8Array) yield Y;
          else if (Hu(Y)) {
            let k = Y.stream().getReader(), J;
            for (; !(J = await k.read()).done; ) yield J.value;
          } else if (Y[Symbol.asyncIterator]) for await (let k of Y) P(), k ? yield* F(k, Q.async || (Q.async = {})) : yield g.encode(k);
          else yield Y;
        }
      }
    }
    useBuffer(a) {
      z = a, He = new DataView(z.buffer, z.byteOffset, z.byteLength), C = 0;
    }
    clearSharedData() {
      this.structures && (this.structures = []), this.sharedValues && (this.sharedValues = void 0);
    }
    updateSharedData() {
      let a = this.sharedVersion || 0;
      this.sharedVersion = a + 1;
      let l = this.structures.slice(0), r = new Ap(l, this.sharedValues, this.sharedVersion), c = this.saveShared(r, (f) => (f && f.version || 0) == a);
      return c === false ? (r = this.getShared() || {}, this.structures = r.structures || [], this.sharedValues = r.packedValues, this.sharedVersion = r.version, this.structures.nextId = this.structures.length) : l.forEach((f, d) => this.structures[d] = f), c;
    }
  }
  function hy(i, a) {
    i < 24 ? z[C++] = a | i : i < 256 ? (z[C++] = a | 24, z[C++] = i) : i < 65536 ? (z[C++] = a | 25, z[C++] = i >> 8, z[C++] = i & 255) : (z[C++] = a | 26, He.setUint32(C, i), C += 4);
  }
  class Ap {
    constructor(a, l, r) {
      this.structures = a, this.packedValues = l, this.version = r;
    }
  }
  function bn(i) {
    i < 24 ? z[C++] = 128 | i : i < 256 ? (z[C++] = 152, z[C++] = i) : i < 65536 ? (z[C++] = 153, z[C++] = i >> 8, z[C++] = i & 255) : (z[C++] = 154, He.setUint32(C, i), C += 4);
  }
  const Qx = typeof Blob > "u" ? function() {
  } : Blob;
  function Hu(i) {
    if (i instanceof Qx) return true;
    let a = i[Symbol.toStringTag];
    return a === "Blob" || a === "File";
  }
  function Vr(i, a) {
    switch (typeof i) {
      case "string":
        if (i.length > 3) {
          if (a.objectMap[i] > -1 || a.values.length >= a.maxValues) return;
          let r = a.get(i);
          if (r) ++r.count == 2 && a.values.push(i);
          else if (a.set(i, {
            count: 1
          }), a.samplingPackedValues) {
            let c = a.samplingPackedValues.get(i);
            c ? c.count++ : a.samplingPackedValues.set(i, {
              count: 1
            });
          }
        }
        break;
      case "object":
        if (i) if (i instanceof Array) for (let r = 0, c = i.length; r < c; r++) Vr(i[r], a);
        else {
          let r = !a.encoder.useRecords;
          for (var l in i) i.hasOwnProperty(l) && (r && Vr(l, a), Vr(i[l], a));
        }
        break;
      case "function":
        console.log(i);
    }
  }
  const Zx = new Uint8Array(new Uint16Array([
    1
  ]).buffer)[0] == 1;
  wp = [
    Date,
    Set,
    Error,
    RegExp,
    ei,
    ArrayBuffer,
    Uint8Array,
    Uint8ClampedArray,
    Uint16Array,
    Uint32Array,
    typeof BigUint64Array > "u" ? function() {
    } : BigUint64Array,
    Int8Array,
    Int16Array,
    Int32Array,
    typeof BigInt64Array > "u" ? function() {
    } : BigInt64Array,
    Float32Array,
    Float64Array,
    Ap
  ];
  uf = [
    {
      tag: 1,
      encode(i, a) {
        let l = i.getTime() / 1e3;
        (this.useTimestamp32 || i.getMilliseconds() === 0) && l >= 0 && l < 4294967296 ? (z[C++] = 26, He.setUint32(C, l), C += 4) : (z[C++] = 251, He.setFloat64(C, l), C += 8);
      }
    },
    {
      tag: 258,
      encode(i, a) {
        let l = Array.from(i);
        a(l);
      }
    },
    {
      tag: 27,
      encode(i, a) {
        a([
          i.name,
          i.message
        ]);
      }
    },
    {
      tag: 27,
      encode(i, a) {
        a([
          "RegExp",
          i.source,
          i.flags
        ]);
      }
    },
    {
      getTag(i) {
        return i.tag;
      },
      encode(i, a) {
        a(i.value);
      }
    },
    {
      encode(i, a, l) {
        ff(i, l);
      }
    },
    {
      getTag(i) {
        if (i.constructor === Uint8Array && (this.tagUint8Array || vl && this.tagUint8Array !== false)) return 64;
      },
      encode(i, a, l) {
        ff(i, l);
      }
    },
    yn(68, 1),
    yn(69, 2),
    yn(70, 4),
    yn(71, 8),
    yn(72, 1),
    yn(77, 2),
    yn(78, 4),
    yn(79, 8),
    yn(85, 4),
    yn(86, 8),
    {
      encode(i, a) {
        let l = i.packedValues || [], r = i.structures || [];
        if (l.values.length > 0) {
          z[C++] = 216, z[C++] = 51, bn(4);
          let c = l.values;
          a(c), bn(0), bn(0), packedObjectMap = Object.create(sharedPackedObjectMap || null);
          for (let f = 0, d = c.length; f < d; f++) packedObjectMap[c[f]] = f;
        }
        if (r) {
          He.setUint32(C, 3655335424), C += 3;
          let c = r.slice(0);
          c.unshift(57344), c.push(new ei(i.version, 1399353956)), a(c);
        } else a(new ei(i.version, 1399353956));
      }
    }
  ];
  function yn(i, a) {
    return !Zx && a > 1 && (i -= 4), {
      tag: i,
      encode: function(r, c) {
        let f = r.byteLength, d = r.byteOffset || 0, h = r.buffer || r;
        c(vl ? so.from(h, d, f) : new Uint8Array(h, d, f));
      }
    };
  }
  function ff(i, a) {
    let l = i.byteLength;
    l < 24 ? z[C++] = 64 + l : l < 256 ? (z[C++] = 88, z[C++] = l) : l < 65536 ? (z[C++] = 89, z[C++] = l >> 8, z[C++] = l & 255) : (z[C++] = 90, He.setUint32(C, l), C += 4), C + l >= z.length && a(C + l), z.set(i.buffer ? i : new Uint8Array(i), C), C += l;
  }
  function Kx(i, a) {
    let l, r = a.length * 2, c = i.length - r;
    a.sort((f, d) => f.offset > d.offset ? 1 : -1);
    for (let f = 0; f < a.length; f++) {
      let d = a[f];
      d.id = f;
      for (let h of d.references) i[h++] = f >> 8, i[h] = f & 255;
    }
    for (; l = a.pop(); ) {
      let f = l.offset;
      i.copyWithin(f + r, f, c), r -= 2;
      let d = f + r;
      i[d++] = 216, i[d++] = 28, c = f;
    }
    return i;
  }
  function my(i, a) {
    He.setUint32(lt.position + i, C - lt.position - i + 1);
    let l = lt;
    lt = null, a(l[0]), a(l[1]);
  }
  let Vf = new Ep({
    useRecords: false
  });
  Vf.encode;
  Vf.encodeAsIterable;
  Vf.encodeAsAsyncIterable;
  const yy = 512, $x = 1024, Lu = 2048;
  function Tp(i) {
    return new Ep({
      tagUint8Array: false,
      useRecords: false
    }).encode(i);
  }
  function Jx(i) {
    return Sp(i);
  }
  const Ix = (i, a) => i.length === a.length && i.every((l, r) => l === a[r]), Xf = (i, a) => Ix(i, a), Wx = async (i, a) => {
    let l;
    const r = new Promise((c, f) => {
      l = setTimeout(() => f(new Px(`withTimeout: timed out after ${a}ms`)), a);
    });
    try {
      return await Promise.race([
        i,
        r
      ]);
    } finally {
      clearTimeout(l);
    }
  };
  class Px extends Error {
    constructor(a) {
      super(a), this.name = "TimeoutError";
    }
  }
  class e2 extends ts {
    constructor(a, l = {}) {
      super();
      __privateAdd(this, _e2_instances);
      __publicField(this, "documentId");
      __privateAdd(this, _t);
      __privateAdd(this, _e);
      __privateAdd(this, _n);
      __privateAdd(this, _a, 6e4);
      __privateAdd(this, _i, {});
      __publicField(this, "isReady", () => this.inState([
        "ready"
      ]));
      __publicField(this, "isDeleted", () => this.inState([
        "deleted"
      ]));
      __publicField(this, "isUnavailable", () => this.inState([
        "unavailable"
      ]));
      __publicField(this, "inState", (a) => a.some((l) => __privateGet(this, _e).getSnapshot().matches(l)));
      this.documentId = a, "timeoutDelay" in l && l.timeoutDelay && __privateSet(this, _a, l.timeoutDelay);
      let r;
      const c = "isNew" in l && l.isNew;
      c ? (r = Bv(l.initialValue), r = Hv(r)) : r = ao(), __privateSet(this, _t, Qn(`automerge-repo:dochandle:${this.documentId.slice(0, 5)}`));
      const f = __privateGet(this, _a), d = gx({
        actions: {
          onUpdate: tf(({ context: h, event: g }) => {
            const y = h.doc;
            hx(g, Hr);
            const { callback: p } = g.payload;
            return {
              doc: p(y)
            };
          }),
          onDelete: tf(() => (this.emit("delete", {
            handle: this
          }), {
            doc: void 0
          })),
          onUnavailable: () => {
            this.emit("unavailable", {
              handle: this
            });
          }
        }
      }).createMachine({
        initial: "idle",
        context: {
          documentId: a,
          doc: r
        },
        on: {
          UPDATE: {
            actions: "onUpdate"
          },
          DELETE: ".deleted"
        },
        states: {
          idle: {
            on: {
              CREATE: "ready",
              FIND: "loading"
            }
          },
          loading: {
            on: {
              REQUEST: "requesting",
              DOC_READY: "ready",
              AWAIT_NETWORK: "awaitingNetwork"
            },
            after: {
              [f]: "unavailable"
            }
          },
          awaitingNetwork: {
            on: {
              NETWORK_READY: "requesting"
            }
          },
          requesting: {
            on: {
              DOC_UNAVAILABLE: "unavailable",
              DOC_READY: "ready"
            },
            after: {
              [f]: "unavailable"
            }
          },
          unavailable: {
            entry: "onUnavailable",
            on: {
              DOC_READY: "ready"
            }
          },
          ready: {},
          deleted: {
            entry: "onDelete",
            type: "final"
          }
        }
      });
      __privateSet(this, _e, fl(d)), __privateGet(this, _e).subscribe((h) => {
        const g = __privateGet(this, _n), y = h.context.doc;
        __privateGet(this, _t).call(this, `\u2192 ${h.value} %o`, y), __privateMethod(this, _e2_instances, o_fn).call(this, g, y);
      }), __privateGet(this, _e).start(), __privateGet(this, _e).send(c ? {
        type: n2
      } : {
        type: a2
      });
    }
    get url() {
      return Lf({
        documentId: this.documentId
      });
    }
    get state() {
      return __privateGet(this, _e).getSnapshot().value;
    }
    async whenReady(a = [
      "ready"
    ]) {
      await Wx(__privateMethod(this, _e2_instances, l_fn).call(this, a), __privateGet(this, _a));
    }
    async doc(a = [
      "ready",
      "unavailable"
    ]) {
      try {
        await __privateMethod(this, _e2_instances, l_fn).call(this, a);
      } catch {
        return;
      }
      return this.isUnavailable() ? void 0 : __privateGet(this, _e2_instances, s_get);
    }
    docSync() {
      if (this.isReady()) return __privateGet(this, _e2_instances, s_get);
    }
    heads() {
      if (this.isReady()) return rn(__privateGet(this, _e2_instances, s_get));
    }
    update(a) {
      __privateGet(this, _e).send({
        type: Hr,
        payload: {
          callback: a
        }
      });
    }
    setRemoteHeads(a, l) {
      __privateGet(this, _i)[a] = l, this.emit("remote-heads", {
        storageId: a,
        heads: l
      });
    }
    getRemoteHeads(a) {
      return __privateGet(this, _i)[a];
    }
    change(a, l = {}) {
      if (!this.isReady()) throw new Error(`DocHandle#${this.documentId} is not ready. Check \`handle.isReady()\` before accessing the document.`);
      __privateGet(this, _e).send({
        type: Hr,
        payload: {
          callback: (r) => qv(r, l, a)
        }
      });
    }
    changeAt(a, l, r = {}) {
      if (!this.isReady()) throw new Error(`DocHandle#${this.documentId} is not ready. Check \`handle.isReady()\` before accessing the document.`);
      let c;
      return __privateGet(this, _e).send({
        type: Hr,
        payload: {
          callback: (f) => {
            const d = Yv(f, a, r, l);
            return c = d.newHeads || void 0, d.newDoc;
          }
        }
      }), c;
    }
    merge(a) {
      if (!this.isReady() || !a.isReady()) throw new Error("Both handles must be ready to merge");
      const l = a.docSync();
      if (!l) throw new Error("The document to be merged in is falsy, aborting.");
      this.update((r) => Gv(r, l));
    }
    unavailable() {
      __privateGet(this, _e).send({
        type: c2
      });
    }
    request() {
      __privateGet(this, _e2_instances, r_get) === "loading" && __privateGet(this, _e).send({
        type: i2
      });
    }
    awaitNetwork() {
      __privateGet(this, _e2_instances, r_get) === "loading" && __privateGet(this, _e).send({
        type: l2
      });
    }
    networkReady() {
      __privateGet(this, _e2_instances, r_get) === "awaitingNetwork" && __privateGet(this, _e).send({
        type: r2
      });
    }
    delete() {
      __privateGet(this, _e).send({
        type: o2
      });
    }
    broadcast(a) {
      this.emit("ephemeral-message-outbound", {
        handle: this,
        data: Tp(a)
      });
    }
  }
  _t = new WeakMap();
  _e = new WeakMap();
  _n = new WeakMap();
  _a = new WeakMap();
  _i = new WeakMap();
  _e2_instances = new WeakSet();
  s_get = function() {
    var _a7;
    return (_a7 = __privateGet(this, _e)) == null ? void 0 : _a7.getSnapshot().context.doc;
  };
  r_get = function() {
    var _a7;
    return (_a7 = __privateGet(this, _e)) == null ? void 0 : _a7.getSnapshot().value;
  };
  l_fn = function(a) {
    const l = Array.isArray(a) ? a : [
      a
    ];
    return vx(__privateGet(this, _e), (r) => l.some((c) => r.matches(c)), {
      timeout: __privateGet(this, _a) * 2
    });
  };
  o_fn = function(a, l) {
    if (l && a && !Xf(rn(l), rn(a))) {
      this.emit("heads-changed", {
        handle: this,
        doc: l
      });
      const c = Lv(l, rn(a), rn(l));
      c.length > 0 && this.emit("change", {
        handle: this,
        doc: l,
        patches: c,
        patchInfo: {
          before: a,
          after: l,
          source: "change"
        }
      }), this.isReady() || __privateGet(this, _e).send({
        type: s2
      });
    }
    __privateSet(this, _n, l);
  };
  const t2 = {
    REQUESTING: "requesting",
    READY: "ready",
    UNAVAILABLE: "unavailable"
  }, { REQUESTING: Br, READY: qu, UNAVAILABLE: py } = t2, n2 = "CREATE", a2 = "FIND", i2 = "REQUEST", s2 = "DOC_READY", l2 = "AWAIT_NETWORK", r2 = "NETWORK_READY", Hr = "UPDATE", o2 = "DELETE", c2 = "DOC_UNAVAILABLE";
  class u2 extends ts {
    constructor() {
      super(...arguments);
      __privateAdd(this, _u2_instances);
      __privateAdd(this, _t2, /* @__PURE__ */ new Map());
      __privateAdd(this, _e2, /* @__PURE__ */ new Set());
      __privateAdd(this, _n2, /* @__PURE__ */ new Map());
      __privateAdd(this, _a2, /* @__PURE__ */ new Set());
      __privateAdd(this, _i2, /* @__PURE__ */ new Map());
      __privateAdd(this, _s, Qn("automerge-repo:remote-heads-subscriptions"));
    }
    subscribeToRemotes(a) {
      __privateGet(this, _s).call(this, "subscribeToRemotes", a);
      const l = [];
      for (const r of a) __privateGet(this, _e2).has(r) || (__privateGet(this, _e2).add(r), l.push(r));
      l.length > 0 && this.emit("change-remote-subs", {
        add: l,
        peers: Array.from(__privateGet(this, _a2))
      });
    }
    unsubscribeFromRemotes(a) {
      __privateGet(this, _s).call(this, "subscribeToRemotes", a);
      const l = [];
      for (const r of a) __privateGet(this, _e2).has(r) && (__privateGet(this, _e2).delete(r), __privateGet(this, _n2).has(r) || l.push(r));
      l.length > 0 && this.emit("change-remote-subs", {
        remove: l,
        peers: Array.from(__privateGet(this, _a2))
      });
    }
    handleControlMessage(a) {
      const l = [], r = [], c = [];
      if (__privateGet(this, _s).call(this, "handleControlMessage", a), a.add) for (const f of a.add) {
        let d = __privateGet(this, _n2).get(f);
        (__privateGet(this, _e2).has(f) || d) && c.push(f), d || (d = /* @__PURE__ */ new Set(), __privateGet(this, _n2).set(f, d), __privateGet(this, _e2).has(f) || l.push(f)), d.add(a.senderId);
      }
      if (a.remove) for (const f of a.remove) {
        const d = __privateGet(this, _n2).get(f);
        d && (d.delete(a.senderId), d.size == 0 && !__privateGet(this, _e2).has(f) && r.push(f));
      }
      (l.length > 0 || r.length > 0) && this.emit("change-remote-subs", {
        peers: Array.from(__privateGet(this, _a2)),
        add: l,
        remove: r
      });
      for (const f of c) {
        const d = __privateGet(this, _i2).get(a.senderId);
        if (d) for (const h of d) {
          const g = __privateGet(this, _t2).get(h);
          if (!g) continue;
          const y = g.get(f);
          y && this.emit("notify-remote-heads", {
            targetId: a.senderId,
            documentId: h,
            heads: y.heads,
            timestamp: y.timestamp,
            storageId: f
          });
        }
      }
    }
    handleRemoteHeads(a) {
      __privateGet(this, _s).call(this, "handleRemoteHeads", a);
      const l = __privateMethod(this, _u2_instances, l_fn2).call(this, a);
      for (const r of l) __privateGet(this, _e2).has(r.storageId) && this.emit("remote-heads-changed", r);
      for (const r of l) for (const c of __privateGet(this, _a2)) c !== a.senderId && this.emit("notify-remote-heads", {
        targetId: c,
        documentId: r.documentId,
        heads: r.remoteHeads,
        timestamp: r.timestamp,
        storageId: r.storageId
      });
      for (const r of l) {
        const c = __privateGet(this, _n2).get(r.storageId);
        if (c) for (const f of c) __privateMethod(this, _u2_instances, r_fn).call(this, f, r.documentId) && this.emit("notify-remote-heads", {
          targetId: f,
          documentId: r.documentId,
          heads: r.remoteHeads,
          timestamp: r.timestamp,
          storageId: r.storageId
        });
      }
    }
    handleImmediateRemoteHeadsChanged(a, l, r) {
      __privateGet(this, _s).call(this, "handleLocalHeadsChanged", a, l, r);
      const c = __privateGet(this, _t2).get(a), f = Date.now();
      if (!c) __privateGet(this, _t2).set(a, /* @__PURE__ */ new Map([
        [
          l,
          {
            heads: r,
            timestamp: f
          }
        ]
      ]));
      else {
        const h = c.get(l);
        (!h || h.timestamp < Date.now()) && c.set(l, {
          heads: r,
          timestamp: Date.now()
        });
      }
      const d = __privateGet(this, _n2).get(l);
      if (d) for (const h of d) __privateMethod(this, _u2_instances, r_fn).call(this, h, a) && this.emit("notify-remote-heads", {
        targetId: h,
        documentId: a,
        heads: r,
        timestamp: f,
        storageId: l
      });
    }
    addGenerousPeer(a) {
      __privateGet(this, _s).call(this, "addGenerousPeer", a), __privateGet(this, _a2).add(a), __privateGet(this, _e2).size > 0 && this.emit("change-remote-subs", {
        add: Array.from(__privateGet(this, _e2)),
        peers: [
          a
        ]
      });
      for (const [l, r] of __privateGet(this, _t2)) for (const [c, { heads: f, timestamp: d }] of r) this.emit("notify-remote-heads", {
        targetId: a,
        documentId: l,
        heads: f,
        timestamp: d,
        storageId: c
      });
    }
    removePeer(a) {
      __privateGet(this, _s).call(this, "removePeer", a);
      const l = [];
      __privateGet(this, _a2).delete(a), __privateGet(this, _i2).delete(a);
      for (const [r, c] of __privateGet(this, _n2)) c.has(a) && (c.delete(a), c.size == 0 && (l.push(r), __privateGet(this, _n2).delete(r)));
      l.length > 0 && this.emit("change-remote-subs", {
        remove: l,
        peers: Array.from(__privateGet(this, _a2))
      });
    }
    subscribePeerToDoc(a, l) {
      let r = __privateGet(this, _i2).get(a);
      r || (r = /* @__PURE__ */ new Set(), __privateGet(this, _i2).set(a, r)), r.add(l);
      const c = __privateGet(this, _t2).get(l);
      if (c) for (const [f, d] of c) {
        const h = __privateGet(this, _n2).get(f);
        h && h.has(a) && this.emit("notify-remote-heads", {
          targetId: a,
          documentId: l,
          heads: d.heads,
          timestamp: d.timestamp,
          storageId: f
        });
      }
    }
  }
  _t2 = new WeakMap();
  _e2 = new WeakMap();
  _n2 = new WeakMap();
  _a2 = new WeakMap();
  _i2 = new WeakMap();
  _s = new WeakMap();
  _u2_instances = new WeakSet();
  r_fn = function(a, l) {
    const r = __privateGet(this, _i2).get(a);
    return r && r.has(l);
  };
  l_fn2 = function(a) {
    const l = [], { documentId: r, newHeads: c } = a;
    for (const [f, { heads: d, timestamp: h }] of Object.entries(c)) {
      if (!__privateGet(this, _e2).has(f) && !__privateGet(this, _n2).has(f)) continue;
      let g = __privateGet(this, _t2).get(r);
      g || (g = /* @__PURE__ */ new Map(), __privateGet(this, _t2).set(r, g));
      const y = g.get(f);
      y && y.timestamp >= h || (g.set(f, {
        timestamp: h,
        heads: d
      }), l.push({
        documentId: r,
        storageId: f,
        remoteHeads: d,
        timestamp: h
      }));
    }
    return l;
  };
  const df = (i, a) => {
    let l = Date.now(), r, c;
    return function(...f) {
      r = l + a - Date.now(), clearTimeout(c), c = setTimeout(() => {
        i(...f), l = Date.now();
      }, r);
    };
  }, f2 = (i) => h2(i) || Cp(i) || Op(i) || d2(i) || m2(i) || y2(i), d2 = (i) => i.type === "doc-unavailable", Op = (i) => i.type === "request", h2 = (i) => i.type === "sync", Cp = (i) => i.type === "ephemeral", m2 = (i) => i.type === "remote-subscription-change", y2 = (i) => i.type === "remote-heads-changed", p2 = (i) => `${i.senderId}:${i.sessionId}`;
  class g2 extends ts {
    constructor(a, l = b2(), r) {
      super();
      __publicField(this, "peerId");
      __publicField(this, "peerMetadata");
      __privateAdd(this, _t3);
      __privateAdd(this, _e3, {});
      __privateAdd(this, _n3, 0);
      __privateAdd(this, _a3, Math.random().toString(36).slice(2));
      __privateAdd(this, _i3, {});
      __privateAdd(this, _s2, 0);
      __privateAdd(this, _r, []);
      __publicField(this, "isReady", () => __privateGet(this, _s2) === __privateGet(this, _r).length);
      __publicField(this, "whenReady", async () => {
        if (!this.isReady()) return new Promise((a) => {
          this.once("ready", () => {
            a();
          });
        });
      });
      this.peerId = l, this.peerMetadata = r, __privateSet(this, _t3, Qn(`automerge-repo:network:${this.peerId}`)), a.forEach((c) => this.addNetworkAdapter(c));
    }
    addNetworkAdapter(a) {
      __privateGet(this, _r).push(a), a.once("ready", () => {
        __privateWrapper(this, _s2)._++, __privateGet(this, _t3).call(this, "Adapters ready: ", __privateGet(this, _s2), "/", __privateGet(this, _r).length), __privateGet(this, _s2) === __privateGet(this, _r).length && this.emit("ready");
      }), a.on("peer-candidate", ({ peerId: l, peerMetadata: r }) => {
        __privateGet(this, _t3).call(this, `peer candidate: ${l} `), __privateGet(this, _e3)[l] || (__privateGet(this, _e3)[l] = a), this.emit("peer", {
          peerId: l,
          peerMetadata: r
        });
      }), a.on("peer-disconnected", ({ peerId: l }) => {
        __privateGet(this, _t3).call(this, `peer disconnected: ${l} `), delete __privateGet(this, _e3)[l], this.emit("peer-disconnected", {
          peerId: l
        });
      }), a.on("message", (l) => {
        if (!f2(l)) {
          __privateGet(this, _t3).call(this, `invalid message: ${JSON.stringify(l)}`);
          return;
        }
        if (__privateGet(this, _t3).call(this, `message from ${l.senderId}`), Cp(l)) {
          const r = p2(l);
          (__privateGet(this, _i3)[r] === void 0 || l.count > __privateGet(this, _i3)[r]) && (__privateGet(this, _i3)[r] = l.count, this.emit("message", l));
          return;
        }
        this.emit("message", l);
      }), a.on("close", () => {
        __privateGet(this, _t3).call(this, "adapter closed"), Object.entries(__privateGet(this, _e3)).forEach(([l, r]) => {
          r === a && delete __privateGet(this, _e3)[l];
        });
      }), this.peerMetadata.then((l) => {
        a.connect(this.peerId, l);
      }).catch((l) => {
        __privateGet(this, _t3).call(this, "error connecting to network", l);
      });
    }
    send(a) {
      const l = __privateGet(this, _e3)[a.targetId];
      if (!l) {
        __privateGet(this, _t3).call(this, `Tried to send message but peer not found: ${a.targetId}`);
        return;
      }
      const c = ((f) => f.type === "ephemeral" ? "count" in f ? f : {
        ...f,
        count: ++__privateWrapper(this, _n3)._,
        sessionId: __privateGet(this, _a3),
        senderId: this.peerId
      } : {
        ...f,
        senderId: this.peerId
      })(a);
      __privateGet(this, _t3).call(this, "sending message %o", c), l.send(c);
    }
  }
  _t3 = new WeakMap();
  _e3 = new WeakMap();
  _n3 = new WeakMap();
  _a3 = new WeakMap();
  _i3 = new WeakMap();
  _s2 = new WeakMap();
  _r = new WeakMap();
  function b2() {
    return `user-${Math.round(Math.random() * 1e5)}`;
  }
  function _p(i) {
    let a = 0;
    i.forEach((c) => {
      a += c.length;
    });
    const l = new Uint8Array(a);
    let r = 0;
    return i.forEach((c) => {
      l.set(c, r), r += c.length;
    }), l;
  }
  var Xr = {
    exports: {}
  }, v2 = Xr.exports, gy;
  function x2() {
    return gy || (gy = 1, function(i) {
      (function(a, l) {
        var r = {};
        l(r);
        var c = r.default;
        for (var f in r) c[f] = r[f];
        i.exports = c;
      })(v2, function(a) {
        a.__esModule = true, a.digestLength = 32, a.blockSize = 64;
        var l = new Uint32Array([
          1116352408,
          1899447441,
          3049323471,
          3921009573,
          961987163,
          1508970993,
          2453635748,
          2870763221,
          3624381080,
          310598401,
          607225278,
          1426881987,
          1925078388,
          2162078206,
          2614888103,
          3248222580,
          3835390401,
          4022224774,
          264347078,
          604807628,
          770255983,
          1249150122,
          1555081692,
          1996064986,
          2554220882,
          2821834349,
          2952996808,
          3210313671,
          3336571891,
          3584528711,
          113926993,
          338241895,
          666307205,
          773529912,
          1294757372,
          1396182291,
          1695183700,
          1986661051,
          2177026350,
          2456956037,
          2730485921,
          2820302411,
          3259730800,
          3345764771,
          3516065817,
          3600352804,
          4094571909,
          275423344,
          430227734,
          506948616,
          659060556,
          883997877,
          958139571,
          1322822218,
          1537002063,
          1747873779,
          1955562222,
          2024104815,
          2227730452,
          2361852424,
          2428436474,
          2756734187,
          3204031479,
          3329325298
        ]);
        function r(S, x, v, A, j) {
          for (var L, B, D, I, ee, ae, be, le, W, P, pe, F, O; j >= 64; ) {
            for (L = x[0], B = x[1], D = x[2], I = x[3], ee = x[4], ae = x[5], be = x[6], le = x[7], P = 0; P < 16; P++) pe = A + P * 4, S[P] = (v[pe] & 255) << 24 | (v[pe + 1] & 255) << 16 | (v[pe + 2] & 255) << 8 | v[pe + 3] & 255;
            for (P = 16; P < 64; P++) W = S[P - 2], F = (W >>> 17 | W << 15) ^ (W >>> 19 | W << 13) ^ W >>> 10, W = S[P - 15], O = (W >>> 7 | W << 25) ^ (W >>> 18 | W << 14) ^ W >>> 3, S[P] = (F + S[P - 7] | 0) + (O + S[P - 16] | 0);
            for (P = 0; P < 64; P++) F = (((ee >>> 6 | ee << 26) ^ (ee >>> 11 | ee << 21) ^ (ee >>> 25 | ee << 7)) + (ee & ae ^ ~ee & be) | 0) + (le + (l[P] + S[P] | 0) | 0) | 0, O = ((L >>> 2 | L << 30) ^ (L >>> 13 | L << 19) ^ (L >>> 22 | L << 10)) + (L & B ^ L & D ^ B & D) | 0, le = be, be = ae, ae = ee, ee = I + F | 0, I = D, D = B, B = L, L = F + O | 0;
            x[0] += L, x[1] += B, x[2] += D, x[3] += I, x[4] += ee, x[5] += ae, x[6] += be, x[7] += le, A += 64, j -= 64;
          }
          return A;
        }
        var c = function() {
          function S() {
            this.digestLength = a.digestLength, this.blockSize = a.blockSize, this.state = new Int32Array(8), this.temp = new Int32Array(64), this.buffer = new Uint8Array(128), this.bufferLength = 0, this.bytesHashed = 0, this.finished = false, this.reset();
          }
          return S.prototype.reset = function() {
            return this.state[0] = 1779033703, this.state[1] = 3144134277, this.state[2] = 1013904242, this.state[3] = 2773480762, this.state[4] = 1359893119, this.state[5] = 2600822924, this.state[6] = 528734635, this.state[7] = 1541459225, this.bufferLength = 0, this.bytesHashed = 0, this.finished = false, this;
          }, S.prototype.clean = function() {
            for (var x = 0; x < this.buffer.length; x++) this.buffer[x] = 0;
            for (var x = 0; x < this.temp.length; x++) this.temp[x] = 0;
            this.reset();
          }, S.prototype.update = function(x, v) {
            if (v === void 0 && (v = x.length), this.finished) throw new Error("SHA256: can't update because hash was finished.");
            var A = 0;
            if (this.bytesHashed += v, this.bufferLength > 0) {
              for (; this.bufferLength < 64 && v > 0; ) this.buffer[this.bufferLength++] = x[A++], v--;
              this.bufferLength === 64 && (r(this.temp, this.state, this.buffer, 0, 64), this.bufferLength = 0);
            }
            for (v >= 64 && (A = r(this.temp, this.state, x, A, v), v %= 64); v > 0; ) this.buffer[this.bufferLength++] = x[A++], v--;
            return this;
          }, S.prototype.finish = function(x) {
            if (!this.finished) {
              var v = this.bytesHashed, A = this.bufferLength, j = v / 536870912 | 0, L = v << 3, B = v % 64 < 56 ? 64 : 128;
              this.buffer[A] = 128;
              for (var D = A + 1; D < B - 8; D++) this.buffer[D] = 0;
              this.buffer[B - 8] = j >>> 24 & 255, this.buffer[B - 7] = j >>> 16 & 255, this.buffer[B - 6] = j >>> 8 & 255, this.buffer[B - 5] = j >>> 0 & 255, this.buffer[B - 4] = L >>> 24 & 255, this.buffer[B - 3] = L >>> 16 & 255, this.buffer[B - 2] = L >>> 8 & 255, this.buffer[B - 1] = L >>> 0 & 255, r(this.temp, this.state, this.buffer, 0, B), this.finished = true;
            }
            for (var D = 0; D < 8; D++) x[D * 4 + 0] = this.state[D] >>> 24 & 255, x[D * 4 + 1] = this.state[D] >>> 16 & 255, x[D * 4 + 2] = this.state[D] >>> 8 & 255, x[D * 4 + 3] = this.state[D] >>> 0 & 255;
            return this;
          }, S.prototype.digest = function() {
            var x = new Uint8Array(this.digestLength);
            return this.finish(x), x;
          }, S.prototype._saveState = function(x) {
            for (var v = 0; v < this.state.length; v++) x[v] = this.state[v];
          }, S.prototype._restoreState = function(x, v) {
            for (var A = 0; A < this.state.length; A++) this.state[A] = x[A];
            this.bytesHashed = v, this.finished = false, this.bufferLength = 0;
          }, S;
        }();
        a.Hash = c;
        var f = function() {
          function S(x) {
            this.inner = new c(), this.outer = new c(), this.blockSize = this.inner.blockSize, this.digestLength = this.inner.digestLength;
            var v = new Uint8Array(this.blockSize);
            if (x.length > this.blockSize) new c().update(x).finish(v).clean();
            else for (var A = 0; A < x.length; A++) v[A] = x[A];
            for (var A = 0; A < v.length; A++) v[A] ^= 54;
            this.inner.update(v);
            for (var A = 0; A < v.length; A++) v[A] ^= 106;
            this.outer.update(v), this.istate = new Uint32Array(8), this.ostate = new Uint32Array(8), this.inner._saveState(this.istate), this.outer._saveState(this.ostate);
            for (var A = 0; A < v.length; A++) v[A] = 0;
          }
          return S.prototype.reset = function() {
            return this.inner._restoreState(this.istate, this.inner.blockSize), this.outer._restoreState(this.ostate, this.outer.blockSize), this;
          }, S.prototype.clean = function() {
            for (var x = 0; x < this.istate.length; x++) this.ostate[x] = this.istate[x] = 0;
            this.inner.clean(), this.outer.clean();
          }, S.prototype.update = function(x) {
            return this.inner.update(x), this;
          }, S.prototype.finish = function(x) {
            return this.outer.finished ? this.outer.finish(x) : (this.inner.finish(x), this.outer.update(x, this.digestLength).finish(x)), this;
          }, S.prototype.digest = function() {
            var x = new Uint8Array(this.digestLength);
            return this.finish(x), x;
          }, S;
        }();
        a.HMAC = f;
        function d(S) {
          var x = new c().update(S), v = x.digest();
          return x.clean(), v;
        }
        a.hash = d, a.default = d;
        function h(S, x) {
          var v = new f(S).update(x), A = v.digest();
          return v.clean(), A;
        }
        a.hmac = h;
        function g(S, x, v, A) {
          var j = A[0];
          if (j === 0) throw new Error("hkdf: cannot expand more");
          x.reset(), j > 1 && x.update(S), v && x.update(v), x.update(A), x.finish(S), A[0]++;
        }
        var y = new Uint8Array(a.digestLength);
        function p(S, x, v, A) {
          x === void 0 && (x = y), A === void 0 && (A = 32);
          for (var j = new Uint8Array([
            1
          ]), L = h(x, S), B = new f(L), D = new Uint8Array(B.digestLength), I = D.length, ee = new Uint8Array(A), ae = 0; ae < A; ae++) I === D.length && (g(D, B, v, j), I = 0), ee[ae] = D[I++];
          return B.clean(), D.fill(0), j.fill(0), ee;
        }
        a.hkdf = p;
        function b(S, x, v, A) {
          for (var j = new f(S), L = j.digestLength, B = new Uint8Array(4), D = new Uint8Array(L), I = new Uint8Array(L), ee = new Uint8Array(A), ae = 0; ae * L < A; ae++) {
            var be = ae + 1;
            B[0] = be >>> 24 & 255, B[1] = be >>> 16 & 255, B[2] = be >>> 8 & 255, B[3] = be >>> 0 & 255, j.reset(), j.update(x), j.update(B), j.finish(I);
            for (var le = 0; le < L; le++) D[le] = I[le];
            for (var le = 2; le <= v; le++) {
              j.reset(), j.update(I).finish(I);
              for (var W = 0; W < L; W++) D[W] ^= I[W];
            }
            for (var le = 0; le < L && ae * L + le < A; le++) ee[ae * L + le] = D[le];
          }
          for (var ae = 0; ae < L; ae++) D[ae] = I[ae] = 0;
          for (var ae = 0; ae < 4; ae++) B[ae] = 0;
          return j.clean(), ee;
        }
        a.pbkdf2 = b;
      });
    }(Xr)), Xr.exports;
  }
  var S2 = x2();
  function Np(i) {
    const a = S2.hash(i);
    return E2(a);
  }
  function w2(i) {
    const a = new TextEncoder(), l = _p(i.map((r) => a.encode(r)));
    return Np(l);
  }
  function E2(i) {
    return Array.from(i, (a) => a.toString(16).padStart(2, "0")).join("");
  }
  function A2(i) {
    if (i.length < 2) return null;
    const a = i[i.length - 2];
    return a === "snapshot" || a === "incremental" ? a : null;
  }
  class T2 {
    constructor(a) {
      __privateAdd(this, _T2_instances);
      __privateAdd(this, _t4);
      __privateAdd(this, _e4, /* @__PURE__ */ new Map());
      __privateAdd(this, _n4, /* @__PURE__ */ new Map());
      __privateAdd(this, _a4, false);
      __privateAdd(this, _i4, Qn("automerge-repo:storage-subsystem"));
      __privateSet(this, _t4, a);
    }
    async id() {
      const a = await __privateGet(this, _t4).load([
        "storage-adapter-id"
      ]);
      let l;
      return a ? l = new TextDecoder().decode(a) : (l = Yy(), await __privateGet(this, _t4).save([
        "storage-adapter-id"
      ], new TextEncoder().encode(l))), l;
    }
    async load(a, l) {
      const r = [
        a,
        l
      ];
      return await __privateGet(this, _t4).load(r);
    }
    async save(a, l, r) {
      const c = [
        a,
        l
      ];
      await __privateGet(this, _t4).save(c, r);
    }
    async remove(a, l) {
      const r = [
        a,
        l
      ];
      await __privateGet(this, _t4).remove(r);
    }
    async loadDoc(a) {
      const l = await __privateGet(this, _t4).loadRange([
        a
      ]), r = [], c = [];
      for (const h of l) {
        if (h.data === void 0) continue;
        const g = A2(h.key);
        g != null && (c.push({
          key: h.key,
          type: g,
          size: h.data.length
        }), r.push(h.data));
      }
      __privateGet(this, _n4).set(a, c);
      const f = _p(r);
      if (f.length === 0) return null;
      const d = Vv(ao(), f);
      return __privateGet(this, _e4).set(a, rn(d)), d;
    }
    async saveDoc(a, l) {
      if (!__privateMethod(this, _T2_instances, l_fn3).call(this, a, l)) return;
      const r = __privateGet(this, _n4).get(a) ?? [];
      __privateMethod(this, _T2_instances, o_fn2).call(this, r) ? await __privateMethod(this, _T2_instances, r_fn2).call(this, a, l, r) : await __privateMethod(this, _T2_instances, s_fn).call(this, a, l), __privateGet(this, _e4).set(a, rn(l));
    }
    async removeDoc(a) {
      await __privateGet(this, _t4).removeRange([
        a,
        "snapshot"
      ]), await __privateGet(this, _t4).removeRange([
        a,
        "incremental"
      ]), await __privateGet(this, _t4).removeRange([
        a,
        "sync-state"
      ]);
    }
    async loadSyncState(a, l) {
      const r = [
        a,
        "sync-state",
        l
      ], c = await __privateGet(this, _t4).load(r);
      return c ? Xy(c) : void 0;
    }
    async saveSyncState(a, l, r) {
      const c = [
        a,
        "sync-state",
        l
      ];
      await __privateGet(this, _t4).save(c, Fy(r));
    }
  }
  _t4 = new WeakMap();
  _e4 = new WeakMap();
  _n4 = new WeakMap();
  _a4 = new WeakMap();
  _i4 = new WeakMap();
  _T2_instances = new WeakSet();
  s_fn = async function(a, l) {
    const r = Xv(l, __privateGet(this, _e4).get(a) ?? []);
    if (r && r.length > 0) {
      const c = [
        a,
        "incremental",
        Np(r)
      ];
      __privateGet(this, _i4).call(this, `Saving incremental ${c} for document ${a}`), await __privateGet(this, _t4).save(c, r), __privateGet(this, _n4).has(a) || __privateGet(this, _n4).set(a, []), __privateGet(this, _n4).get(a).push({
        key: c,
        type: "incremental",
        size: r.length
      }), __privateGet(this, _e4).set(a, rn(l));
    } else return Promise.resolve();
  };
  r_fn2 = async function(a, l, r) {
    var _a7;
    __privateSet(this, _a4, true);
    const c = Vy(l), f = w2(rn(l)), d = [
      a,
      "snapshot",
      f
    ], h = new Set(r.map((y) => y.key).filter((y) => y[2] !== f));
    __privateGet(this, _i4).call(this, `Saving snapshot ${d} for document ${a}`), __privateGet(this, _i4).call(this, `deleting old chunks ${Array.from(h)}`), await __privateGet(this, _t4).save(d, c);
    for (const y of h) await __privateGet(this, _t4).remove(y);
    const g = ((_a7 = __privateGet(this, _n4).get(a)) == null ? void 0 : _a7.filter((y) => !h.has(y.key))) ?? [];
    g.push({
      key: d,
      type: "snapshot",
      size: c.length
    }), __privateGet(this, _n4).set(a, g), __privateSet(this, _a4, false);
  };
  l_fn3 = function(a, l) {
    const r = __privateGet(this, _e4).get(a);
    if (!r) return true;
    const c = rn(l);
    return !Xf(c, r);
  };
  o_fn2 = function(a) {
    if (__privateGet(this, _a4)) return false;
    let l = 0, r = 0;
    for (const c of a) c.type === "snapshot" ? l += c.size : r += c.size;
    return l < 1024 || r >= l;
  };
  class Rp extends ts {
  }
  class O2 extends Rp {
    constructor({ handle: a, onLoadSyncState: l }) {
      super();
      __privateAdd(this, _O2_instances);
      __privateAdd(this, _t5);
      __publicField(this, "syncDebounceRate", 100);
      __privateAdd(this, _e5, []);
      __privateAdd(this, _n5, {});
      __privateAdd(this, _a5, {});
      __privateAdd(this, _i5, {});
      __privateAdd(this, _s3, []);
      __privateAdd(this, _r2, false);
      __privateAdd(this, _l);
      __privateAdd(this, _o);
      __privateSet(this, _l, a), __privateSet(this, _o, l ?? (() => Promise.resolve(void 0)));
      const r = a.documentId.slice(0, 5);
      __privateSet(this, _t5, Qn(`automerge-repo:docsync:${r}`)), a.on("change", df(() => __privateMethod(this, _O2_instances, y_fn).call(this), this.syncDebounceRate)), a.on("ephemeral-message-outbound", (c) => __privateMethod(this, _O2_instances, p_fn).call(this, c)), (async () => (await a.doc([
        qu,
        Br
      ]), __privateMethod(this, _O2_instances, m_fn).call(this)))();
    }
    get peerStates() {
      return __privateGet(this, _a5);
    }
    get documentId() {
      return __privateGet(this, _l).documentId;
    }
    hasPeer(a) {
      return __privateGet(this, _e5).includes(a);
    }
    beginSync(a) {
      const l = a.every((c) => __privateGet(this, _a5)[c] in [
        "unavailable",
        "wants"
      ]), r = __privateGet(this, _l).doc([
        qu,
        Br,
        py
      ]).then((c) => {
        if (__privateSet(this, _r2, true), __privateMethod(this, _O2_instances, c_fn).call(this), !(c === void 0 && l)) return c ?? ao();
      });
      __privateGet(this, _t5).call(this, `beginSync: ${a.join(", ")}`), a.forEach((c) => {
        __privateMethod(this, _O2_instances, u_fn).call(this, c, (f) => {
          const d = Xy(Fy(f));
          __privateMethod(this, _O2_instances, f_fn).call(this, c, d), r.then((h) => {
            h && __privateMethod(this, _O2_instances, d_fn).call(this, c, h);
          }).catch((h) => {
            __privateGet(this, _t5).call(this, `Error loading doc for ${c}: ${h}`);
          });
        });
      });
    }
    endSync(a) {
      __privateGet(this, _t5).call(this, `removing peer ${a}`), __privateSet(this, _e5, __privateGet(this, _e5).filter((l) => l !== a));
    }
    receiveMessage(a) {
      switch (a.type) {
        case "sync":
        case "request":
          this.receiveSyncMessage(a);
          break;
        case "ephemeral":
          this.receiveEphemeralMessage(a);
          break;
        case "doc-unavailable":
          __privateGet(this, _a5)[a.senderId] = "unavailable", __privateMethod(this, _O2_instances, c_fn).call(this);
          break;
        default:
          throw new Error(`unknown message type: ${a}`);
      }
    }
    receiveEphemeralMessage(a) {
      if (a.documentId !== __privateGet(this, _l).documentId) throw new Error("channelId doesn't match documentId");
      const { senderId: l, data: r } = a, c = Sp(new Uint8Array(r));
      __privateGet(this, _l).emit("ephemeral-message", {
        handle: __privateGet(this, _l),
        senderId: l,
        message: c
      }), __privateGet(this, _e5).forEach((f) => {
        f !== l && this.emit("message", {
          ...a,
          targetId: f
        });
      });
    }
    receiveSyncMessage(a) {
      if (a.documentId !== __privateGet(this, _l).documentId) throw new Error("channelId doesn't match documentId");
      if (!__privateGet(this, _l).inState([
        qu,
        Br,
        py
      ])) {
        __privateGet(this, _s3).push({
          message: a,
          received: /* @__PURE__ */ new Date()
        });
        return;
      }
      __privateMethod(this, _O2_instances, m_fn).call(this), __privateMethod(this, _O2_instances, h_fn).call(this, a);
    }
  }
  _t5 = new WeakMap();
  _e5 = new WeakMap();
  _n5 = new WeakMap();
  _a5 = new WeakMap();
  _i5 = new WeakMap();
  _s3 = new WeakMap();
  _r2 = new WeakMap();
  _l = new WeakMap();
  _o = new WeakMap();
  _O2_instances = new WeakSet();
  y_fn = async function() {
    __privateGet(this, _t5).call(this, "syncWithPeers");
    const a = await __privateGet(this, _l).doc();
    a !== void 0 && __privateGet(this, _e5).forEach((l) => __privateMethod(this, _O2_instances, d_fn).call(this, l, a));
  };
  p_fn = async function({ data: a }) {
    __privateGet(this, _t5).call(this, "broadcastToPeers", __privateGet(this, _e5)), __privateGet(this, _e5).forEach((l) => __privateMethod(this, _O2_instances, g_fn).call(this, l, a));
  };
  g_fn = function(a, l) {
    __privateGet(this, _t5).call(this, `sendEphemeralMessage ->${a}`);
    const r = {
      type: "ephemeral",
      targetId: a,
      documentId: __privateGet(this, _l).documentId,
      data: l
    };
    this.emit("message", r);
  };
  u_fn = function(a, l) {
    __privateMethod(this, _O2_instances, b_fn).call(this, a), a in __privateGet(this, _a5) || (__privateGet(this, _a5)[a] = "unknown");
    const r = __privateGet(this, _i5)[a];
    if (r) {
      l(r);
      return;
    }
    let c = __privateGet(this, _n5)[a];
    c || (__privateGet(this, _o).call(this, a).then((f) => {
      __privateMethod(this, _O2_instances, v_fn).call(this, a, f ?? Fv());
    }).catch((f) => {
      __privateGet(this, _t5).call(this, `Error loading sync state for ${a}: ${f}`);
    }), c = __privateGet(this, _n5)[a] = []), c.push(l);
  };
  b_fn = function(a) {
    __privateGet(this, _e5).includes(a) || (__privateGet(this, _e5).push(a), this.emit("open-doc", {
      documentId: this.documentId,
      peerId: a
    }));
  };
  v_fn = function(a, l) {
    const r = __privateGet(this, _n5)[a];
    if (r) for (const c of r) c(l);
    delete __privateGet(this, _n5)[a], __privateGet(this, _i5)[a] = l;
  };
  f_fn = function(a, l) {
    __privateGet(this, _i5)[a] = l, this.emit("sync-state", {
      peerId: a,
      syncState: l,
      documentId: __privateGet(this, _l).documentId
    });
  };
  d_fn = function(a, l) {
    __privateGet(this, _t5).call(this, `sendSyncMessage ->${a}`), __privateMethod(this, _O2_instances, u_fn).call(this, a, (r) => {
      const [c, f] = Qv(l, r);
      if (f) {
        __privateMethod(this, _O2_instances, f_fn).call(this, a, c);
        const d = rn(l).length === 0;
        !__privateGet(this, _l).isReady() && d && c.sharedHeads.length === 0 && !Object.values(__privateGet(this, _a5)).includes("has") && __privateGet(this, _a5)[a] === "unknown" ? this.emit("message", {
          type: "request",
          targetId: a,
          documentId: __privateGet(this, _l).documentId,
          data: f
        }) : this.emit("message", {
          type: "sync",
          targetId: a,
          data: f,
          documentId: __privateGet(this, _l).documentId
        }), d || (__privateGet(this, _a5)[a] = "has");
      }
    });
  };
  h_fn = function(a) {
    Op(a) && (__privateGet(this, _a5)[a.senderId] = "wants"), __privateMethod(this, _O2_instances, c_fn).call(this), Zv(a.data).heads.length > 0 && (__privateGet(this, _a5)[a.senderId] = "has"), __privateMethod(this, _O2_instances, u_fn).call(this, a.senderId, (l) => {
      __privateGet(this, _l).update((r) => {
        const [c, f] = Kv(r, l, a.data);
        return __privateMethod(this, _O2_instances, f_fn).call(this, a.senderId, f), __privateMethod(this, _O2_instances, d_fn).call(this, a.senderId, r), c;
      }), __privateMethod(this, _O2_instances, c_fn).call(this);
    });
  };
  c_fn = function() {
    __privateGet(this, _r2) && __privateGet(this, _l).inState([
      Br
    ]) && __privateGet(this, _e5).every((a) => __privateGet(this, _a5)[a] === "unavailable" || __privateGet(this, _a5)[a] === "wants") && (__privateGet(this, _e5).filter((a) => __privateGet(this, _a5)[a] === "wants").forEach((a) => {
      const l = {
        type: "doc-unavailable",
        documentId: __privateGet(this, _l).documentId,
        targetId: a
      };
      this.emit("message", l);
    }), __privateGet(this, _l).unavailable());
  };
  m_fn = function() {
    for (const a of __privateGet(this, _s3)) __privateMethod(this, _O2_instances, h_fn).call(this, a.message);
    __privateSet(this, _s3, []);
  };
  const Yu = Qn("automerge-repo:collectionsync");
  class C2 extends Rp {
    constructor(a) {
      super();
      __privateAdd(this, _C2_instances);
      __publicField(this, "repo");
      __privateAdd(this, _t6, /* @__PURE__ */ new Set());
      __privateAdd(this, _e6, {});
      __privateAdd(this, _n6, {});
      this.repo = a;
    }
    async receiveMessage(a) {
      Yu(`onSyncMessage: ${a.senderId}, ${a.documentId}, ${"data" in a ? a.data.byteLength + "bytes" : ""}`);
      const l = a.documentId;
      if (!l) throw new Error("received a message with an invalid documentId");
      __privateGet(this, _n6)[l] = true;
      const r = __privateMethod(this, _C2_instances, a_fn).call(this, l);
      r.receiveMessage(a);
      const c = await __privateMethod(this, _C2_instances, s_fn2).call(this, l);
      r.beginSync(c.filter((f) => !r.hasPeer(f)));
    }
    addDocument(a) {
      if (__privateGet(this, _n6)[a]) return;
      const l = __privateMethod(this, _C2_instances, a_fn).call(this, a);
      __privateMethod(this, _C2_instances, s_fn2).call(this, a).then((r) => {
        l.beginSync(r);
      });
    }
    removeDocument(a) {
      throw new Error("not implemented");
    }
    addPeer(a) {
      if (Yu(`adding ${a} & synchronizing with them`), !__privateGet(this, _t6).has(a)) {
        __privateGet(this, _t6).add(a);
        for (const l of Object.values(__privateGet(this, _e6))) {
          const { documentId: r } = l;
          this.repo.sharePolicy(a, r).then((c) => {
            c && l.beginSync([
              a
            ]);
          });
        }
      }
    }
    removePeer(a) {
      Yu(`removing peer ${a}`), __privateGet(this, _t6).delete(a);
      for (const l of Object.values(__privateGet(this, _e6))) l.endSync(a);
    }
    get peers() {
      return Array.from(__privateGet(this, _t6));
    }
  }
  _t6 = new WeakMap();
  _e6 = new WeakMap();
  _n6 = new WeakMap();
  _C2_instances = new WeakSet();
  a_fn = function(a) {
    if (!__privateGet(this, _e6)[a]) {
      const l = this.repo.find(Lf({
        documentId: a
      }));
      __privateGet(this, _e6)[a] = __privateMethod(this, _C2_instances, i_fn).call(this, l);
    }
    return __privateGet(this, _e6)[a];
  };
  i_fn = function(a) {
    const l = new O2({
      handle: a,
      onLoadSyncState: async (r) => {
        if (!this.repo.storageSubsystem) return;
        const { storageId: c, isEphemeral: f } = this.repo.peerMetadataByPeerId[r] || {};
        if (!(!c || f)) return this.repo.storageSubsystem.loadSyncState(a.documentId, c);
      }
    });
    return l.on("message", (r) => this.emit("message", r)), l.on("open-doc", (r) => this.emit("open-doc", r)), l.on("sync-state", (r) => this.emit("sync-state", r)), l;
  };
  s_fn2 = async function(a) {
    const l = Array.from(__privateGet(this, _t6)), r = [];
    for (const c of l) await this.repo.sharePolicy(c, a) && r.push(c);
    return r;
  };
  class _2 extends ts {
    constructor({ storage: a, network: l = [], peerId: r, sharePolicy: c, isEphemeral: f = a === void 0, enableRemoteHeadsGossiping: d = false } = {}) {
      super();
      __privateAdd(this, __2_instances);
      __privateAdd(this, _t7);
      __publicField(this, "networkSubsystem");
      __publicField(this, "storageSubsystem");
      __publicField(this, "saveDebounceRate", 100);
      __privateAdd(this, _e7, {});
      __privateAdd(this, _n7);
      __publicField(this, "sharePolicy", async () => true);
      __publicField(this, "peerMetadataByPeerId", {});
      __privateAdd(this, _a6, new u2());
      __privateAdd(this, _i6, false);
      __privateAdd(this, _r3, {});
      __publicField(this, "subscribeToRemotes", (a) => {
        __privateGet(this, _i6) ? (__privateGet(this, _t7).call(this, "subscribeToRemotes", {
          remotes: a
        }), __privateGet(this, _a6).subscribeToRemotes(a)) : __privateGet(this, _t7).call(this, "WARN: subscribeToRemotes called but remote heads gossiping is not enabled");
      });
      __publicField(this, "storageId", async () => {
        if (this.storageSubsystem) return this.storageSubsystem.id();
      });
      __privateSet(this, _i6, d), __privateSet(this, _t7, Qn("automerge-repo:repo")), this.sharePolicy = c ?? this.sharePolicy, this.on("document", async ({ handle: p, isNew: b }) => {
        if (h) {
          const S = ({ handle: x, doc: v }) => {
            h.saveDoc(x.documentId, v);
          };
          if (p.on("heads-changed", df(S, this.saveDebounceRate)), b) await h.saveDoc(p.documentId, p.docSync());
          else {
            const x = await h.loadDoc(p.documentId);
            x && p.update(() => x);
          }
        }
        p.on("unavailable", () => {
          __privateGet(this, _t7).call(this, "document unavailable", {
            documentId: p.documentId
          }), this.emit("unavailable-document", {
            documentId: p.documentId
          });
        }), this.networkSubsystem.isReady() ? p.request() : (p.awaitNetwork(), this.networkSubsystem.whenReady().then(() => {
          p.networkReady();
        }).catch((S) => {
          __privateGet(this, _t7).call(this, "error waiting for network", {
            err: S
          });
        })), __privateGet(this, _n7).addDocument(p.documentId);
      }), this.on("delete-document", ({ documentId: p }) => {
        h && h.removeDoc(p).catch((b) => {
          __privateGet(this, _t7).call(this, "error deleting document", {
            documentId: p,
            err: b
          });
        });
      }), __privateSet(this, _n7, new C2(this)), __privateGet(this, _n7).on("message", (p) => {
        __privateGet(this, _t7).call(this, `sending ${p.type} message to ${p.targetId}`), y.send(p);
      }), __privateGet(this, _i6) && __privateGet(this, _n7).on("open-doc", ({ peerId: p, documentId: b }) => {
        __privateGet(this, _a6).subscribePeerToDoc(p, b);
      });
      const h = a ? new T2(a) : void 0;
      this.storageSubsystem = h;
      const g = (async () => ({
        storageId: await (h == null ? void 0 : h.id()),
        isEphemeral: f
      }))(), y = new g2(l, r, g);
      this.networkSubsystem = y, y.on("peer", async ({ peerId: p, peerMetadata: b }) => {
        __privateGet(this, _t7).call(this, "peer connected", {
          peerId: p
        }), b && (this.peerMetadataByPeerId[p] = {
          ...b
        }), this.sharePolicy(p).then((S) => {
          S && __privateGet(this, _i6) && __privateGet(this, _a6).addGenerousPeer(p);
        }).catch((S) => {
          console.log("error in share policy", {
            err: S
          });
        }), __privateGet(this, _n7).addPeer(p);
      }), y.on("peer-disconnected", ({ peerId: p }) => {
        __privateGet(this, _n7).removePeer(p), __privateGet(this, _a6).removePeer(p);
      }), y.on("message", async (p) => {
        __privateMethod(this, __2_instances, s_fn3).call(this, p);
      }), __privateGet(this, _n7).on("sync-state", (p) => {
        __privateMethod(this, __2_instances, l_fn4).call(this, p);
        const b = __privateGet(this, _e7)[p.documentId], { storageId: S } = this.peerMetadataByPeerId[p.peerId] || {};
        if (!S) return;
        const x = b.getRemoteHeads(S);
        p.syncState.theirHeads && (!x || !Xf(x, p.syncState.theirHeads)) && p.syncState.theirHeads && (b.setRemoteHeads(S, p.syncState.theirHeads), S && __privateGet(this, _i6) && __privateGet(this, _a6).handleImmediateRemoteHeadsChanged(p.documentId, S, p.syncState.theirHeads));
      }), __privateGet(this, _i6) && (__privateGet(this, _a6).on("notify-remote-heads", (p) => {
        this.networkSubsystem.send({
          type: "remote-heads-changed",
          targetId: p.targetId,
          documentId: p.documentId,
          newHeads: {
            [p.storageId]: {
              heads: p.heads,
              timestamp: p.timestamp
            }
          }
        });
      }), __privateGet(this, _a6).on("change-remote-subs", (p) => {
        __privateGet(this, _t7).call(this, "change-remote-subs", p);
        for (const b of p.peers) this.networkSubsystem.send({
          type: "remote-subscription-change",
          targetId: b,
          add: p.add,
          remove: p.remove
        });
      }), __privateGet(this, _a6).on("remote-heads-changed", (p) => {
        __privateGet(this, _e7)[p.documentId].setRemoteHeads(p.storageId, p.remoteHeads);
      }));
    }
    get handles() {
      return __privateGet(this, _e7);
    }
    get peers() {
      return __privateGet(this, _n7).peers;
    }
    getStorageIdOfPeer(a) {
      var _a7;
      return (_a7 = this.peerMetadataByPeerId[a]) == null ? void 0 : _a7.storageId;
    }
    create(a) {
      const { documentId: l } = Hf(Rx()), r = __privateMethod(this, __2_instances, o_fn3).call(this, {
        documentId: l,
        isNew: true,
        initialValue: a
      });
      return this.emit("document", {
        handle: r,
        isNew: true
      }), r;
    }
    clone(a) {
      if (!a.isReady()) throw new Error(`Cloned handle is not yet in ready state.
        (Try await handle.waitForReady() first.)`);
      const l = a.docSync();
      if (!l) throw new Error("Cloned handle doesn't have a document.");
      const r = this.create();
      return r.update(() => _m(l)), r;
    }
    find(a) {
      const l = zu(a);
      if (__privateGet(this, _e7)[l]) return __privateGet(this, _e7)[l].isUnavailable() && setTimeout(() => {
        __privateGet(this, _e7)[l].emit("unavailable", {
          handle: __privateGet(this, _e7)[l]
        });
      }), __privateGet(this, _e7)[l];
      const r = __privateMethod(this, __2_instances, o_fn3).call(this, {
        documentId: l,
        isNew: false
      });
      return this.emit("document", {
        handle: r,
        isNew: false
      }), r;
    }
    delete(a) {
      const l = zu(a);
      __privateMethod(this, __2_instances, o_fn3).call(this, {
        documentId: l,
        isNew: false
      }).delete(), delete __privateGet(this, _e7)[l], this.emit("delete-document", {
        documentId: l
      });
    }
    async export(a) {
      const l = zu(a), c = await __privateMethod(this, __2_instances, o_fn3).call(this, {
        documentId: l,
        isNew: false
      }).doc();
      if (c) return Vy(c);
    }
    import(a) {
      const l = $v(a), r = this.create();
      return r.update(() => _m(l)), r;
    }
    async flush(a) {
      if (!this.storageSubsystem) return;
      const l = a ? a.map((r) => __privateGet(this, _e7)[r]) : Object.values(__privateGet(this, _e7));
      await Promise.all(l.map(async (r) => {
        const c = r.docSync();
        if (c) return this.storageSubsystem.saveDoc(r.documentId, c);
      }));
    }
  }
  _t7 = new WeakMap();
  _e7 = new WeakMap();
  _n7 = new WeakMap();
  _a6 = new WeakMap();
  _i6 = new WeakMap();
  __2_instances = new WeakSet();
  s_fn3 = function(a) {
    switch (a.type) {
      case "remote-subscription-change":
        __privateGet(this, _i6) && __privateGet(this, _a6).handleControlMessage(a);
        break;
      case "remote-heads-changed":
        __privateGet(this, _i6) && __privateGet(this, _a6).handleRemoteHeads(a);
        break;
      case "sync":
      case "request":
      case "ephemeral":
      case "doc-unavailable":
        __privateGet(this, _n7).receiveMessage(a).catch((l) => {
          console.log("error receiving message", {
            err: l
          });
        });
    }
  };
  _r3 = new WeakMap();
  l_fn4 = function(a) {
    if (!this.storageSubsystem) return;
    const { storageId: l, isEphemeral: r } = this.peerMetadataByPeerId[a.peerId] || {};
    if (!l || r) return;
    let c = __privateGet(this, _r3)[l];
    c || (c = __privateGet(this, _r3)[l] = df(({ documentId: f, syncState: d }) => {
      this.storageSubsystem.saveSyncState(f, l, d);
    }, this.saveDebounceRate)), c(a);
  };
  o_fn3 = function({ documentId: a, isNew: l, initialValue: r }) {
    if (__privateGet(this, _e7)[a]) return __privateGet(this, _e7)[a];
    if (!a) throw new Error(`Invalid documentId ${a}`);
    const c = new e2(a, {
      isNew: l,
      initialValue: r
    });
    return __privateGet(this, _e7)[a] = c, c;
  };
  class N2 extends ts {
    constructor() {
      super(...arguments);
      __publicField(this, "peerId");
      __publicField(this, "peerMetadata");
    }
  }
  ao();
  const Gu = 10, by = (i = 0) => (a) => `\x1B[${a + i}m`, vy = (i = 0) => (a) => `\x1B[${38 + i};5;${a}m`, xy = (i = 0) => (a, l, r) => `\x1B[${38 + i};2;${a};${l};${r}m`, Le = {
    modifier: {
      reset: [
        0,
        0
      ],
      bold: [
        1,
        22
      ],
      dim: [
        2,
        22
      ],
      italic: [
        3,
        23
      ],
      underline: [
        4,
        24
      ],
      overline: [
        53,
        55
      ],
      inverse: [
        7,
        27
      ],
      hidden: [
        8,
        28
      ],
      strikethrough: [
        9,
        29
      ]
    },
    color: {
      black: [
        30,
        39
      ],
      red: [
        31,
        39
      ],
      green: [
        32,
        39
      ],
      yellow: [
        33,
        39
      ],
      blue: [
        34,
        39
      ],
      magenta: [
        35,
        39
      ],
      cyan: [
        36,
        39
      ],
      white: [
        37,
        39
      ],
      blackBright: [
        90,
        39
      ],
      gray: [
        90,
        39
      ],
      grey: [
        90,
        39
      ],
      redBright: [
        91,
        39
      ],
      greenBright: [
        92,
        39
      ],
      yellowBright: [
        93,
        39
      ],
      blueBright: [
        94,
        39
      ],
      magentaBright: [
        95,
        39
      ],
      cyanBright: [
        96,
        39
      ],
      whiteBright: [
        97,
        39
      ]
    },
    bgColor: {
      bgBlack: [
        40,
        49
      ],
      bgRed: [
        41,
        49
      ],
      bgGreen: [
        42,
        49
      ],
      bgYellow: [
        43,
        49
      ],
      bgBlue: [
        44,
        49
      ],
      bgMagenta: [
        45,
        49
      ],
      bgCyan: [
        46,
        49
      ],
      bgWhite: [
        47,
        49
      ],
      bgBlackBright: [
        100,
        49
      ],
      bgGray: [
        100,
        49
      ],
      bgGrey: [
        100,
        49
      ],
      bgRedBright: [
        101,
        49
      ],
      bgGreenBright: [
        102,
        49
      ],
      bgYellowBright: [
        103,
        49
      ],
      bgBlueBright: [
        104,
        49
      ],
      bgMagentaBright: [
        105,
        49
      ],
      bgCyanBright: [
        106,
        49
      ],
      bgWhiteBright: [
        107,
        49
      ]
    }
  };
  Object.keys(Le.modifier);
  const R2 = Object.keys(Le.color), j2 = Object.keys(Le.bgColor);
  [
    ...R2,
    ...j2
  ];
  function M2() {
    const i = /* @__PURE__ */ new Map();
    for (const [a, l] of Object.entries(Le)) {
      for (const [r, c] of Object.entries(l)) Le[r] = {
        open: `\x1B[${c[0]}m`,
        close: `\x1B[${c[1]}m`
      }, l[r] = Le[r], i.set(c[0], c[1]);
      Object.defineProperty(Le, a, {
        value: l,
        enumerable: false
      });
    }
    return Object.defineProperty(Le, "codes", {
      value: i,
      enumerable: false
    }), Le.color.close = "\x1B[39m", Le.bgColor.close = "\x1B[49m", Le.color.ansi = by(), Le.color.ansi256 = vy(), Le.color.ansi16m = xy(), Le.bgColor.ansi = by(Gu), Le.bgColor.ansi256 = vy(Gu), Le.bgColor.ansi16m = xy(Gu), Object.defineProperties(Le, {
      rgbToAnsi256: {
        value(a, l, r) {
          return a === l && l === r ? a < 8 ? 16 : a > 248 ? 231 : Math.round((a - 8) / 247 * 24) + 232 : 16 + 36 * Math.round(a / 255 * 5) + 6 * Math.round(l / 255 * 5) + Math.round(r / 255 * 5);
        },
        enumerable: false
      },
      hexToRgb: {
        value(a) {
          const l = /[a-f\d]{6}|[a-f\d]{3}/i.exec(a.toString(16));
          if (!l) return [
            0,
            0,
            0
          ];
          let [r] = l;
          r.length === 3 && (r = [
            ...r
          ].map((f) => f + f).join(""));
          const c = Number.parseInt(r, 16);
          return [
            c >> 16 & 255,
            c >> 8 & 255,
            c & 255
          ];
        },
        enumerable: false
      },
      hexToAnsi256: {
        value: (a) => Le.rgbToAnsi256(...Le.hexToRgb(a)),
        enumerable: false
      },
      ansi256ToAnsi: {
        value(a) {
          if (a < 8) return 30 + a;
          if (a < 16) return 90 + (a - 8);
          let l, r, c;
          if (a >= 232) l = ((a - 232) * 10 + 8) / 255, r = l, c = l;
          else {
            a -= 16;
            const h = a % 36;
            l = Math.floor(a / 36) / 5, r = Math.floor(h / 6) / 5, c = h % 6 / 5;
          }
          const f = Math.max(l, r, c) * 2;
          if (f === 0) return 30;
          let d = 30 + (Math.round(c) << 2 | Math.round(r) << 1 | Math.round(l));
          return f === 2 && (d += 60), d;
        },
        enumerable: false
      },
      rgbToAnsi: {
        value: (a, l, r) => Le.ansi256ToAnsi(Le.rgbToAnsi256(a, l, r)),
        enumerable: false
      },
      hexToAnsi: {
        value: (a) => Le.ansi256ToAnsi(Le.hexToAnsi256(a)),
        enumerable: false
      }
    }), Le;
  }
  const vn = M2(), Sy = (() => {
    if (!("navigator" in globalThis)) return 0;
    if (globalThis.navigator.userAgentData) {
      const i = navigator.userAgentData.brands.find(({ brand: a }) => a === "Chromium");
      if (i && i.version > 93) return 3;
    }
    return /\b(Chrome|Chromium)\//.test(globalThis.navigator.userAgent) ? 1 : 0;
  })(), wy = Sy !== 0 && {
    level: Sy
  }, D2 = {
    stdout: wy,
    stderr: wy
  };
  function U2(i, a, l) {
    let r = i.indexOf(a);
    if (r === -1) return i;
    const c = a.length;
    let f = 0, d = "";
    do
      d += i.slice(f, r) + a + l, f = r + c, r = i.indexOf(a, f);
    while (r !== -1);
    return d += i.slice(f), d;
  }
  function z2(i, a, l, r) {
    let c = 0, f = "";
    do {
      const d = i[r - 1] === "\r";
      f += i.slice(c, d ? r - 1 : r) + a + (d ? `\r
` : `
`) + l, c = r + 1, r = i.indexOf(`
`, c);
    } while (r !== -1);
    return f += i.slice(c), f;
  }
  const { stdout: Ey, stderr: Ay } = D2, hf = Symbol("GENERATOR"), Pi = Symbol("STYLER"), yl = Symbol("IS_EMPTY"), Ty = [
    "ansi",
    "ansi",
    "ansi256",
    "ansi16m"
  ], es = /* @__PURE__ */ Object.create(null), k2 = (i, a = {}) => {
    if (a.level && !(Number.isInteger(a.level) && a.level >= 0 && a.level <= 3)) throw new Error("The `level` option should be an integer from 0 to 3");
    const l = Ey ? Ey.level : 0;
    i.level = a.level === void 0 ? l : a.level;
  }, B2 = (i) => {
    const a = (...l) => l.join(" ");
    return k2(a, i), Object.setPrototypeOf(a, xl.prototype), a;
  };
  function xl(i) {
    return B2(i);
  }
  Object.setPrototypeOf(xl.prototype, Function.prototype);
  for (const [i, a] of Object.entries(vn)) es[i] = {
    get() {
      const l = eo(this, yf(a.open, a.close, this[Pi]), this[yl]);
      return Object.defineProperty(this, i, {
        value: l
      }), l;
    }
  };
  es.visible = {
    get() {
      const i = eo(this, this[Pi], true);
      return Object.defineProperty(this, "visible", {
        value: i
      }), i;
    }
  };
  const mf = (i, a, l, ...r) => i === "rgb" ? a === "ansi16m" ? vn[l].ansi16m(...r) : a === "ansi256" ? vn[l].ansi256(vn.rgbToAnsi256(...r)) : vn[l].ansi(vn.rgbToAnsi(...r)) : i === "hex" ? mf("rgb", a, l, ...vn.hexToRgb(...r)) : vn[l][i](...r), H2 = [
    "rgb",
    "hex",
    "ansi256"
  ];
  for (const i of H2) {
    es[i] = {
      get() {
        const { level: l } = this;
        return function(...r) {
          const c = yf(mf(i, Ty[l], "color", ...r), vn.color.close, this[Pi]);
          return eo(this, c, this[yl]);
        };
      }
    };
    const a = "bg" + i[0].toUpperCase() + i.slice(1);
    es[a] = {
      get() {
        const { level: l } = this;
        return function(...r) {
          const c = yf(mf(i, Ty[l], "bgColor", ...r), vn.bgColor.close, this[Pi]);
          return eo(this, c, this[yl]);
        };
      }
    };
  }
  const L2 = Object.defineProperties(() => {
  }, {
    ...es,
    level: {
      enumerable: true,
      get() {
        return this[hf].level;
      },
      set(i) {
        this[hf].level = i;
      }
    }
  }), yf = (i, a, l) => {
    let r, c;
    return l === void 0 ? (r = i, c = a) : (r = l.openAll + i, c = a + l.closeAll), {
      open: i,
      close: a,
      openAll: r,
      closeAll: c,
      parent: l
    };
  }, eo = (i, a, l) => {
    const r = (...c) => q2(r, c.length === 1 ? "" + c[0] : c.join(" "));
    return Object.setPrototypeOf(r, L2), r[hf] = i, r[Pi] = a, r[yl] = l, r;
  }, q2 = (i, a) => {
    if (i.level <= 0 || !a) return i[yl] ? "" : a;
    let l = i[Pi];
    if (l === void 0) return a;
    const { openAll: r, closeAll: c } = l;
    if (a.includes("\x1B")) for (; l !== void 0; ) a = U2(a, l.close, l.open), l = l.parent;
    const f = a.indexOf(`
`);
    return f !== -1 && (a = z2(a, c, r, f)), r + a + c;
  };
  Object.defineProperties(xl.prototype, es);
  const sl = xl();
  xl({
    level: Ay ? Ay.level : 0
  });
  var jp = (i) => {
    throw TypeError(i);
  }, Mp = (i, a, l) => a.has(i) || jp("Cannot " + l), Vn = (i, a, l) => (Mp(i, a, "read from private field"), l ? l.call(i) : a.get(i)), ll = (i, a, l) => a.has(i) ? jp("Cannot add the same private member more than once") : a instanceof WeakSet ? a.add(i) : a.set(i, l), Lr = (i, a, l, r) => (Mp(i, a, "write to private field"), a.set(i, l), l);
  class $i {
    constructor() {
      this.logLevel = "debug";
    }
    static getInstance() {
      return $i.instance || ($i.instance = new $i()), $i.instance;
    }
    setLogLevel(a) {
      this.logLevel = a;
    }
    getTimestamp() {
      return (/* @__PURE__ */ new Date()).toISOString();
    }
    shouldLog(a) {
      const l = [
        "debug",
        "info",
        "warn",
        "error"
      ];
      return l.indexOf(a) >= l.indexOf(this.logLevel);
    }
    debug(a, ...l) {
      this.shouldLog("debug") && console.log(sl.gray(`[${this.getTimestamp()}] DEBUG:`), a, ...l);
    }
    info(a, ...l) {
      this.shouldLog("info") && console.log(sl.blue(`[${this.getTimestamp()}] INFO:`), a, ...l);
    }
    warn(a, ...l) {
      this.shouldLog("warn") && console.log(sl.yellow(`[${this.getTimestamp()}] WARN:`), a, ...l);
    }
    error(a, ...l) {
      if (this.shouldLog("error")) {
        const r = a instanceof Error ? a.stack || a.message : a;
        console.error(sl.red(`[${this.getTimestamp()}] ERROR:`), r, ...l);
      }
    }
    formatObject(a) {
      return a instanceof Uint8Array ? `Uint8Array(${a.length})` : a;
    }
    debugWithContext(a, l, ...r) {
      if (this.shouldLog("debug")) {
        const c = r.map((f) => this.formatObject(f));
        console.log(sl.gray(`[${this.getTimestamp()}] DEBUG [${a}]:`), l, ...c);
      }
    }
  }
  const rt = $i.getInstance();
  function Dp(i, a) {
    return function() {
      return i.apply(a, arguments);
    };
  }
  const { toString: Y2 } = Object.prototype, { getPrototypeOf: Ff } = Object, { iterator: lo, toStringTag: Up } = Symbol, ro = /* @__PURE__ */ ((i) => (a) => {
    const l = Y2.call(a);
    return i[l] || (i[l] = l.slice(8, -1).toLowerCase());
  })(/* @__PURE__ */ Object.create(null)), on = (i) => (i = i.toLowerCase(), (a) => ro(a) === i), oo = (i) => (a) => typeof a === i, { isArray: ns } = Array, pl = oo("undefined");
  function G2(i) {
    return i !== null && !pl(i) && i.constructor !== null && !pl(i.constructor) && jt(i.constructor.isBuffer) && i.constructor.isBuffer(i);
  }
  const zp = on("ArrayBuffer");
  function V2(i) {
    let a;
    return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? a = ArrayBuffer.isView(i) : a = i && i.buffer && zp(i.buffer), a;
  }
  const X2 = oo("string"), jt = oo("function"), kp = oo("number"), co = (i) => i !== null && typeof i == "object", F2 = (i) => i === true || i === false, Fr = (i) => {
    if (ro(i) !== "object") return false;
    const a = Ff(i);
    return (a === null || a === Object.prototype || Object.getPrototypeOf(a) === null) && !(Up in i) && !(lo in i);
  }, Q2 = on("Date"), Z2 = on("File"), K2 = on("Blob"), $2 = on("FileList"), J2 = (i) => co(i) && jt(i.pipe), I2 = (i) => {
    let a;
    return i && (typeof FormData == "function" && i instanceof FormData || jt(i.append) && ((a = ro(i)) === "formdata" || a === "object" && jt(i.toString) && i.toString() === "[object FormData]"));
  }, W2 = on("URLSearchParams"), [P2, eS, tS, nS] = [
    "ReadableStream",
    "Request",
    "Response",
    "Headers"
  ].map(on), aS = (i) => i.trim ? i.trim() : i.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
  function Sl(i, a, { allOwnKeys: l = false } = {}) {
    if (i === null || typeof i > "u") return;
    let r, c;
    if (typeof i != "object" && (i = [
      i
    ]), ns(i)) for (r = 0, c = i.length; r < c; r++) a.call(null, i[r], r, i);
    else {
      const f = l ? Object.getOwnPropertyNames(i) : Object.keys(i), d = f.length;
      let h;
      for (r = 0; r < d; r++) h = f[r], a.call(null, i[h], h, i);
    }
  }
  function Bp(i, a) {
    a = a.toLowerCase();
    const l = Object.keys(i);
    let r = l.length, c;
    for (; r-- > 0; ) if (c = l[r], a === c.toLowerCase()) return c;
    return null;
  }
  const Ja = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global, Hp = (i) => !pl(i) && i !== Ja;
  function pf() {
    const { caseless: i } = Hp(this) && this || {}, a = {}, l = (r, c) => {
      const f = i && Bp(a, c) || c;
      Fr(a[f]) && Fr(r) ? a[f] = pf(a[f], r) : Fr(r) ? a[f] = pf({}, r) : ns(r) ? a[f] = r.slice() : a[f] = r;
    };
    for (let r = 0, c = arguments.length; r < c; r++) arguments[r] && Sl(arguments[r], l);
    return a;
  }
  const iS = (i, a, l, { allOwnKeys: r } = {}) => (Sl(a, (c, f) => {
    l && jt(c) ? i[f] = Dp(c, l) : i[f] = c;
  }, {
    allOwnKeys: r
  }), i), sS = (i) => (i.charCodeAt(0) === 65279 && (i = i.slice(1)), i), lS = (i, a, l, r) => {
    i.prototype = Object.create(a.prototype, r), i.prototype.constructor = i, Object.defineProperty(i, "super", {
      value: a.prototype
    }), l && Object.assign(i.prototype, l);
  }, rS = (i, a, l, r) => {
    let c, f, d;
    const h = {};
    if (a = a || {}, i == null) return a;
    do {
      for (c = Object.getOwnPropertyNames(i), f = c.length; f-- > 0; ) d = c[f], (!r || r(d, i, a)) && !h[d] && (a[d] = i[d], h[d] = true);
      i = l !== false && Ff(i);
    } while (i && (!l || l(i, a)) && i !== Object.prototype);
    return a;
  }, oS = (i, a, l) => {
    i = String(i), (l === void 0 || l > i.length) && (l = i.length), l -= a.length;
    const r = i.indexOf(a, l);
    return r !== -1 && r === l;
  }, cS = (i) => {
    if (!i) return null;
    if (ns(i)) return i;
    let a = i.length;
    if (!kp(a)) return null;
    const l = new Array(a);
    for (; a-- > 0; ) l[a] = i[a];
    return l;
  }, uS = /* @__PURE__ */ ((i) => (a) => i && a instanceof i)(typeof Uint8Array < "u" && Ff(Uint8Array)), fS = (i, a) => {
    const l = (i && i[lo]).call(i);
    let r;
    for (; (r = l.next()) && !r.done; ) {
      const c = r.value;
      a.call(i, c[0], c[1]);
    }
  }, dS = (i, a) => {
    let l;
    const r = [];
    for (; (l = i.exec(a)) !== null; ) r.push(l);
    return r;
  }, hS = on("HTMLFormElement"), mS = (i) => i.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(a, l, r) {
    return l.toUpperCase() + r;
  }), Oy = (({ hasOwnProperty: i }) => (a, l) => i.call(a, l))(Object.prototype), yS = on("RegExp"), Lp = (i, a) => {
    const l = Object.getOwnPropertyDescriptors(i), r = {};
    Sl(l, (c, f) => {
      let d;
      (d = a(c, f, i)) !== false && (r[f] = d || c);
    }), Object.defineProperties(i, r);
  }, pS = (i) => {
    Lp(i, (a, l) => {
      if (jt(i) && [
        "arguments",
        "caller",
        "callee"
      ].indexOf(l) !== -1) return false;
      const r = i[l];
      if (jt(r)) {
        if (a.enumerable = false, "writable" in a) {
          a.writable = false;
          return;
        }
        a.set || (a.set = () => {
          throw Error("Can not rewrite read-only method '" + l + "'");
        });
      }
    });
  }, gS = (i, a) => {
    const l = {}, r = (c) => {
      c.forEach((f) => {
        l[f] = true;
      });
    };
    return ns(i) ? r(i) : r(String(i).split(a)), l;
  }, bS = () => {
  }, vS = (i, a) => i != null && Number.isFinite(i = +i) ? i : a;
  function xS(i) {
    return !!(i && jt(i.append) && i[Up] === "FormData" && i[lo]);
  }
  const SS = (i) => {
    const a = new Array(10), l = (r, c) => {
      if (co(r)) {
        if (a.indexOf(r) >= 0) return;
        if (!("toJSON" in r)) {
          a[c] = r;
          const f = ns(r) ? [] : {};
          return Sl(r, (d, h) => {
            const g = l(d, c + 1);
            !pl(g) && (f[h] = g);
          }), a[c] = void 0, f;
        }
      }
      return r;
    };
    return l(i, 0);
  }, wS = on("AsyncFunction"), ES = (i) => i && (co(i) || jt(i)) && jt(i.then) && jt(i.catch), qp = ((i, a) => i ? setImmediate : a ? ((l, r) => (Ja.addEventListener("message", ({ source: c, data: f }) => {
    c === Ja && f === l && r.length && r.shift()();
  }, false), (c) => {
    r.push(c), Ja.postMessage(l, "*");
  }))(`axios@${Math.random()}`, []) : (l) => setTimeout(l))(typeof setImmediate == "function", jt(Ja.postMessage)), AS = typeof queueMicrotask < "u" ? queueMicrotask.bind(Ja) : typeof process < "u" && process.nextTick || qp, TS = (i) => i != null && jt(i[lo]), q = {
    isArray: ns,
    isArrayBuffer: zp,
    isBuffer: G2,
    isFormData: I2,
    isArrayBufferView: V2,
    isString: X2,
    isNumber: kp,
    isBoolean: F2,
    isObject: co,
    isPlainObject: Fr,
    isReadableStream: P2,
    isRequest: eS,
    isResponse: tS,
    isHeaders: nS,
    isUndefined: pl,
    isDate: Q2,
    isFile: Z2,
    isBlob: K2,
    isRegExp: yS,
    isFunction: jt,
    isStream: J2,
    isURLSearchParams: W2,
    isTypedArray: uS,
    isFileList: $2,
    forEach: Sl,
    merge: pf,
    extend: iS,
    trim: aS,
    stripBOM: sS,
    inherits: lS,
    toFlatObject: rS,
    kindOf: ro,
    kindOfTest: on,
    endsWith: oS,
    toArray: cS,
    forEachEntry: fS,
    matchAll: dS,
    isHTMLForm: hS,
    hasOwnProperty: Oy,
    hasOwnProp: Oy,
    reduceDescriptors: Lp,
    freezeMethods: pS,
    toObjectSet: gS,
    toCamelCase: mS,
    noop: bS,
    toFiniteNumber: vS,
    findKey: Bp,
    global: Ja,
    isContextDefined: Hp,
    isSpecCompliantForm: xS,
    toJSONObject: SS,
    isAsyncFn: wS,
    isThenable: ES,
    setImmediate: qp,
    asap: AS,
    isIterable: TS
  };
  function ge(i, a, l, r, c) {
    Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = i, this.name = "AxiosError", a && (this.code = a), l && (this.config = l), r && (this.request = r), c && (this.response = c, this.status = c.status ? c.status : null);
  }
  q.inherits(ge, Error, {
    toJSON: function() {
      return {
        message: this.message,
        name: this.name,
        description: this.description,
        number: this.number,
        fileName: this.fileName,
        lineNumber: this.lineNumber,
        columnNumber: this.columnNumber,
        stack: this.stack,
        config: q.toJSONObject(this.config),
        code: this.code,
        status: this.status
      };
    }
  });
  const Yp = ge.prototype, Gp = {};
  [
    "ERR_BAD_OPTION_VALUE",
    "ERR_BAD_OPTION",
    "ECONNABORTED",
    "ETIMEDOUT",
    "ERR_NETWORK",
    "ERR_FR_TOO_MANY_REDIRECTS",
    "ERR_DEPRECATED",
    "ERR_BAD_RESPONSE",
    "ERR_BAD_REQUEST",
    "ERR_CANCELED",
    "ERR_NOT_SUPPORT",
    "ERR_INVALID_URL"
  ].forEach((i) => {
    Gp[i] = {
      value: i
    };
  });
  Object.defineProperties(ge, Gp);
  Object.defineProperty(Yp, "isAxiosError", {
    value: true
  });
  ge.from = (i, a, l, r, c, f) => {
    const d = Object.create(Yp);
    return q.toFlatObject(i, d, function(h) {
      return h !== Error.prototype;
    }, (h) => h !== "isAxiosError"), ge.call(d, i.message, a, l, r, c), d.cause = i, d.name = i.name, f && Object.assign(d, f), d;
  };
  const OS = null;
  function gf(i) {
    return q.isPlainObject(i) || q.isArray(i);
  }
  function Vp(i) {
    return q.endsWith(i, "[]") ? i.slice(0, -2) : i;
  }
  function Cy(i, a, l) {
    return i ? i.concat(a).map(function(r, c) {
      return r = Vp(r), !l && c ? "[" + r + "]" : r;
    }).join(l ? "." : "") : a;
  }
  function CS(i) {
    return q.isArray(i) && !i.some(gf);
  }
  const _S = q.toFlatObject(q, {}, null, function(i) {
    return /^is[A-Z]/.test(i);
  });
  function uo(i, a, l) {
    if (!q.isObject(i)) throw new TypeError("target must be an object");
    a = a || new FormData(), l = q.toFlatObject(l, {
      metaTokens: true,
      dots: false,
      indexes: false
    }, false, function(x, v) {
      return !q.isUndefined(v[x]);
    });
    const r = l.metaTokens, c = l.visitor || y, f = l.dots, d = l.indexes, h = (l.Blob || typeof Blob < "u" && Blob) && q.isSpecCompliantForm(a);
    if (!q.isFunction(c)) throw new TypeError("visitor must be a function");
    function g(x) {
      if (x === null) return "";
      if (q.isDate(x)) return x.toISOString();
      if (!h && q.isBlob(x)) throw new ge("Blob is not supported. Use a Buffer instead.");
      return q.isArrayBuffer(x) || q.isTypedArray(x) ? h && typeof Blob == "function" ? new Blob([
        x
      ]) : Buffer.from(x) : x;
    }
    function y(x, v, A) {
      let j = x;
      if (x && !A && typeof x == "object") {
        if (q.endsWith(v, "{}")) v = r ? v : v.slice(0, -2), x = JSON.stringify(x);
        else if (q.isArray(x) && CS(x) || (q.isFileList(x) || q.endsWith(v, "[]")) && (j = q.toArray(x))) return v = Vp(v), j.forEach(function(L, B) {
          !(q.isUndefined(L) || L === null) && a.append(d === true ? Cy([
            v
          ], B, f) : d === null ? v : v + "[]", g(L));
        }), false;
      }
      return gf(x) ? true : (a.append(Cy(A, v, f), g(x)), false);
    }
    const p = [], b = Object.assign(_S, {
      defaultVisitor: y,
      convertValue: g,
      isVisitable: gf
    });
    function S(x, v) {
      if (!q.isUndefined(x)) {
        if (p.indexOf(x) !== -1) throw Error("Circular reference detected in " + v.join("."));
        p.push(x), q.forEach(x, function(A, j) {
          (!(q.isUndefined(A) || A === null) && c.call(a, A, q.isString(j) ? j.trim() : j, v, b)) === true && S(A, v ? v.concat(j) : [
            j
          ]);
        }), p.pop();
      }
    }
    if (!q.isObject(i)) throw new TypeError("data must be an object");
    return S(i), a;
  }
  function _y(i) {
    const a = {
      "!": "%21",
      "'": "%27",
      "(": "%28",
      ")": "%29",
      "~": "%7E",
      "%20": "+",
      "%00": "\0"
    };
    return encodeURIComponent(i).replace(/[!'()~]|%20|%00/g, function(l) {
      return a[l];
    });
  }
  function Qf(i, a) {
    this._pairs = [], i && uo(i, this, a);
  }
  const Xp = Qf.prototype;
  Xp.append = function(i, a) {
    this._pairs.push([
      i,
      a
    ]);
  };
  Xp.toString = function(i) {
    const a = i ? function(l) {
      return i.call(this, l, _y);
    } : _y;
    return this._pairs.map(function(l) {
      return a(l[0]) + "=" + a(l[1]);
    }, "").join("&");
  };
  function NS(i) {
    return encodeURIComponent(i).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
  }
  function Fp(i, a, l) {
    if (!a) return i;
    const r = l && l.encode || NS;
    q.isFunction(l) && (l = {
      serialize: l
    });
    const c = l && l.serialize;
    let f;
    if (c ? f = c(a, l) : f = q.isURLSearchParams(a) ? a.toString() : new Qf(a, l).toString(r), f) {
      const d = i.indexOf("#");
      d !== -1 && (i = i.slice(0, d)), i += (i.indexOf("?") === -1 ? "?" : "&") + f;
    }
    return i;
  }
  class Ny {
    constructor() {
      this.handlers = [];
    }
    use(a, l, r) {
      return this.handlers.push({
        fulfilled: a,
        rejected: l,
        synchronous: r ? r.synchronous : false,
        runWhen: r ? r.runWhen : null
      }), this.handlers.length - 1;
    }
    eject(a) {
      this.handlers[a] && (this.handlers[a] = null);
    }
    clear() {
      this.handlers && (this.handlers = []);
    }
    forEach(a) {
      q.forEach(this.handlers, function(l) {
        l !== null && a(l);
      });
    }
  }
  const Qp = {
    silentJSONParsing: true,
    forcedJSONParsing: true,
    clarifyTimeoutError: false
  }, RS = typeof URLSearchParams < "u" ? URLSearchParams : Qf, jS = typeof FormData < "u" ? FormData : null, MS = typeof Blob < "u" ? Blob : null, DS = {
    isBrowser: true,
    classes: {
      URLSearchParams: RS,
      FormData: jS,
      Blob: MS
    },
    protocols: [
      "http",
      "https",
      "file",
      "blob",
      "url",
      "data"
    ]
  }, Zf = typeof window < "u" && typeof document < "u", bf = typeof navigator == "object" && navigator || void 0, US = Zf && (!bf || [
    "ReactNative",
    "NativeScript",
    "NS"
  ].indexOf(bf.product) < 0), zS = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope && typeof self.importScripts == "function", kS = Zf && window.location.href || "http://localhost", BS = Object.freeze(Object.defineProperty({
    __proto__: null,
    hasBrowserEnv: Zf,
    hasStandardBrowserEnv: US,
    hasStandardBrowserWebWorkerEnv: zS,
    navigator: bf,
    origin: kS
  }, Symbol.toStringTag, {
    value: "Module"
  })), St = {
    ...BS,
    ...DS
  };
  function HS(i, a) {
    return uo(i, new St.classes.URLSearchParams(), Object.assign({
      visitor: function(l, r, c, f) {
        return St.isNode && q.isBuffer(l) ? (this.append(r, l.toString("base64")), false) : f.defaultVisitor.apply(this, arguments);
      }
    }, a));
  }
  function LS(i) {
    return q.matchAll(/\w+|\[(\w*)]/g, i).map((a) => a[0] === "[]" ? "" : a[1] || a[0]);
  }
  function qS(i) {
    const a = {}, l = Object.keys(i);
    let r;
    const c = l.length;
    let f;
    for (r = 0; r < c; r++) f = l[r], a[f] = i[f];
    return a;
  }
  function Zp(i) {
    function a(l, r, c, f) {
      let d = l[f++];
      if (d === "__proto__") return true;
      const h = Number.isFinite(+d), g = f >= l.length;
      return d = !d && q.isArray(c) ? c.length : d, g ? (q.hasOwnProp(c, d) ? c[d] = [
        c[d],
        r
      ] : c[d] = r, !h) : ((!c[d] || !q.isObject(c[d])) && (c[d] = []), a(l, r, c[d], f) && q.isArray(c[d]) && (c[d] = qS(c[d])), !h);
    }
    if (q.isFormData(i) && q.isFunction(i.entries)) {
      const l = {};
      return q.forEachEntry(i, (r, c) => {
        a(LS(r), c, l, 0);
      }), l;
    }
    return null;
  }
  function YS(i, a, l) {
    if (q.isString(i)) try {
      return (a || JSON.parse)(i), q.trim(i);
    } catch (r) {
      if (r.name !== "SyntaxError") throw r;
    }
    return (l || JSON.stringify)(i);
  }
  const wl = {
    transitional: Qp,
    adapter: [
      "xhr",
      "http",
      "fetch"
    ],
    transformRequest: [
      function(i, a) {
        const l = a.getContentType() || "", r = l.indexOf("application/json") > -1, c = q.isObject(i);
        if (c && q.isHTMLForm(i) && (i = new FormData(i)), q.isFormData(i)) return r ? JSON.stringify(Zp(i)) : i;
        if (q.isArrayBuffer(i) || q.isBuffer(i) || q.isStream(i) || q.isFile(i) || q.isBlob(i) || q.isReadableStream(i)) return i;
        if (q.isArrayBufferView(i)) return i.buffer;
        if (q.isURLSearchParams(i)) return a.setContentType("application/x-www-form-urlencoded;charset=utf-8", false), i.toString();
        let f;
        if (c) {
          if (l.indexOf("application/x-www-form-urlencoded") > -1) return HS(i, this.formSerializer).toString();
          if ((f = q.isFileList(i)) || l.indexOf("multipart/form-data") > -1) {
            const d = this.env && this.env.FormData;
            return uo(f ? {
              "files[]": i
            } : i, d && new d(), this.formSerializer);
          }
        }
        return c || r ? (a.setContentType("application/json", false), YS(i)) : i;
      }
    ],
    transformResponse: [
      function(i) {
        const a = this.transitional || wl.transitional, l = a && a.forcedJSONParsing, r = this.responseType === "json";
        if (q.isResponse(i) || q.isReadableStream(i)) return i;
        if (i && q.isString(i) && (l && !this.responseType || r)) {
          const c = !(a && a.silentJSONParsing) && r;
          try {
            return JSON.parse(i);
          } catch (f) {
            if (c) throw f.name === "SyntaxError" ? ge.from(f, ge.ERR_BAD_RESPONSE, this, null, this.response) : f;
          }
        }
        return i;
      }
    ],
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
      FormData: St.classes.FormData,
      Blob: St.classes.Blob
    },
    validateStatus: function(i) {
      return i >= 200 && i < 300;
    },
    headers: {
      common: {
        Accept: "application/json, text/plain, */*",
        "Content-Type": void 0
      }
    }
  };
  q.forEach([
    "delete",
    "get",
    "head",
    "post",
    "put",
    "patch"
  ], (i) => {
    wl.headers[i] = {};
  });
  const GS = q.toObjectSet([
    "age",
    "authorization",
    "content-length",
    "content-type",
    "etag",
    "expires",
    "from",
    "host",
    "if-modified-since",
    "if-unmodified-since",
    "last-modified",
    "location",
    "max-forwards",
    "proxy-authorization",
    "referer",
    "retry-after",
    "user-agent"
  ]), VS = (i) => {
    const a = {};
    let l, r, c;
    return i && i.split(`
`).forEach(function(f) {
      c = f.indexOf(":"), l = f.substring(0, c).trim().toLowerCase(), r = f.substring(c + 1).trim(), !(!l || a[l] && GS[l]) && (l === "set-cookie" ? a[l] ? a[l].push(r) : a[l] = [
        r
      ] : a[l] = a[l] ? a[l] + ", " + r : r);
    }), a;
  }, Ry = Symbol("internals");
  function rl(i) {
    return i && String(i).trim().toLowerCase();
  }
  function Qr(i) {
    return i === false || i == null ? i : q.isArray(i) ? i.map(Qr) : String(i);
  }
  function XS(i) {
    const a = /* @__PURE__ */ Object.create(null), l = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let r;
    for (; r = l.exec(i); ) a[r[1]] = r[2];
    return a;
  }
  const FS = (i) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(i.trim());
  function Vu(i, a, l, r, c) {
    if (q.isFunction(r)) return r.call(this, a, l);
    if (c && (a = l), !!q.isString(a)) {
      if (q.isString(r)) return a.indexOf(r) !== -1;
      if (q.isRegExp(r)) return r.test(a);
    }
  }
  function QS(i) {
    return i.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (a, l, r) => l.toUpperCase() + r);
  }
  function ZS(i, a) {
    const l = q.toCamelCase(" " + a);
    [
      "get",
      "set",
      "has"
    ].forEach((r) => {
      Object.defineProperty(i, r + l, {
        value: function(c, f, d) {
          return this[r].call(this, a, c, f, d);
        },
        configurable: true
      });
    });
  }
  let Mt = class {
    constructor(i) {
      i && this.set(i);
    }
    set(i, a, l) {
      const r = this;
      function c(d, h, g) {
        const y = rl(h);
        if (!y) throw new Error("header name must be a non-empty string");
        const p = q.findKey(r, y);
        (!p || r[p] === void 0 || g === true || g === void 0 && r[p] !== false) && (r[p || h] = Qr(d));
      }
      const f = (d, h) => q.forEach(d, (g, y) => c(g, y, h));
      if (q.isPlainObject(i) || i instanceof this.constructor) f(i, a);
      else if (q.isString(i) && (i = i.trim()) && !FS(i)) f(VS(i), a);
      else if (q.isObject(i) && q.isIterable(i)) {
        let d = {}, h, g;
        for (const y of i) {
          if (!q.isArray(y)) throw TypeError("Object iterator must return a key-value pair");
          d[g = y[0]] = (h = d[g]) ? q.isArray(h) ? [
            ...h,
            y[1]
          ] : [
            h,
            y[1]
          ] : y[1];
        }
        f(d, a);
      } else i != null && c(a, i, l);
      return this;
    }
    get(i, a) {
      if (i = rl(i), i) {
        const l = q.findKey(this, i);
        if (l) {
          const r = this[l];
          if (!a) return r;
          if (a === true) return XS(r);
          if (q.isFunction(a)) return a.call(this, r, l);
          if (q.isRegExp(a)) return a.exec(r);
          throw new TypeError("parser must be boolean|regexp|function");
        }
      }
    }
    has(i, a) {
      if (i = rl(i), i) {
        const l = q.findKey(this, i);
        return !!(l && this[l] !== void 0 && (!a || Vu(this, this[l], l, a)));
      }
      return false;
    }
    delete(i, a) {
      const l = this;
      let r = false;
      function c(f) {
        if (f = rl(f), f) {
          const d = q.findKey(l, f);
          d && (!a || Vu(l, l[d], d, a)) && (delete l[d], r = true);
        }
      }
      return q.isArray(i) ? i.forEach(c) : c(i), r;
    }
    clear(i) {
      const a = Object.keys(this);
      let l = a.length, r = false;
      for (; l--; ) {
        const c = a[l];
        (!i || Vu(this, this[c], c, i, true)) && (delete this[c], r = true);
      }
      return r;
    }
    normalize(i) {
      const a = this, l = {};
      return q.forEach(this, (r, c) => {
        const f = q.findKey(l, c);
        if (f) {
          a[f] = Qr(r), delete a[c];
          return;
        }
        const d = i ? QS(c) : String(c).trim();
        d !== c && delete a[c], a[d] = Qr(r), l[d] = true;
      }), this;
    }
    concat(...i) {
      return this.constructor.concat(this, ...i);
    }
    toJSON(i) {
      const a = /* @__PURE__ */ Object.create(null);
      return q.forEach(this, (l, r) => {
        l != null && l !== false && (a[r] = i && q.isArray(l) ? l.join(", ") : l);
      }), a;
    }
    [Symbol.iterator]() {
      return Object.entries(this.toJSON())[Symbol.iterator]();
    }
    toString() {
      return Object.entries(this.toJSON()).map(([i, a]) => i + ": " + a).join(`
`);
    }
    getSetCookie() {
      return this.get("set-cookie") || [];
    }
    get [Symbol.toStringTag]() {
      return "AxiosHeaders";
    }
    static from(i) {
      return i instanceof this ? i : new this(i);
    }
    static concat(i, ...a) {
      const l = new this(i);
      return a.forEach((r) => l.set(r)), l;
    }
    static accessor(i) {
      const a = (this[Ry] = this[Ry] = {
        accessors: {}
      }).accessors, l = this.prototype;
      function r(c) {
        const f = rl(c);
        a[f] || (ZS(l, c), a[f] = true);
      }
      return q.isArray(i) ? i.forEach(r) : r(i), this;
    }
  };
  Mt.accessor([
    "Content-Type",
    "Content-Length",
    "Accept",
    "Accept-Encoding",
    "User-Agent",
    "Authorization"
  ]);
  q.reduceDescriptors(Mt.prototype, ({ value: i }, a) => {
    let l = a[0].toUpperCase() + a.slice(1);
    return {
      get: () => i,
      set(r) {
        this[l] = r;
      }
    };
  });
  q.freezeMethods(Mt);
  function Xu(i, a) {
    const l = this || wl, r = a || l, c = Mt.from(r.headers);
    let f = r.data;
    return q.forEach(i, function(d) {
      f = d.call(l, f, c.normalize(), a ? a.status : void 0);
    }), c.normalize(), f;
  }
  function Kp(i) {
    return !!(i && i.__CANCEL__);
  }
  function as(i, a, l) {
    ge.call(this, i ?? "canceled", ge.ERR_CANCELED, a, l), this.name = "CanceledError";
  }
  q.inherits(as, ge, {
    __CANCEL__: true
  });
  function $p(i, a, l) {
    const r = l.config.validateStatus;
    !l.status || !r || r(l.status) ? i(l) : a(new ge("Request failed with status code " + l.status, [
      ge.ERR_BAD_REQUEST,
      ge.ERR_BAD_RESPONSE
    ][Math.floor(l.status / 100) - 4], l.config, l.request, l));
  }
  function KS(i) {
    const a = /^([-+\w]{1,25})(:?\/\/|:)/.exec(i);
    return a && a[1] || "";
  }
  function $S(i, a) {
    i = i || 10;
    const l = new Array(i), r = new Array(i);
    let c = 0, f = 0, d;
    return a = a !== void 0 ? a : 1e3, function(h) {
      const g = Date.now(), y = r[f];
      d || (d = g), l[c] = h, r[c] = g;
      let p = f, b = 0;
      for (; p !== c; ) b += l[p++], p = p % i;
      if (c = (c + 1) % i, c === f && (f = (f + 1) % i), g - d < a) return;
      const S = y && g - y;
      return S ? Math.round(b * 1e3 / S) : void 0;
    };
  }
  function JS(i, a) {
    let l = 0, r = 1e3 / a, c, f;
    const d = (h, g = Date.now()) => {
      l = g, c = null, f && (clearTimeout(f), f = null), i.apply(null, h);
    };
    return [
      (...h) => {
        const g = Date.now(), y = g - l;
        y >= r ? d(h, g) : (c = h, f || (f = setTimeout(() => {
          f = null, d(c);
        }, r - y)));
      },
      () => c && d(c)
    ];
  }
  const to = (i, a, l = 3) => {
    let r = 0;
    const c = $S(50, 250);
    return JS((f) => {
      const d = f.loaded, h = f.lengthComputable ? f.total : void 0, g = d - r, y = c(g), p = d <= h;
      r = d;
      const b = {
        loaded: d,
        total: h,
        progress: h ? d / h : void 0,
        bytes: g,
        rate: y || void 0,
        estimated: y && h && p ? (h - d) / y : void 0,
        event: f,
        lengthComputable: h != null,
        [a ? "download" : "upload"]: true
      };
      i(b);
    }, l);
  }, jy = (i, a) => {
    const l = i != null;
    return [
      (r) => a[0]({
        lengthComputable: l,
        total: i,
        loaded: r
      }),
      a[1]
    ];
  }, My = (i) => (...a) => q.asap(() => i(...a)), IS = St.hasStandardBrowserEnv ? /* @__PURE__ */ ((i, a) => (l) => (l = new URL(l, St.origin), i.protocol === l.protocol && i.host === l.host && (a || i.port === l.port)))(new URL(St.origin), St.navigator && /(msie|trident)/i.test(St.navigator.userAgent)) : () => true, WS = St.hasStandardBrowserEnv ? {
    write(i, a, l, r, c, f) {
      const d = [
        i + "=" + encodeURIComponent(a)
      ];
      q.isNumber(l) && d.push("expires=" + new Date(l).toGMTString()), q.isString(r) && d.push("path=" + r), q.isString(c) && d.push("domain=" + c), f === true && d.push("secure"), document.cookie = d.join("; ");
    },
    read(i) {
      const a = document.cookie.match(new RegExp("(^|;\\s*)(" + i + ")=([^;]*)"));
      return a ? decodeURIComponent(a[3]) : null;
    },
    remove(i) {
      this.write(i, "", Date.now() - 864e5);
    }
  } : {
    write() {
    },
    read() {
      return null;
    },
    remove() {
    }
  };
  function PS(i) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(i);
  }
  function ew(i, a) {
    return a ? i.replace(/\/?\/$/, "") + "/" + a.replace(/^\/+/, "") : i;
  }
  function Jp(i, a, l) {
    let r = !PS(a);
    return i && (r || l == false) ? ew(i, a) : a;
  }
  const Dy = (i) => i instanceof Mt ? {
    ...i
  } : i;
  function ti(i, a) {
    a = a || {};
    const l = {};
    function r(y, p, b, S) {
      return q.isPlainObject(y) && q.isPlainObject(p) ? q.merge.call({
        caseless: S
      }, y, p) : q.isPlainObject(p) ? q.merge({}, p) : q.isArray(p) ? p.slice() : p;
    }
    function c(y, p, b, S) {
      if (q.isUndefined(p)) {
        if (!q.isUndefined(y)) return r(void 0, y, b, S);
      } else return r(y, p, b, S);
    }
    function f(y, p) {
      if (!q.isUndefined(p)) return r(void 0, p);
    }
    function d(y, p) {
      if (q.isUndefined(p)) {
        if (!q.isUndefined(y)) return r(void 0, y);
      } else return r(void 0, p);
    }
    function h(y, p, b) {
      if (b in a) return r(y, p);
      if (b in i) return r(void 0, y);
    }
    const g = {
      url: f,
      method: f,
      data: f,
      baseURL: d,
      transformRequest: d,
      transformResponse: d,
      paramsSerializer: d,
      timeout: d,
      timeoutMessage: d,
      withCredentials: d,
      withXSRFToken: d,
      adapter: d,
      responseType: d,
      xsrfCookieName: d,
      xsrfHeaderName: d,
      onUploadProgress: d,
      onDownloadProgress: d,
      decompress: d,
      maxContentLength: d,
      maxBodyLength: d,
      beforeRedirect: d,
      transport: d,
      httpAgent: d,
      httpsAgent: d,
      cancelToken: d,
      socketPath: d,
      responseEncoding: d,
      validateStatus: h,
      headers: (y, p, b) => c(Dy(y), Dy(p), b, true)
    };
    return q.forEach(Object.keys(Object.assign({}, i, a)), function(y) {
      const p = g[y] || c, b = p(i[y], a[y], y);
      q.isUndefined(b) && p !== h || (l[y] = b);
    }), l;
  }
  const Ip = (i) => {
    const a = ti({}, i);
    let { data: l, withXSRFToken: r, xsrfHeaderName: c, xsrfCookieName: f, headers: d, auth: h } = a;
    a.headers = d = Mt.from(d), a.url = Fp(Jp(a.baseURL, a.url, a.allowAbsoluteUrls), i.params, i.paramsSerializer), h && d.set("Authorization", "Basic " + btoa((h.username || "") + ":" + (h.password ? unescape(encodeURIComponent(h.password)) : "")));
    let g;
    if (q.isFormData(l)) {
      if (St.hasStandardBrowserEnv || St.hasStandardBrowserWebWorkerEnv) d.setContentType(void 0);
      else if ((g = d.getContentType()) !== false) {
        const [y, ...p] = g ? g.split(";").map((b) => b.trim()).filter(Boolean) : [];
        d.setContentType([
          y || "multipart/form-data",
          ...p
        ].join("; "));
      }
    }
    if (St.hasStandardBrowserEnv && (r && q.isFunction(r) && (r = r(a)), r || r !== false && IS(a.url))) {
      const y = c && f && WS.read(f);
      y && d.set(c, y);
    }
    return a;
  }, tw = typeof XMLHttpRequest < "u", nw = tw && function(i) {
    return new Promise(function(a, l) {
      const r = Ip(i);
      let c = r.data;
      const f = Mt.from(r.headers).normalize();
      let { responseType: d, onUploadProgress: h, onDownloadProgress: g } = r, y, p, b, S, x;
      function v() {
        S && S(), x && x(), r.cancelToken && r.cancelToken.unsubscribe(y), r.signal && r.signal.removeEventListener("abort", y);
      }
      let A = new XMLHttpRequest();
      A.open(r.method.toUpperCase(), r.url, true), A.timeout = r.timeout;
      function j() {
        if (!A) return;
        const B = Mt.from("getAllResponseHeaders" in A && A.getAllResponseHeaders()), D = {
          data: !d || d === "text" || d === "json" ? A.responseText : A.response,
          status: A.status,
          statusText: A.statusText,
          headers: B,
          config: i,
          request: A
        };
        $p(function(I) {
          a(I), v();
        }, function(I) {
          l(I), v();
        }, D), A = null;
      }
      "onloadend" in A ? A.onloadend = j : A.onreadystatechange = function() {
        !A || A.readyState !== 4 || A.status === 0 && !(A.responseURL && A.responseURL.indexOf("file:") === 0) || setTimeout(j);
      }, A.onabort = function() {
        A && (l(new ge("Request aborted", ge.ECONNABORTED, i, A)), A = null);
      }, A.onerror = function() {
        l(new ge("Network Error", ge.ERR_NETWORK, i, A)), A = null;
      }, A.ontimeout = function() {
        let B = r.timeout ? "timeout of " + r.timeout + "ms exceeded" : "timeout exceeded";
        const D = r.transitional || Qp;
        r.timeoutErrorMessage && (B = r.timeoutErrorMessage), l(new ge(B, D.clarifyTimeoutError ? ge.ETIMEDOUT : ge.ECONNABORTED, i, A)), A = null;
      }, c === void 0 && f.setContentType(null), "setRequestHeader" in A && q.forEach(f.toJSON(), function(B, D) {
        A.setRequestHeader(D, B);
      }), q.isUndefined(r.withCredentials) || (A.withCredentials = !!r.withCredentials), d && d !== "json" && (A.responseType = r.responseType), g && ([b, x] = to(g, true), A.addEventListener("progress", b)), h && A.upload && ([p, S] = to(h), A.upload.addEventListener("progress", p), A.upload.addEventListener("loadend", S)), (r.cancelToken || r.signal) && (y = (B) => {
        A && (l(!B || B.type ? new as(null, i, A) : B), A.abort(), A = null);
      }, r.cancelToken && r.cancelToken.subscribe(y), r.signal && (r.signal.aborted ? y() : r.signal.addEventListener("abort", y)));
      const L = KS(r.url);
      if (L && St.protocols.indexOf(L) === -1) {
        l(new ge("Unsupported protocol " + L + ":", ge.ERR_BAD_REQUEST, i));
        return;
      }
      A.send(c || null);
    });
  }, aw = (i, a) => {
    const { length: l } = i = i ? i.filter(Boolean) : [];
    if (a || l) {
      let r = new AbortController(), c;
      const f = function(y) {
        if (!c) {
          c = true, h();
          const p = y instanceof Error ? y : this.reason;
          r.abort(p instanceof ge ? p : new as(p instanceof Error ? p.message : p));
        }
      };
      let d = a && setTimeout(() => {
        d = null, f(new ge(`timeout ${a} of ms exceeded`, ge.ETIMEDOUT));
      }, a);
      const h = () => {
        i && (d && clearTimeout(d), d = null, i.forEach((y) => {
          y.unsubscribe ? y.unsubscribe(f) : y.removeEventListener("abort", f);
        }), i = null);
      };
      i.forEach((y) => y.addEventListener("abort", f));
      const { signal: g } = r;
      return g.unsubscribe = () => q.asap(h), g;
    }
  }, iw = function* (i, a) {
    let l = i.byteLength;
    if (l < a) {
      yield i;
      return;
    }
    let r = 0, c;
    for (; r < l; ) c = r + a, yield i.slice(r, c), r = c;
  }, sw = async function* (i, a) {
    for await (const l of lw(i)) yield* iw(l, a);
  }, lw = async function* (i) {
    if (i[Symbol.asyncIterator]) {
      yield* i;
      return;
    }
    const a = i.getReader();
    try {
      for (; ; ) {
        const { done: l, value: r } = await a.read();
        if (l) break;
        yield r;
      }
    } finally {
      await a.cancel();
    }
  }, Uy = (i, a, l, r) => {
    const c = sw(i, a);
    let f = 0, d, h = (g) => {
      d || (d = true, r && r(g));
    };
    return new ReadableStream({
      async pull(g) {
        try {
          const { done: y, value: p } = await c.next();
          if (y) {
            h(), g.close();
            return;
          }
          let b = p.byteLength;
          if (l) {
            let S = f += b;
            l(S);
          }
          g.enqueue(new Uint8Array(p));
        } catch (y) {
          throw h(y), y;
        }
      },
      cancel(g) {
        return h(g), c.return();
      }
    }, {
      highWaterMark: 2
    });
  }, fo = typeof fetch == "function" && typeof Request == "function" && typeof Response == "function", Wp = fo && typeof ReadableStream == "function", rw = fo && (typeof TextEncoder == "function" ? /* @__PURE__ */ ((i) => (a) => i.encode(a))(new TextEncoder()) : async (i) => new Uint8Array(await new Response(i).arrayBuffer())), Pp = (i, ...a) => {
    try {
      return !!i(...a);
    } catch {
      return false;
    }
  }, ow = Wp && Pp(() => {
    let i = false;
    const a = new Request(St.origin, {
      body: new ReadableStream(),
      method: "POST",
      get duplex() {
        return i = true, "half";
      }
    }).headers.has("Content-Type");
    return i && !a;
  }), zy = 64 * 1024, vf = Wp && Pp(() => q.isReadableStream(new Response("").body)), no = {
    stream: vf && ((i) => i.body)
  };
  fo && ((i) => {
    [
      "text",
      "arrayBuffer",
      "blob",
      "formData",
      "stream"
    ].forEach((a) => {
      !no[a] && (no[a] = q.isFunction(i[a]) ? (l) => l[a]() : (l, r) => {
        throw new ge(`Response type '${a}' is not supported`, ge.ERR_NOT_SUPPORT, r);
      });
    });
  })(new Response());
  const cw = async (i) => {
    if (i == null) return 0;
    if (q.isBlob(i)) return i.size;
    if (q.isSpecCompliantForm(i)) return (await new Request(St.origin, {
      method: "POST",
      body: i
    }).arrayBuffer()).byteLength;
    if (q.isArrayBufferView(i) || q.isArrayBuffer(i)) return i.byteLength;
    if (q.isURLSearchParams(i) && (i = i + ""), q.isString(i)) return (await rw(i)).byteLength;
  }, uw = async (i, a) => q.toFiniteNumber(i.getContentLength()) ?? cw(a), fw = fo && (async (i) => {
    let { url: a, method: l, data: r, signal: c, cancelToken: f, timeout: d, onDownloadProgress: h, onUploadProgress: g, responseType: y, headers: p, withCredentials: b = "same-origin", fetchOptions: S } = Ip(i);
    y = y ? (y + "").toLowerCase() : "text";
    let x = aw([
      c,
      f && f.toAbortSignal()
    ], d), v;
    const A = x && x.unsubscribe && (() => {
      x.unsubscribe();
    });
    let j;
    try {
      if (g && ow && l !== "get" && l !== "head" && (j = await uw(p, r)) !== 0) {
        let ee = new Request(a, {
          method: "POST",
          body: r,
          duplex: "half"
        }), ae;
        if (q.isFormData(r) && (ae = ee.headers.get("content-type")) && p.setContentType(ae), ee.body) {
          const [be, le] = jy(j, to(My(g)));
          r = Uy(ee.body, zy, be, le);
        }
      }
      q.isString(b) || (b = b ? "include" : "omit");
      const L = "credentials" in Request.prototype;
      v = new Request(a, {
        ...S,
        signal: x,
        method: l.toUpperCase(),
        headers: p.normalize().toJSON(),
        body: r,
        duplex: "half",
        credentials: L ? b : void 0
      });
      let B = await fetch(v);
      const D = vf && (y === "stream" || y === "response");
      if (vf && (h || D && A)) {
        const ee = {};
        [
          "status",
          "statusText",
          "headers"
        ].forEach((W) => {
          ee[W] = B[W];
        });
        const ae = q.toFiniteNumber(B.headers.get("content-length")), [be, le] = h && jy(ae, to(My(h), true)) || [];
        B = new Response(Uy(B.body, zy, be, () => {
          le && le(), A && A();
        }), ee);
      }
      y = y || "text";
      let I = await no[q.findKey(no, y) || "text"](B, i);
      return !D && A && A(), await new Promise((ee, ae) => {
        $p(ee, ae, {
          data: I,
          headers: Mt.from(B.headers),
          status: B.status,
          statusText: B.statusText,
          config: i,
          request: v
        });
      });
    } catch (L) {
      throw A && A(), L && L.name === "TypeError" && /Load failed|fetch/i.test(L.message) ? Object.assign(new ge("Network Error", ge.ERR_NETWORK, i, v), {
        cause: L.cause || L
      }) : ge.from(L, L && L.code, i, v);
    }
  }), xf = {
    http: OS,
    xhr: nw,
    fetch: fw
  };
  q.forEach(xf, (i, a) => {
    if (i) {
      try {
        Object.defineProperty(i, "name", {
          value: a
        });
      } catch {
      }
      Object.defineProperty(i, "adapterName", {
        value: a
      });
    }
  });
  const ky = (i) => `- ${i}`, dw = (i) => q.isFunction(i) || i === null || i === false, eg = {
    getAdapter: (i) => {
      i = q.isArray(i) ? i : [
        i
      ];
      const { length: a } = i;
      let l, r;
      const c = {};
      for (let f = 0; f < a; f++) {
        l = i[f];
        let d;
        if (r = l, !dw(l) && (r = xf[(d = String(l)).toLowerCase()], r === void 0)) throw new ge(`Unknown adapter '${d}'`);
        if (r) break;
        c[d || "#" + f] = r;
      }
      if (!r) {
        const f = Object.entries(c).map(([h, g]) => `adapter ${h} ` + (g === false ? "is not supported by the environment" : "is not available in the build"));
        let d = a ? f.length > 1 ? `since :
` + f.map(ky).join(`
`) : " " + ky(f[0]) : "as no adapter specified";
        throw new ge("There is no suitable adapter to dispatch the request " + d, "ERR_NOT_SUPPORT");
      }
      return r;
    },
    adapters: xf
  };
  function Fu(i) {
    if (i.cancelToken && i.cancelToken.throwIfRequested(), i.signal && i.signal.aborted) throw new as(null, i);
  }
  function By(i) {
    return Fu(i), i.headers = Mt.from(i.headers), i.data = Xu.call(i, i.transformRequest), [
      "post",
      "put",
      "patch"
    ].indexOf(i.method) !== -1 && i.headers.setContentType("application/x-www-form-urlencoded", false), eg.getAdapter(i.adapter || wl.adapter)(i).then(function(a) {
      return Fu(i), a.data = Xu.call(i, i.transformResponse, a), a.headers = Mt.from(a.headers), a;
    }, function(a) {
      return Kp(a) || (Fu(i), a && a.response && (a.response.data = Xu.call(i, i.transformResponse, a.response), a.response.headers = Mt.from(a.response.headers))), Promise.reject(a);
    });
  }
  const tg = "1.9.0", ho = {};
  [
    "object",
    "boolean",
    "number",
    "function",
    "string",
    "symbol"
  ].forEach((i, a) => {
    ho[i] = function(l) {
      return typeof l === i || "a" + (a < 1 ? "n " : " ") + i;
    };
  });
  const Hy = {};
  ho.transitional = function(i, a, l) {
    function r(c, f) {
      return "[Axios v" + tg + "] Transitional option '" + c + "'" + f + (l ? ". " + l : "");
    }
    return (c, f, d) => {
      if (i === false) throw new ge(r(f, " has been removed" + (a ? " in " + a : "")), ge.ERR_DEPRECATED);
      return a && !Hy[f] && (Hy[f] = true, console.warn(r(f, " has been deprecated since v" + a + " and will be removed in the near future"))), i ? i(c, f, d) : true;
    };
  };
  ho.spelling = function(i) {
    return (a, l) => (console.warn(`${l} is likely a misspelling of ${i}`), true);
  };
  function hw(i, a, l) {
    if (typeof i != "object") throw new ge("options must be an object", ge.ERR_BAD_OPTION_VALUE);
    const r = Object.keys(i);
    let c = r.length;
    for (; c-- > 0; ) {
      const f = r[c], d = a[f];
      if (d) {
        const h = i[f], g = h === void 0 || d(h, f, i);
        if (g !== true) throw new ge("option " + f + " must be " + g, ge.ERR_BAD_OPTION_VALUE);
        continue;
      }
      if (l !== true) throw new ge("Unknown option " + f, ge.ERR_BAD_OPTION);
    }
  }
  const Zr = {
    assertOptions: hw,
    validators: ho
  }, pn = Zr.validators;
  let Wa = class {
    constructor(i) {
      this.defaults = i || {}, this.interceptors = {
        request: new Ny(),
        response: new Ny()
      };
    }
    async request(i, a) {
      try {
        return await this._request(i, a);
      } catch (l) {
        if (l instanceof Error) {
          let r = {};
          Error.captureStackTrace ? Error.captureStackTrace(r) : r = new Error();
          const c = r.stack ? r.stack.replace(/^.+\n/, "") : "";
          try {
            l.stack ? c && !String(l.stack).endsWith(c.replace(/^.+\n.+\n/, "")) && (l.stack += `
` + c) : l.stack = c;
          } catch {
          }
        }
        throw l;
      }
    }
    _request(i, a) {
      typeof i == "string" ? (a = a || {}, a.url = i) : a = i || {}, a = ti(this.defaults, a);
      const { transitional: l, paramsSerializer: r, headers: c } = a;
      l !== void 0 && Zr.assertOptions(l, {
        silentJSONParsing: pn.transitional(pn.boolean),
        forcedJSONParsing: pn.transitional(pn.boolean),
        clarifyTimeoutError: pn.transitional(pn.boolean)
      }, false), r != null && (q.isFunction(r) ? a.paramsSerializer = {
        serialize: r
      } : Zr.assertOptions(r, {
        encode: pn.function,
        serialize: pn.function
      }, true)), a.allowAbsoluteUrls !== void 0 || (this.defaults.allowAbsoluteUrls !== void 0 ? a.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls : a.allowAbsoluteUrls = true), Zr.assertOptions(a, {
        baseUrl: pn.spelling("baseURL"),
        withXsrfToken: pn.spelling("withXSRFToken")
      }, true), a.method = (a.method || this.defaults.method || "get").toLowerCase();
      let f = c && q.merge(c.common, c[a.method]);
      c && q.forEach([
        "delete",
        "get",
        "head",
        "post",
        "put",
        "patch",
        "common"
      ], (x) => {
        delete c[x];
      }), a.headers = Mt.concat(f, c);
      const d = [];
      let h = true;
      this.interceptors.request.forEach(function(x) {
        typeof x.runWhen == "function" && x.runWhen(a) === false || (h = h && x.synchronous, d.unshift(x.fulfilled, x.rejected));
      });
      const g = [];
      this.interceptors.response.forEach(function(x) {
        g.push(x.fulfilled, x.rejected);
      });
      let y, p = 0, b;
      if (!h) {
        const x = [
          By.bind(this),
          void 0
        ];
        for (x.unshift.apply(x, d), x.push.apply(x, g), b = x.length, y = Promise.resolve(a); p < b; ) y = y.then(x[p++], x[p++]);
        return y;
      }
      b = d.length;
      let S = a;
      for (p = 0; p < b; ) {
        const x = d[p++], v = d[p++];
        try {
          S = x(S);
        } catch (A) {
          v.call(this, A);
          break;
        }
      }
      try {
        y = By.call(this, S);
      } catch (x) {
        return Promise.reject(x);
      }
      for (p = 0, b = g.length; p < b; ) y = y.then(g[p++], g[p++]);
      return y;
    }
    getUri(i) {
      i = ti(this.defaults, i);
      const a = Jp(i.baseURL, i.url, i.allowAbsoluteUrls);
      return Fp(a, i.params, i.paramsSerializer);
    }
  };
  q.forEach([
    "delete",
    "get",
    "head",
    "options"
  ], function(i) {
    Wa.prototype[i] = function(a, l) {
      return this.request(ti(l || {}, {
        method: i,
        url: a,
        data: (l || {}).data
      }));
    };
  });
  q.forEach([
    "post",
    "put",
    "patch"
  ], function(i) {
    function a(l) {
      return function(r, c, f) {
        return this.request(ti(f || {}, {
          method: i,
          headers: l ? {
            "Content-Type": "multipart/form-data"
          } : {},
          url: r,
          data: c
        }));
      };
    }
    Wa.prototype[i] = a(), Wa.prototype[i + "Form"] = a(true);
  });
  let mw = class ng {
    constructor(a) {
      if (typeof a != "function") throw new TypeError("executor must be a function.");
      let l;
      this.promise = new Promise(function(c) {
        l = c;
      });
      const r = this;
      this.promise.then((c) => {
        if (!r._listeners) return;
        let f = r._listeners.length;
        for (; f-- > 0; ) r._listeners[f](c);
        r._listeners = null;
      }), this.promise.then = (c) => {
        let f;
        const d = new Promise((h) => {
          r.subscribe(h), f = h;
        }).then(c);
        return d.cancel = function() {
          r.unsubscribe(f);
        }, d;
      }, a(function(c, f, d) {
        r.reason || (r.reason = new as(c, f, d), l(r.reason));
      });
    }
    throwIfRequested() {
      if (this.reason) throw this.reason;
    }
    subscribe(a) {
      if (this.reason) {
        a(this.reason);
        return;
      }
      this._listeners ? this._listeners.push(a) : this._listeners = [
        a
      ];
    }
    unsubscribe(a) {
      if (!this._listeners) return;
      const l = this._listeners.indexOf(a);
      l !== -1 && this._listeners.splice(l, 1);
    }
    toAbortSignal() {
      const a = new AbortController(), l = (r) => {
        a.abort(r);
      };
      return this.subscribe(l), a.signal.unsubscribe = () => this.unsubscribe(l), a.signal;
    }
    static source() {
      let a;
      return {
        token: new ng(function(l) {
          a = l;
        }),
        cancel: a
      };
    }
  };
  function yw(i) {
    return function(a) {
      return i.apply(null, a);
    };
  }
  function pw(i) {
    return q.isObject(i) && i.isAxiosError === true;
  }
  const Sf = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511
  };
  Object.entries(Sf).forEach(([i, a]) => {
    Sf[a] = i;
  });
  function ag(i) {
    const a = new Wa(i), l = Dp(Wa.prototype.request, a);
    return q.extend(l, Wa.prototype, a, {
      allOwnKeys: true
    }), q.extend(l, a, null, {
      allOwnKeys: true
    }), l.create = function(r) {
      return ag(ti(i, r));
    }, l;
  }
  const $e = ag(wl);
  $e.Axios = Wa;
  $e.CanceledError = as;
  $e.CancelToken = mw;
  $e.isCancel = Kp;
  $e.VERSION = tg;
  $e.toFormData = uo;
  $e.AxiosError = ge;
  $e.Cancel = $e.CanceledError;
  $e.all = function(i) {
    return Promise.all(i);
  };
  $e.spread = yw;
  $e.isAxiosError = pw;
  $e.mergeConfig = ti;
  $e.AxiosHeaders = Mt;
  $e.formToJSON = (i) => Zp(q.isHTMLForm(i) ? new FormData(i) : i);
  $e.getAdapter = eg.getAdapter;
  $e.HttpStatusCode = Sf;
  $e.default = $e;
  const { Axios: VE, AxiosError: XE, CanceledError: FE, isCancel: QE, CancelToken: ZE, VERSION: KE, all: $E, Cancel: JE, isAxiosError: IE, spread: WE, toFormData: PE, AxiosHeaders: e3, HttpStatusCode: t3, formToJSON: n3, getAdapter: a3, mergeConfig: i3 } = $e;
  var Xi, Fi, cl, wf, Ef;
  class gw {
    constructor(a = {
      url: ""
    }) {
      ll(this, Xi), ll(this, Fi), ll(this, cl, false), ll(this, wf, async () => {
        let c = 0;
        return new Promise(async (f, d) => {
          const h = setInterval(async () => {
            c++, Vn(this, Fi) && (clearInterval(h), f(true)), c > 100 && d();
          }, 200);
        });
      }), ll(this, Ef, async (c, f) => {
        if (!c || c.trim() === "") return rt.warn("Creating new root document (no URL provided)"), f.create().documentId;
        try {
          const d = await $e.get(`${c}/.well-known/root.json`);
          if (!d.data) throw new Error("No data was returned from the url provided");
          const h = d.data.rootId;
          if (!h) throw new Error("No root was returned from the url provided");
          return await f.find(h).doc() ? h : (rt.warn("Creating new root document (url did not return a rootId)"), f.create().documentId);
        } catch (d) {
          throw console.error(d), new Error("unexpected error when fetching root document");
        }
      });
      const l = a.peerId || (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)), r = a.network || [];
      Lr(this, Xi, new _2({
        network: r.length > 0 ? r : void 0,
        storage: a.storage,
        peerId: l,
        sharePolicy: a.sharePolicy,
        isEphemeral: a.ephemeral
      })), Lr(this, Fi, void 0), Vn(this, Ef).call(this, a.url, Vn(this, Xi)).then((c) => {
        Lr(this, Fi, c), rt.info("Root document initialized");
      }).catch((c) => {
        rt.error("Failed to initialize root document:", c);
      }), rt.info("SyncEngine created successfully");
    }
    whenReady() {
      return new Promise(async (a) => {
        await Vn(this, Xi).networkSubsystem.whenReady(), await Vn(this, wf).call(this), Lr(this, cl, true), a();
      });
    }
    getRepo() {
      return Vn(this, cl) || rt.warn("getRepo() should not be called yet. Please await on SyncEngine.whenReady() to make sure initialization is complete."), Vn(this, Xi);
    }
    getRootId() {
      return Vn(this, cl) || rt.warn("getRootId() should not be called yet. Please await on SyncEngine.whenReady() to make sure initialization is complete."), Vn(this, Fi);
    }
  }
  Xi = /* @__PURE__ */ new WeakMap(), Fi = /* @__PURE__ */ new WeakMap(), cl = /* @__PURE__ */ new WeakMap(), wf = /* @__PURE__ */ new WeakMap(), Ef = /* @__PURE__ */ new WeakMap();
  const bw = (i, a) => {
    const l = i.getState(), r = JSON.stringify(gl(l)), c = JSON.stringify(gl(a));
    r !== c && i.setState((f) => {
      const d = {
        ...f
      };
      return Object.keys(a).forEach((h) => {
        h in a && (d[h] = a[h]);
      }), d;
    });
  };
  function gl(i) {
    if (!i || typeof i != "object") return i;
    const a = Array.isArray(i) ? [] : {};
    for (const l in i) {
      const r = i[l];
      typeof r != "function" && (r && typeof r == "object" ? a[l] = gl(r) : a[l] = r);
    }
    return a;
  }
  async function ig(i, a, l, r = false) {
    const c = l.startsWith("/") ? l.slice(1) : l, f = c ? c.split("/") : [];
    if (f.length === 0) {
      const b = i.find(a), S = await b.doc();
      if (!S && r) {
        b.change((v) => {
          v.type = "dir", v.name = "/", v.timestamps = {
            create: Date.now(),
            modified: Date.now()
          }, v.children = [];
        });
        const x = await b.doc();
        return x ? {
          nodeHandle: b,
          node: JSON.parse(JSON.stringify(x)),
          parentPath: ""
        } : void 0;
      } else if (!S) return;
      return {
        nodeHandle: b,
        node: JSON.parse(JSON.stringify(S)),
        parentPath: ""
      };
    }
    let d = a, h = i.find(d), g = await h.doc(), y = "";
    if (!g && r) {
      h.change((S) => {
        S.type = "dir", S.name = "/", S.timestamps = {
          create: Date.now(),
          modified: Date.now()
        }, S.children = [];
      });
      const b = await h.doc();
      if (!b) return;
      g = JSON.parse(JSON.stringify(b));
    } else if (g) g = JSON.parse(JSON.stringify(g));
    else return;
    let p;
    for (let b = 0; b < f.length; b++) {
      const S = f[b], x = b === f.length - 1;
      if (y += `/${S}`, !g.children && r) {
        h.change((j) => {
          j.children = [];
        });
        const A = await h.doc();
        if (!A) return;
        g = A;
      } else if (!g.children) return;
      let v = (g.children || []).find((A) => A.name === S);
      if (!v && r) {
        const A = i.create(), j = A.documentId;
        A.change((B) => {
          B.type = "dir", B.name = S, B.timestamps = {
            create: Date.now(),
            modified: Date.now()
          }, B.children = [];
        }), h.change((B) => {
          B.children || (B.children = []);
          const D = {
            name: S,
            type: "dir",
            pointer: j,
            timestamps: {
              create: Date.now(),
              modified: Date.now()
            }
          };
          B.children.push(D), B.timestamps && (B.timestamps.modified = Date.now());
        }), d = j, h = A;
        const L = await h.doc();
        if (!L) return;
        if (g = L, p = void 0, x) return {
          nodeHandle: h,
          node: JSON.parse(JSON.stringify(g)),
          parentPath: y
        };
      } else if (v) if (v.pointer) {
        if (p = v, x) return {
          nodeHandle: h,
          node: g,
          targetRef: v,
          parentPath: y
        };
        if (v.type === "dir") {
          d = v.pointer, h = i.find(d);
          const A = await h.doc();
          if (!A) return;
          g = JSON.parse(JSON.stringify(A));
        } else return;
      } else return;
      else return;
    }
    return {
      nodeHandle: h,
      node: JSON.parse(JSON.stringify(g)),
      targetRef: p,
      parentPath: y
    };
  }
  async function sg(i, a, l) {
    var _a7;
    const r = await ig(i, a, l);
    if (r && !(!r.targetRef || ((_a7 = r.targetRef) == null ? void 0 : _a7.type) === "dir")) return i.find(r.targetRef.pointer);
  }
  async function vw(i, a, l, r) {
    const c = (l.startsWith("/") ? l.slice(1) : l).split("/");
    if (c.length === 0 || c.length === 1 && c[0] === "") throw new Error("Cannot create document at root path");
    const f = c[c.length - 1], d = c.slice(0, -1).join("/"), h = await ig(i, a, d, true);
    if (!h) throw new Error(`Failed to create directory structure for ${l}`);
    let g;
    h.targetRef ? g = i.find(h.targetRef.pointer) : g = h.nodeHandle, g.change((y) => {
      y.children || (y.children = []);
      const p = y.children.findIndex((S) => S.name === f), b = {
        name: f,
        type: "doc",
        pointer: r.documentId,
        timestamps: {
          create: Date.now(),
          modified: Date.now()
        }
      };
      p >= 0 ? y.children[p] = b : y.children.push(b), y.timestamps && (y.timestamps.modified = Date.now());
    });
  }
  let Kr = null;
  function xw(i) {
    return Kr ? rt.warn("SyncEngine instance already exists. Ignoring new options.") : (rt.info("Creating new SyncEngine instance"), Kr = new gw(i)), Kr;
  }
  function lg() {
    return Kr || (rt.warn("Sync engine not created yet"), null);
  }
  function ul() {
    const i = lg();
    return i ? i.getRepo() : null;
  }
  function rg() {
    const i = lg();
    return i ? i.getRootId() : void 0;
  }
  const Kf = (i, a) => (l, r, c) => {
    let f = null, d = false;
    const h = i((v, A) => {
      if (l(v, A), !f || !d) return;
      const j = r();
      try {
        const L = gl(j);
        f.change((B) => {
          Object.assign(B, JSON.parse(JSON.stringify(L)));
        });
      } catch (L) {
        rt.warn(`Error updating document ${a.docId}:`, L);
      }
    }, r, c), g = (v) => {
      if (v) try {
        rt.debugWithContext("sync-middleware", "Received doc change, updating Zustand store:", v), bw(c, v);
      } catch (A) {
        rt.error(`Error handling document change for ${a.docId}:`, A);
      }
    };
    async function y() {
      if (d) return;
      const v = ul(), A = rg();
      if (!v) {
        rt.warn(`Cannot initialize sync for ${a.docId}: repo not available`);
        return;
      }
      try {
        let j = await sg(v, A, a.docId);
        j ? (f = j, await j.doc()) : (f = v.create(), vw(v, A, a.docId, f)), f == null ? void 0 : f.on("change", ({ doc: B }) => {
          B && g(B);
        });
        const L = f == null ? void 0 : f.docSync();
        if (L) g(L);
        else {
          const B = r(), D = gl(B);
          f == null ? void 0 : f.change((I) => {
            Object.assign(I, JSON.parse(JSON.stringify(D)));
          });
        }
        d = true, rt.debug(`Sync initialized for document ${a.docId}`);
      } catch (j) {
        rt.error(`Failed to initialize document ${a.docId}:`, j), a.onInitError && a.onInitError(j instanceof Error ? j : new Error(String(j)));
      }
    }
    const p = a.initTimeout ?? 3e4;
    let b = null, S = Date.now();
    if (typeof window < "u" && !window.__REPO_REGISTRY__) {
      window.__REPO_REGISTRY__ = {
        callbacks: [],
        notifyCallbacks: function() {
          const A = ul();
          A && (this.callbacks.forEach((j) => j(A)), this.callbacks = []);
        }
      };
      const v = setInterval(() => {
        ul() && window.__REPO_REGISTRY__ && (window.__REPO_REGISTRY__.notifyCallbacks(), clearInterval(v));
      }, 100);
    }
    const x = async () => {
      if (Date.now() - S > p) {
        b && (clearTimeout(b), b = null);
        const A = new Error(`Sync initialization timed out after ${p}ms for document ${a.docId}`);
        rt.error(A.message), a.onInitError && a.onInitError(A);
        return;
      }
      const v = ul();
      v && !d ? (rt.debug(`Repo available, initializing store for ${a.docId}`), await y(), b && (clearTimeout(b), b = null)) : v || (typeof window < "u" && window.__REPO_REGISTRY__ ? (window.__REPO_REGISTRY__.callbacks.push(async () => {
        d || (rt.debug(`Repo became available, initializing store for ${a.docId}`), await y());
      }), b = setTimeout(x, 1e3)) : b = setTimeout(x, 100));
    };
    return x(), {
      ...h
    };
  }, Sw = () => {
    const i = ul(), a = rg();
    if (!i || !a) throw new Error("SyncEngine is not properly initialized");
    return {
      repo: i,
      root: a
    };
  }, ww = async (i) => {
    const { repo: a, root: l } = Sw(), r = await sg(a, l, i);
    if (r) return await r.doc();
  }, Ew = () => Math.random().toString(36).substring(2, 15), Aw = () => localStorage.getItem("activeProfileId"), wa = Of(Kf((i) => ({
    profiles: [],
    activeProfileId: Aw(),
    createProfile: (a) => {
      const l = Ew(), r = {
        id: l,
        name: a,
        createdAt: Date.now()
      };
      return i((c) => ({
        profiles: [
          ...c.profiles,
          r
        ]
      })), Fn.getState().updateUserName(l, a), r;
    },
    setActiveProfile: (a) => {
      localStorage.setItem("activeProfileId", a), i({
        activeProfileId: a
      });
    },
    updateProfileName: (a, l) => {
      i((r) => ({
        profiles: r.profiles.map((c) => c.id === a ? {
          ...c,
          name: l
        } : c)
      })), Fn.getState().updateUserName(a, l);
    },
    deleteProfile: (a) => {
      i((l) => {
        const r = l.profiles.filter((f) => f.id !== a), c = l.activeProfileId === a ? r.length > 0 ? r[0].id : null : l.activeProfileId;
        return c !== l.activeProfileId && (c ? localStorage.setItem("activeProfileId", c) : localStorage.removeItem("activeProfileId")), {
          profiles: r,
          activeProfileId: c
        };
      });
    }
  }), {
    docId: "my-world-users",
    initTimeout: 3e4,
    onInitError: (i) => console.error("User sync initialization error:", i)
  })), Ly = () => Math.random().toString(36).substring(2, 15), Fn = Of(Kf((i) => ({
    locations: {},
    userNames: {},
    addLocation: (a) => {
      i((l) => {
        const r = Ly(), c = wa.getState(), f = c.activeProfileId;
        if (!f) return console.error("No active user profile found"), l;
        const d = c.profiles.find((y) => y.id === f);
        if (!d) return console.error("Active profile not found"), l;
        const h = {
          ...l.userNames,
          [f]: d.name
        }, g = {
          ...a,
          id: r,
          addedBy: f,
          createdAt: Date.now()
        };
        return {
          locations: {
            ...l.locations,
            [r]: g
          },
          userNames: h
        };
      });
    },
    updateUserName: (a, l) => {
      i((r) => ({
        userNames: {
          ...r.userNames,
          [a]: l
        }
      }));
    },
    removeLocation: (a) => {
      i((l) => {
        const r = {
          ...l.locations
        };
        return delete r[a], {
          locations: r
        };
      });
    },
    updateLocation: (a, l) => {
      i((r) => r.locations[a] ? {
        locations: {
          ...r.locations,
          [a]: {
            ...r.locations[a],
            ...l
          }
        }
      } : r);
    },
    addReview: (a, l, r) => {
      i((c) => {
        if (!c.locations[a]) return c;
        const d = wa.getState().activeProfileId;
        if (!d) return console.error("No active user profile found"), c;
        const g = {
          id: Ly(),
          userId: d,
          rating: l,
          comment: r,
          createdAt: Date.now()
        }, y = c.locations[a], p = y.reviews ? [
          ...y.reviews,
          g
        ] : [
          g
        ];
        return {
          locations: {
            ...c.locations,
            [a]: {
              ...y,
              reviews: p
            }
          }
        };
      });
    },
    removeReview: (a, l) => {
      i((r) => {
        var _a7;
        if (!r.locations[a] || !r.locations[a].reviews) return r;
        const c = r.locations[a], f = (_a7 = c.reviews) == null ? void 0 : _a7.filter((d) => d.id !== l);
        return {
          locations: {
            ...r.locations,
            [a]: {
              ...c,
              reviews: f
            }
          }
        };
      });
    }
  }), {
    docId: "my-world-locations",
    initTimeout: 3e4,
    onInitError: (i) => console.error("Location sync initialization error:", i)
  })), Tw = () => Math.random().toString(36).substring(2, 15), Ow = [
    {
      id: "default",
      name: "General",
      color: "#8E8E93",
      icon: "map-pin",
      createdBy: "system"
    },
    {
      id: "favorite",
      name: "Favorites",
      color: "#FF9500",
      icon: "star",
      createdBy: "system"
    },
    {
      id: "food",
      name: "Food & Drink",
      color: "#FF2D55",
      icon: "utensils",
      createdBy: "system"
    },
    {
      id: "shopping",
      name: "Shopping",
      color: "#5AC8FA",
      icon: "shopping-bag",
      createdBy: "system"
    },
    {
      id: "nature",
      name: "Nature",
      color: "#34C759",
      icon: "tree",
      createdBy: "system"
    },
    {
      id: "culture",
      name: "Culture",
      color: "#AF52DE",
      icon: "landmark",
      createdBy: "system"
    }
  ], og = Of(Kf((i, a) => ({
    categories: Ow.reduce((l, r) => (l[r.id] = r, l), {}),
    addCategory: (l, r, c) => {
      const f = Tw(), d = wa.getState().activeProfileId;
      if (!d) throw console.error("No active user profile found"), new Error("No active user profile found");
      const h = {
        id: f,
        name: l,
        color: r,
        icon: c === void 0 ? null : c,
        createdBy: d
      };
      return i((g) => ({
        categories: {
          ...g.categories,
          [f]: h
        }
      })), h;
    },
    updateCategory: (l, r) => {
      i((c) => {
        if (!c.categories[l]) return c;
        if (c.categories[l].createdBy === "system") return console.warn("Cannot modify system categories"), c;
        const f = {
          ...r
        };
        return "icon" in f && f.icon === void 0 && (f.icon = null), {
          categories: {
            ...c.categories,
            [l]: {
              ...c.categories[l],
              ...f
            }
          }
        };
      });
    },
    deleteCategory: (l) => {
      i((r) => {
        var _a7;
        if (((_a7 = r.categories[l]) == null ? void 0 : _a7.createdBy) === "system") return console.warn("Cannot delete system categories"), r;
        const c = {
          ...r.categories
        };
        return delete c[l], {
          categories: c
        };
      });
    }
  }), {
    docId: "my-world-categories",
    initTimeout: 3e4,
    onInitError: (i) => console.error("Category sync initialization error:", i)
  }));
  const Cw = (i) => i.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), cg = (...i) => i.filter((a, l, r) => !!a && a.trim() !== "" && r.indexOf(a) === l).join(" ").trim();
  var _w = {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  };
  const Nw = ue.forwardRef(({ color: i = "currentColor", size: a = 24, strokeWidth: l = 2, absoluteStrokeWidth: r, className: c = "", children: f, iconNode: d, ...h }, g) => ue.createElement("svg", {
    ref: g,
    ..._w,
    width: a,
    height: a,
    stroke: i,
    strokeWidth: r ? Number(l) * 24 / Number(a) : l,
    className: cg("lucide", c),
    ...h
  }, [
    ...d.map(([y, p]) => ue.createElement(y, p)),
    ...Array.isArray(f) ? f : [
      f
    ]
  ]));
  const tt = (i, a) => {
    const l = ue.forwardRef(({ className: r, ...c }, f) => ue.createElement(Nw, {
      ref: f,
      iconNode: a,
      className: cg(`lucide-${Cw(i)}`, r),
      ...c
    }));
    return l.displayName = `${i}`, l;
  };
  const Rw = [
    [
      "path",
      {
        d: "m15 18-6-6 6-6",
        key: "1wnfg3"
      }
    ]
  ], jw = tt("ChevronLeft", Rw);
  const Mw = [
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ],
    [
      "line",
      {
        x1: "12",
        x2: "12",
        y1: "8",
        y2: "12",
        key: "1pkeuh"
      }
    ],
    [
      "line",
      {
        x1: "12",
        x2: "12.01",
        y1: "16",
        y2: "16",
        key: "4dfq90"
      }
    ]
  ], Dw = tt("CircleAlert", Mw);
  const Uw = [
    [
      "path",
      {
        d: "M21.801 10A10 10 0 1 1 17 3.335",
        key: "yps3ct"
      }
    ],
    [
      "path",
      {
        d: "m9 11 3 3L22 4",
        key: "1pflzl"
      }
    ]
  ], zw = tt("CircleCheckBig", Uw);
  const kw = [
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ],
    [
      "polyline",
      {
        points: "12 6 12 12 16 14",
        key: "68esgv"
      }
    ]
  ], Bw = tt("Clock", kw);
  const Hw = [
    [
      "path",
      {
        d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
        key: "ih7n3h"
      }
    ],
    [
      "polyline",
      {
        points: "7 10 12 15 17 10",
        key: "2ggqvy"
      }
    ],
    [
      "line",
      {
        x1: "12",
        x2: "12",
        y1: "15",
        y2: "3",
        key: "1vk2je"
      }
    ]
  ], Lw = tt("Download", Hw);
  const qw = [
    [
      "polygon",
      {
        points: "22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3",
        key: "1yg77f"
      }
    ]
  ], Yw = tt("Filter", qw);
  const Gw = [
    [
      "circle",
      {
        cx: "12",
        cy: "12",
        r: "10",
        key: "1mglay"
      }
    ],
    [
      "path",
      {
        d: "M12 16v-4",
        key: "1dtifu"
      }
    ],
    [
      "path",
      {
        d: "M12 8h.01",
        key: "e9boi3"
      }
    ]
  ], qy = tt("Info", Gw);
  const Vw = [
    [
      "path",
      {
        d: "M12 2v4",
        key: "3427ic"
      }
    ],
    [
      "path",
      {
        d: "m16.2 7.8 2.9-2.9",
        key: "r700ao"
      }
    ],
    [
      "path",
      {
        d: "M18 12h4",
        key: "wj9ykh"
      }
    ],
    [
      "path",
      {
        d: "m16.2 16.2 2.9 2.9",
        key: "1bxg5t"
      }
    ],
    [
      "path",
      {
        d: "M12 18v4",
        key: "jadmvz"
      }
    ],
    [
      "path",
      {
        d: "m4.9 19.1 2.9-2.9",
        key: "bwix9q"
      }
    ],
    [
      "path",
      {
        d: "M2 12h4",
        key: "j09sii"
      }
    ],
    [
      "path",
      {
        d: "m4.9 4.9 2.9 2.9",
        key: "giyufr"
      }
    ]
  ], ug = tt("Loader", Vw);
  const Xw = [
    [
      "path",
      {
        d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
        key: "1r0f0z"
      }
    ],
    [
      "circle",
      {
        cx: "12",
        cy: "10",
        r: "3",
        key: "ilqhr7"
      }
    ]
  ], qr = tt("MapPin", Xw);
  const Fw = [
    [
      "line",
      {
        x1: "4",
        x2: "20",
        y1: "12",
        y2: "12",
        key: "1e0a9i"
      }
    ],
    [
      "line",
      {
        x1: "4",
        x2: "20",
        y1: "6",
        y2: "6",
        key: "1owob3"
      }
    ],
    [
      "line",
      {
        x1: "4",
        x2: "20",
        y1: "18",
        y2: "18",
        key: "yk5zj1"
      }
    ]
  ], Qw = tt("Menu", Fw);
  const Zw = [
    [
      "path",
      {
        d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
        key: "1lielz"
      }
    ]
  ], Kw = tt("MessageSquare", Zw);
  const $w = [
    [
      "path",
      {
        d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
        key: "1a8usu"
      }
    ]
  ], fg = tt("Pen", $w);
  const Jw = [
    [
      "path",
      {
        d: "M5 12h14",
        key: "1ays0h"
      }
    ],
    [
      "path",
      {
        d: "M12 5v14",
        key: "s699le"
      }
    ]
  ], dg = tt("Plus", Jw);
  const Iw = [
    [
      "circle",
      {
        cx: "11",
        cy: "11",
        r: "8",
        key: "4ej97u"
      }
    ],
    [
      "path",
      {
        d: "m21 21-4.3-4.3",
        key: "1qie3q"
      }
    ]
  ], Ww = tt("Search", Iw);
  const Pw = [
    [
      "path",
      {
        d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
        key: "r04s7s"
      }
    ]
  ], Qu = tt("Star", Pw);
  const eE = [
    [
      "path",
      {
        d: "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",
        key: "vktsd0"
      }
    ],
    [
      "circle",
      {
        cx: "7.5",
        cy: "7.5",
        r: ".5",
        fill: "currentColor",
        key: "kqv944"
      }
    ]
  ], tE = tt("Tag", eE);
  const nE = [
    [
      "path",
      {
        d: "M3 6h18",
        key: "d0wm0j"
      }
    ],
    [
      "path",
      {
        d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",
        key: "4alrt4"
      }
    ],
    [
      "path",
      {
        d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",
        key: "v07s0e"
      }
    ],
    [
      "line",
      {
        x1: "10",
        x2: "10",
        y1: "11",
        y2: "17",
        key: "1uufr5"
      }
    ],
    [
      "line",
      {
        x1: "14",
        x2: "14",
        y1: "11",
        y2: "17",
        key: "xtxkd"
      }
    ]
  ], hg = tt("Trash2", nE);
  const aE = [
    [
      "path",
      {
        d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",
        key: "975kel"
      }
    ],
    [
      "circle",
      {
        cx: "12",
        cy: "7",
        r: "4",
        key: "17ys0d"
      }
    ]
  ], Af = tt("User", aE);
  const iE = [
    [
      "path",
      {
        d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",
        key: "1yyitq"
      }
    ],
    [
      "circle",
      {
        cx: "9",
        cy: "7",
        r: "4",
        key: "nufk8"
      }
    ],
    [
      "path",
      {
        d: "M22 21v-2a4 4 0 0 0-3-3.87",
        key: "kshegd"
      }
    ],
    [
      "path",
      {
        d: "M16 3.13a4 4 0 0 1 0 7.75",
        key: "1da9ce"
      }
    ]
  ], sE = tt("Users", iE);
  const lE = [
    [
      "path",
      {
        d: "M18 6 6 18",
        key: "1bl5f8"
      }
    ],
    [
      "path",
      {
        d: "m6 6 12 12",
        key: "d8bk6v"
      }
    ]
  ], rE = tt("X", lE), mg = async (i) => {
    if (!i) return console.warn("No place ID provided to fetch business hours"), null;
    try {
      return console.error("Google Maps API key not found in environment variables"), null;
    } catch (a) {
      return console.error("Error fetching business hours:", a), null;
    }
  }, oE = async () => {
    const i = Fn.getState(), a = i.locations, l = 5, r = Object.keys(a).filter((c) => a[c].placeId);
    for (let c = 0; c < r.length; c += l) {
      const f = r.slice(c, c + l);
      await Promise.all(f.map(async (d) => {
        const h = a[d];
        if (h.placeId) try {
          const g = await mg(h.placeId);
          g && i.updateLocation(d, {
            isOpen: g.isOpen
          });
        } catch (g) {
          console.error(`Error updating open status for location ${d}:`, g);
        }
      })), c + l < r.length && await new Promise((d) => setTimeout(d, 1e3));
    }
  }, cE = async (i) => {
    const a = Fn.getState(), l = a.locations[i];
    if (!l || !l.placeId) return console.warn(`Location ${i} not found or has no place ID`), null;
    try {
      const r = await mg(l.placeId);
      return r ? (a.updateLocation(i, {
        isOpen: r.isOpen
      }), r) : null;
    } catch (r) {
      return console.error(`Error fetching business hours for location ${i}:`, r), null;
    }
  }, uE = ({ onPlaceSelect: i }) => {
    const [a, l] = ue.useState(""), [r, c] = ue.useState([]), [f, d] = ue.useState(false), [h, g] = ue.useState(false), y = ue.useRef(null), p = ue.useRef(null);
    ue.useEffect(() => {
      window.mapkit && !p.current && (p.current = new window.mapkit.Search());
    }, []), ue.useEffect(() => {
      const v = (A) => {
        y.current && !y.current.contains(A.target) && g(false);
      };
      return document.addEventListener("mousedown", v), () => {
        document.removeEventListener("mousedown", v);
      };
    }, []);
    const b = (v) => {
      if (!v.trim() || !window.mapkit) {
        c([]);
        return;
      }
      d(true), p.current || (p.current = new window.mapkit.Search({
        includePointsOfInterest: true,
        includeAddresses: true,
        includePhysicalFeatures: true,
        autocomplete: true
      })), p.current.search(v, (A, j) => {
        if (d(false), A) {
          console.error("Apple Maps search error:", A), c([]);
          return;
        }
        if (j && j.places) {
          const L = j.places.map((B) => ({
            displayLines: B.displayLines || [
              B.name
            ],
            coordinate: B.coordinate,
            name: B.name,
            formattedAddress: B.formattedAddress,
            placeId: B.id,
            category: B.pointOfInterestCategory || ""
          }));
          c(L);
        } else c([]);
      });
    };
    ue.useEffect(() => {
      const v = setTimeout(() => {
        a ? b(a) : c([]);
      }, 300);
      return () => clearTimeout(v);
    }, [
      a
    ]);
    const S = (v) => {
      i(v.coordinate.latitude, v.coordinate.longitude, v.name, v.placeId, v.place), l(""), c([]);
    }, x = (v) => v.includes("restaurant") || v.includes("food") ? "\u{1F37D}\uFE0F" : v.includes("hotel") || v.includes("lodging") ? "\u{1F3E8}" : v.includes("airport") || v.includes("transportation") ? "\u2708\uFE0F" : v.includes("shopping") || v.includes("store") ? "\u{1F6CD}\uFE0F" : v.includes("park") || v.includes("outdoor") ? "\u{1F333}" : "\u{1F4CD}";
    return E.jsxs("div", {
      ref: y,
      className: "relative search-container w-full max-w-md",
      children: [
        E.jsxs("div", {
          className: `flex items-center bg-white rounded-full shadow-lg transition-all duration-200 ${h ? "ring-2 ring-blue-400" : ""}`,
          style: {
            boxShadow: "0 2px 12px rgba(0, 0, 0, 0.15)",
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)"
          },
          children: [
            E.jsx("div", {
              className: "pl-4 pr-2 text-gray-500",
              children: E.jsx(Ww, {
                size: 16
              })
            }),
            E.jsx("input", {
              type: "text",
              value: a,
              onChange: (v) => l(v.target.value),
              onFocus: () => g(true),
              placeholder: "Search Maps",
              className: "py-3 px-1 w-full outline-none rounded-full text-sm font-medium",
              "aria-label": "Search for a place"
            }),
            f ? E.jsx("div", {
              className: "px-4 text-gray-400",
              children: E.jsx(ug, {
                size: 16,
                className: "animate-spin"
              })
            }) : a && E.jsx("button", {
              className: "px-4 text-gray-400 hover:text-gray-600 transition-colors",
              onClick: () => l(""),
              "aria-label": "Clear search",
              children: E.jsx(rE, {
                size: 16
              })
            })
          ]
        }),
        r.length > 0 && E.jsx("div", {
          className: "absolute w-full mt-2 bg-white rounded-xl max-h-80 overflow-y-auto search-results z-10",
          style: {
            boxShadow: "0 4px 20px rgba(0, 0, 0, 0.15)",
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)",
            border: "none"
          },
          children: r.map((v, A) => E.jsxs("div", {
            className: "px-4 py-3 hover:bg-gray-50 cursor-pointer transition-colors duration-150 border-b border-gray-100 last:border-b-0 flex items-start",
            onClick: () => S(v),
            children: [
              E.jsx("div", {
                className: "mr-3 mt-1 text-lg",
                children: x(v.category || "")
              }),
              E.jsxs("div", {
                className: "flex-1",
                children: [
                  E.jsx("div", {
                    className: "font-medium text-sm",
                    children: v.name
                  }),
                  E.jsx("div", {
                    className: "text-xs text-gray-500 mt-0.5 line-clamp-2",
                    children: v.formattedAddress || v.displayLines.join(", ")
                  })
                ]
              })
            ]
          }, A))
        })
      ]
    });
  }, fE = 100, dE = ({ onShowCommonLocations: i }) => {
    const { locations: a } = Fn(), l = Fn((y) => y.userNames), { activeProfileId: r } = wa(), [c, f] = ue.useState(""), d = Object.values(a).reduce((y, p) => (!y.includes(p.addedBy) && p.addedBy !== r && y.push(p.addedBy), y), []), h = (y, p, b, S) => {
      const v = y * Math.PI / 180, A = b * Math.PI / 180, j = (b - y) * Math.PI / 180, L = (S - p) * Math.PI / 180, B = Math.sin(j / 2) * Math.sin(j / 2) + Math.cos(v) * Math.cos(A) * Math.sin(L / 2) * Math.sin(L / 2);
      return 6371e3 * (2 * Math.atan2(Math.sqrt(B), Math.sqrt(1 - B)));
    }, g = () => {
      if (!c || !r) return;
      const y = Object.values(a).filter((x) => x.addedBy === r), p = Object.values(a).filter((x) => x.addedBy === c), b = [];
      y.forEach((x) => {
        p.forEach((v) => {
          h(x.latitude, x.longitude, v.latitude, v.longitude) <= fE && b.push(x.id, v.id);
        });
      });
      const S = [
        ...new Set(b)
      ];
      i(S);
    };
    return E.jsxs("div", {
      className: "mb-6 p-4 bg-gray-50 rounded-lg",
      children: [
        E.jsxs("h3", {
          className: "font-semibold mb-3 flex items-center gap-2",
          children: [
            E.jsx(sE, {
              className: "h-4 w-4"
            }),
            "Compare Places"
          ]
        }),
        d.length === 0 ? E.jsx("p", {
          className: "text-sm text-gray-500",
          children: "No other users have added locations yet"
        }) : E.jsxs(E.Fragment, {
          children: [
            E.jsxs("div", {
              className: "mb-3",
              children: [
                E.jsx("label", {
                  htmlFor: "user-select",
                  className: "text-sm font-medium block mb-1",
                  children: "Select user to compare with:"
                }),
                E.jsxs("select", {
                  id: "user-select",
                  value: c,
                  onChange: (y) => f(y.target.value),
                  className: "w-full px-3 py-2 border rounded-md",
                  children: [
                    E.jsx("option", {
                      value: "",
                      children: "Select a user"
                    }),
                    d.map((y) => E.jsx("option", {
                      value: y,
                      children: l[y] || "Anonymous"
                    }, y))
                  ]
                })
              ]
            }),
            E.jsx("button", {
              onClick: g,
              disabled: !c,
              className: `w-full py-2 rounded-md text-white text-sm ${c ? "bg-blue-500 hover:bg-blue-600" : "bg-gray-300 cursor-not-allowed"}`,
              children: "Show Common Places"
            })
          ]
        })
      ]
    });
  }, hE = () => {
    const { profiles: i, activeProfileId: a, createProfile: l, setActiveProfile: r, updateProfileName: c, deleteProfile: f } = wa(), [d, h] = ue.useState(false), [g, y] = ue.useState(false), [p, b] = ue.useState(""), [S, x] = ue.useState(null), v = {
      blue: "#007AFF",
      red: "#FF3B30",
      gray: {
        light: "#F2F2F7",
        medium: "#E5E5EA",
        dark: "#8E8E93"
      },
      text: {
        primary: "#000000",
        secondary: "#8E8E93"
      }
    }, A = (D) => {
      if (D.preventDefault(), p.trim() === "") return;
      const I = l(p);
      r(I.id), b(""), h(false);
    }, j = (D) => {
      D.preventDefault(), !(!S || p.trim() === "") && (c(S, p), b(""), y(false), x(null));
    }, L = (D) => {
      if (i.length <= 1) {
        alert("Cannot delete the last profile. Please create another profile first.");
        return;
      }
      f(D);
    }, B = (D) => {
      x(D.id), b(D.name), y(true);
    };
    return E.jsxs("div", {
      className: "mb-6 rounded-xl overflow-hidden user-selector",
      style: {
        backgroundColor: v.gray.light
      },
      children: [
        E.jsx("div", {
          className: "px-4 py-3 border-b",
          style: {
            borderColor: "rgba(0, 0, 0, 0.05)"
          },
          children: E.jsxs("h3", {
            className: "font-semibold flex items-center gap-2",
            style: {
              fontSize: "15px"
            },
            children: [
              E.jsx(Af, {
                className: "h-4 w-4"
              }),
              "User Profiles"
            ]
          })
        }),
        E.jsxs("div", {
          className: "p-4",
          children: [
            d ? E.jsxs("form", {
              onSubmit: A,
              className: "mb-4",
              children: [
                E.jsxs("div", {
                  className: "mb-3",
                  children: [
                    E.jsx("label", {
                      htmlFor: "new-profile-name",
                      className: "text-sm font-medium",
                      style: {
                        color: v.text.secondary
                      },
                      children: "New Profile Name"
                    }),
                    E.jsx("input", {
                      id: "new-profile-name",
                      type: "text",
                      value: p,
                      onChange: (D) => b(D.target.value),
                      className: "w-full px-3 py-2 border mt-1 focus:outline-none focus:ring-2",
                      style: {
                        borderColor: v.gray.medium,
                        borderRadius: "8px",
                        fontSize: "15px"
                      },
                      placeholder: "Enter profile name",
                      autoFocus: true,
                      required: true
                    })
                  ]
                }),
                E.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    E.jsx("button", {
                      type: "button",
                      onClick: () => {
                        h(false), b("");
                      },
                      className: "flex-1 py-2 px-3 text-sm rounded-lg font-medium",
                      style: {
                        backgroundColor: "rgba(142, 142, 147, 0.12)",
                        color: v.text.primary
                      },
                      children: "Cancel"
                    }),
                    E.jsx("button", {
                      type: "submit",
                      className: "flex-1 py-2 px-3 text-sm rounded-lg font-medium text-white",
                      style: {
                        backgroundColor: v.blue
                      },
                      children: "Create"
                    })
                  ]
                })
              ]
            }) : g ? E.jsxs("form", {
              onSubmit: j,
              className: "mb-4",
              children: [
                E.jsxs("div", {
                  className: "mb-3",
                  children: [
                    E.jsx("label", {
                      htmlFor: "edit-profile-name",
                      className: "text-sm font-medium",
                      style: {
                        color: v.text.secondary
                      },
                      children: "Edit Profile Name"
                    }),
                    E.jsx("input", {
                      id: "edit-profile-name",
                      type: "text",
                      value: p,
                      onChange: (D) => b(D.target.value),
                      className: "w-full px-3 py-2 border mt-1 focus:outline-none focus:ring-2",
                      style: {
                        borderColor: v.gray.medium,
                        borderRadius: "8px",
                        fontSize: "15px"
                      },
                      placeholder: "Enter profile name",
                      autoFocus: true,
                      required: true
                    })
                  ]
                }),
                E.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    E.jsx("button", {
                      type: "button",
                      onClick: () => {
                        y(false), x(null), b("");
                      },
                      className: "flex-1 py-2 px-3 text-sm rounded-lg font-medium",
                      style: {
                        backgroundColor: "rgba(142, 142, 147, 0.12)",
                        color: v.text.primary
                      },
                      children: "Cancel"
                    }),
                    E.jsx("button", {
                      type: "submit",
                      className: "flex-1 py-2 px-3 text-sm rounded-lg font-medium text-white",
                      style: {
                        backgroundColor: v.blue
                      },
                      children: "Update"
                    })
                  ]
                })
              ]
            }) : E.jsxs("button", {
              onClick: () => h(true),
              className: "mb-4 w-full py-2 px-3 text-sm rounded-lg font-medium flex items-center justify-center gap-2",
              style: {
                backgroundColor: v.blue,
                color: "white"
              },
              children: [
                E.jsx(dg, {
                  className: "h-4 w-4"
                }),
                "Create New Profile"
              ]
            }),
            E.jsx("div", {
              className: "space-y-2 max-h-[200px] overflow-y-auto",
              children: i.length === 0 ? E.jsx("div", {
                className: "text-center p-4 text-sm",
                style: {
                  color: v.text.secondary
                },
                children: "No profiles yet. Create your first profile."
              }) : i.map((D) => E.jsxs("div", {
                className: `p-3 rounded-lg flex items-center justify-between ${D.id === a ? "bg-blue-50" : "bg-white"}`,
                style: {
                  borderLeft: D.id === a ? `4px solid ${v.blue}` : "none"
                },
                children: [
                  E.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      E.jsx(Af, {
                        className: "h-5 w-5",
                        style: {
                          color: D.id === a ? v.blue : v.text.secondary
                        }
                      }),
                      E.jsxs("div", {
                        children: [
                          E.jsx("div", {
                            className: "font-medium",
                            children: D.name
                          }),
                          E.jsx("div", {
                            className: "text-xs",
                            style: {
                              color: v.text.secondary
                            },
                            children: D.id === a ? "Active" : ""
                          })
                        ]
                      })
                    ]
                  }),
                  E.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      D.id !== a && E.jsx("button", {
                        onClick: () => r(D.id),
                        className: "text-xs px-2 py-1 rounded",
                        style: {
                          color: v.blue
                        },
                        children: "Select"
                      }),
                      E.jsx("button", {
                        onClick: () => B(D),
                        className: "p-1 rounded-full hover:bg-gray-100",
                        "aria-label": "Edit profile",
                        children: E.jsx(fg, {
                          className: "h-4 w-4",
                          style: {
                            color: v.text.secondary
                          }
                        })
                      }),
                      E.jsx("button", {
                        onClick: () => L(D.id),
                        className: "p-1 rounded-full hover:bg-gray-100",
                        "aria-label": "Delete profile",
                        disabled: i.length <= 1,
                        children: E.jsx(hg, {
                          className: "h-4 w-4",
                          style: {
                            color: i.length <= 1 ? v.gray.dark : v.red,
                            opacity: i.length <= 1 ? 0.5 : 1
                          }
                        })
                      })
                    ]
                  })
                ]
              }, D.id))
            })
          ]
        })
      ]
    });
  }, mE = () => {
    const { categories: i, addCategory: a, updateCategory: l, deleteCategory: r } = og(), [c, f] = ue.useState(false), [d, h] = ue.useState(false), [g, y] = ue.useState(""), [p, b] = ue.useState("#007AFF"), [S, x] = ue.useState(null), v = {
      blue: "#007AFF",
      green: "#34C759",
      red: "#FF3B30",
      yellow: "#FFCC00",
      orange: "#FF9500",
      purple: "#AF52DE",
      pink: "#FF2D55",
      teal: "#5AC8FA",
      indigo: "#5856D6",
      gray: {
        light: "#F2F2F7",
        medium: "#E5E5EA",
        dark: "#8E8E93"
      },
      text: {
        primary: "#000000",
        secondary: "#8E8E93"
      }
    }, A = [
      {
        name: "Blue",
        value: v.blue
      },
      {
        name: "Green",
        value: v.green
      },
      {
        name: "Red",
        value: v.red
      },
      {
        name: "Yellow",
        value: v.yellow
      },
      {
        name: "Orange",
        value: v.orange
      },
      {
        name: "Purple",
        value: v.purple
      },
      {
        name: "Pink",
        value: v.pink
      },
      {
        name: "Teal",
        value: v.teal
      },
      {
        name: "Indigo",
        value: v.indigo
      },
      {
        name: "Gray",
        value: v.gray.dark
      }
    ], j = (I) => {
      I.preventDefault(), g.trim() !== "" && (a(g, p, null), y(""), b(v.blue), f(false));
    }, L = (I) => {
      I.preventDefault(), !(!S || g.trim() === "") && (l(S, {
        name: g,
        color: p,
        icon: null
      }), y(""), b(v.blue), h(false), x(null));
    }, B = (I) => {
      r(I);
    }, D = (I) => {
      x(I.id), y(I.name), b(I.color), h(true);
    };
    return E.jsxs("div", {
      className: "mb-6 rounded-xl overflow-hidden category-manager",
      style: {
        backgroundColor: v.gray.light
      },
      children: [
        E.jsx("div", {
          className: "px-4 py-3 border-b",
          style: {
            borderColor: "rgba(0, 0, 0, 0.05)"
          },
          children: E.jsxs("h3", {
            className: "font-semibold flex items-center gap-2",
            style: {
              fontSize: "15px"
            },
            children: [
              E.jsx(tE, {
                className: "h-4 w-4"
              }),
              "Categories"
            ]
          })
        }),
        E.jsxs("div", {
          className: "p-4",
          children: [
            c ? E.jsxs("form", {
              onSubmit: j,
              className: "mb-4",
              children: [
                E.jsxs("div", {
                  className: "mb-3",
                  children: [
                    E.jsx("label", {
                      htmlFor: "new-category-name",
                      className: "text-sm font-medium",
                      style: {
                        color: v.text.secondary
                      },
                      children: "New Category Name"
                    }),
                    E.jsx("input", {
                      id: "new-category-name",
                      type: "text",
                      value: g,
                      onChange: (I) => y(I.target.value),
                      className: "w-full px-3 py-2 border mt-1 focus:outline-none focus:ring-2",
                      style: {
                        borderColor: v.gray.medium,
                        borderRadius: "8px",
                        fontSize: "15px"
                      },
                      placeholder: "Enter category name",
                      autoFocus: true,
                      required: true
                    })
                  ]
                }),
                E.jsxs("div", {
                  className: "mb-3",
                  children: [
                    E.jsx("label", {
                      className: "text-sm font-medium",
                      style: {
                        color: v.text.secondary
                      },
                      children: "Color"
                    }),
                    E.jsx("div", {
                      className: "grid grid-cols-5 gap-2 mt-1",
                      children: A.map((I) => E.jsx("button", {
                        type: "button",
                        className: `w-8 h-8 rounded-full ${p === I.value ? "ring-2 ring-offset-2" : ""}`,
                        style: {
                          backgroundColor: I.value
                        },
                        onClick: () => b(I.value),
                        "aria-label": `Select ${I.name} color`
                      }, I.value))
                    })
                  ]
                }),
                E.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    E.jsx("button", {
                      type: "button",
                      onClick: () => {
                        f(false), y(""), b(v.blue);
                      },
                      className: "flex-1 py-2 px-3 text-sm rounded-lg font-medium",
                      style: {
                        backgroundColor: "rgba(142, 142, 147, 0.12)",
                        color: v.text.primary
                      },
                      children: "Cancel"
                    }),
                    E.jsx("button", {
                      type: "submit",
                      className: "flex-1 py-2 px-3 text-sm rounded-lg font-medium text-white",
                      style: {
                        backgroundColor: v.blue
                      },
                      children: "Create"
                    })
                  ]
                })
              ]
            }) : d ? E.jsxs("form", {
              onSubmit: L,
              className: "mb-4",
              children: [
                E.jsxs("div", {
                  className: "mb-3",
                  children: [
                    E.jsx("label", {
                      htmlFor: "edit-category-name",
                      className: "text-sm font-medium",
                      style: {
                        color: v.text.secondary
                      },
                      children: "Edit Category Name"
                    }),
                    E.jsx("input", {
                      id: "edit-category-name",
                      type: "text",
                      value: g,
                      onChange: (I) => y(I.target.value),
                      className: "w-full px-3 py-2 border mt-1 focus:outline-none focus:ring-2",
                      style: {
                        borderColor: v.gray.medium,
                        borderRadius: "8px",
                        fontSize: "15px"
                      },
                      placeholder: "Enter category name",
                      autoFocus: true,
                      required: true
                    })
                  ]
                }),
                E.jsxs("div", {
                  className: "mb-3",
                  children: [
                    E.jsx("label", {
                      className: "text-sm font-medium",
                      style: {
                        color: v.text.secondary
                      },
                      children: "Color"
                    }),
                    E.jsx("div", {
                      className: "grid grid-cols-5 gap-2 mt-1",
                      children: A.map((I) => E.jsx("button", {
                        type: "button",
                        className: `w-8 h-8 rounded-full ${p === I.value ? "ring-2 ring-offset-2" : ""}`,
                        style: {
                          backgroundColor: I.value
                        },
                        onClick: () => b(I.value),
                        "aria-label": `Select ${I.name} color`
                      }, I.value))
                    })
                  ]
                }),
                E.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    E.jsx("button", {
                      type: "button",
                      onClick: () => {
                        h(false), x(null), y(""), b(v.blue);
                      },
                      className: "flex-1 py-2 px-3 text-sm rounded-lg font-medium",
                      style: {
                        backgroundColor: "rgba(142, 142, 147, 0.12)",
                        color: v.text.primary
                      },
                      children: "Cancel"
                    }),
                    E.jsx("button", {
                      type: "submit",
                      className: "flex-1 py-2 px-3 text-sm rounded-lg font-medium text-white",
                      style: {
                        backgroundColor: v.blue
                      },
                      children: "Update"
                    })
                  ]
                })
              ]
            }) : E.jsxs("button", {
              onClick: () => f(true),
              className: "mb-4 w-full py-2 px-3 text-sm rounded-lg font-medium flex items-center justify-center gap-2",
              style: {
                backgroundColor: v.blue,
                color: "white"
              },
              children: [
                E.jsx(dg, {
                  className: "h-4 w-4"
                }),
                "Create New Category"
              ]
            }),
            E.jsx("div", {
              className: "space-y-2 max-h-[200px] overflow-y-auto",
              children: Object.values(i).length === 0 ? E.jsx("div", {
                className: "text-center p-4 text-sm",
                style: {
                  color: v.text.secondary
                },
                children: "No categories yet. Create your first category."
              }) : Object.values(i).map((I) => E.jsxs("div", {
                className: "p-3 rounded-lg bg-white flex items-center justify-between",
                children: [
                  E.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      E.jsx("div", {
                        className: "w-4 h-4 rounded-full",
                        style: {
                          backgroundColor: I.color
                        }
                      }),
                      E.jsx("div", {
                        className: "font-medium",
                        children: I.name
                      })
                    ]
                  }),
                  E.jsxs("div", {
                    className: "flex items-center gap-2",
                    children: [
                      I.createdBy !== "system" && E.jsxs(E.Fragment, {
                        children: [
                          E.jsx("button", {
                            onClick: () => D(I),
                            className: "p-1 rounded-full hover:bg-gray-100",
                            "aria-label": "Edit category",
                            children: E.jsx(fg, {
                              className: "h-4 w-4",
                              style: {
                                color: v.text.secondary
                              }
                            })
                          }),
                          E.jsx("button", {
                            onClick: () => B(I.id),
                            className: "p-1 rounded-full hover:bg-gray-100",
                            "aria-label": "Delete category",
                            children: E.jsx(hg, {
                              className: "h-4 w-4",
                              style: {
                                color: v.red
                              }
                            })
                          })
                        ]
                      }),
                      I.createdBy === "system" && E.jsx("span", {
                        className: "text-xs",
                        style: {
                          color: v.text.secondary
                        },
                        children: "System"
                      })
                    ]
                  })
                ]
              }, I.id))
            })
          ]
        })
      ]
    });
  }, yE = ({ steps: i, currentStep: a, onNext: l, onPrev: r, onClose: c, totalSteps: f, tourId: d = "default-tour" }) => {
    const h = i[a], g = h.target ? document.querySelector(h.target) : null, [y, p] = ue.useState({
      top: 0,
      left: 0
    });
    return ue.useEffect(() => {
      var _a7;
      ((_a7 = i[a]) == null ? void 0 : _a7.persistAfterReload) && (localStorage.setItem(`tour-${d}-step`, a.toString()), localStorage.setItem(`tour-${d}-active`, "true"));
    }, [
      a,
      i,
      d
    ]), ue.useEffect(() => {
      if (h.position === "center") {
        const b = window.innerHeight, S = window.innerWidth;
        p({
          top: b / 2 - 100,
          left: S / 2
        });
      } else if (g) {
        const b = g.getBoundingClientRect();
        let S = 0, x = 0;
        switch (h.position) {
          case "right":
            S = b.top, x = b.right + 10;
            break;
          case "left":
            S = b.top, x = b.left - 320;
            break;
          case "bottom":
            S = b.bottom + 10, x = b.left;
            break;
          case "top":
            S = b.top - 150, x = b.left;
            break;
        }
        p({
          top: S,
          left: x
        }), g.classList.add("tour-highlight");
      }
      return () => {
        g && g.classList.remove("tour-highlight");
      };
    }, [
      a,
      h.target,
      h.position
    ]), E.jsxs(E.Fragment, {
      children: [
        E.jsx("div", {
          className: "fixed inset-0 bg-black bg-opacity-50 z-[970]"
        }),
        E.jsxs("div", {
          className: `fixed z-[990] bg-white rounded-xl shadow-lg p-[1.2em] w-[30em] max-w-[90vw] ${h.position === "center" ? "transform -translate-x-1/2 -translate-y-1/2" : ""}`,
          style: {
            top: y.top,
            left: y.left
          },
          children: [
            E.jsx("h3", {
              className: "font-medium text-lg mb-2",
              children: h.title
            }),
            E.jsx("div", {
              className: "text-gray-600 mb-4 whitespace-pre-wrap font-sans",
              style: {
                maxWidth: "60ch",
                lineHeight: "1.5"
              },
              dangerouslySetInnerHTML: {
                __html: h.content
              }
            }),
            E.jsxs("div", {
              className: "flex justify-between items-center",
              children: [
                E.jsxs("div", {
                  className: "flex gap-2",
                  children: [
                    a > 0 && E.jsx("button", {
                      onClick: r,
                      className: "px-3 py-1 rounded-full text-sm",
                      style: {
                        color: "#007AFF"
                      },
                      children: "Previous"
                    }),
                    a < f - 1 && E.jsx("button", {
                      onClick: l,
                      className: "px-3 py-1 rounded-full text-sm",
                      style: {
                        backgroundColor: "#007AFF",
                        color: "white"
                      },
                      children: "Next"
                    }),
                    a === f - 1 && E.jsx("button", {
                      onClick: c,
                      className: "px-3 py-1 rounded-full text-sm",
                      style: {
                        backgroundColor: "#007AFF",
                        color: "white"
                      },
                      children: "Finish"
                    })
                  ]
                }),
                E.jsxs("span", {
                  className: "text-sm text-gray-500",
                  children: [
                    a + 1,
                    " of ",
                    f
                  ]
                })
              ]
            })
          ]
        })
      ]
    });
  }, pE = (i) => {
    const a = i.match(/!1s([^:]+):/);
    return a ? a[1] : null;
  }, gE = async (i, a) => new Promise((l) => {
    if (!window.mapkit) {
      console.error("MapKit is not initialized"), l(null);
      return;
    }
    new window.mapkit.Search({
      includePointsOfInterest: true,
      includeAddresses: true
    }).search(i, (c, f) => {
      if (c) {
        console.error("Search error:", c), l(null);
        return;
      }
      if (f && f.places && f.places.length > 0) {
        const d = f.places[0];
        l({
          latitude: d.coordinate.latitude,
          longitude: d.coordinate.longitude,
          name: d.name,
          placeId: a || d.id,
          category: d.pointOfInterestCategory || ""
        });
      } else console.warn(`No results found for "${i}"`), l(null);
    });
  }), bE = async (i, a = "Jack") => {
    try {
      const l = await ww(i);
      if (!l || !l.locations) return {
        success: false,
        imported: 0,
        skipped: 0,
        failed: 0,
        message: "Failed to load locations document or no locations found"
      };
      const r = Fn.getState(), c = wa.getState();
      let f = c.profiles.find((p) => p.name === a);
      f || (f = c.createProfile(a)), c.setActiveProfile(f.id);
      let d = 0, h = 0, g = 0;
      const y = Object.values(r.locations);
      for (const p of l.locations) try {
        const b = pE(p.URL);
        if (y.some((v) => v.name.toLowerCase() === p.Title.toLowerCase() || b && v.placeId === b)) {
          console.log(`Skipping duplicate location: "${p.Title}"`), h++;
          continue;
        }
        const x = await gE(p.Title, b || void 0);
        x ? (r.addLocation({
          name: p.Title,
          description: p.Comment || p.Note || "",
          latitude: x.latitude,
          longitude: x.longitude,
          placeId: x.placeId || "",
          category: x.category || "other"
        }), d++) : (console.warn(`Could not find coordinates for "${p.Title}"`), g++);
      } catch (b) {
        console.error(`Error importing location "${p.Title}":`, b), g++;
      }
      return {
        success: true,
        imported: d,
        skipped: h,
        failed: g,
        message: `Successfully imported ${d} locations. ${h} locations skipped as duplicates. ${g} locations failed to import.`
      };
    } catch (l) {
      return console.error("Error importing locations:", l), {
        success: false,
        imported: 0,
        skipped: 0,
        failed: 0,
        message: `Error importing locations: ${l}`
      };
    }
  }, vE = ({ docPath: i = "/jack/locations", username: a = "Jack", onComplete: l }) => {
    const [r, c] = ue.useState(false), [f, d] = ue.useState(null), h = {
      blue: "#007AFF",
      green: "#34C759",
      red: "#FF3B30"
    }, g = async () => {
      c(true), d(null);
      try {
        const y = await bE(i, a);
        d(y), l && l(y);
      } catch (y) {
        console.error("Import error:", y), d({
          success: false,
          imported: 0,
          skipped: 0,
          failed: 0,
          message: `Error: ${y}`
        });
      } finally {
        c(false);
      }
    };
    return E.jsxs("div", {
      className: "flex flex-col items-center",
      children: [
        E.jsx("button", {
          onClick: g,
          disabled: r,
          className: "mb-1 w-full py-2 px-3 text-sm rounded-lg font-medium flex items-center justify-center gap-2",
          style: {
            backgroundColor: h.blue,
            color: "white"
          },
          children: r ? E.jsxs(E.Fragment, {
            children: [
              E.jsx(ug, {
                size: 16,
                className: "animate-spin mr-2"
              }),
              "Importing..."
            ]
          }) : E.jsxs(E.Fragment, {
            children: [
              E.jsx(Lw, {
                size: 16,
                className: "mr-2"
              }),
              "Import Saved Locations"
            ]
          })
        }),
        f && E.jsxs("div", {
          className: "mt-3 p-3 rounded-lg text-sm flex items-start",
          style: {
            backgroundColor: f.success ? "rgba(52, 199, 89, 0.1)" : "rgba(255, 59, 48, 0.1)",
            color: f.success ? h.green : h.red,
            maxWidth: "280px",
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)",
            border: `1px solid ${f.success ? "rgba(52, 199, 89, 0.2)" : "rgba(255, 59, 48, 0.2)"}`
          },
          children: [
            f.success ? E.jsx(zw, {
              size: 16,
              className: "mr-2 mt-0.5 flex-shrink-0"
            }) : E.jsx(Dw, {
              size: 16,
              className: "mr-2 mt-0.5 flex-shrink-0"
            }),
            E.jsx("span", {
              children: f.message
            })
          ]
        })
      ]
    });
  }, xE = async () => "eyJraWQiOiI3VDU0M0RUWjIyIiwidHlwIjoiSldUIiwiYWxnIjoiRVMyNTYifQ.eyJpc3MiOiI4V1ZLUzJGMjRDIiwiaWF0IjoxNzQ5MTE4NjQzLCJleHAiOjE3NDk3OTc5OTl9.DVld6WskUrlqbm2Cxqba_kbAzkezOihjhQT_RSc3fBGtNvovwxwIVGLnk0N3IPcpmXBTgEpoBZ5zi4y3omcI5A", SE = ({}) => (ue.useEffect(() => {
    (async () => {
      try {
        if (!window.mapkit) {
          const l = document.createElement("script");
          l.src = "https://cdn.apple-mapkit.com/mk/5.x.x/mapkit.js", l.async = true, document.head.appendChild(l), await new Promise((r) => {
            l.onload = () => r();
          });
        }
        const a = await xE();
        window.mapkit.init({
          authorizationCallback: (l) => {
            l(a);
          }
        });
      } catch (a) {
        console.error("Failed to initialize MapKit JS:", a);
      }
    })();
  }, []), null), wE = () => {
    var _a7, _b;
    const { locations: i, addLocation: a, removeLocation: l, addReview: r, removeReview: c } = Fn(), { profiles: f, activeProfileId: d } = wa(), { categories: h } = og(), [g, y] = ue.useState(false), [p, b] = ue.useState({
      name: "",
      description: "",
      latitude: 0,
      longitude: 0,
      placeId: "",
      category: "default"
    }), [S, x] = ue.useState(null), [v, A] = ue.useState(false), [j, L] = ue.useState(null), [B, D] = ue.useState(null), [I, ee] = ue.useState(false), [ae, be] = ue.useState([]), le = Fn((K) => K.userNames), W = ue.useRef(null), P = ue.useRef(null), pe = ue.useRef([]), [F, O] = ue.useState(false), [Q, Y] = ue.useState(null), [R, k] = ue.useState(false), [J, ne] = ue.useState(5), [te, de] = ue.useState(""), [me, gt] = ue.useState(null), [Ee, bt] = ue.useState(false), [Ea, xn] = ue.useState(false), [Tt, Ge] = ue.useState(() => {
      const K = localStorage.getItem("tour-main-step");
      return K ? parseInt(K, 10) : 0;
    }), ze = f.find((K) => K.id === d) || {
      name: "Select a profile"
    }, oe = {
      blue: "#007AFF",
      red: "#FF3B30",
      yellow: "#FFCC00",
      gray: {
        light: "#F2F2F7",
        medium: "#E5E5EA",
        dark: "#8E8E93"
      },
      text: {
        primary: "#000000",
        secondary: "#8E8E93"
      }
    }, Zn = [
      {
        title: "Welcome to My World!",
        content: "This is a demo app made by Tonk to get you started. Let's take a quick look around. Click 'Next' to begin.",
        position: "center"
      },
      {
        target: ".user-selector",
        title: "User Profiles",
        content: "Create and switch between different user profiles to manage your locations.",
        position: "right"
      },
      {
        target: ".category-manager",
        title: "Categories",
        content: "Organise your locations by creating custom categories with colours.",
        position: "right"
      },
      {
        target: ".location-list",
        title: "Saved Locations",
        content: "View all your saved locations here. Click on any location to see details.",
        position: "right"
      },
      {
        target: ".search-bar",
        title: "Interactive Map",
        content: "Use the search bar to add a new location to the map, then continue to the next step.",
        position: "right"
      },
      {
        title: "Transparent Data",
        content: "Go back to the Tonk Hub and navigate to the file <code>my-world-locations.automerge</code> under <code>stores</code>. You should see your new location present in the list.",
        position: "center"
      },
      {
        title: "Add a Feature",
        content: `If you haven't already, open this project in your AI editor of choice and run the following prompt:

"Add a new 'Bucket List' feature that lets users star saved locations and displays them in a special list under saved locations in the sidebar."`,
        position: "center",
        persistAfterReload: true
      }
    ], tn = [
      51.505,
      -0.09
    ];
    ue.useEffect(() => {
      if (window.mapkit && W.current && !P.current) {
        const K = window.matchMedia("(prefers-color-scheme: dark)").matches ? window.mapkit.Map.ColorSchemes.Dark : window.mapkit.Map.ColorSchemes.Light, he = new window.mapkit.Map(W.current, {
          showsZoomControl: true,
          showsCompass: window.mapkit.FeatureVisibility.Adaptive,
          showsScale: window.mapkit.FeatureVisibility.Adaptive,
          showsMapTypeControl: false,
          isRotationEnabled: true,
          showsPointsOfInterest: true,
          showsUserLocation: true,
          colorScheme: K,
          padding: new window.mapkit.Padding({
            top: 50,
            right: 10,
            bottom: 50,
            left: 10
          })
        });
        he.mapType = window.mapkit.Map.MapTypes.Standard, he.region = new window.mapkit.CoordinateRegion(new window.mapkit.Coordinate(tn[0], tn[1]), new window.mapkit.CoordinateSpan(0.1, 0.1)), he.addEventListener("click", (Ve) => {
          const Je = Ve.coordinate;
          ai(Je.latitude, Je.longitude), y(true);
        });
        const Ae = window.matchMedia("(prefers-color-scheme: dark)"), Ne = (Ve) => {
          he.colorScheme = Ve.matches ? window.mapkit.Map.ColorSchemes.Dark : window.mapkit.Map.ColorSchemes.Light;
        };
        return Ae.addEventListener("change", Ne), P.current = he, O(true), () => {
          Ae.removeEventListener("change", Ne);
        };
      }
    }, [
      W.current,
      window.mapkit
    ]), ue.useEffect(() => {
      if (F && P.current && j) {
        const K = P.current, Ae = 0.01 * Math.pow(2, 15 - (B || 15));
        K.region = new window.mapkit.CoordinateRegion(new window.mapkit.Coordinate(j[0], j[1]), new window.mapkit.CoordinateSpan(Ae, Ae));
      }
    }, [
      j,
      B,
      F
    ]);
    const ni = (K, he, Ae, Ne) => {
      const Ve = Ne || "";
      if (b({
        ...p,
        name: Ae,
        latitude: K,
        longitude: he,
        placeId: Ve
      }), L([
        K,
        he
      ]), D(15), F && P.current) {
        const Je = pe.current.find((Te) => Te.isTemporary);
        Je && (P.current.removeAnnotation(Je), pe.current = pe.current.filter((Te) => !Te.isTemporary));
        const Aa = new window.mapkit.Coordinate(K, he), nt = new window.mapkit.MarkerAnnotation(Aa, {
          color: "#34C759",
          title: Ae,
          glyphText: "+"
        });
        nt.isTemporary = true, Ve && (nt.placeId = Ve);
        try {
          P.current.addAnnotation(nt), pe.current.push(nt);
        } catch (Te) {
          console.error("Error adding annotation:", Te);
        }
      }
    }, ai = (K, he) => {
      if (b((Ae) => ({
        ...Ae,
        latitude: K,
        longitude: he
      })), F && P.current) {
        const Ae = pe.current.find((Ve) => Ve.isTemporary);
        Ae && (P.current.removeAnnotation(Ae), pe.current = pe.current.filter((Ve) => !Ve.isTemporary));
        const Ne = new window.mapkit.MarkerAnnotation(new window.mapkit.Coordinate(K, he), {
          color: "#34C759",
          title: "New Location",
          glyphText: "+"
        });
        Ne.isTemporary = true, P.current.addAnnotation(Ne), pe.current.push(Ne);
      }
    }, Sn = () => {
      if (!F || !P.current) return;
      const K = pe.current.find((Ne) => Ne.isTemporary);
      P.current.removeAnnotations(pe.current.filter((Ne) => !Ne.isTemporary)), pe.current = K ? [
        K
      ] : [];
      const Ae = (S ? Object.values(i).filter((Ne) => Ne.category === S) : Object.values(i)).map((Ne) => {
        let Ve = oe.blue;
        Ne.category && h[Ne.category] ? Ve = h[Ne.category].color : d !== Ne.addedBy && (Ve = oe.red), ae.includes(Ne.id) && (Ve = oe.yellow);
        const Je = new window.mapkit.MarkerAnnotation(new window.mapkit.Coordinate(Ne.latitude, Ne.longitude), {
          color: Ve,
          title: Ne.name,
          subtitle: Ne.description || "",
          selected: false,
          animates: true,
          displayPriority: 1e3
        });
        return Je.locationId = Ne.id, Je.callout = {
          calloutElementForAnnotation: (Aa) => {
            const nt = document.createElement("div");
            nt.className = "mapkit-callout", nt.style.padding = "16px", nt.style.maxWidth = "280px", nt.style.backgroundColor = "white", nt.style.borderRadius = "14px", nt.style.boxShadow = "0 4px 16px rgba(0, 0, 0, 0.12)", nt.style.border = "none", nt.style.fontFamily = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif";
            const Te = Object.values(i).find((cn) => cn.id === Aa.locationId);
            if (!Te) return nt;
            const wn = Te.category ? h[Te.category] : null, mo = wn ? wn.name : "Uncategorized", El = wn ? wn.color : "#8E8E93";
            return nt.innerHTML = `
                <h3 style="font-weight: 600; font-size: 17px; margin-bottom: 6px; color: #000;">${Te.name}</h3>
                ${Te.description ? `<p style="font-size: 15px; margin-bottom: 8px; color: #333;">${Te.description}</p>` : ""}
                <div style="display: flex; align-items: center; margin-bottom: 4px;">
                  <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background-color: ${El}; margin-right: 6px;"></span>
                  <span style="font-size: 13px; color: #8E8E93;">${mo}</span>
                  ${Te.isOpen !== void 0 && Te.isOpen !== null ? `<span style="font-size: 12px; margin-left: 8px; padding: 2px 6px; border-radius: 10px; background-color: ${Te.isOpen ? "rgba(52, 199, 89, 0.1)" : "rgba(255, 59, 48, 0.1)"}; color: ${Te.isOpen ? "#34C759" : "#FF3B30"};">
                      ${Te.isOpen ? "Open" : "Closed"}
                    </span>` : ""}
                </div>
                <p style="font-size: 13px; color: #8E8E93; margin-bottom: 4px;">
                  Added by: ${d === Te.addedBy ? "You" : le[Te.addedBy] || "Anonymous"}
                </p>
                ${ae.includes(Te.id) ? '<p style="font-size: 13px; color: #FF9500; font-weight: 500; margin-top: 4px; display: flex; align-items: center;"><span style="margin-right: 4px;">\u2B50</span> Common place</p>' : ""}
                <div style="display: flex; gap: 12px; margin-top: 12px;">
                  <button id="info-${Te.id}" style="font-size: 15px; color: #007AFF; border: none; background: none; cursor: pointer; padding: 8px 12px; border-radius: 8px; font-weight: 500; transition: background-color 0.2s;">Show Details</button>
                  <button id="review-${Te.id}" style="font-size: 15px; color: #FF9500; border: none; background: none; cursor: pointer; padding: 8px 12px; border-radius: 8px; font-weight: 500; transition: background-color 0.2s;">Add Review</button>
                  ${d === Te.addedBy ? `<button id="remove-${Te.id}" style="font-size: 15px; color: #FF3B30; border: none; background: none; cursor: pointer; padding: 8px 12px; border-radius: 8px; font-weight: 500; transition: background-color 0.2s;">Remove</button>` : ""}
                </div>
              `, setTimeout(() => {
              const cn = document.getElementById(`info-${Te.id}`);
              cn && (cn.addEventListener("mouseover", () => {
                cn.style.backgroundColor = "rgba(0, 122, 255, 0.1)";
              }), cn.addEventListener("mouseout", () => {
                cn.style.backgroundColor = "transparent";
              }), cn.addEventListener("click", () => {
                Y(Te.id), k(false), Te.placeId && (bt(true), gt(null), cE(Te.id).then((at) => {
                  gt(at), bt(false);
                }).catch((at) => {
                  console.error("Error fetching business hours:", at), bt(false);
                }));
              }));
              const Kn = document.getElementById(`review-${Te.id}`);
              Kn && (Kn.addEventListener("mouseover", () => {
                Kn.style.backgroundColor = "rgba(255, 149, 0, 0.1)";
              }), Kn.addEventListener("mouseout", () => {
                Kn.style.backgroundColor = "transparent";
              }), Kn.addEventListener("click", () => {
                Y(Te.id), k(true), ne(5), de("");
              }));
              const qt = document.getElementById(`remove-${Te.id}`);
              qt && (qt.addEventListener("mouseover", () => {
                qt.style.backgroundColor = "rgba(255, 59, 48, 0.1)";
              }), qt.addEventListener("mouseout", () => {
                qt.style.backgroundColor = "transparent";
              }), qt.addEventListener("click", () => {
                l(Te.id), P.current.removeAnnotation(Aa), pe.current = pe.current.filter((at) => at !== Aa);
              }));
            }, 0), nt;
          }
        }, Je;
      });
      Ae.length > 0 && (P.current.addAnnotations(Ae), pe.current = [
        ...pe.current,
        ...Ae
      ]);
    };
    ue.useEffect(() => {
      Sn();
    }, [
      i,
      ae,
      F
    ]), ue.useEffect(() => {
      Object.keys(i).length > 0 && oE().catch((K) => {
        console.error("Error updating locations open status:", K);
      });
    }, []), ue.useEffect(() => {
      Ea && localStorage.setItem("tour-main-active", "true");
    }, [
      Ea
    ]);
    const is = (K) => {
      if (K.preventDefault(), !(p.name.trim() === "" || p.latitude === 0)) {
        if (a(p), y(false), b({
          name: "",
          description: "",
          latitude: 0,
          longitude: 0,
          placeId: "",
          category: "default"
        }), F && P.current) {
          const he = pe.current.find((Ae) => Ae.isTemporary);
          he && (P.current.removeAnnotation(he), pe.current = pe.current.filter((Ae) => !Ae.isTemporary));
        }
        Sn();
      }
    }, ii = () => {
      if (y(false), b({
        name: "",
        description: "",
        latitude: 0,
        longitude: 0,
        placeId: "",
        category: "default"
      }), F && P.current) {
        const K = pe.current.find((he) => he.isTemporary);
        K && (P.current.removeAnnotation(K), pe.current = pe.current.filter((he) => !he.isTemporary));
      }
    };
    return E.jsxs("div", {
      className: "flex flex-col h-full relative",
      children: [
        E.jsxs("div", {
          className: "flex justify-between items-center p-4 bg-white shadow-sm",
          style: {
            backgroundColor: "rgba(255, 255, 255, 0.8)",
            backdropFilter: "blur(10px)",
            WebkitBackdropFilter: "blur(10px)",
            borderBottom: "1px solid rgba(0, 0, 0, 0.1)"
          },
          children: [
            E.jsxs("div", {
              className: "flex items-center gap-2",
              children: [
                E.jsx("button", {
                  onClick: () => ee(!I),
                  className: "md:hidden p-2 rounded-full hover:bg-gray-100 transition-colors",
                  "aria-label": "Toggle sidebar",
                  style: {
                    color: oe.blue
                  },
                  children: E.jsx(Qw, {
                    className: "h-5 w-5"
                  })
                }),
                E.jsx("h2", {
                  className: "text-xl font-semibold",
                  style: {
                    fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Arial, sans-serif',
                    fontWeight: 600
                  },
                  children: "My World"
                }),
                E.jsx("button", {
                  onClick: () => xn(true),
                  className: "p-2 rounded-full hover:bg-gray-100 transition-colors tour-button",
                  style: {
                    color: oe.blue
                  },
                  children: E.jsx(qy, {
                    className: "h-5 w-5"
                  })
                })
              ]
            }),
            E.jsxs("div", {
              className: "flex items-center gap-2 px-3 py-1.5 rounded-full bg-gray-100",
              children: [
                E.jsx(Af, {
                  className: "h-4 w-4 text-gray-600"
                }),
                E.jsx("span", {
                  className: "inline text-sm font-medium",
                  children: ze.name
                })
              ]
            })
          ]
        }),
        I && E.jsx("div", {
          className: "md:hidden fixed inset-0 bg-black bg-opacity-50 z-[950]",
          onClick: () => ee(false)
        }),
        E.jsxs("div", {
          className: "relative flex flex-grow overflow-hidden",
          children: [
            E.jsxs("div", {
              className: `
            fixed md:relative top-0 h-full z-[960] overflow-y-auto
            w-[300px] transition-transform duration-300 ease-in-out
            ${I ? "translate-x-0" : "-translate-x-full md:translate-x-0"}
          `,
              style: {
                backgroundColor: "rgba(255, 255, 255, 0.95)",
                backdropFilter: "blur(10px)",
                WebkitBackdropFilter: "blur(10px)",
                borderRight: "1px solid rgba(0, 0, 0, 0.1)"
              },
              children: [
                E.jsxs("div", {
                  className: "p-4 flex items-center justify-between md:hidden",
                  children: [
                    E.jsx("h2", {
                      className: "font-semibold",
                      style: {
                        fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Arial, sans-serif'
                      },
                      children: "My World"
                    }),
                    E.jsx("button", {
                      onClick: () => ee(false),
                      className: "p-2 rounded-full hover:bg-gray-100 transition-colors",
                      style: {
                        color: oe.blue
                      },
                      children: E.jsx(jw, {
                        className: "h-5 w-5"
                      })
                    })
                  ]
                }),
                E.jsxs("div", {
                  className: "p-4",
                  children: [
                    E.jsx(hE, {}),
                    E.jsx(mE, {}),
                    E.jsx(dE, {
                      onShowCommonLocations: be
                    }),
                    E.jsxs("div", {
                      className: "mb-6 rounded-xl overflow-hidden location-list",
                      style: {
                        backgroundColor: oe.gray.light
                      },
                      children: [
                        E.jsxs("div", {
                          className: "px-4 py-3 border-b flex justify-between items-center",
                          style: {
                            borderColor: "rgba(0, 0, 0, 0.05)"
                          },
                          children: [
                            E.jsxs("h3", {
                              className: "font-semibold flex items-center gap-2",
                              style: {
                                fontSize: "15px"
                              },
                              children: [
                                E.jsx(qr, {
                                  className: "h-4 w-4"
                                }),
                                "Saved Locations"
                              ]
                            }),
                            E.jsx("button", {
                              onClick: () => A(!v),
                              className: "p-1 rounded-full hover:bg-gray-200 transition-colors",
                              style: {
                                color: S ? (_a7 = h[S]) == null ? void 0 : _a7.color : oe.text.secondary
                              },
                              "aria-label": "Filter by category",
                              children: E.jsx(Yw, {
                                className: "h-4 w-4"
                              })
                            })
                          ]
                        }),
                        v && E.jsx("div", {
                          className: "p-2 border-b",
                          style: {
                            borderColor: "rgba(0, 0, 0, 0.05)"
                          },
                          children: E.jsxs("div", {
                            className: "flex flex-wrap gap-2",
                            children: [
                              E.jsx("button", {
                                onClick: () => x(null),
                                className: `px-2 py-1 rounded-full text-xs font-medium transition-colors ${S === null ? "bg-gray-200" : "bg-gray-100"}`,
                                style: {
                                  color: oe.text.primary
                                },
                                children: "All"
                              }),
                              Object.values(h).map((K) => E.jsx("button", {
                                onClick: () => x(K.id),
                                className: `px-2 py-1 rounded-full text-xs font-medium transition-colors ${S === K.id ? "bg-opacity-20" : "bg-opacity-10"}`,
                                style: {
                                  backgroundColor: `${K.color}${S === K.id ? "33" : "1A"}`,
                                  color: K.color
                                },
                                children: K.name
                              }, K.id))
                            ]
                          })
                        }),
                        E.jsx("div", {
                          className: "p-1 max-h-[40vh] overflow-y-auto",
                          children: Object.values(i).length === 0 ? E.jsxs("div", {
                            className: "p-4 flex flex-col items-center justify-center text-center",
                            children: [
                              E.jsx(qr, {
                                className: "h-8 w-8 mb-2 opacity-30"
                              }),
                              E.jsx("p", {
                                className: "text-sm",
                                style: {
                                  color: oe.text.secondary
                                },
                                children: "No locations saved yet"
                              }),
                              E.jsx("p", {
                                className: "text-xs mt-1",
                                style: {
                                  color: oe.text.secondary
                                },
                                children: "Add your first location using the + button"
                              })
                            ]
                          }) : Object.values(i).filter((K) => !S || K.category === S).map((K) => {
                            const he = K.category ? h[K.category] : null;
                            return E.jsxs("div", {
                              className: "mx-2 my-1 p-3 rounded-lg text-sm cursor-pointer transition-colors duration-150",
                              style: {
                                backgroundColor: ae.includes(K.id) ? "rgba(255, 204, 0, 0.1)" : "rgba(255, 255, 255, 0.6)",
                                borderLeft: `3px solid ${he ? he.color : "transparent"}`
                              },
                              onClick: () => {
                                L([
                                  K.latitude,
                                  K.longitude
                                ]), D(15), ee(false);
                              },
                              children: [
                                E.jsxs("div", {
                                  className: "font-medium flex items-center justify-between",
                                  style: {
                                    fontSize: "15px"
                                  },
                                  children: [
                                    E.jsxs("div", {
                                      className: "flex items-center gap-1",
                                      children: [
                                        E.jsx("span", {
                                          children: K.name
                                        }),
                                        K.isOpen !== void 0 && K.isOpen !== null && E.jsx("span", {
                                          className: `text-xs px-1.5 py-0.5 rounded-full ml-1 ${K.isOpen ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`,
                                          children: K.isOpen ? "Open" : "Closed"
                                        })
                                      ]
                                    }),
                                    K.reviews && K.reviews.length > 0 && E.jsxs("div", {
                                      className: "flex items-center gap-1",
                                      children: [
                                        E.jsx(Qu, {
                                          className: "h-3 w-3",
                                          fill: oe.yellow,
                                          stroke: oe.yellow
                                        }),
                                        E.jsx("span", {
                                          className: "text-xs",
                                          style: {
                                            color: oe.text.secondary
                                          },
                                          children: K.reviews.reduce((Ae, Ne) => Ae + Ne.rating, 0) / K.reviews.length
                                        })
                                      ]
                                    })
                                  ]
                                }),
                                K.description && E.jsx("div", {
                                  className: "text-xs mt-0.5 line-clamp-1",
                                  style: {
                                    color: oe.text.secondary
                                  },
                                  children: K.description
                                }),
                                E.jsxs("div", {
                                  className: "flex justify-between items-center mt-1",
                                  children: [
                                    E.jsxs("div", {
                                      className: "text-xs flex items-center",
                                      children: [
                                        ae.includes(K.id) && E.jsx("span", {
                                          className: "mr-1",
                                          style: {
                                            color: oe.yellow
                                          },
                                          children: "\u2B50"
                                        }),
                                        E.jsx("span", {
                                          style: {
                                            color: oe.text.secondary
                                          },
                                          children: d === K.addedBy ? "Added by you" : `Added by ${le[K.addedBy] || "Anonymous"}`
                                        })
                                      ]
                                    }),
                                    E.jsxs("div", {
                                      className: "flex items-center gap-1",
                                      children: [
                                        K.reviews && K.reviews.length > 0 && E.jsxs("span", {
                                          className: "text-xs",
                                          style: {
                                            color: oe.text.secondary
                                          },
                                          children: [
                                            K.reviews.length,
                                            " ",
                                            K.reviews.length === 1 ? "review" : "reviews"
                                          ]
                                        }),
                                        he && E.jsx("span", {
                                          className: "text-xs px-1.5 py-0.5 rounded-full ml-1",
                                          style: {
                                            backgroundColor: `${he.color}1A`,
                                            color: he.color
                                          },
                                          children: he.name
                                        })
                                      ]
                                    })
                                  ]
                                })
                              ]
                            }, K.id);
                          })
                        })
                      ]
                    }),
                    E.jsxs("div", {
                      className: "mb-6",
                      children: [
                        E.jsxs("h3", {
                          className: "font-medium mb-2 flex items-center gap-2",
                          children: [
                            E.jsx(qr, {
                              className: "h-4 w-4"
                            }),
                            "Import Locations"
                          ]
                        }),
                        E.jsx(vE, {
                          docPath: "/jack/locations",
                          username: "Jack",
                          onComplete: (K) => {
                            if (K.success && K.imported > 0) {
                              const he = Object.values(i);
                              if (he.length > 0) {
                                const Ae = he[he.length - 1];
                                L([
                                  Ae.latitude,
                                  Ae.longitude
                                ]), D(12);
                              }
                            }
                          }
                        })
                      ]
                    }),
                    E.jsxs("div", {
                      children: [
                        E.jsxs("h3", {
                          className: "font-medium mb-2 flex items-center gap-2",
                          children: [
                            E.jsx(qy, {
                              className: "h-4 w-4"
                            }),
                            "About"
                          ]
                        }),
                        E.jsx("p", {
                          className: "text-sm text-gray-600",
                          children: "My World is a collaborative map where you can save and share locations with friends. All data is stored locally first and synced when online."
                        })
                      ]
                    })
                  ]
                })
              ]
            }),
            E.jsxs("div", {
              className: "flex-grow h-full relative",
              children: [
                E.jsx(SE, {
                  onMapReady: (K) => {
                    P.current = K, O(true);
                  }
                }),
                E.jsx("div", {
                  ref: W,
                  style: {
                    height: "100%",
                    width: "100%"
                  },
                  className: "map-container"
                }),
                E.jsx("div", {
                  className: "absolute top-4 left-4 z-[900] pointer-events-none search-bar",
                  children: E.jsx("div", {
                    className: "w-80 pointer-events-auto",
                    children: E.jsx(uE, {
                      onPlaceSelect: (K, he, Ae, Ne) => {
                        ni(K, he, Ae, Ne), y(true);
                      }
                    })
                  })
                }),
                Q && !R && E.jsxs("div", {
                  className: "absolute inset-x-0 bottom-0 bg-white rounded-t-xl shadow-lg z-[10000] transition-transform transform translate-y-0 max-h-[80vh] md:max-h-[60%] flex flex-col",
                  style: {
                    backgroundColor: "rgba(255, 255, 255, 0.95)",
                    backdropFilter: "blur(10px)",
                    WebkitBackdropFilter: "blur(10px)",
                    borderTopLeftRadius: "16px",
                    borderTopRightRadius: "16px",
                    boxShadow: "0 -2px 20px rgba(0, 0, 0, 0.1)"
                  },
                  children: [
                    E.jsxs("div", {
                      className: "p-4 flex items-center justify-between",
                      style: {
                        borderBottom: "1px solid rgba(0, 0, 0, 0.1)"
                      },
                      children: [
                        E.jsx("button", {
                          onClick: () => {
                            Y(null), gt(null);
                          },
                          className: "text-sm font-medium px-3 py-1 rounded-full",
                          style: {
                            color: oe.blue
                          },
                          children: "Close"
                        }),
                        E.jsx("h3", {
                          className: "font-semibold text-base md:text-lg",
                          style: {
                            fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Arial, sans-serif'
                          },
                          children: "Location Details"
                        }),
                        E.jsx("button", {
                          onClick: () => k(true),
                          className: "text-sm font-medium px-3 py-1 rounded-full",
                          style: {
                            color: oe.blue
                          },
                          children: "Add Review"
                        })
                      ]
                    }),
                    E.jsx("div", {
                      className: "p-4 overflow-y-auto",
                      children: i[Q] && E.jsx("div", {
                        className: "flex flex-col gap-4",
                        children: E.jsxs("div", {
                          children: [
                            E.jsx("h2", {
                              className: "text-xl font-semibold mb-2",
                              children: i[Q].name
                            }),
                            i[Q].description && E.jsx("p", {
                              className: "text-gray-700 mb-4",
                              children: i[Q].description
                            }),
                            i[Q].category && h[i[Q].category] && E.jsxs("div", {
                              className: "flex items-center gap-2 mb-4",
                              children: [
                                E.jsx("span", {
                                  className: "w-3 h-3 rounded-full",
                                  style: {
                                    backgroundColor: h[i[Q].category].color
                                  }
                                }),
                                E.jsx("span", {
                                  className: "text-sm text-gray-600",
                                  children: h[i[Q].category].name
                                })
                              ]
                            }),
                            E.jsxs("div", {
                              className: "text-sm text-gray-600 mb-4",
                              children: [
                                "Added by:",
                                " ",
                                d === i[Q].addedBy ? "You" : le[i[Q].addedBy] || "Anonymous"
                              ]
                            }),
                            E.jsxs("div", {
                              className: "text-sm text-gray-600 mb-4",
                              children: [
                                "Coordinates:",
                                " ",
                                i[Q].latitude.toFixed(6),
                                ",",
                                " ",
                                i[Q].longitude.toFixed(6)
                              ]
                            }),
                            i[Q].placeId && E.jsxs("div", {
                              className: "mb-4",
                              children: [
                                E.jsxs("h3", {
                                  className: "text-md font-semibold mb-2 flex items-center gap-2",
                                  children: [
                                    E.jsx(Bw, {
                                      className: "h-4 w-4"
                                    }),
                                    "Business Hours"
                                  ]
                                }),
                                Ee ? E.jsxs("div", {
                                  className: "flex items-center gap-2 text-gray-500",
                                  children: [
                                    E.jsx("div", {
                                      className: "animate-spin h-4 w-4 border-2 border-blue-500 rounded-full border-t-transparent"
                                    }),
                                    E.jsx("span", {
                                      children: "Loading hours..."
                                    })
                                  ]
                                }) : me ? E.jsxs("div", {
                                  children: [
                                    E.jsx("div", {
                                      className: "text-sm mb-2",
                                      children: E.jsx("span", {
                                        className: `font-medium ${me.isOpen ? "text-green-600" : "text-red-600"}`,
                                        children: me.isOpen ? "Open now" : "Closed now"
                                      })
                                    }),
                                    E.jsx("div", {
                                      className: "text-sm text-gray-600 space-y-1",
                                      children: me.weekdayText.map((K, he) => E.jsxs("div", {
                                        className: "flex justify-between",
                                        children: [
                                          E.jsx("span", {
                                            children: K.split(": ")[0]
                                          }),
                                          E.jsx("span", {
                                            children: K.split(": ")[1]
                                          })
                                        ]
                                      }, he))
                                    })
                                  ]
                                }) : E.jsx("div", {
                                  className: "text-sm text-gray-500",
                                  children: "No business hours available"
                                })
                              ]
                            }),
                            E.jsxs("div", {
                              className: "mt-6",
                              children: [
                                E.jsxs("h3", {
                                  className: "text-lg font-semibold mb-3 flex items-center gap-2",
                                  children: [
                                    E.jsx(Kw, {
                                      className: "h-5 w-5"
                                    }),
                                    "Reviews"
                                  ]
                                }),
                                !i[Q].reviews || i[Q].reviews.length === 0 ? E.jsx("div", {
                                  className: "text-gray-500 text-sm",
                                  children: "No reviews yet. Be the first to add a review!"
                                }) : E.jsx("div", {
                                  className: "space-y-4",
                                  children: (_b = i[Q].reviews) == null ? void 0 : _b.map((K) => {
                                    const he = le[K.userId] || "Anonymous", Ae = K.userId === d;
                                    return E.jsxs("div", {
                                      className: "p-4 rounded-lg",
                                      style: {
                                        backgroundColor: "rgba(0, 0, 0, 0.03)"
                                      },
                                      children: [
                                        E.jsxs("div", {
                                          className: "flex justify-between items-start",
                                          children: [
                                            E.jsxs("div", {
                                              className: "flex items-center gap-2 mb-2",
                                              children: [
                                                E.jsx("div", {
                                                  className: "flex",
                                                  children: [
                                                    ...Array(5)
                                                  ].map((Ne, Ve) => E.jsx(Qu, {
                                                    className: "h-4 w-4",
                                                    fill: Ve < K.rating ? oe.yellow : "none",
                                                    stroke: Ve < K.rating ? oe.yellow : oe.gray.dark
                                                  }, Ve))
                                                }),
                                                E.jsx("span", {
                                                  className: "text-sm font-medium",
                                                  children: Ae ? "You" : he
                                                })
                                              ]
                                            }),
                                            Ae && E.jsx("button", {
                                              onClick: () => c(Q, K.id),
                                              className: "text-xs text-red-500",
                                              children: "Delete"
                                            })
                                          ]
                                        }),
                                        E.jsx("p", {
                                          className: "text-sm text-gray-700",
                                          children: K.comment
                                        }),
                                        E.jsx("div", {
                                          className: "text-xs text-gray-500 mt-2",
                                          children: new Date(K.createdAt).toLocaleDateString()
                                        })
                                      ]
                                    }, K.id);
                                  })
                                }),
                                E.jsx("button", {
                                  onClick: () => k(true),
                                  className: "mt-4 w-full py-2 rounded-lg font-medium text-sm",
                                  style: {
                                    backgroundColor: oe.blue,
                                    color: "white"
                                  },
                                  children: "Add Your Review"
                                })
                              ]
                            })
                          ]
                        })
                      })
                    })
                  ]
                }),
                Q && R && E.jsxs("div", {
                  className: "absolute inset-x-0 bottom-0 bg-white rounded-t-xl shadow-lg z-[10000] transition-transform transform translate-y-0 max-h-[80vh] md:max-h-[60%] flex flex-col",
                  style: {
                    backgroundColor: "rgba(255, 255, 255, 0.95)",
                    backdropFilter: "blur(10px)",
                    WebkitBackdropFilter: "blur(10px)",
                    borderTopLeftRadius: "16px",
                    borderTopRightRadius: "16px",
                    boxShadow: "0 -2px 20px rgba(0, 0, 0, 0.1)"
                  },
                  children: [
                    E.jsxs("div", {
                      className: "p-4 flex items-center justify-between",
                      style: {
                        borderBottom: "1px solid rgba(0, 0, 0, 0.1)"
                      },
                      children: [
                        E.jsx("button", {
                          onClick: () => k(false),
                          className: "text-sm font-medium px-3 py-1 rounded-full",
                          style: {
                            color: oe.blue
                          },
                          children: "Back"
                        }),
                        E.jsx("h3", {
                          className: "font-semibold text-base md:text-lg",
                          style: {
                            fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Arial, sans-serif'
                          },
                          children: "Add Review"
                        }),
                        E.jsx("button", {
                          onClick: () => {
                            te.trim() && (r(Q, J, te), k(false));
                          },
                          disabled: !te.trim(),
                          className: "text-sm font-medium px-3 py-1 rounded-full",
                          style: {
                            color: te.trim() ? oe.blue : oe.gray.dark,
                            opacity: te.trim() ? 1 : 0.5
                          },
                          children: "Submit"
                        })
                      ]
                    }),
                    E.jsx("div", {
                      className: "p-4 overflow-y-auto",
                      children: i[Q] && E.jsxs("div", {
                        className: "flex flex-col gap-4",
                        children: [
                          E.jsx("h2", {
                            className: "text-lg font-medium mb-2",
                            children: i[Q].name
                          }),
                          E.jsxs("div", {
                            children: [
                              E.jsx("label", {
                                className: "block text-sm font-medium mb-2 text-gray-700",
                                children: "Your Rating"
                              }),
                              E.jsx("div", {
                                className: "flex gap-2",
                                children: [
                                  1,
                                  2,
                                  3,
                                  4,
                                  5
                                ].map((K) => E.jsx("button", {
                                  type: "button",
                                  onClick: () => ne(K),
                                  className: "p-2",
                                  children: E.jsx(Qu, {
                                    className: "h-8 w-8",
                                    fill: K <= J ? oe.yellow : "none",
                                    stroke: K <= J ? oe.yellow : oe.gray.dark
                                  })
                                }, K))
                              })
                            ]
                          }),
                          E.jsxs("div", {
                            children: [
                              E.jsx("label", {
                                htmlFor: "review-comment",
                                className: "block text-sm font-medium mb-2 text-gray-700",
                                children: "Your Review"
                              }),
                              E.jsx("textarea", {
                                id: "review-comment",
                                rows: 5,
                                placeholder: "Share your experience with this place...",
                                className: "w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2",
                                style: {
                                  borderColor: oe.gray.medium,
                                  borderRadius: "10px",
                                  fontSize: "16px",
                                  resize: "none"
                                },
                                value: te,
                                onChange: (K) => de(K.target.value)
                              })
                            ]
                          }),
                          E.jsx("button", {
                            onClick: () => {
                              te.trim() && (r(Q, J, te), k(false));
                            },
                            disabled: !te.trim(),
                            className: "mt-4 w-full py-3 rounded-lg font-medium",
                            style: {
                              backgroundColor: te.trim() ? oe.blue : oe.gray.light,
                              color: te.trim() ? "white" : oe.gray.dark,
                              opacity: te.trim() ? 1 : 0.7
                            },
                            children: "Submit Review"
                          })
                        ]
                      })
                    })
                  ]
                }),
                g && E.jsxs("div", {
                  className: "absolute inset-x-0 bottom-0 bg-white rounded-t-xl shadow-lg z-[10000] transition-transform transform translate-y-0 max-h-[80vh] md:max-h-[60%] flex flex-col",
                  style: {
                    backgroundColor: "rgba(255, 255, 255, 0.95)",
                    backdropFilter: "blur(10px)",
                    WebkitBackdropFilter: "blur(10px)",
                    borderTopLeftRadius: "16px",
                    borderTopRightRadius: "16px",
                    boxShadow: "0 -2px 20px rgba(0, 0, 0, 0.1)"
                  },
                  children: [
                    E.jsxs("div", {
                      className: "p-4 flex items-center justify-between",
                      style: {
                        borderBottom: "1px solid rgba(0, 0, 0, 0.1)"
                      },
                      children: [
                        E.jsx("button", {
                          onClick: ii,
                          className: "text-sm font-medium px-3 py-1 rounded-full",
                          style: {
                            color: oe.blue
                          },
                          children: "Cancel"
                        }),
                        E.jsx("h3", {
                          className: "font-semibold text-base md:text-lg",
                          style: {
                            fontFamily: '-apple-system, BlinkMacSystemFont, "SF Pro Display", "SF Pro Text", "Helvetica Neue", Arial, sans-serif'
                          },
                          children: "Add Location"
                        }),
                        E.jsx("button", {
                          type: "button",
                          onClick: is,
                          disabled: p.latitude === 0 || !p.name.trim(),
                          className: "text-sm font-medium px-3 py-1 rounded-full",
                          style: {
                            color: p.latitude === 0 || !p.name.trim() ? oe.gray.dark : oe.blue,
                            opacity: p.latitude === 0 || !p.name.trim() ? 0.5 : 1
                          },
                          children: "Add"
                        })
                      ]
                    }),
                    E.jsx("div", {
                      className: "p-4 overflow-y-auto",
                      children: E.jsxs("form", {
                        className: "flex flex-col gap-4",
                        children: [
                          E.jsxs("div", {
                            children: [
                              E.jsx("label", {
                                htmlFor: "location-name",
                                className: "block text-sm font-medium mb-1",
                                style: {
                                  color: oe.text.secondary
                                },
                                children: "Name"
                              }),
                              E.jsx("input", {
                                id: "location-name",
                                type: "text",
                                placeholder: "Enter a name for this location",
                                className: "w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2",
                                style: {
                                  borderColor: oe.gray.medium,
                                  borderRadius: "10px",
                                  fontSize: "16px"
                                },
                                value: p.name,
                                onChange: (K) => b((he) => ({
                                  ...he,
                                  name: K.target.value
                                })),
                                required: true
                              })
                            ]
                          }),
                          E.jsxs("div", {
                            children: [
                              E.jsx("label", {
                                htmlFor: "location-description",
                                className: "block text-sm font-medium mb-1",
                                style: {
                                  color: oe.text.secondary
                                },
                                children: "Description (optional)"
                              }),
                              E.jsx("textarea", {
                                id: "location-description",
                                rows: 3,
                                placeholder: "What's special about this place?",
                                className: "w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2",
                                style: {
                                  borderColor: oe.gray.medium,
                                  borderRadius: "10px",
                                  fontSize: "16px",
                                  resize: "none"
                                },
                                value: p.description,
                                onChange: (K) => b((he) => ({
                                  ...he,
                                  description: K.target.value
                                }))
                              })
                            ]
                          }),
                          E.jsxs("div", {
                            children: [
                              E.jsx("label", {
                                htmlFor: "location-category",
                                className: "block text-sm font-medium mb-1",
                                style: {
                                  color: oe.text.secondary
                                },
                                children: "Category"
                              }),
                              E.jsx("div", {
                                className: "grid grid-cols-2 gap-2 mt-1",
                                children: Object.values(h).map((K) => E.jsxs("button", {
                                  type: "button",
                                  className: `p-2 rounded-lg flex items-center gap-2 transition-colors ${p.category === K.id ? "ring-2" : "hover:bg-gray-50"}`,
                                  style: {
                                    backgroundColor: p.category === K.id ? `${K.color}1A` : "white",
                                    borderColor: oe.gray.medium
                                  },
                                  onClick: () => b((he) => ({
                                    ...he,
                                    category: K.id
                                  })),
                                  children: [
                                    E.jsx("span", {
                                      className: "w-3 h-3 rounded-full",
                                      style: {
                                        backgroundColor: K.color
                                      }
                                    }),
                                    E.jsx("span", {
                                      className: "text-sm",
                                      children: K.name
                                    })
                                  ]
                                }, K.id))
                              })
                            ]
                          }),
                          p.latitude !== 0 && E.jsxs("div", {
                            className: "p-3 rounded-lg flex items-center gap-2 text-sm",
                            style: {
                              backgroundColor: "rgba(0, 122, 255, 0.1)",
                              borderRadius: "10px"
                            },
                            children: [
                              E.jsx(qr, {
                                className: "h-4 w-4",
                                style: {
                                  color: oe.blue
                                }
                              }),
                              E.jsx("span", {
                                style: {
                                  color: oe.text.primary
                                },
                                children: "Location selected. Tap on map to adjust."
                              })
                            ]
                          })
                        ]
                      })
                    })
                  ]
                }),
                Ea && E.jsx(yE, {
                  steps: Zn,
                  currentStep: Tt,
                  onNext: () => {
                    const K = Tt + 1;
                    Ge(K), localStorage.setItem("tour-main-step", K.toString());
                  },
                  onPrev: () => {
                    const K = Tt - 1;
                    Ge(K), localStorage.setItem("tour-main-step", K.toString());
                  },
                  onClose: () => {
                    xn(false), Ge(0), localStorage.removeItem("tour-main-active"), localStorage.removeItem("tour-main-step");
                  },
                  totalSteps: Zn.length,
                  tourId: "main"
                })
              ]
            })
          ]
        })
      ]
    });
  };
  function EE() {
    const { profiles: i, createProfile: a, activeProfileId: l, setActiveProfile: r } = wa();
    return ue.useEffect(() => {
      if (i.length === 0) {
        const c = a("Default User");
        r(c.id);
      } else !l && i.length > 0 && r(i[0].id);
    }, [
      i,
      l
    ]), E.jsx("div", {
      className: "h-screen w-screen overflow-hidden",
      children: E.jsx(wE, {})
    });
  }
  class AE {
    constructor(a = "automerge", l = "documents") {
      __publicField(this, "database");
      __publicField(this, "store");
      __publicField(this, "dbPromise");
      this.database = a, this.store = l, this.dbPromise = this.createDatabasePromise();
    }
    createDatabasePromise() {
      return new Promise((a, l) => {
        const r = indexedDB.open(this.database, 1);
        r.onerror = () => {
          l(r.error);
        }, r.onupgradeneeded = (c) => {
          c.target.result.createObjectStore(this.store);
        }, r.onsuccess = (c) => {
          const f = c.target.result;
          a(f);
        };
      });
    }
    async load(a) {
      const r = (await this.dbPromise).transaction(this.store), f = r.objectStore(this.store).get(a);
      return new Promise((d, h) => {
        r.onerror = () => {
          h(f.error);
        }, f.onsuccess = (g) => {
          const y = g.target.result;
          y && typeof y == "object" && "binary" in y ? d(y.binary) : d(void 0);
        };
      });
    }
    async save(a, l) {
      const c = (await this.dbPromise).transaction(this.store, "readwrite");
      return c.objectStore(this.store).put({
        key: a,
        binary: l
      }, a), new Promise((d, h) => {
        c.onerror = () => {
          h(c.error);
        }, c.oncomplete = () => {
          d();
        };
      });
    }
    async remove(a) {
      const r = (await this.dbPromise).transaction(this.store, "readwrite");
      return r.objectStore(this.store).delete(a), new Promise((f, d) => {
        r.onerror = () => {
          d(r.error);
        }, r.oncomplete = () => {
          f();
        };
      });
    }
    async loadRange(a) {
      const l = await this.dbPromise, r = a, c = [
        ...a,
        "\uFFFF"
      ], f = IDBKeyRange.bound(r, c), d = l.transaction(this.store), g = d.objectStore(this.store).openCursor(f), y = [];
      return new Promise((p, b) => {
        d.onerror = () => {
          b(g.error);
        }, g.onsuccess = (S) => {
          const x = S.target.result;
          x ? (y.push({
            data: x.value.binary,
            key: x.key
          }), x.continue()) : p(y);
        };
      });
    }
    async removeRange(a) {
      const l = await this.dbPromise, r = a, c = [
        ...a,
        "\uFFFF"
      ], f = IDBKeyRange.bound(r, c), d = l.transaction(this.store, "readwrite");
      return d.objectStore(this.store).delete(f), new Promise((g, y) => {
        d.onerror = () => {
          y(d.error);
        }, d.oncomplete = () => {
          g();
        };
      });
    }
  }
  var Qi = null;
  typeof WebSocket < "u" ? Qi = WebSocket : typeof MozWebSocket < "u" ? Qi = MozWebSocket : typeof global < "u" ? Qi = global.WebSocket || global.MozWebSocket : typeof window < "u" ? Qi = window.WebSocket || window.MozWebSocket : typeof self < "u" && (Qi = self.WebSocket || self.MozWebSocket);
  const Zu = Qi, TE = (i) => i.type === "peer", OE = (i) => i.type === "error", CE = "1";
  function gn(i, a = "Assertion failed") {
    if (i === false || i === null || i === void 0) {
      const l = new Error(_E(a));
      throw l.stack = NE(l.stack, "assert.ts"), l;
    }
  }
  const _E = (i) => i.split(`
`).map((a) => a.trim()).join(`
`), NE = (i = "", a) => i.split(`
`).filter((l) => !l.includes(a)).join(`
`), RE = (i) => {
    const { buffer: a, byteOffset: l, byteLength: r } = i;
    return a.slice(l, l + r);
  };
  class jE extends N2 {
    constructor() {
      super(...arguments);
      __publicField(this, "socket");
    }
  }
  class ME extends jE {
    constructor(a, l = 5e3) {
      super();
      __privateAdd(this, _ME_instances);
      __publicField(this, "url");
      __publicField(this, "retryInterval");
      __privateAdd(this, _t8, false);
      __privateAdd(this, _e8);
      __privateAdd(this, _n8, Qn("automerge-repo:websocket:browser"));
      __publicField(this, "remotePeerId");
      __publicField(this, "onOpen", () => {
        __privateGet(this, _n8).call(this, "open"), clearInterval(__privateGet(this, _e8)), __privateSet(this, _e8, void 0), this.join();
      });
      __publicField(this, "onClose", () => {
        __privateGet(this, _n8).call(this, "close"), this.remotePeerId && this.emit("peer-disconnected", {
          peerId: this.remotePeerId
        }), this.retryInterval > 0 && !__privateGet(this, _e8) && setTimeout(() => (gn(this.peerId), this.connect(this.peerId, this.peerMetadata)), this.retryInterval);
      });
      __publicField(this, "onMessage", (a) => {
        this.receiveMessage(a.data);
      });
      __publicField(this, "onError", (a) => {
        if ("error" in a && a.error.code !== "ECONNREFUSED") throw a.error;
        __privateGet(this, _n8).call(this, "Connection failed, retrying...");
      });
      this.url = a, this.retryInterval = l, __privateSet(this, _n8, __privateGet(this, _n8).extend(a));
    }
    connect(a, l) {
      !this.socket || !this.peerId ? (__privateGet(this, _n8).call(this, "connecting"), this.peerId = a, this.peerMetadata = l ?? {}) : (__privateGet(this, _n8).call(this, "reconnecting"), gn(a === this.peerId), this.socket.removeEventListener("open", this.onOpen), this.socket.removeEventListener("close", this.onClose), this.socket.removeEventListener("message", this.onMessage), this.socket.removeEventListener("error", this.onError)), __privateGet(this, _e8) || __privateSet(this, _e8, setInterval(() => {
        this.connect(a, l);
      }, this.retryInterval)), this.socket = new Zu(this.url), this.socket.binaryType = "arraybuffer", this.socket.addEventListener("open", this.onOpen), this.socket.addEventListener("close", this.onClose), this.socket.addEventListener("message", this.onMessage), this.socket.addEventListener("error", this.onError), setTimeout(() => __privateMethod(this, _ME_instances, a_fn2).call(this), 1e3), this.join();
    }
    join() {
      gn(this.peerId), gn(this.socket), this.socket.readyState === Zu.OPEN && this.send(DE(this.peerId, this.peerMetadata));
    }
    disconnect() {
      gn(this.peerId), gn(this.socket), this.send({
        type: "leave",
        senderId: this.peerId
      });
    }
    send(a) {
      var _a7;
      if ("data" in a && ((_a7 = a.data) == null ? void 0 : _a7.byteLength) === 0) throw new Error("Tried to send a zero-length message");
      if (gn(this.peerId), gn(this.socket), this.socket.readyState !== Zu.OPEN) throw new Error(`Websocket not ready (${this.socket.readyState})`);
      const l = Tp(a);
      this.socket.send(RE(l));
    }
    peerCandidate(a, l) {
      gn(this.socket), __privateMethod(this, _ME_instances, a_fn2).call(this), this.remotePeerId = a, this.emit("peer-candidate", {
        peerId: a,
        peerMetadata: l
      });
    }
    receiveMessage(a) {
      const l = Jx(new Uint8Array(a));
      if (gn(this.socket), a.byteLength === 0) throw new Error("received a zero-length message");
      if (TE(l)) {
        const { peerMetadata: r } = l;
        __privateGet(this, _n8).call(this, `peer: ${l.senderId}`), this.peerCandidate(l.senderId, r);
      } else OE(l) ? __privateGet(this, _n8).call(this, `error: ${l.message}`) : this.emit("message", l);
    }
  }
  _t8 = new WeakMap();
  _e8 = new WeakMap();
  _n8 = new WeakMap();
  _ME_instances = new WeakSet();
  a_fn2 = function() {
    __privateGet(this, _t8) || (__privateSet(this, _t8, true), this.emit("ready", {
      network: this
    }));
  };
  function DE(i, a) {
    return {
      type: "join",
      senderId: i,
      peerMetadata: a,
      supportedProtocolVersions: [
        CE
      ]
    };
  }
  Qn("WebsocketServer");
  const UE = window.location.protocol === "https:" ? "wss:" : "ws:", zE = `${UE}//${window.location.host}/sync`, kE = new ME(zE), BE = new AE(), HE = xw({
    url: `${window.location.protocol}//${window.location.host}`,
    network: [
      kE
    ],
    storage: BE
  });
  await HE.whenReady();
  const yg = document.getElementById("root");
  if (!yg) throw new Error("Failed to find the root element");
  const LE = n1.createRoot(yg);
  LE.render(E.jsx(Ku.StrictMode, {
    children: E.jsx(Uv, {
      children: E.jsx(EE, {})
    })
  }));
});
