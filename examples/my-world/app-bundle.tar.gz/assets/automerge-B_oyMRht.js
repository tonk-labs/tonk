let ke, qo, Jo, Go, Ko, c_, o_, __, a_, Xo, Zo, Mn, Yo, Qo, n_, No, e_, r_, Lo, t_, s_, Wo, i_;
let __tla = (async () => {
  const M = Symbol.for("_am_meta"), $ = Symbol.for("_am_trace"), U = Symbol.for("_am_objectId"), ee = Symbol.for("_am_isProxy"), ye = Symbol.for("_am_clearCache"), fn = Symbol.for("_am_uint"), dn = Symbol.for("_am_int"), ln = Symbol.for("_am_f64"), ve = Symbol.for("_am_counter"), bn = Symbol.for("_am_text");
  class D {
    constructor(e) {
      if (typeof e == "string") this.elems = [
        ...e
      ];
      else if (Array.isArray(e)) this.elems = e;
      else if (e === void 0) this.elems = [];
      else throw new TypeError(`Unsupported initial value for Text: ${e}`);
      Reflect.defineProperty(this, bn, {
        value: true
      });
    }
    get length() {
      return this.elems.length;
    }
    get(e) {
      return this.elems[e];
    }
    [Symbol.iterator]() {
      const e = this.elems;
      let n = -1;
      return {
        next() {
          return n += 1, n < e.length ? {
            done: false,
            value: e[n]
          } : {
            done: true
          };
        }
      };
    }
    toString() {
      if (!this.str) {
        this.str = "";
        for (const e of this.elems) typeof e == "string" ? this.str += e : this.str += "\uFFFC";
      }
      return this.str;
    }
    toSpans() {
      if (!this.spans) {
        this.spans = [];
        let e = "";
        for (const n of this.elems) typeof n == "string" ? e += n : (e.length > 0 && (this.spans.push(e), e = ""), this.spans.push(n));
        e.length > 0 && this.spans.push(e);
      }
      return this.spans;
    }
    toJSON() {
      return this.toString();
    }
    set(e, n) {
      if (this[M]) throw new RangeError("object cannot be modified outside of a change block");
      this.elems[e] = n;
    }
    insertAt(e, ...n) {
      if (this[M]) throw new RangeError("object cannot be modified outside of a change block");
      n.every((r) => typeof r == "string") ? this.elems.splice(e, 0, ...n.join("")) : this.elems.splice(e, 0, ...n);
    }
    deleteAt(e, n = 1) {
      if (this[M]) throw new RangeError("object cannot be modified outside of a change block");
      this.elems.splice(e, n);
    }
    map(e) {
      this.elems.map(e);
    }
    lastIndexOf(e, n) {
      this.elems.lastIndexOf(e, n);
    }
    concat(e) {
      return new D(this.elems.concat(e.elems));
    }
    every(e) {
      return this.elems.every(e);
    }
    filter(e) {
      return new D(this.elems.filter(e));
    }
    find(e) {
      return this.elems.find(e);
    }
    findIndex(e) {
      return this.elems.findIndex(e);
    }
    forEach(e) {
      this.elems.forEach(e);
    }
    includes(e) {
      return this.elems.includes(e);
    }
    indexOf(e) {
      return this.elems.indexOf(e);
    }
    join(e) {
      return this.elems.join(e);
    }
    reduce(e) {
      this.elems.reduce(e);
    }
    reduceRight(e) {
      this.elems.reduceRight(e);
    }
    slice(e, n) {
      return new D(this.elems.slice(e, n));
    }
    some(e) {
      return this.elems.some(e);
    }
    toLocaleString() {
      this.toString();
    }
  }
  class ae {
    constructor(e) {
      this.value = e || 0, Reflect.defineProperty(this, ve, {
        value: true
      });
    }
    valueOf() {
      return this.value;
    }
    toString() {
      return this.valueOf().toString();
    }
    toJSON() {
      return this.value;
    }
    increment(e) {
      throw new Error("Counters should not be incremented outside of a change callback");
    }
    decrement(e) {
      throw new Error("Counters should not be decremented outside of a change callback");
    }
  }
  class wn extends ae {
    constructor(e, n, r, o, s) {
      super(e), this.context = n, this.path = r, this.objectId = o, this.key = s;
    }
    increment(e) {
      return e = typeof e == "number" ? e : 1, this.context.increment(this.objectId, this.key, e), this.value += e, this.value;
    }
    decrement(e) {
      return this.increment(typeof e == "number" ? -e : -1);
    }
  }
  function pn(t, e, n, r, o) {
    return new wn(t, e, n, r, o);
  }
  class se {
    constructor(e) {
      this.val = e;
    }
    toString() {
      return this.val;
    }
    toJSON() {
      return this.val;
    }
  }
  function T(t) {
    if (typeof t == "string" && /^[0-9]+$/.test(t) && (t = parseInt(t, 10)), typeof t != "number") return t;
    if (t < 0 || isNaN(t) || t === 1 / 0 || t === -1 / 0) throw new RangeError("A list index must be positive, but you passed " + t);
    return t;
  }
  function A(t, e) {
    const { context: n, objectId: r, path: o, textV2: s } = t, a = n.getWithType(r, e);
    if (a === null) return;
    const c = a[0], d = a[1];
    switch (c) {
      case void 0:
        return;
      case "map":
        return L(n, d, s, [
          ...o,
          e
        ]);
      case "list":
        return ne(n, d, s, [
          ...o,
          e
        ]);
      case "text":
        return s ? n.text(d) : F(n, d, [
          ...o,
          e
        ]);
      case "str":
        return d;
      case "uint":
        return d;
      case "int":
        return d;
      case "f64":
        return d;
      case "boolean":
        return d;
      case "null":
        return null;
      case "bytes":
        return d;
      case "timestamp":
        return d;
      case "counter":
        return pn(d, n, o, r, e);
      default:
        throw RangeError(`datatype ${c} unimplemented`);
    }
  }
  function Q(t, e, n, r) {
    const o = typeof t;
    switch (o) {
      case "object":
        if (t == null) return [
          null,
          "null"
        ];
        if (t[fn]) return [
          t.value,
          "uint"
        ];
        if (t[dn]) return [
          t.value,
          "int"
        ];
        if (t[ln]) return [
          t.value,
          "f64"
        ];
        if (t[ve]) return [
          t.value,
          "counter"
        ];
        if (t instanceof Date) return [
          t.getTime(),
          "timestamp"
        ];
        if (t instanceof se) return [
          t.toString(),
          "str"
        ];
        if (t instanceof D) return [
          t,
          "text"
        ];
        if (t instanceof Uint8Array) return [
          t,
          "bytes"
        ];
        if (t instanceof Array) return [
          t,
          "list"
        ];
        if (Object.prototype.toString.call(t) === "[object Object]") return [
          t,
          "map"
        ];
        throw te(t, r) ? new RangeError("Cannot create a reference to an existing document object") : new RangeError(`Cannot assign unknown object: ${t}`);
      case "boolean":
        return [
          t,
          "boolean"
        ];
      case "number":
        return Number.isInteger(t) ? [
          t,
          "int"
        ] : [
          t,
          "f64"
        ];
      case "string":
        return e ? [
          t,
          "text"
        ] : [
          t,
          "str"
        ];
      case "undefined":
        throw new RangeError([
          `Cannot assign undefined value at ${le(n)}, `,
          "because `undefined` is not a valid JSON data type. ",
          "You might consider setting the property's value to `null`, ",
          "or using `delete` to remove it altogether."
        ].join(""));
      default:
        throw new RangeError([
          `Cannot assign ${o} value at ${le(n)}. `,
          "All JSON primitive datatypes (object, array, string, number, boolean, null) ",
          `are supported in an Automerge document; ${o} values are not. `
        ].join(""));
    }
  }
  function te(t, e) {
    var n, r;
    return t instanceof Date ? false : !!(t && ((r = (n = t[M]) === null || n === void 0 ? void 0 : n.handle) === null || r === void 0 ? void 0 : r.__wbg_ptr) === e.__wbg_ptr);
  }
  const hn = {
    get(t, e) {
      const { context: n, objectId: r, cache: o } = t;
      return e === Symbol.toStringTag ? t[Symbol.toStringTag] : e === U ? r : e === ee ? true : e === $ ? t.trace : e === M ? {
        handle: n,
        textV2: t.textV2
      } : (o[e] || (o[e] = A(t, e)), o[e]);
    },
    set(t, e, n) {
      const { context: r, objectId: o, path: s, textV2: a } = t;
      if (t.cache = {}, te(n, r)) throw new RangeError("Cannot create a reference to an existing document object");
      if (e === $) return t.trace = n, true;
      if (e === ye) return true;
      const [c, d] = Q(n, a, [
        ...s,
        e
      ], r);
      switch (d) {
        case "list": {
          const b = r.putObject(o, e, []), p = ne(r, b, a, [
            ...s,
            e
          ]);
          for (let w = 0; w < c.length; w++) p[w] = c[w];
          break;
        }
        case "text": {
          if (a) Z(c), r.putObject(o, e, c);
          else {
            ge(c);
            const b = r.putObject(o, e, "");
            F(r, b, [
              ...s,
              e
            ]).splice(0, 0, ...c);
          }
          break;
        }
        case "map": {
          const b = r.putObject(o, e, {}), p = L(r, b, a, [
            ...s,
            e
          ]);
          for (const w in c) p[w] = c[w];
          break;
        }
        default:
          r.put(o, e, c, d);
      }
      return true;
    },
    deleteProperty(t, e) {
      const { context: n, objectId: r } = t;
      return t.cache = {}, n.delete(r, e), true;
    },
    has(t, e) {
      return this.get(t, e) !== void 0;
    },
    getOwnPropertyDescriptor(t, e) {
      const n = this.get(t, e);
      if (typeof n < "u") return {
        configurable: true,
        enumerable: true,
        value: n
      };
    },
    ownKeys(t) {
      const { context: e, objectId: n } = t, r = e.keys(n);
      return [
        ...new Set(r)
      ];
    }
  }, Se = {
    get(t, e) {
      const { context: n, objectId: r } = t;
      return e = T(e), e === Symbol.hasInstance ? (o) => Array.isArray(o) : e === Symbol.toStringTag ? t[Symbol.toStringTag] : e === U ? r : e === ee ? true : e === $ ? t.trace : e === M ? {
        handle: n
      } : e === "length" ? n.length(r) : typeof e == "number" ? A(t, e) : ue(t)[e];
    },
    set(t, e, n) {
      const { context: r, objectId: o, path: s, textV2: a } = t;
      if (e = T(e), te(n, r)) throw new RangeError("Cannot create a reference to an existing document object");
      if (e === ye) return true;
      if (e === $) return t.trace = n, true;
      if (typeof e == "string") throw new RangeError("list index must be a number");
      const [c, d] = Q(n, a, [
        ...s,
        e
      ], r);
      switch (d) {
        case "list": {
          let b;
          e >= r.length(o) ? b = r.insertObject(o, e, []) : b = r.putObject(o, e, []), ne(r, b, a, [
            ...s,
            e
          ]).splice(0, 0, ...c);
          break;
        }
        case "text": {
          if (a) Z(c), e >= r.length(o) ? r.insertObject(o, e, c) : r.putObject(o, e, c);
          else {
            let b;
            ge(c), e >= r.length(o) ? b = r.insertObject(o, e, "") : b = r.putObject(o, e, ""), F(r, b, [
              ...s,
              e
            ]).splice(0, 0, ...c);
          }
          break;
        }
        case "map": {
          let b;
          e >= r.length(o) ? b = r.insertObject(o, e, {}) : b = r.putObject(o, e, {});
          const p = L(r, b, a, [
            ...s,
            e
          ]);
          for (const w in c) p[w] = c[w];
          break;
        }
        default:
          e >= r.length(o) ? r.insert(o, e, c, d) : r.put(o, e, c, d);
      }
      return true;
    },
    deleteProperty(t, e) {
      const { context: n, objectId: r } = t;
      e = T(e);
      const o = n.get(r, e);
      if (o != null && o[0] == "counter") throw new TypeError("Unsupported operation: deleting a counter from a list");
      return n.delete(r, e), true;
    },
    has(t, e) {
      const { context: n, objectId: r } = t;
      return e = T(e), typeof e == "number" ? e < n.length(r) : e === "length";
    },
    getOwnPropertyDescriptor(t, e) {
      const { context: n, objectId: r } = t;
      return e === "length" ? {
        writable: true,
        value: n.length(r)
      } : e === U ? {
        configurable: false,
        enumerable: false,
        value: r
      } : (e = T(e), {
        configurable: true,
        enumerable: true,
        value: A(t, e)
      });
    },
    getPrototypeOf(t) {
      return Object.getPrototypeOf(t);
    },
    ownKeys() {
      const t = [];
      return t.push("length"), t;
    }
  }, mn = Object.assign({}, Se, {
    get(t, e) {
      const { context: n, objectId: r } = t;
      return e = T(e), e === Symbol.hasInstance ? (o) => Array.isArray(o) : e === Symbol.toStringTag ? t[Symbol.toStringTag] : e === U ? r : e === ee ? true : e === $ ? t.trace : e === M ? {
        handle: n
      } : e === "length" ? n.length(r) : typeof e == "number" ? A(t, e) : vn(t)[e] || ue(t)[e];
    },
    getPrototypeOf() {
      return Object.getPrototypeOf(new D());
    }
  });
  function L(t, e, n, r) {
    const o = {
      context: t,
      objectId: e,
      path: r || [],
      cache: {},
      textV2: n
    }, s = {};
    return Object.assign(s, o), new Proxy(s, hn);
  }
  function ne(t, e, n, r) {
    const o = {
      context: t,
      objectId: e,
      path: r || [],
      cache: {},
      textV2: n
    }, s = [];
    return Object.assign(s, o), new Proxy(s, Se);
  }
  function F(t, e, n) {
    const r = {
      context: t,
      objectId: e,
      path: n || [],
      cache: {},
      textV2: false
    }, o = {};
    return Object.assign(o, r), new Proxy(o, mn);
  }
  function yn(t, e) {
    return L(t, "_root", e, []);
  }
  function ue(t) {
    const { context: e, objectId: n, path: r, textV2: o } = t;
    return {
      deleteAt(a, c) {
        return typeof c == "number" ? e.splice(n, a, c) : e.delete(n, a), this;
      },
      fill(a, c, d) {
        const [b, p] = Q(a, o, [
          ...r,
          c
        ], e), w = e.length(n);
        c = T(c || 0), d = T(d || w);
        for (let m = c; m < Math.min(d, w); m++) if (p === "list" || p === "map") e.putObject(n, m, b);
        else if (p === "text") if (o) Z(b), e.putObject(n, m, b);
        else {
          ge(b);
          const x = e.putObject(n, m, ""), B = F(e, x, [
            ...r,
            m
          ]);
          for (let H = 0; H < b.length; H++) B[H] = b.get(H);
        }
        else e.put(n, m, b, p);
        return this;
      },
      indexOf(a, c = 0) {
        const d = e.length(n);
        for (let b = c; b < d; b++) {
          const p = e.getWithType(n, b);
          if (p && (p[1] === a[U] || p[1] === a)) return b;
        }
        return -1;
      },
      insertAt(a, ...c) {
        return this.splice(a, 0, ...c), this;
      },
      pop() {
        const a = e.length(n);
        if (a == 0) return;
        const c = A(t, a - 1);
        return e.delete(n, a - 1), c;
      },
      push(...a) {
        const c = e.length(n);
        return this.splice(c, 0, ...a), e.length(n);
      },
      shift() {
        if (e.length(n) == 0) return;
        const a = A(t, 0);
        return e.delete(n, 0), a;
      },
      splice(a, c, ...d) {
        a = T(a), typeof c != "number" && (c = e.length(n) - a), c = T(c);
        for (const w of d) if (te(w, e)) throw new RangeError("Cannot create a reference to an existing document object");
        const b = [];
        for (let w = 0; w < c; w++) {
          const m = A(t, a);
          m !== void 0 && b.push(m), e.delete(n, a);
        }
        const p = d.map((w, m) => {
          try {
            return Q(w, o, [
              ...r
            ], e);
          } catch (x) {
            throw x instanceof RangeError ? new RangeError(`${x.message} (at index ${m} in the input)`) : x;
          }
        });
        for (const [w, m] of p) {
          switch (m) {
            case "list": {
              const x = e.insertObject(n, a, []);
              ne(e, x, o, [
                ...r,
                a
              ]).splice(0, 0, ...w);
              break;
            }
            case "text": {
              if (o) Z(w), e.insertObject(n, a, w);
              else {
                const x = e.insertObject(n, a, "");
                F(e, x, [
                  ...r,
                  a
                ]).splice(0, 0, ...w);
              }
              break;
            }
            case "map": {
              const x = e.insertObject(n, a, {}), B = L(e, x, o, [
                ...r,
                a
              ]);
              for (const H in w) B[H] = w[H];
              break;
            }
            default:
              e.insert(n, a, w, m);
          }
          a += 1;
        }
        return b;
      },
      unshift(...a) {
        return this.splice(0, 0, ...a), e.length(n);
      },
      entries() {
        let a = 0;
        return {
          next: () => {
            const d = A(t, a);
            return d === void 0 ? {
              value: void 0,
              done: true
            } : {
              value: [
                a++,
                d
              ],
              done: false
            };
          },
          [Symbol.iterator]() {
            return this;
          }
        };
      },
      keys() {
        let a = 0;
        const c = e.length(n);
        return {
          next: () => a < c ? {
            value: a++,
            done: false
          } : {
            value: void 0,
            done: true
          },
          [Symbol.iterator]() {
            return this;
          }
        };
      },
      values() {
        let a = 0;
        return {
          next: () => {
            const d = A(t, a++);
            return d === void 0 ? {
              value: void 0,
              done: true
            } : {
              value: d,
              done: false
            };
          },
          [Symbol.iterator]() {
            return this;
          }
        };
      },
      toArray() {
        const a = [];
        let c;
        do
          c = A(t, a.length), c !== void 0 && a.push(c);
        while (c !== void 0);
        return a;
      },
      map(a) {
        return this.toArray().map(a);
      },
      toString() {
        return this.toArray().toString();
      },
      toLocaleString() {
        return this.toArray().toLocaleString();
      },
      forEach(a) {
        return this.toArray().forEach(a);
      },
      concat(a) {
        return this.toArray().concat(a);
      },
      every(a) {
        return this.toArray().every(a);
      },
      filter(a) {
        return this.toArray().filter(a);
      },
      find(a) {
        let c = 0;
        for (const d of this) {
          if (a(d, c)) return d;
          c += 1;
        }
      },
      findIndex(a) {
        let c = 0;
        for (const d of this) {
          if (a(d, c)) return c;
          c += 1;
        }
        return -1;
      },
      includes(a) {
        return this.find((c) => c === a) !== void 0;
      },
      join(a) {
        return this.toArray().join(a);
      },
      reduce(a, c) {
        return this.toArray().reduce(a, c);
      },
      reduceRight(a, c) {
        return this.toArray().reduceRight(a, c);
      },
      lastIndexOf(a, c = 1 / 0) {
        return this.toArray().lastIndexOf(a, c);
      },
      slice(a, c) {
        return this.toArray().slice(a, c);
      },
      some(a) {
        let c = 0;
        for (const d of this) {
          if (a(d, c)) return true;
          c += 1;
        }
        return false;
      },
      [Symbol.iterator]: function* () {
        let a = 0, c = A(t, a);
        for (; c !== void 0; ) yield c, a += 1, c = A(t, a);
      }
    };
  }
  function vn(t) {
    const { context: e, objectId: n } = t;
    return {
      set(o, s) {
        return this[o] = s;
      },
      get(o) {
        return this[o];
      },
      toString() {
        return e.text(n).replace(/￼/g, "");
      },
      toSpans() {
        const o = [];
        let s = "";
        const a = e.length(n);
        for (let c = 0; c < a; c++) {
          const d = this[c];
          typeof d == "string" ? s += d : (s.length > 0 && (o.push(s), s = ""), o.push(d));
        }
        return s.length > 0 && o.push(s), o;
      },
      toJSON() {
        return this.toString();
      },
      indexOf(o, s = 0) {
        return e.text(n).indexOf(o, s);
      },
      insertAt(o, ...s) {
        s.every((a) => typeof a == "string") ? e.splice(n, o, 0, s.join("")) : ue(t).insertAt(o, ...s);
      }
    };
  }
  function ge(t) {
    if (!(t instanceof D)) throw new Error("value was not a Text instance");
  }
  function Z(t) {
    if (typeof t != "string") throw new Error("value was not a string");
  }
  function le(t) {
    const e = t.map((n) => {
      if (typeof n == "number") return n.toString();
      if (typeof n == "string") return n.replace(/~/g, "~0").replace(/\//g, "~1");
    });
    return t.length === 0 ? "" : "/" + e.join("/");
  }
  let W;
  const Sn = new Uint8Array(16);
  function kn() {
    if (!W && (W = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !W)) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    return W(Sn);
  }
  const jn = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
  ke = function(t) {
    return typeof t == "string" && jn.test(t);
  };
  const y = [];
  for (let t = 0; t < 256; ++t) y.push((t + 256).toString(16).slice(1));
  function je(t, e = 0) {
    return y[t[e + 0]] + y[t[e + 1]] + y[t[e + 2]] + y[t[e + 3]] + "-" + y[t[e + 4]] + y[t[e + 5]] + "-" + y[t[e + 6]] + y[t[e + 7]] + "-" + y[t[e + 8]] + y[t[e + 9]] + "-" + y[t[e + 10]] + y[t[e + 11]] + y[t[e + 12]] + y[t[e + 13]] + y[t[e + 14]] + y[t[e + 15]];
  }
  Lo = function(t, e = 0) {
    const n = je(t, e);
    if (!ke(n)) throw TypeError("Stringified UUID is invalid");
    return n;
  };
  No = function(t) {
    if (!ke(t)) throw TypeError("Invalid UUID");
    let e;
    const n = new Uint8Array(16);
    return n[0] = (e = parseInt(t.slice(0, 8), 16)) >>> 24, n[1] = e >>> 16 & 255, n[2] = e >>> 8 & 255, n[3] = e & 255, n[4] = (e = parseInt(t.slice(9, 13), 16)) >>> 8, n[5] = e & 255, n[6] = (e = parseInt(t.slice(14, 18), 16)) >>> 8, n[7] = e & 255, n[8] = (e = parseInt(t.slice(19, 23), 16)) >>> 8, n[9] = e & 255, n[10] = (e = parseInt(t.slice(24, 36), 16)) / 1099511627776 & 255, n[11] = e / 4294967296 & 255, n[12] = e >>> 24 & 255, n[13] = e >>> 16 & 255, n[14] = e >>> 8 & 255, n[15] = e & 255, n;
  };
  const An = typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto), be = {
    randomUUID: An
  };
  Wo = function(t, e, n) {
    if (be.randomUUID && !e && !t) return be.randomUUID();
    t = t || {};
    const r = t.random || (t.rng || kn)();
    if (r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, e) {
      n = n || 0;
      for (let o = 0; o < 16; ++o) e[n + o] = r[o];
      return e;
    }
    return je(r);
  };
  let Ae;
  const Ce = new Array(128).fill(void 0);
  Ce.push(void 0, null, true, false);
  Ce.length;
  const _e = typeof TextEncoder < "u" ? new TextEncoder("utf-8") : {
    encode: () => {
      throw Error("TextEncoder not available");
    }
  };
  _e.encodeInto;
  const Cn = typeof TextDecoder < "u" ? new TextDecoder("utf-8", {
    ignoreBOM: true,
    fatal: true
  }) : {
    decode: () => {
      throw Error("TextDecoder not available");
    }
  };
  typeof TextDecoder < "u" && Cn.decode();
  typeof FinalizationRegistry > "u" || new FinalizationRegistry((t) => Ae.__wbg_automerge_free(t >>> 0));
  typeof FinalizationRegistry > "u" || new FinalizationRegistry((t) => Ae.__wbg_syncstate_free(t >>> 0));
  let On = [];
  function xn(t) {
    for (const e in t) k[e] = t[e];
    for (const e of On) e();
  }
  const k = {
    create(t) {
      throw new RangeError("Automerge.use() not called");
    },
    load(t, e) {
      throw new RangeError("Automerge.use() not called (load)");
    },
    encodeChange(t) {
      throw new RangeError("Automerge.use() not called (encodeChange)");
    },
    decodeChange(t) {
      throw new RangeError("Automerge.use() not called (decodeChange)");
    },
    initSyncState() {
      throw new RangeError("Automerge.use() not called (initSyncState)");
    },
    encodeSyncMessage(t) {
      throw new RangeError("Automerge.use() not called (encodeSyncMessage)");
    },
    decodeSyncMessage(t) {
      throw new RangeError("Automerge.use() not called (decodeSyncMessage)");
    },
    encodeSyncState(t) {
      throw new RangeError("Automerge.use() not called (encodeSyncState)");
    },
    decodeSyncState(t) {
      throw new RangeError("Automerge.use() not called (decodeSyncState)");
    },
    exportSyncState(t) {
      throw new RangeError("Automerge.use() not called (exportSyncState)");
    },
    importSyncState(t) {
      throw new RangeError("Automerge.use() not called (importSyncState)");
    }
  };
  function v(t, e = true) {
    if (typeof t != "object") throw new RangeError("must be the document root");
    const n = Reflect.get(t, M);
    if (n === void 0 || n == null || e && Rn(t) !== "_root") throw new RangeError("must be the document root");
    return n;
  }
  function Oe(t) {
    return Reflect.get(t, $);
  }
  function Rn(t) {
    return typeof t != "object" || t === null ? null : Reflect.get(t, U);
  }
  function re(t) {
    return !!Reflect.get(t, ee);
  }
  var Tn = function(t, e) {
    var n = {};
    for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && e.indexOf(r) < 0 && (n[r] = t[r]);
    if (t != null && typeof Object.getOwnPropertySymbols == "function") for (var o = 0, r = Object.getOwnPropertySymbols(t); o < r.length; o++) e.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(t, r[o]) && (n[r[o]] = t[r[o]]);
    return n;
  };
  function fe(t) {
    return typeof t == "object" ? t : {
      actor: t
    };
  }
  function de(t) {
    const e = fe(t), n = !!e.freeze, r = e.patchCallback, o = !e.enableTextV2, s = e.actor, a = k.create({
      actor: s,
      text_v1: o
    });
    a.enableFreeze(!!e.freeze);
    const c = e.enableTextV2 || false;
    return xe(a, c), a.materialize("/", void 0, {
      handle: a,
      heads: void 0,
      freeze: n,
      patchCallback: r,
      textV2: c
    });
  }
  function En(t, e) {
    const n = v(t), r = n.heads, o = fe(e), s = n.handle.fork(o.actor, r);
    s.updateDiffCursor();
    const { heads: a } = n, c = Tn(n, [
      "heads"
    ]);
    return c.patchCallback = o.patchCallback, s.applyPatches(t, Object.assign(Object.assign({}, c), {
      handle: s
    }));
  }
  function In(t, e) {
    return V(de(e), "from", {}, (n) => Object.assign(n, t)).newDoc;
  }
  Jo = function(t, e, n) {
    if (typeof e == "function") return V(t, "change", {}, e).newDoc;
    if (typeof n == "function") return typeof e == "string" && (e = {
      message: e
    }), V(t, "change", e, n).newDoc;
    throw RangeError("Invalid args for change");
  };
  qo = function(t, e, n, r) {
    if (typeof n == "function") return V(t, "changeAt", {}, n, e);
    if (typeof r == "function") return typeof n == "string" && (n = {
      message: n
    }), V(t, "changeAt", n, r, e);
    throw RangeError("Invalid args for changeAt");
  };
  function N(t, e, n, r) {
    if (n == null) return t;
    const o = v(t), s = Object.assign(Object.assign({}, o), {
      heads: void 0
    }), { value: a, patches: c } = o.handle.applyAndReturnPatches(t, s);
    if (c.length > 0) {
      r == null ? void 0 : r(c, {
        before: t,
        after: a,
        source: e
      });
      const d = v(a);
      d.mostRecentPatch = {
        before: v(t).heads,
        after: d.handle.getHeads(),
        patches: c
      };
    }
    return o.heads = n, a;
  }
  function V(t, e, n, r, o) {
    if (typeof r != "function") throw new RangeError("invalid change function");
    const s = v(t);
    if (t === void 0 || s === void 0) throw new RangeError("must be the document root");
    if (s.heads) throw new RangeError("Attempting to change an outdated document.  Use Automerge.clone() if you wish to make a writable copy.");
    if (re(t)) throw new RangeError("Calls to Automerge.change cannot be nested");
    let a = s.handle.getHeads();
    o && Hn(o, a) && (o = void 0), o && (s.handle.isolate(o), a = o), "time" in n || (n.time = Math.floor(Date.now() / 1e3));
    try {
      s.heads = a;
      const c = yn(s.handle, s.textV2);
      if (r(c), s.handle.pendingOps() === 0) return s.heads = void 0, o && s.handle.integrate(), {
        newDoc: t,
        newHeads: null
      };
      {
        const d = s.handle.commit(n.message, n.time);
        return s.handle.integrate(), {
          newDoc: N(t, e, a, n.patchCallback || s.patchCallback),
          newHeads: d != null ? [
            d
          ] : null
        };
      }
    } catch (c) {
      throw s.heads = void 0, s.handle.rollback(), c;
    }
  }
  Ko = function(t, e) {
    e === void 0 && (e = {}), typeof e == "string" && (e = {
      message: e
    }), "time" in e || (e.time = Math.floor(Date.now() / 1e3));
    const n = v(t);
    if (n.heads) throw new RangeError("Attempting to change an outdated document.  Use Automerge.clone() if you wish to make a writable copy.");
    if (re(t)) throw new RangeError("Calls to Automerge.change cannot be nested");
    const r = n.handle.getHeads();
    return n.handle.emptyChange(e.message, e.time), N(t, "emptyChange", r);
  };
  function Dn(t, e) {
    const n = fe(e), r = n.actor, o = n.patchCallback, s = !n.enableTextV2, a = n.unchecked || false, c = n.allowMissingChanges || false, d = n.convertRawStringsToText || false, b = k.load(t, {
      text_v1: s,
      actor: r,
      unchecked: a,
      allowMissingDeps: c,
      convertRawStringsToText: d
    });
    b.enableFreeze(!!n.freeze);
    const p = n.enableTextV2 || false;
    return xe(b, p), b.materialize("/", void 0, {
      handle: b,
      heads: void 0,
      patchCallback: o,
      textV2: p
    });
  }
  Mn = function(t, e, n) {
    n || (n = {});
    const r = v(t);
    if (r.heads) throw new RangeError("Attempting to change an out of date document - set at: " + Oe(t));
    if (re(t)) throw new RangeError("Calls to Automerge.change cannot be nested");
    const o = r.handle.getHeads();
    return r.handle.loadIncremental(e), N(t, "loadIncremental", o, n.patchCallback || r.patchCallback);
  };
  Xo = function(t) {
    return v(t).handle.save();
  };
  Yo = function(t, e) {
    const n = v(t);
    if (n.heads) throw new RangeError("Attempting to change an out of date document - set at: " + Oe(t));
    const r = n.handle.getHeads(), o = v(e), s = n.handle.getChangesAdded(o.handle);
    return n.handle.applyChanges(s), N(t, "merge", r, n.patchCallback);
  };
  Go = function(t, e, n) {
    we(e, "before"), we(n, "after");
    const r = v(t);
    return r.mostRecentPatch && ce(r.mostRecentPatch.before, e) && ce(r.mostRecentPatch.after, n) ? r.mostRecentPatch.patches : r.handle.diff(e, n);
  };
  function Hn(t, e) {
    if (t.length !== e.length) return false;
    for (let n = 0; n < t.length; n++) if (t[n] !== e[n]) return false;
    return true;
  }
  function we(t, e) {
    if (!Array.isArray(t)) throw new Error(`${e} must be an array`);
  }
  function ce(t, e) {
    if (!pe(t) || !pe(e)) return t === e;
    const n = Object.keys(t).sort(), r = Object.keys(e).sort();
    if (n.length !== r.length) return false;
    for (let o = 0; o < n.length; o++) if (n[o] !== r[o] || !ce(t[n[o]], e[r[o]])) return false;
    return true;
  }
  Qo = function(t) {
    const e = k.importSyncState(t), n = k.encodeSyncState(e);
    return e.free(), n;
  };
  Zo = function(t) {
    const e = k.decodeSyncState(t), n = k.exportSyncState(e);
    return e.free(), n;
  };
  e_ = function(t, e) {
    const n = v(t), r = k.importSyncState(e), o = n.handle.generateSyncMessage(r);
    return [
      k.exportSyncState(r),
      o
    ];
  };
  t_ = function(t, e, n, r) {
    const o = k.importSyncState(e);
    r || (r = {});
    const s = v(t);
    if (s.heads) throw new RangeError("Attempting to change an outdated document.  Use Automerge.clone() if you wish to make a writable copy.");
    if (re(t)) throw new RangeError("Calls to Automerge.change cannot be nested");
    const a = s.handle.getHeads();
    s.handle.receiveSyncMessage(o, n);
    const c = k.exportSyncState(o);
    return [
      N(t, "receiveSyncMessage", a, r.patchCallback || s.patchCallback),
      c,
      null
    ];
  };
  n_ = function() {
    return k.exportSyncState(k.initSyncState());
  };
  r_ = function(t) {
    return k.decodeSyncMessage(t);
  };
  o_ = function(t) {
    const e = v(t);
    return e.heads || e.handle.getHeads();
  };
  function pe(t) {
    return typeof t == "object" && t !== null;
  }
  __ = function(t, e) {
    return v(t).handle.saveSince(e);
  };
  function xe(t, e) {
    t.registerDatatype("counter", (n) => new ae(n), (n) => {
      if (n instanceof ae) return n.value;
    }), e ? t.registerDatatype("str", (n) => new se(n), (n) => {
      if (n instanceof se) return n.val;
    }) : t.registerDatatype("text", (n) => new D(n), (n) => {
      if (n instanceof D) return n.join("");
    });
  }
  a_ = function(t) {
    const e = oe(t);
    return e.enableTextV2 = true, de(e);
  };
  s_ = function(t, e) {
    const n = oe(e);
    return n.enableTextV2 = true, En(t, n);
  };
  c_ = function(t, e) {
    const n = oe(e);
    return n.enableTextV2 = true, In(t, n);
  };
  i_ = function(t, e) {
    const n = oe(e);
    return n.enableTextV2 = true, n.patchCallback ? Mn(de(n), t) : Dn(t, n);
  };
  function oe(t) {
    return {
      actor: t
    };
  }
  const Pn = "/my-world/assets/automerge_wasm_bg-BEjDkhWo.wasm", $n = async (t = {}, e) => {
    let n;
    if (e.startsWith("data:")) {
      const r = e.replace(/^data:.*?base64,/, "");
      let o;
      if (typeof Buffer == "function" && typeof Buffer.from == "function") o = Buffer.from(r, "base64");
      else if (typeof atob == "function") {
        const s = atob(r);
        o = new Uint8Array(s.length);
        for (let a = 0; a < s.length; a++) o[a] = s.charCodeAt(a);
      } else throw new Error("Cannot decode base64-encoded data URL");
      n = await WebAssembly.instantiate(o, t);
    } else {
      const r = await fetch(e), o = r.headers.get("Content-Type") || "";
      if ("instantiateStreaming" in WebAssembly && o.startsWith("application/wasm")) n = await WebAssembly.instantiateStreaming(r, t);
      else {
        const s = await r.arrayBuffer();
        n = await WebAssembly.instantiate(s, t);
      }
    }
    return n.instance.exports;
  };
  let _;
  function Re(t) {
    _ = t;
  }
  const I = new Array(128).fill(void 0);
  I.push(void 0, null, true, false);
  function l(t) {
    return I[t];
  }
  let z = I.length;
  function Un(t) {
    t < 132 || (I[t] = z, z = t);
  }
  function g(t) {
    const e = l(t);
    return Un(t), e;
  }
  let C = 0, J = null;
  function X() {
    return (J === null || J.byteLength === 0) && (J = new Uint8Array(_.memory.buffer)), J;
  }
  const Bn = typeof TextEncoder > "u" ? (0, module.require)("util").TextEncoder : TextEncoder;
  let Y = new Bn("utf-8");
  const zn = typeof Y.encodeInto == "function" ? function(t, e) {
    return Y.encodeInto(t, e);
  } : function(t, e) {
    const n = Y.encode(t);
    return e.set(n), {
      read: t.length,
      written: n.length
    };
  };
  function E(t, e, n) {
    if (n === void 0) {
      const c = Y.encode(t), d = e(c.length, 1) >>> 0;
      return X().subarray(d, d + c.length).set(c), C = c.length, d;
    }
    let r = t.length, o = e(r, 1) >>> 0;
    const s = X();
    let a = 0;
    for (; a < r; a++) {
      const c = t.charCodeAt(a);
      if (c > 127) break;
      s[o + a] = c;
    }
    if (a !== r) {
      a !== 0 && (t = t.slice(a)), o = n(o, r, r = a + t.length * 3, 1) >>> 0;
      const c = X().subarray(o + a, o + r), d = zn(t, c);
      a += d.written, o = n(o, r, a, 1) >>> 0;
    }
    return C = a, o;
  }
  function h(t) {
    return t == null;
  }
  let q = null;
  function i() {
    return (q === null || q.byteLength === 0) && (q = new Int32Array(_.memory.buffer)), q;
  }
  const Fn = typeof TextDecoder > "u" ? (0, module.require)("util").TextDecoder : TextDecoder;
  let Te = new Fn("utf-8", {
    ignoreBOM: true,
    fatal: true
  });
  Te.decode();
  function j(t, e) {
    return t = t >>> 0, Te.decode(X().subarray(t, t + e));
  }
  function u(t) {
    z === I.length && I.push(I.length + 1);
    const e = z;
    return z = I[e], I[e] = t, e;
  }
  let K = null;
  function G() {
    return (K === null || K.byteLength === 0) && (K = new Float64Array(_.memory.buffer)), K;
  }
  function ie(t) {
    const e = typeof t;
    if (e == "number" || e == "boolean" || t == null) return `${t}`;
    if (e == "string") return `"${t}"`;
    if (e == "symbol") {
      const o = t.description;
      return o == null ? "Symbol" : `Symbol(${o})`;
    }
    if (e == "function") {
      const o = t.name;
      return typeof o == "string" && o.length > 0 ? `Function(${o})` : "Function";
    }
    if (Array.isArray(t)) {
      const o = t.length;
      let s = "[";
      o > 0 && (s += ie(t[0]));
      for (let a = 1; a < o; a++) s += ", " + ie(t[a]);
      return s += "]", s;
    }
    const n = /\[object ([^\]]+)\]/.exec(toString.call(t));
    let r;
    if (n.length > 1) r = n[1];
    else return toString.call(t);
    if (r == "Object") try {
      return "Object(" + JSON.stringify(t) + ")";
    } catch {
      return "Object";
    }
    return t instanceof Error ? `${t.name}: ${t.message}
${t.stack}` : r;
  }
  function P(t, e) {
    if (!(t instanceof e)) throw new Error(`expected instance of ${e.name}`);
    return t.ptr;
  }
  function Vn(t) {
    try {
      const o = _.__wbindgen_add_to_stack_pointer(-16);
      _.create(o, u(t));
      var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
      if (r) throw g(n);
      return R.__wrap(e);
    } finally {
      _.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function Ln(t, e) {
    try {
      const s = _.__wbindgen_add_to_stack_pointer(-16);
      _.load(s, u(t), u(e));
      var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
      if (o) throw g(r);
      return R.__wrap(n);
    } finally {
      _.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function Nn(t) {
    try {
      const o = _.__wbindgen_add_to_stack_pointer(-16);
      _.encodeChange(o, u(t));
      var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
      if (r) throw g(n);
      return g(e);
    } finally {
      _.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function Wn(t) {
    try {
      const o = _.__wbindgen_add_to_stack_pointer(-16);
      _.decodeChange(o, u(t));
      var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
      if (r) throw g(n);
      return g(e);
    } finally {
      _.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function Jn() {
    const t = _.initSyncState();
    return O.__wrap(t);
  }
  function qn(t) {
    try {
      const o = _.__wbindgen_add_to_stack_pointer(-16);
      _.importSyncState(o, u(t));
      var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
      if (r) throw g(n);
      return O.__wrap(e);
    } finally {
      _.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function Kn(t) {
    P(t, O);
    const e = _.exportSyncState(t.__wbg_ptr);
    return g(e);
  }
  function Xn(t) {
    try {
      const o = _.__wbindgen_add_to_stack_pointer(-16);
      _.encodeSyncMessage(o, u(t));
      var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
      if (r) throw g(n);
      return g(e);
    } finally {
      _.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function Yn(t) {
    try {
      const o = _.__wbindgen_add_to_stack_pointer(-16);
      _.decodeSyncMessage(o, u(t));
      var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
      if (r) throw g(n);
      return g(e);
    } finally {
      _.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function Gn(t) {
    P(t, O);
    const e = _.encodeSyncState(t.__wbg_ptr);
    return g(e);
  }
  function Qn(t) {
    try {
      const o = _.__wbindgen_add_to_stack_pointer(-16);
      _.decodeSyncState(o, u(t));
      var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
      if (r) throw g(n);
      return O.__wrap(e);
    } finally {
      _.__wbindgen_add_to_stack_pointer(16);
    }
  }
  function S(t, e) {
    try {
      return t.apply(this, e);
    } catch (n) {
      _.__wbindgen_exn_store(u(n));
    }
  }
  const Zn = Object.freeze({
    Array: 0,
    0: "Array",
    String: 1,
    1: "String"
  }), he = typeof FinalizationRegistry > "u" ? {
    register: () => {
    },
    unregister: () => {
    }
  } : new FinalizationRegistry((t) => _.__wbg_automerge_free(t >>> 0));
  class R {
    static __wrap(e) {
      e = e >>> 0;
      const n = Object.create(R.prototype);
      return n.__wbg_ptr = e, he.register(n, n.__wbg_ptr, n), n;
    }
    __destroy_into_raw() {
      const e = this.__wbg_ptr;
      return this.__wbg_ptr = 0, he.unregister(this), e;
    }
    free() {
      const e = this.__destroy_into_raw();
      _.__wbg_automerge_free(e);
    }
    static new(e, n) {
      try {
        const d = _.__wbindgen_add_to_stack_pointer(-16);
        var r = h(e) ? 0 : E(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = C;
        _.automerge_new(d, r, o, n);
        var s = i()[d / 4 + 0], a = i()[d / 4 + 1], c = i()[d / 4 + 2];
        if (c) throw g(a);
        return R.__wrap(s);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    clone(e) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        var n = h(e) ? 0 : E(e, _.__wbindgen_malloc, _.__wbindgen_realloc), r = C;
        _.automerge_clone(c, this.__wbg_ptr, n, r);
        var o = i()[c / 4 + 0], s = i()[c / 4 + 1], a = i()[c / 4 + 2];
        if (a) throw g(s);
        return R.__wrap(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    fork(e, n) {
      try {
        const d = _.__wbindgen_add_to_stack_pointer(-16);
        var r = h(e) ? 0 : E(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = C;
        _.automerge_fork(d, this.__wbg_ptr, r, o, u(n));
        var s = i()[d / 4 + 0], a = i()[d / 4 + 1], c = i()[d / 4 + 2];
        if (c) throw g(a);
        return R.__wrap(s);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    pendingOps() {
      const e = _.automerge_pendingOps(this.__wbg_ptr);
      return g(e);
    }
    commit(e, n) {
      var r = h(e) ? 0 : E(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = C;
      const s = _.automerge_commit(this.__wbg_ptr, r, o, !h(n), h(n) ? 0 : n);
      return g(s);
    }
    merge(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        P(e, R), _.automerge_merge(s, this.__wbg_ptr, e.__wbg_ptr);
        var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
        if (o) throw g(r);
        return g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    rollback() {
      return _.automerge_rollback(this.__wbg_ptr);
    }
    keys(e, n) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_keys(a, this.__wbg_ptr, u(e), h(n) ? 0 : u(n));
        var r = i()[a / 4 + 0], o = i()[a / 4 + 1], s = i()[a / 4 + 2];
        if (s) throw g(o);
        return g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    text(e, n) {
      let r, o;
      try {
        const w = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_text(w, this.__wbg_ptr, u(e), h(n) ? 0 : u(n));
        var s = i()[w / 4 + 0], a = i()[w / 4 + 1], c = i()[w / 4 + 2], d = i()[w / 4 + 3], b = s, p = a;
        if (d) throw b = 0, p = 0, g(c);
        return r = b, o = p, j(b, p);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16), _.__wbindgen_free(r, o, 1);
      }
    }
    spans(e, n) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_spans(a, this.__wbg_ptr, u(e), h(n) ? 0 : u(n));
        var r = i()[a / 4 + 0], o = i()[a / 4 + 1], s = i()[a / 4 + 2];
        if (s) throw g(o);
        return g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    splice(e, n, r, o) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_splice(c, this.__wbg_ptr, u(e), n, r, u(o));
        var s = i()[c / 4 + 0], a = i()[c / 4 + 1];
        if (a) throw g(s);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    updateText(e, n) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_updateText(s, this.__wbg_ptr, u(e), u(n));
        var r = i()[s / 4 + 0], o = i()[s / 4 + 1];
        if (o) throw g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    updateSpans(e, n) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_updateSpans(s, this.__wbg_ptr, u(e), u(n));
        var r = i()[s / 4 + 0], o = i()[s / 4 + 1];
        if (o) throw g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    push(e, n, r) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_push(a, this.__wbg_ptr, u(e), u(n), u(r));
        var o = i()[a / 4 + 0], s = i()[a / 4 + 1];
        if (s) throw g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    pushObject(e, n) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_pushObject(c, this.__wbg_ptr, u(e), u(n));
        var r = i()[c / 4 + 0], o = i()[c / 4 + 1], s = i()[c / 4 + 2], a = i()[c / 4 + 3];
        if (a) throw g(s);
        let d;
        return r !== 0 && (d = j(r, o).slice(), _.__wbindgen_free(r, o * 1, 1)), d;
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    insert(e, n, r, o) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_insert(c, this.__wbg_ptr, u(e), n, u(r), u(o));
        var s = i()[c / 4 + 0], a = i()[c / 4 + 1];
        if (a) throw g(s);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    splitBlock(e, n, r) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_splitBlock(a, this.__wbg_ptr, u(e), n, u(r));
        var o = i()[a / 4 + 0], s = i()[a / 4 + 1];
        if (s) throw g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    joinBlock(e, n) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_joinBlock(s, this.__wbg_ptr, u(e), n);
        var r = i()[s / 4 + 0], o = i()[s / 4 + 1];
        if (o) throw g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    updateBlock(e, n, r) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_updateBlock(a, this.__wbg_ptr, u(e), n, u(r));
        var o = i()[a / 4 + 0], s = i()[a / 4 + 1];
        if (s) throw g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    getBlock(e, n, r) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getBlock(c, this.__wbg_ptr, u(e), n, h(r) ? 0 : u(r));
        var o = i()[c / 4 + 0], s = i()[c / 4 + 1], a = i()[c / 4 + 2];
        if (a) throw g(s);
        return g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    insertObject(e, n, r) {
      try {
        const d = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_insertObject(d, this.__wbg_ptr, u(e), n, u(r));
        var o = i()[d / 4 + 0], s = i()[d / 4 + 1], a = i()[d / 4 + 2], c = i()[d / 4 + 3];
        if (c) throw g(a);
        let b;
        return o !== 0 && (b = j(o, s).slice(), _.__wbindgen_free(o, s * 1, 1)), b;
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    put(e, n, r, o) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_put(c, this.__wbg_ptr, u(e), u(n), u(r), u(o));
        var s = i()[c / 4 + 0], a = i()[c / 4 + 1];
        if (a) throw g(s);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    putObject(e, n, r) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_putObject(c, this.__wbg_ptr, u(e), u(n), u(r));
        var o = i()[c / 4 + 0], s = i()[c / 4 + 1], a = i()[c / 4 + 2];
        if (a) throw g(s);
        return g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    increment(e, n, r) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_increment(a, this.__wbg_ptr, u(e), u(n), u(r));
        var o = i()[a / 4 + 0], s = i()[a / 4 + 1];
        if (s) throw g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    get(e, n, r) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_get(c, this.__wbg_ptr, u(e), u(n), h(r) ? 0 : u(r));
        var o = i()[c / 4 + 0], s = i()[c / 4 + 1], a = i()[c / 4 + 2];
        if (a) throw g(s);
        return g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    getWithType(e, n, r) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getWithType(c, this.__wbg_ptr, u(e), u(n), h(r) ? 0 : u(r));
        var o = i()[c / 4 + 0], s = i()[c / 4 + 1], a = i()[c / 4 + 2];
        if (a) throw g(s);
        return g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    objInfo(e, n) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_objInfo(a, this.__wbg_ptr, u(e), h(n) ? 0 : u(n));
        var r = i()[a / 4 + 0], o = i()[a / 4 + 1], s = i()[a / 4 + 2];
        if (s) throw g(o);
        return g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    getAll(e, n, r) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getAll(c, this.__wbg_ptr, u(e), u(n), h(r) ? 0 : u(r));
        var o = i()[c / 4 + 0], s = i()[c / 4 + 1], a = i()[c / 4 + 2];
        if (a) throw g(s);
        return g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    enableFreeze(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_enableFreeze(s, this.__wbg_ptr, u(e));
        var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
        if (o) throw g(r);
        return g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    registerDatatype(e, n, r) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_registerDatatype(a, this.__wbg_ptr, u(e), u(n), u(r));
        var o = i()[a / 4 + 0], s = i()[a / 4 + 1];
        if (s) throw g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    applyPatches(e, n) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_applyPatches(a, this.__wbg_ptr, u(e), u(n));
        var r = i()[a / 4 + 0], o = i()[a / 4 + 1], s = i()[a / 4 + 2];
        if (s) throw g(o);
        return g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    applyAndReturnPatches(e, n) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_applyAndReturnPatches(a, this.__wbg_ptr, u(e), u(n));
        var r = i()[a / 4 + 0], o = i()[a / 4 + 1], s = i()[a / 4 + 2];
        if (s) throw g(o);
        return g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    diffIncremental() {
      try {
        const o = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_diffIncremental(o, this.__wbg_ptr);
        var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
        if (r) throw g(n);
        return g(e);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    updateDiffCursor() {
      _.automerge_updateDiffCursor(this.__wbg_ptr);
    }
    resetDiffCursor() {
      _.automerge_resetDiffCursor(this.__wbg_ptr);
    }
    diff(e, n) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_diff(a, this.__wbg_ptr, u(e), u(n));
        var r = i()[a / 4 + 0], o = i()[a / 4 + 1], s = i()[a / 4 + 2];
        if (s) throw g(o);
        return g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    isolate(e) {
      try {
        const o = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_isolate(o, this.__wbg_ptr, u(e));
        var n = i()[o / 4 + 0], r = i()[o / 4 + 1];
        if (r) throw g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    integrate() {
      _.automerge_integrate(this.__wbg_ptr);
    }
    length(e, n) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_length(a, this.__wbg_ptr, u(e), h(n) ? 0 : u(n));
        var r = G()[a / 8 + 0], o = i()[a / 4 + 2], s = i()[a / 4 + 3];
        if (s) throw g(o);
        return r;
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    delete(e, n) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_delete(s, this.__wbg_ptr, u(e), u(n));
        var r = i()[s / 4 + 0], o = i()[s / 4 + 1];
        if (o) throw g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    save() {
      const e = _.automerge_save(this.__wbg_ptr);
      return g(e);
    }
    saveIncremental() {
      const e = _.automerge_saveIncremental(this.__wbg_ptr);
      return g(e);
    }
    saveSince(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_saveSince(s, this.__wbg_ptr, u(e));
        var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
        if (o) throw g(r);
        return g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    saveNoCompress() {
      const e = _.automerge_saveNoCompress(this.__wbg_ptr);
      return g(e);
    }
    saveAndVerify() {
      try {
        const o = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_saveAndVerify(o, this.__wbg_ptr);
        var e = i()[o / 4 + 0], n = i()[o / 4 + 1], r = i()[o / 4 + 2];
        if (r) throw g(n);
        return g(e);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    loadIncremental(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_loadIncremental(s, this.__wbg_ptr, u(e));
        var n = G()[s / 8 + 0], r = i()[s / 4 + 2], o = i()[s / 4 + 3];
        if (o) throw g(r);
        return n;
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    applyChanges(e) {
      try {
        const o = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_applyChanges(o, this.__wbg_ptr, u(e));
        var n = i()[o / 4 + 0], r = i()[o / 4 + 1];
        if (r) throw g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    getChanges(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getChanges(s, this.__wbg_ptr, u(e));
        var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
        if (o) throw g(r);
        return g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    getChangeByHash(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getChangeByHash(s, this.__wbg_ptr, u(e));
        var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
        if (o) throw g(r);
        return g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    getDecodedChangeByHash(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getDecodedChangeByHash(s, this.__wbg_ptr, u(e));
        var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
        if (o) throw g(r);
        return g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    getChangesAdded(e) {
      P(e, R);
      const n = _.automerge_getChangesAdded(this.__wbg_ptr, e.__wbg_ptr);
      return g(n);
    }
    getHeads() {
      const e = _.automerge_getHeads(this.__wbg_ptr);
      return g(e);
    }
    getActorId() {
      let e, n;
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getActorId(s, this.__wbg_ptr);
        var r = i()[s / 4 + 0], o = i()[s / 4 + 1];
        return e = r, n = o, j(r, o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16), _.__wbindgen_free(e, n, 1);
      }
    }
    getLastLocalChange() {
      const e = _.automerge_getLastLocalChange(this.__wbg_ptr);
      return g(e);
    }
    dump() {
      _.automerge_dump(this.__wbg_ptr);
    }
    getMissingDeps(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getMissingDeps(s, this.__wbg_ptr, h(e) ? 0 : u(e));
        var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
        if (o) throw g(r);
        return g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    receiveSyncMessage(e, n) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        P(e, O), _.automerge_receiveSyncMessage(s, this.__wbg_ptr, e.__wbg_ptr, u(n));
        var r = i()[s / 4 + 0], o = i()[s / 4 + 1];
        if (o) throw g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    generateSyncMessage(e) {
      P(e, O);
      const n = _.automerge_generateSyncMessage(this.__wbg_ptr, e.__wbg_ptr);
      return g(n);
    }
    toJS(e) {
      try {
        const s = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_toJS(s, this.__wbg_ptr, u(e));
        var n = i()[s / 4 + 0], r = i()[s / 4 + 1], o = i()[s / 4 + 2];
        if (o) throw g(r);
        return g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    materialize(e, n, r) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_materialize(c, this.__wbg_ptr, u(e), h(n) ? 0 : u(n), u(r));
        var o = i()[c / 4 + 0], s = i()[c / 4 + 1], a = i()[c / 4 + 2];
        if (a) throw g(s);
        return g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    getCursor(e, n, r) {
      let o, s;
      try {
        const m = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getCursor(m, this.__wbg_ptr, u(e), n, h(r) ? 0 : u(r));
        var a = i()[m / 4 + 0], c = i()[m / 4 + 1], d = i()[m / 4 + 2], b = i()[m / 4 + 3], p = a, w = c;
        if (b) throw p = 0, w = 0, g(d);
        return o = p, s = w, j(p, w);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16), _.__wbindgen_free(o, s, 1);
      }
    }
    getCursorPosition(e, n, r) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_getCursorPosition(c, this.__wbg_ptr, u(e), u(n), h(r) ? 0 : u(r));
        var o = G()[c / 8 + 0], s = i()[c / 4 + 2], a = i()[c / 4 + 3];
        if (a) throw g(s);
        return o;
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    emptyChange(e, n) {
      var r = h(e) ? 0 : E(e, _.__wbindgen_malloc, _.__wbindgen_realloc), o = C;
      const s = _.automerge_emptyChange(this.__wbg_ptr, r, o, !h(n), h(n) ? 0 : n);
      return g(s);
    }
    mark(e, n, r, o, s) {
      try {
        const d = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_mark(d, this.__wbg_ptr, u(e), u(n), u(r), u(o), u(s));
        var a = i()[d / 4 + 0], c = i()[d / 4 + 1];
        if (c) throw g(a);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    unmark(e, n, r) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_unmark(a, this.__wbg_ptr, u(e), u(n), u(r));
        var o = i()[a / 4 + 0], s = i()[a / 4 + 1];
        if (s) throw g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    marks(e, n) {
      try {
        const a = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_marks(a, this.__wbg_ptr, u(e), h(n) ? 0 : u(n));
        var r = i()[a / 4 + 0], o = i()[a / 4 + 1], s = i()[a / 4 + 2];
        if (s) throw g(o);
        return g(r);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    marksAt(e, n, r) {
      try {
        const c = _.__wbindgen_add_to_stack_pointer(-16);
        _.automerge_marksAt(c, this.__wbg_ptr, u(e), n, h(r) ? 0 : u(r));
        var o = i()[c / 4 + 0], s = i()[c / 4 + 1], a = i()[c / 4 + 2];
        if (a) throw g(s);
        return g(o);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    hasOurChanges(e) {
      P(e, O);
      const n = _.automerge_hasOurChanges(this.__wbg_ptr, e.__wbg_ptr);
      return g(n);
    }
    topoHistoryTraversal() {
      const e = _.automerge_topoHistoryTraversal(this.__wbg_ptr);
      return g(e);
    }
    stats() {
      const e = _.automerge_stats(this.__wbg_ptr);
      return g(e);
    }
  }
  const me = typeof FinalizationRegistry > "u" ? {
    register: () => {
    },
    unregister: () => {
    }
  } : new FinalizationRegistry((t) => _.__wbg_syncstate_free(t >>> 0));
  class O {
    static __wrap(e) {
      e = e >>> 0;
      const n = Object.create(O.prototype);
      return n.__wbg_ptr = e, me.register(n, n.__wbg_ptr, n), n;
    }
    __destroy_into_raw() {
      const e = this.__wbg_ptr;
      return this.__wbg_ptr = 0, me.unregister(this), e;
    }
    free() {
      const e = this.__destroy_into_raw();
      _.__wbg_syncstate_free(e);
    }
    get sharedHeads() {
      const e = _.syncstate_sharedHeads(this.__wbg_ptr);
      return g(e);
    }
    get lastSentHeads() {
      const e = _.syncstate_lastSentHeads(this.__wbg_ptr);
      return g(e);
    }
    set lastSentHeads(e) {
      try {
        const o = _.__wbindgen_add_to_stack_pointer(-16);
        _.syncstate_set_lastSentHeads(o, this.__wbg_ptr, u(e));
        var n = i()[o / 4 + 0], r = i()[o / 4 + 1];
        if (r) throw g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    set sentHashes(e) {
      try {
        const o = _.__wbindgen_add_to_stack_pointer(-16);
        _.syncstate_set_sentHashes(o, this.__wbg_ptr, u(e));
        var n = i()[o / 4 + 0], r = i()[o / 4 + 1];
        if (r) throw g(n);
      } finally {
        _.__wbindgen_add_to_stack_pointer(16);
      }
    }
    clone() {
      const e = _.syncstate_clone(this.__wbg_ptr);
      return O.__wrap(e);
    }
  }
  function Ee(t) {
    g(t);
  }
  function Ie(t, e) {
    const n = l(e), r = typeof n == "string" ? n : void 0;
    var o = h(r) ? 0 : E(r, _.__wbindgen_malloc, _.__wbindgen_realloc), s = C;
    i()[t / 4 + 1] = s, i()[t / 4 + 0] = o;
  }
  function De(t, e) {
    const n = new Error(j(t, e));
    return u(n);
  }
  function Me(t, e) {
    const n = j(t, e);
    return u(n);
  }
  function He(t) {
    return u(t);
  }
  function Pe(t) {
    const e = l(t);
    return u(e);
  }
  function $e(t, e) {
    const n = l(e), r = typeof n == "number" ? n : void 0;
    G()[t / 8 + 1] = h(r) ? 0 : r, i()[t / 4 + 0] = !h(r);
  }
  function Ue(t) {
    return l(t) === void 0;
  }
  function Be(t) {
    const e = l(t);
    return typeof e == "boolean" ? e ? 1 : 0 : 2;
  }
  function ze(t) {
    return l(t) === null;
  }
  function Fe(t) {
    return typeof l(t) == "string";
  }
  function Ve(t) {
    return typeof l(t) == "function";
  }
  function Le(t) {
    const e = l(t);
    return typeof e == "object" && e !== null;
  }
  function Ne(t) {
    return Array.isArray(l(t));
  }
  function We(t, e) {
    const n = l(e), r = JSON.stringify(n === void 0 ? null : n), o = E(r, _.__wbindgen_malloc, _.__wbindgen_realloc), s = C;
    i()[t / 4 + 1] = s, i()[t / 4 + 0] = o;
  }
  function Je() {
    const t = new Error();
    return u(t);
  }
  function qe(t, e) {
    const n = l(e).stack, r = E(n, _.__wbindgen_malloc, _.__wbindgen_realloc), o = C;
    i()[t / 4 + 1] = o, i()[t / 4 + 0] = r;
  }
  function Ke(t, e) {
    let n, r;
    try {
      n = t, r = e, console.error(j(t, e));
    } finally {
      _.__wbindgen_free(n, r, 1);
    }
  }
  function Xe(t, e) {
    return l(t) == l(e);
  }
  function Ye(t, e) {
    const n = String(l(e)), r = E(n, _.__wbindgen_malloc, _.__wbindgen_realloc), o = C;
    i()[t / 4 + 1] = o, i()[t / 4 + 0] = r;
  }
  function Ge(t) {
    return u(t);
  }
  function Qe(t) {
    const e = BigInt.asUintN(64, t);
    return u(e);
  }
  function Ze(t, e, n) {
    l(t)[g(e)] = g(n);
  }
  function et() {
    return S(function(t, e) {
      l(t).getRandomValues(l(e));
    }, arguments);
  }
  function tt() {
    return S(function(t, e) {
      l(t).randomFillSync(g(e));
    }, arguments);
  }
  function nt(t) {
    const e = l(t).crypto;
    return u(e);
  }
  function rt(t) {
    const e = l(t).process;
    return u(e);
  }
  function ot(t) {
    const e = l(t).versions;
    return u(e);
  }
  function _t(t) {
    const e = l(t).node;
    return u(e);
  }
  function at() {
    return S(function() {
      const t = module.require;
      return u(t);
    }, arguments);
  }
  function st(t) {
    const e = l(t).msCrypto;
    return u(e);
  }
  function ct(t) {
    console.log(l(t));
  }
  function it(t, e) {
    console.log(l(t), l(e));
  }
  function ut(t, e) {
    const n = l(t)[e >>> 0];
    return u(n);
  }
  function gt(t) {
    return l(t).length;
  }
  function ft() {
    const t = new Array();
    return u(t);
  }
  function dt(t, e) {
    const n = new Function(j(t, e));
    return u(n);
  }
  function lt(t) {
    const e = l(t).next;
    return u(e);
  }
  function bt() {
    return S(function(t) {
      const e = l(t).next();
      return u(e);
    }, arguments);
  }
  function wt(t) {
    return l(t).done;
  }
  function pt(t) {
    const e = l(t).value;
    return u(e);
  }
  function ht() {
    return u(Symbol.iterator);
  }
  function mt() {
    return S(function(t, e) {
      const n = Reflect.get(l(t), l(e));
      return u(n);
    }, arguments);
  }
  function yt() {
    return S(function(t, e) {
      const n = l(t).call(l(e));
      return u(n);
    }, arguments);
  }
  function vt() {
    const t = new Object();
    return u(t);
  }
  function St(t) {
    return l(t).length;
  }
  function kt(t, e, n) {
    l(t)[e >>> 0] = g(n);
  }
  function jt(t) {
    const e = Array.from(l(t));
    return u(e);
  }
  function At(t) {
    return Array.isArray(l(t));
  }
  function Ct(t, e) {
    return l(t).push(l(e));
  }
  function Ot(t, e) {
    return l(t).unshift(l(e));
  }
  function xt(t) {
    let e;
    try {
      e = l(t) instanceof ArrayBuffer;
    } catch {
      e = false;
    }
    return e;
  }
  function Rt(t, e) {
    const n = new Error(j(t, e));
    return u(n);
  }
  function Tt() {
    return S(function(t, e, n) {
      const r = l(t).call(l(e), l(n));
      return u(r);
    }, arguments);
  }
  function Et(t) {
    let e;
    try {
      e = l(t) instanceof Date;
    } catch {
      e = false;
    }
    return e;
  }
  function It(t) {
    return l(t).getTime();
  }
  function Dt(t) {
    const e = new Date(l(t));
    return u(e);
  }
  function Mt(t) {
    let e;
    try {
      e = l(t) instanceof Object;
    } catch {
      e = false;
    }
    return e;
  }
  function Ht(t, e) {
    const n = Object.assign(l(t), l(e));
    return u(n);
  }
  function Pt(t, e, n) {
    const r = Object.defineProperty(l(t), l(e), l(n));
    return u(r);
  }
  function $t(t) {
    const e = Object.entries(l(t));
    return u(e);
  }
  function Ut(t) {
    const e = Object.freeze(l(t));
    return u(e);
  }
  function Bt(t) {
    const e = Object.keys(l(t));
    return u(e);
  }
  function zt(t) {
    const e = Object.values(l(t));
    return u(e);
  }
  function Ft(t, e) {
    const n = new RangeError(j(t, e));
    return u(n);
  }
  function Vt() {
    return S(function(t, e, n) {
      const r = Reflect.apply(l(t), l(e), l(n));
      return u(r);
    }, arguments);
  }
  function Lt() {
    return S(function(t, e) {
      return Reflect.deleteProperty(l(t), l(e));
    }, arguments);
  }
  function Nt() {
    return S(function(t) {
      const e = Reflect.ownKeys(l(t));
      return u(e);
    }, arguments);
  }
  function Wt() {
    return S(function(t, e, n) {
      return Reflect.set(l(t), l(e), l(n));
    }, arguments);
  }
  function Jt(t) {
    const e = l(t).buffer;
    return u(e);
  }
  function qt(t, e) {
    const n = l(t).concat(l(e));
    return u(n);
  }
  function Kt(t, e, n) {
    const r = l(t).slice(e >>> 0, n >>> 0);
    return u(r);
  }
  function Xt(t, e) {
    const n = Symbol.for(j(t, e));
    return u(n);
  }
  function Yt(t) {
    const e = l(t).toString();
    return u(e);
  }
  function Gt() {
    return S(function() {
      const t = self.self;
      return u(t);
    }, arguments);
  }
  function Qt() {
    return S(function() {
      const t = window.window;
      return u(t);
    }, arguments);
  }
  function Zt() {
    return S(function() {
      const t = globalThis.globalThis;
      return u(t);
    }, arguments);
  }
  function en() {
    return S(function() {
      const t = global.global;
      return u(t);
    }, arguments);
  }
  function tn(t, e, n) {
    const r = new Uint8Array(l(t), e >>> 0, n >>> 0);
    return u(r);
  }
  function nn(t) {
    const e = new Uint8Array(l(t));
    return u(e);
  }
  function rn(t, e, n) {
    l(t).set(l(e), n >>> 0);
  }
  function on(t) {
    return l(t).length;
  }
  function _n(t) {
    let e;
    try {
      e = l(t) instanceof Uint8Array;
    } catch {
      e = false;
    }
    return e;
  }
  function an(t) {
    const e = new Uint8Array(t >>> 0);
    return u(e);
  }
  function sn(t, e, n) {
    const r = l(t).subarray(e >>> 0, n >>> 0);
    return u(r);
  }
  function cn(t, e) {
    const n = ie(l(e)), r = E(n, _.__wbindgen_malloc, _.__wbindgen_realloc), o = C;
    i()[t / 4 + 1] = o, i()[t / 4 + 0] = r;
  }
  function un(t, e) {
    throw new Error(j(t, e));
  }
  function gn() {
    const t = _.memory;
    return u(t);
  }
  URL = globalThis.URL;
  const f = await $n({
    "./automerge_wasm_bg.js": {
      __wbindgen_object_drop_ref: Ee,
      __wbindgen_string_get: Ie,
      __wbindgen_error_new: De,
      __wbindgen_string_new: Me,
      __wbindgen_number_new: He,
      __wbindgen_object_clone_ref: Pe,
      __wbindgen_number_get: $e,
      __wbindgen_is_undefined: Ue,
      __wbindgen_boolean_get: Be,
      __wbindgen_is_null: ze,
      __wbindgen_is_string: Fe,
      __wbindgen_is_function: Ve,
      __wbindgen_is_object: Le,
      __wbindgen_is_array: Ne,
      __wbindgen_json_serialize: We,
      __wbg_new_abda76e883ba8a5f: Je,
      __wbg_stack_658279fe44541cf6: qe,
      __wbg_error_f851667af71bcfc6: Ke,
      __wbindgen_jsval_loose_eq: Xe,
      __wbg_String_91fba7ded13ba54c: Ye,
      __wbindgen_bigint_from_i64: Ge,
      __wbindgen_bigint_from_u64: Qe,
      __wbg_set_20cbc34131e76824: Ze,
      __wbg_getRandomValues_3aa56aa6edec874c: et,
      __wbg_randomFillSync_5c9c955aa56b6049: tt,
      __wbg_crypto_1d1f22824a6a080c: nt,
      __wbg_process_4a72847cc503995b: rt,
      __wbg_versions_f686565e586dd935: ot,
      __wbg_node_104a2ff8d6ea03a2: _t,
      __wbg_require_cca90b1a94a0255b: at,
      __wbg_msCrypto_eb05e62b530a1508: st,
      __wbg_log_5bb5f88f245d7762: ct,
      __wbg_log_1746d5c75ec89963: it,
      __wbg_get_bd8e338fbd5f5cc8: ut,
      __wbg_length_cd7af8117672b8b8: gt,
      __wbg_new_16b304a2cfa7ff4a: ft,
      __wbg_newnoargs_e258087cd0daa0ea: dt,
      __wbg_next_40fc327bfc8770e6: lt,
      __wbg_next_196c84450b364254: bt,
      __wbg_done_298b57d23c0fc80c: wt,
      __wbg_value_d93c65011f51a456: pt,
      __wbg_iterator_2cee6dadfd956dfa: ht,
      __wbg_get_e3c254076557e348: mt,
      __wbg_call_27c0f87801dedf93: yt,
      __wbg_new_72fb9a18b5ae2624: vt,
      __wbg_length_dee433d4c85c9387: St,
      __wbg_set_d4638f722068f043: kt,
      __wbg_from_89e3fc3ba5e6fb48: jt,
      __wbg_isArray_2ab64d95e09ea0ae: At,
      __wbg_push_a5b05aedc7234f9f: Ct,
      __wbg_unshift_e22df4b34bcf5070: Ot,
      __wbg_instanceof_ArrayBuffer_836825be07d4c9d2: xt,
      __wbg_new_28c511d9baebfa89: Rt,
      __wbg_call_b3ca7c6051f9bec1: Tt,
      __wbg_instanceof_Date_f65cf97fb83fc369: Et,
      __wbg_getTime_2bc4375165f02d15: It,
      __wbg_new_cf3ec55744a78578: Dt,
      __wbg_instanceof_Object_71ca3c0a59266746: Mt,
      __wbg_assign_496d2d14fecafbcf: Ht,
      __wbg_defineProperty_cc00e2de8a0f5141: Pt,
      __wbg_entries_95cc2c823b285a09: $t,
      __wbg_freeze_cc6bc19f75299986: Ut,
      __wbg_keys_91e412b4b222659f: Bt,
      __wbg_values_9c75e6e2bfbdb70d: zt,
      __wbg_new_dd6a5dd7b538af21: Ft,
      __wbg_apply_0a5aa603881e6d79: Vt,
      __wbg_deleteProperty_13e721a56f19e842: Lt,
      __wbg_ownKeys_658942b7f28d1fe9: Nt,
      __wbg_set_1f9b04f170055d33: Wt,
      __wbg_buffer_12d079cc21e14bdb: Jt,
      __wbg_concat_3de229fe4fe90fea: qt,
      __wbg_slice_52fb626ffdc8da8f: Kt,
      __wbg_for_27c67e2dbdce22f6: Xt,
      __wbg_toString_7df3c77999517c20: Yt,
      __wbg_self_ce0dbfc45cf2f5be: Gt,
      __wbg_window_c6fb939a7f436783: Qt,
      __wbg_globalThis_d1e6af4856ba331b: Zt,
      __wbg_global_207b558942527489: en,
      __wbg_newwithbyteoffsetandlength_aa4a17c33a06e5cb: tn,
      __wbg_new_63b92bc8671ed464: nn,
      __wbg_set_a47bac70306a19a7: rn,
      __wbg_length_c20a40f15020d68a: on,
      __wbg_instanceof_Uint8Array_2b3bbecd033d19f6: _n,
      __wbg_newwithlength_e9b4878cebadb3d3: an,
      __wbg_subarray_a1f73cd4b5b42fe1: sn,
      __wbindgen_debug_string: cn,
      __wbindgen_throw: un,
      __wbindgen_memory: gn
    }
  }, Pn), er = f.memory, tr = f.__wbg_syncstate_free, nr = f.syncstate_sharedHeads, rr = f.syncstate_lastSentHeads, or = f.syncstate_set_lastSentHeads, _r = f.syncstate_set_sentHashes, ar = f.syncstate_clone, sr = f.__wbg_automerge_free, cr = f.automerge_new, ir = f.automerge_clone, ur = f.automerge_fork, gr = f.automerge_pendingOps, fr = f.automerge_commit, dr = f.automerge_merge, lr = f.automerge_rollback, br = f.automerge_keys, wr = f.automerge_text, pr = f.automerge_spans, hr = f.automerge_splice, mr = f.automerge_updateText, yr = f.automerge_updateSpans, vr = f.automerge_push, Sr = f.automerge_pushObject, kr = f.automerge_insert, jr = f.automerge_splitBlock, Ar = f.automerge_joinBlock, Cr = f.automerge_updateBlock, Or = f.automerge_getBlock, xr = f.automerge_insertObject, Rr = f.automerge_put, Tr = f.automerge_putObject, Er = f.automerge_increment, Ir = f.automerge_get, Dr = f.automerge_getWithType, Mr = f.automerge_objInfo, Hr = f.automerge_getAll, Pr = f.automerge_enableFreeze, $r = f.automerge_registerDatatype, Ur = f.automerge_applyPatches, Br = f.automerge_applyAndReturnPatches, zr = f.automerge_diffIncremental, Fr = f.automerge_updateDiffCursor, Vr = f.automerge_resetDiffCursor, Lr = f.automerge_diff, Nr = f.automerge_isolate, Wr = f.automerge_integrate, Jr = f.automerge_length, qr = f.automerge_delete, Kr = f.automerge_save, Xr = f.automerge_saveIncremental, Yr = f.automerge_saveSince, Gr = f.automerge_saveNoCompress, Qr = f.automerge_saveAndVerify, Zr = f.automerge_loadIncremental, eo = f.automerge_applyChanges, to = f.automerge_getChanges, no = f.automerge_getChangeByHash, ro = f.automerge_getDecodedChangeByHash, oo = f.automerge_getChangesAdded, _o = f.automerge_getHeads, ao = f.automerge_getActorId, so = f.automerge_getLastLocalChange, co = f.automerge_dump, io = f.automerge_getMissingDeps, uo = f.automerge_receiveSyncMessage, go = f.automerge_generateSyncMessage, fo = f.automerge_toJS, lo = f.automerge_materialize, bo = f.automerge_getCursor, wo = f.automerge_getCursorPosition, po = f.automerge_emptyChange, ho = f.automerge_mark, mo = f.automerge_unmark, yo = f.automerge_marks, vo = f.automerge_marksAt, So = f.automerge_hasOurChanges, ko = f.automerge_topoHistoryTraversal, jo = f.automerge_stats, Ao = f.create, Co = f.load, Oo = f.encodeChange, xo = f.decodeChange, Ro = f.initSyncState, To = f.importSyncState, Eo = f.exportSyncState, Io = f.encodeSyncMessage, Do = f.decodeSyncMessage, Mo = f.encodeSyncState, Ho = f.decodeSyncState, Po = f.__wbindgen_malloc, $o = f.__wbindgen_realloc, Uo = f.__wbindgen_add_to_stack_pointer, Bo = f.__wbindgen_free, zo = f.__wbindgen_exn_store, Fo = Object.freeze(Object.defineProperty({
    __proto__: null,
    __wbg_automerge_free: sr,
    __wbg_syncstate_free: tr,
    __wbindgen_add_to_stack_pointer: Uo,
    __wbindgen_exn_store: zo,
    __wbindgen_free: Bo,
    __wbindgen_malloc: Po,
    __wbindgen_realloc: $o,
    automerge_applyAndReturnPatches: Br,
    automerge_applyChanges: eo,
    automerge_applyPatches: Ur,
    automerge_clone: ir,
    automerge_commit: fr,
    automerge_delete: qr,
    automerge_diff: Lr,
    automerge_diffIncremental: zr,
    automerge_dump: co,
    automerge_emptyChange: po,
    automerge_enableFreeze: Pr,
    automerge_fork: ur,
    automerge_generateSyncMessage: go,
    automerge_get: Ir,
    automerge_getActorId: ao,
    automerge_getAll: Hr,
    automerge_getBlock: Or,
    automerge_getChangeByHash: no,
    automerge_getChanges: to,
    automerge_getChangesAdded: oo,
    automerge_getCursor: bo,
    automerge_getCursorPosition: wo,
    automerge_getDecodedChangeByHash: ro,
    automerge_getHeads: _o,
    automerge_getLastLocalChange: so,
    automerge_getMissingDeps: io,
    automerge_getWithType: Dr,
    automerge_hasOurChanges: So,
    automerge_increment: Er,
    automerge_insert: kr,
    automerge_insertObject: xr,
    automerge_integrate: Wr,
    automerge_isolate: Nr,
    automerge_joinBlock: Ar,
    automerge_keys: br,
    automerge_length: Jr,
    automerge_loadIncremental: Zr,
    automerge_mark: ho,
    automerge_marks: yo,
    automerge_marksAt: vo,
    automerge_materialize: lo,
    automerge_merge: dr,
    automerge_new: cr,
    automerge_objInfo: Mr,
    automerge_pendingOps: gr,
    automerge_push: vr,
    automerge_pushObject: Sr,
    automerge_put: Rr,
    automerge_putObject: Tr,
    automerge_receiveSyncMessage: uo,
    automerge_registerDatatype: $r,
    automerge_resetDiffCursor: Vr,
    automerge_rollback: lr,
    automerge_save: Kr,
    automerge_saveAndVerify: Qr,
    automerge_saveIncremental: Xr,
    automerge_saveNoCompress: Gr,
    automerge_saveSince: Yr,
    automerge_spans: pr,
    automerge_splice: hr,
    automerge_splitBlock: jr,
    automerge_stats: jo,
    automerge_text: wr,
    automerge_toJS: fo,
    automerge_topoHistoryTraversal: ko,
    automerge_unmark: mo,
    automerge_updateBlock: Cr,
    automerge_updateDiffCursor: Fr,
    automerge_updateSpans: yr,
    automerge_updateText: mr,
    create: Ao,
    decodeChange: xo,
    decodeSyncMessage: Do,
    decodeSyncState: Ho,
    encodeChange: Oo,
    encodeSyncMessage: Io,
    encodeSyncState: Mo,
    exportSyncState: Eo,
    importSyncState: To,
    initSyncState: Ro,
    load: Co,
    memory: er,
    syncstate_clone: ar,
    syncstate_lastSentHeads: rr,
    syncstate_set_lastSentHeads: or,
    syncstate_set_sentHashes: _r,
    syncstate_sharedHeads: nr
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  Re(Fo);
  const Vo = Object.freeze(Object.defineProperty({
    __proto__: null,
    Automerge: R,
    SyncState: O,
    TextRepresentation: Zn,
    __wbg_String_91fba7ded13ba54c: Ye,
    __wbg_apply_0a5aa603881e6d79: Vt,
    __wbg_assign_496d2d14fecafbcf: Ht,
    __wbg_buffer_12d079cc21e14bdb: Jt,
    __wbg_call_27c0f87801dedf93: yt,
    __wbg_call_b3ca7c6051f9bec1: Tt,
    __wbg_concat_3de229fe4fe90fea: qt,
    __wbg_crypto_1d1f22824a6a080c: nt,
    __wbg_defineProperty_cc00e2de8a0f5141: Pt,
    __wbg_deleteProperty_13e721a56f19e842: Lt,
    __wbg_done_298b57d23c0fc80c: wt,
    __wbg_entries_95cc2c823b285a09: $t,
    __wbg_error_f851667af71bcfc6: Ke,
    __wbg_for_27c67e2dbdce22f6: Xt,
    __wbg_freeze_cc6bc19f75299986: Ut,
    __wbg_from_89e3fc3ba5e6fb48: jt,
    __wbg_getRandomValues_3aa56aa6edec874c: et,
    __wbg_getTime_2bc4375165f02d15: It,
    __wbg_get_bd8e338fbd5f5cc8: ut,
    __wbg_get_e3c254076557e348: mt,
    __wbg_globalThis_d1e6af4856ba331b: Zt,
    __wbg_global_207b558942527489: en,
    __wbg_instanceof_ArrayBuffer_836825be07d4c9d2: xt,
    __wbg_instanceof_Date_f65cf97fb83fc369: Et,
    __wbg_instanceof_Object_71ca3c0a59266746: Mt,
    __wbg_instanceof_Uint8Array_2b3bbecd033d19f6: _n,
    __wbg_isArray_2ab64d95e09ea0ae: At,
    __wbg_iterator_2cee6dadfd956dfa: ht,
    __wbg_keys_91e412b4b222659f: Bt,
    __wbg_length_c20a40f15020d68a: on,
    __wbg_length_cd7af8117672b8b8: gt,
    __wbg_length_dee433d4c85c9387: St,
    __wbg_log_1746d5c75ec89963: it,
    __wbg_log_5bb5f88f245d7762: ct,
    __wbg_msCrypto_eb05e62b530a1508: st,
    __wbg_new_16b304a2cfa7ff4a: ft,
    __wbg_new_28c511d9baebfa89: Rt,
    __wbg_new_63b92bc8671ed464: nn,
    __wbg_new_72fb9a18b5ae2624: vt,
    __wbg_new_abda76e883ba8a5f: Je,
    __wbg_new_cf3ec55744a78578: Dt,
    __wbg_new_dd6a5dd7b538af21: Ft,
    __wbg_newnoargs_e258087cd0daa0ea: dt,
    __wbg_newwithbyteoffsetandlength_aa4a17c33a06e5cb: tn,
    __wbg_newwithlength_e9b4878cebadb3d3: an,
    __wbg_next_196c84450b364254: bt,
    __wbg_next_40fc327bfc8770e6: lt,
    __wbg_node_104a2ff8d6ea03a2: _t,
    __wbg_ownKeys_658942b7f28d1fe9: Nt,
    __wbg_process_4a72847cc503995b: rt,
    __wbg_push_a5b05aedc7234f9f: Ct,
    __wbg_randomFillSync_5c9c955aa56b6049: tt,
    __wbg_require_cca90b1a94a0255b: at,
    __wbg_self_ce0dbfc45cf2f5be: Gt,
    __wbg_set_1f9b04f170055d33: Wt,
    __wbg_set_20cbc34131e76824: Ze,
    __wbg_set_a47bac70306a19a7: rn,
    __wbg_set_d4638f722068f043: kt,
    __wbg_set_wasm: Re,
    __wbg_slice_52fb626ffdc8da8f: Kt,
    __wbg_stack_658279fe44541cf6: qe,
    __wbg_subarray_a1f73cd4b5b42fe1: sn,
    __wbg_toString_7df3c77999517c20: Yt,
    __wbg_unshift_e22df4b34bcf5070: Ot,
    __wbg_value_d93c65011f51a456: pt,
    __wbg_values_9c75e6e2bfbdb70d: zt,
    __wbg_versions_f686565e586dd935: ot,
    __wbg_window_c6fb939a7f436783: Qt,
    __wbindgen_bigint_from_i64: Ge,
    __wbindgen_bigint_from_u64: Qe,
    __wbindgen_boolean_get: Be,
    __wbindgen_debug_string: cn,
    __wbindgen_error_new: De,
    __wbindgen_is_array: Ne,
    __wbindgen_is_function: Ve,
    __wbindgen_is_null: ze,
    __wbindgen_is_object: Le,
    __wbindgen_is_string: Fe,
    __wbindgen_is_undefined: Ue,
    __wbindgen_json_serialize: We,
    __wbindgen_jsval_loose_eq: Xe,
    __wbindgen_memory: gn,
    __wbindgen_number_get: $e,
    __wbindgen_number_new: He,
    __wbindgen_object_clone_ref: Pe,
    __wbindgen_object_drop_ref: Ee,
    __wbindgen_string_get: Ie,
    __wbindgen_string_new: Me,
    __wbindgen_throw: un,
    create: Vn,
    decodeChange: Wn,
    decodeSyncMessage: Yn,
    decodeSyncState: Qn,
    encodeChange: Nn,
    encodeSyncMessage: Xn,
    encodeSyncState: Gn,
    exportSyncState: Kn,
    importSyncState: qn,
    initSyncState: Jn,
    load: Ln
  }, Symbol.toStringTag, {
    value: "Module"
  }));
  xn(Vo);
})();
export {
  __tla,
  ke as a,
  qo as b,
  Jo as c,
  Go as d,
  Ko as e,
  c_ as f,
  o_ as g,
  __ as h,
  a_ as i,
  Xo as j,
  Zo as k,
  Mn as l,
  Yo as m,
  Qo as n,
  n_ as o,
  No as p,
  e_ as q,
  r_ as r,
  Lo as s,
  t_ as t,
  s_ as u,
  Wo as v,
  i_ as w
};
